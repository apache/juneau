/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.juneau.examples.rest;

import static org.apache.juneau.commons.utils.CollectionUtils.*;
import static org.apache.juneau.commons.utils.ThrowableUtils.*;
import static org.apache.juneau.examples.rest.TestUtils.*;
import static org.junit.runners.MethodSorters.*;

import java.io.*;
import java.util.*;
import java.util.function.*;

import org.apache.juneau.*;
import org.apache.juneau.csv.*;
import org.apache.juneau.html.*;
import org.apache.juneau.json.*;
import org.apache.juneau.msgpack.*;
import org.apache.juneau.parser.*;
import org.apache.juneau.plaintext.*;
import org.apache.juneau.rest.client.*;
import org.apache.juneau.serializer.*;
import org.apache.juneau.uon.*;
import org.apache.juneau.urlencoding.*;
import org.apache.juneau.xml.*;
import org.junit.*;

@FixMethodOrder(NAME_ASCENDING)
@Ignore("Base class for parameterized tests - not meant to be run directly")
@SuppressWarnings({
	"java:S3577" // Class name ends with "TestBase" to indicate it's a base class, not a test class itself
})
public class ContentComboTestBase extends RestTestcase {

	// Reusable RestClients keyed by label that live for the duration of a testcase class.
	private static Map<String,RestClient> clients = map();

	protected RestClient getClient(MediaType mediaType) {
		var mt = mediaType.toString();
		return switch (mt) {
			case "text/csv" -> getClient(mt, CsvSerializer.DEFAULT, CsvParser.DEFAULT);
			case "text/html" -> getClient(mt, HtmlSerializer.DEFAULT, HtmlParser.DEFAULT);
			case "application/json" -> getClient(mt, JsonSerializer.DEFAULT, JsonParser.DEFAULT);
			case "octal/msgpack" -> getClient(mt, MsgPackSerializer.DEFAULT, MsgPackParser.DEFAULT, x -> x.queryData("plainText", "true").queryData("juneauSerializerOptions", "(binaryFormat=BASE64)"));
			case "text/plain" -> getClient(mt, PlainTextSerializer.DEFAULT, PlainTextParser.DEFAULT);
			case "text/uon" -> getClient(mt, UonSerializer.DEFAULT, UonParser.DEFAULT);
			case "application/x-www-form-urlencoded" -> getClient(mt, UrlEncodingSerializer.DEFAULT, UrlEncodingParser.DEFAULT);
			case "text/xml" -> getClient(mt, XmlSerializer.DEFAULT, XmlParser.DEFAULT);
			default -> throw rex("Client for mediaType ''{0}'' not found", mt);
		};
	}

	protected RestClient getClient(String label, Serializer serializer, Parser parser, Consumer<RestClient.Builder>...postApply) {
		if (! clients.containsKey(label)) {
			var b = SamplesMicroservice.client(serializer, parser);
			for (var c : postApply)
				c.accept(b);
			clients.put(label, b.build());
		}
		return clients.get(label);
	}

	@AfterClass
	public static void tearDown() {
		clients.values().forEach(rc -> {
			try {
				rc.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		clients.clear();
	}

	public static class ComboInput {
		public final String name, url;
		public final MediaType mediaType;
		public final String[] expectedResults;

		public ComboInput(String name, String url, MediaType mediaType, String...expectedResults) {
			this.name = name;
			this.url = url;
			this.mediaType = mediaType;
			this.expectedResults = expectedResults;
		}
	}

	private final ComboInput comboInput;

	public ContentComboTestBase(ComboInput comboInput) {
		this.comboInput = comboInput;
	}

	@Test
	public void doTest() throws Exception {
		var rc = getClient(comboInput.mediaType);
		var s = rc.get(comboInput.url).run().getContent().asString();
		assertContains(s, comboInput.expectedResults);
	}
}