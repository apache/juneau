/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the License); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.juneau.rest;

import static org.apache.juneau.commons.reflect.AnnotationTraversal.*;
import static org.apache.juneau.rest.RestServerConstants.PROPERTY_allowedParserOptions;
import static org.apache.juneau.rest.RestServerConstants.PROPERTY_allowedSerializerOptions;
import static org.junit.jupiter.api.Assertions.*;

import org.apache.juneau.*;
import org.apache.juneau.commons.reflect.*;
import org.apache.juneau.rest.annotation.*;
import org.junit.jupiter.api.*;

/**
 * Tests for {@link RestOpContext#getRestOpAnnotations()}, {@link RestOpContext#findRestOpAnnotations()}, and {@code noInherit} resolution.
 */
class RestOpContext_Test extends TestBase {

	public static class Parent {
		@RestOp(path = "/p")
		public Object op() {
			return null;
		}
	}

	public static class Child extends Parent {
		@Override
		@RestGet(path = "/c")
		public Object op() {
			return null;
		}
	}

	@Rest
	public static class Solo {
		@RestGet
		public void only() {}
	}

	@Test
	void a01_getRestOpAnnotations_childToParent_order() throws Exception {
		var rc = RestContext.create(Child.class, null, null).init(() -> new Child()).build();
		var roc = RestOpContext.create(Child.class.getMethod("op"), rc).build();
		var list = roc.getRestOpAnnotations();
		
		assertEquals(2, list.size());
		assertEquals(RestGet.class, list.get(0).inner().annotationType());
		assertEquals(RestOp.class, list.get(1).inner().annotationType());
	}

	@Test
	void a02_restGet_not_found_by_typed_find_restOp() throws Exception {
		var mi = MethodInfo.of(Solo.class.getMethod("only")).accessible();
		var typed = AnnotationProvider.INSTANCE.find(RestOp.class, mi, SELF, MATCHING_METHODS);
		assertTrue(typed.isEmpty());
	}

	@Test
	void a03_restGet_found_by_group_on_rest_op_context() throws Exception {
		var rc = RestContext.create(Solo.class, null, null).init(() -> new Solo()).build();
		var roc = RestOpContext.create(Solo.class.getMethod("only"), rc).build();
		var list = roc.getRestOpAnnotations();
		
		assertEquals(1, list.size());
		assertEquals(RestGet.class, list.get(0).inner().annotationType());
	}

	@Rest
	public static class NoInheritB01Base {
		@RestOp(noInherit = "allowedParserOptions")
		public void m() {}
	}

	@Rest
	public static class NoInheritB01Derived extends NoInheritB01Base {
		@Override
		@RestGet(path = "/x")
		public void m() {}
	}

	@Test
	void b01_findNoInherit_skips_empty_child_uses_parent() throws Exception {
		var rc = RestContext.create(NoInheritB01Derived.class, null, null).init(NoInheritB01Derived::new).build();
		var roc = RestOpContext.create(NoInheritB01Derived.class.getMethod("m"), rc).build();
		
		assertTrue(roc.getNoInheritKeys().contains("allowedParserOptions"));
	}

	@Rest
	public static class NoInheritB02Base {
		@RestOp(noInherit = "allowedParserOptions")
		public void m() {}
	}

	@Rest
	public static class NoInheritB02Derived extends NoInheritB02Base {
		@Override
		@RestGet(noInherit = "allowedSerializerOptions", path = "/x")
		public void m() {}
	}

	@Test
	void b02_findNoInherit_aggregates_child_and_parent() throws Exception {
		var rc = RestContext.create(NoInheritB02Derived.class, null, null).init(NoInheritB02Derived::new).build();
		var roc = RestOpContext.create(NoInheritB02Derived.class.getMethod("m"), rc).build();
		var keys = roc.getNoInheritKeys();
		
		assertEquals(2, keys.size());
		assertTrue(keys.contains("allowedSerializerOptions"));
		assertTrue(keys.contains("allowedParserOptions"));
	}

	@Test
	void b03_findNoInherit_empty_when_unset() throws Exception {
		var rc = RestContext.create(Solo.class, null, null).init(() -> new Solo()).build();
		var roc = RestOpContext.create(Solo.class.getMethod("only"), rc).build();
		assertTrue(roc.getNoInheritKeys().isEmpty());
	}

	@Rest(allowedParserOptions = "fooKey")
	public static class AllowedParserMerge {
		@RestGet(allowedParserOptions = "barKey", path = "/x")
		public void m() {}
	}

	@Rest
	public static class AllowedParserHierarchyParent {
		@RestOp(allowedParserOptions = "parentKey", path = "/x")
		public void m() {}
	}

	@Rest
	public static class AllowedParserHierarchyChild extends AllowedParserHierarchyParent {
		@Override
		@RestGet(allowedParserOptions = "childKey", path = "/x")
		public void m() {}
	}

	@Test
	void c01_getAllowedParserOptionsKeys_merges_resource_and_method() throws Exception {
		var rc = RestContext.create(AllowedParserMerge.class, null, null).init(AllowedParserMerge::new).build();
		var roc = RestOpContext.create(AllowedParserMerge.class.getMethod("m"), rc).build();
		var keys = roc.getAllowedParserOptions();
		
		assertTrue(keys.contains("fooKey"));
		assertTrue(keys.contains("barKey"));
	}

	@Rest(allowedParserOptions = "fooKey")
	public static class AllowedParserNoInherit {
		@RestGet(noInherit = PROPERTY_allowedParserOptions, allowedParserOptions = "barKey", path = "/x")
		public void m() {}
	}

	@Test
	void c02_getAllowedParserOptionsKeys_noInherit_skips_resource_keys() throws Exception {
		var rc = RestContext.create(AllowedParserNoInherit.class, null, null).init(AllowedParserNoInherit::new).build();
		var roc = RestOpContext.create(AllowedParserNoInherit.class.getMethod("m"), rc).build();
		var keys = roc.getAllowedParserOptions();
		
		assertFalse(keys.contains("fooKey"));
		assertTrue(keys.contains("barKey"));
	}

	@Test
	void c03_getAllowedParserOptionsKeys_aggregates_override_chain() throws Exception {
		var rc = RestContext.create(AllowedParserHierarchyChild.class, null, null).init(AllowedParserHierarchyChild::new).build();
		var roc = RestOpContext.create(AllowedParserHierarchyChild.class.getMethod("m"), rc).build();
		var keys = roc.getAllowedParserOptions();
		
		assertTrue(keys.contains("childKey"));
		assertTrue(keys.contains("parentKey"));
	}

	@Rest(allowedSerializerOptions = "serFooKey")
	public static class AllowedSerializerMerge {
		@RestGet(allowedSerializerOptions = "serBarKey", path = "/x")
		public void m() {}
	}

	@Rest
	public static class AllowedSerializerHierarchyParent {
		@RestOp(allowedSerializerOptions = "serParentKey", path = "/x")
		public void m() {}
	}

	@Rest
	public static class AllowedSerializerHierarchyChild extends AllowedSerializerHierarchyParent {
		@Override
		@RestGet(allowedSerializerOptions = "serChildKey", path = "/x")
		public void m() {}
	}

	@Rest(allowedSerializerOptions = "serFooKey")
	public static class AllowedSerializerNoInherit {
		@RestGet(noInherit = PROPERTY_allowedSerializerOptions, allowedSerializerOptions = "serBarKey", path = "/x")
		public void m() {}
	}

	@Test
	void d01_getAllowedSerializerOptionsKeys_merges_resource_and_method() throws Exception {
		var rc = RestContext.create(AllowedSerializerMerge.class, null, null).init(AllowedSerializerMerge::new).build();
		var roc = RestOpContext.create(AllowedSerializerMerge.class.getMethod("m"), rc).build();
		var keys = roc.getAllowedSerializerOptions();
		
		assertTrue(keys.contains("serFooKey"));
		assertTrue(keys.contains("serBarKey"));
	}

	@Test
	void d02_getAllowedSerializerOptionsKeys_noInherit_skips_resource_keys() throws Exception {
		var rc = RestContext.create(AllowedSerializerNoInherit.class, null, null).init(AllowedSerializerNoInherit::new).build();
		var roc = RestOpContext.create(AllowedSerializerNoInherit.class.getMethod("m"), rc).build();
		var keys = roc.getAllowedSerializerOptions();
		
		assertFalse(keys.contains("serFooKey"));
		assertTrue(keys.contains("serBarKey"));
	}

	@Test
	void d03_getAllowedSerializerOptionsKeys_aggregates_override_chain() throws Exception {
		var rc = RestContext.create(AllowedSerializerHierarchyChild.class, null, null).init(AllowedSerializerHierarchyChild::new).build();
		var roc = RestOpContext.create(AllowedSerializerHierarchyChild.class.getMethod("m"), rc).build();
		var keys = roc.getAllowedSerializerOptions();
		
		assertTrue(keys.contains("serChildKey"));
		assertTrue(keys.contains("serParentKey"));
	}
}
