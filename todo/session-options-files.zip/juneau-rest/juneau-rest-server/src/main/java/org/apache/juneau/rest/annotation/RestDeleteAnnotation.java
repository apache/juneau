/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.juneau.rest.annotation;

import static org.apache.juneau.commons.utils.CollectionUtils.*;

import java.lang.annotation.*;
import java.nio.charset.*;

import org.apache.juneau.*;
import org.apache.juneau.encoders.*;
import org.apache.juneau.http.*;
import org.apache.juneau.commons.annotation.*;
import org.apache.juneau.commons.reflect.*;
import org.apache.juneau.rest.*;
import org.apache.juneau.rest.guard.*;
import org.apache.juneau.rest.httppart.*;
import org.apache.juneau.rest.matcher.*;
import org.apache.juneau.svl.*;

/**
 * Utility classes and methods for the {@link RestDelete @RestDelete} annotation.
 *
 * <h5 class='section'>See Also:</h5><ul>
 * 	<li class='link'><a class="doclink" href="https://juneau.apache.org/docs/topics/RestOpAnnotatedMethodBasics">@RestOp-Annotated Method Basics</a>
 * </ul>
 */
public class RestDeleteAnnotation {

	/**
	 * Private constructor to prevent instantiation.
	 */
	private RestDeleteAnnotation() {
		// Utility class - prevent instantiation
	}

	/**
	 * Builder class.
	 *
	 * <h5 class='section'>See Also:</h5><ul>
	 * 	<li class='jm'>{@link org.apache.juneau.BeanContext.Builder#annotations(Annotation...)}
	 * </ul>
	 */
	@SuppressWarnings({
		"unchecked" // Type erasure requires cast for Builder inheritance
	})
	public static class Builder extends AppliedAnnotationObject.BuilderM {

		private String[] description = {};
		private Class<? extends RestGuard>[] guards = new Class[0];
		private Class<? extends RestMatcher>[] matchers = new Class[0];
		private Class<? extends Encoder>[] encoders = new Class[0];
		private OpSwagger swagger = OpSwaggerAnnotation.DEFAULT;
		private String clientVersion = "";
		private String debug = "";
		private String defaultAccept = "";
		private String defaultCharset = "";
		private String rolesDeclared = "";
		private String roleGuard = "";
		private String summary = "";
		private String value = "";
		private String[] defaultRequestQueryData = {};
		private String[] defaultRequestAttributes = {};
		private String[] defaultRequestHeaders = {};
		private String[] defaultResponseHeaders = {};
		private String[] allowedParserOptions = {};
		private String[] allowedSerializerOptions = {};
		private String[] noInherit = {};
		private String[] path = {};

		/**
		 * Constructor.
		 */
		protected Builder() {
			super(RestDelete.class);
		}

		/**
		 * Instantiates a new {@link RestDelete @RestDelete} object initialized with this builder.
		 *
		 * @return A new {@link RestDelete @RestDelete} object.
		 */
		public RestDelete build() {
			return new Object(this);
		}

		/**
		 * Sets the description property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder description(String...value) {
			description = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#clientVersion()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder clientVersion(String value) {
			clientVersion = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#debug()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder debug(String value) {
			debug = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#defaultAccept()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder defaultAccept(String value) {
			defaultAccept = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#defaultCharset()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder defaultCharset(String value) {
			defaultCharset = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#defaultRequestAttributes()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder defaultRequestAttributes(String...value) {
			defaultRequestAttributes = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#defaultRequestHeaders()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder defaultRequestHeaders(String...value) {
			defaultRequestHeaders = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#defaultRequestQueryData()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder defaultRequestQueryData(String...value) {
			defaultRequestQueryData = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#defaultResponseHeaders()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder defaultResponseHeaders(String...value) {
			defaultResponseHeaders = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#encoders()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		@SafeVarargs
		public final Builder encoders(Class<? extends Encoder>...value) {
			encoders = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#guards()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		@SafeVarargs
		public final Builder guards(Class<? extends RestGuard>...value) {
			guards = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#matchers()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		@SafeVarargs
		public final Builder matchers(Class<? extends RestMatcher>...value) {
			matchers = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#path()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder path(String...value) {
			path = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#allowedParserOptions()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder allowedParserOptions(String...value) {
			allowedParserOptions = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#allowedSerializerOptions()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder allowedSerializerOptions(String...value) {
			allowedSerializerOptions = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#noInherit()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder noInherit(String...value) {
			noInherit = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#roleGuard()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder roleGuard(String value) {
			roleGuard = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#rolesDeclared()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder rolesDeclared(String value) {
			rolesDeclared = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#summary()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder summary(String value) {
			summary = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#swagger()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder swagger(OpSwagger value) {
			swagger = value;
			return this;
		}

		/**
		 * Sets the {@link RestDelete#value()} property on this annotation.
		 *
		 * @param value The new value for this property.
		 * @return This object.
		 */
		public Builder value(String value) {
			this.value = value;
			return this;
		}

		@Override /* Overridden from AppliedAnnotationObject.Builder */
		public Builder on(String...value) {
			super.on(value);
			return this;
		}

		@Override /* Overridden from AppliedAnnotationObject.BuilderM */
		public Builder on(java.lang.reflect.Method...value) {
			super.on(value);
			return this;
		}

		@Override /* Overridden from AppliedAnnotationObject.BuilderM */
		public Builder on(MethodInfo...value) {
			super.on(value);
			return this;
		}

	}

	/**
	 * Applies {@link RestDelete} annotations to a {@link org.apache.juneau.rest.RestOpContext.Builder}.
	 */
	public static class RestOpContextApply extends AnnotationApplier<RestDelete,RestOpContext.Builder> {

		/**
		 * Constructor.
		 *
		 * @param vr The resolver for resolving values in annotations.
		 */
		public RestOpContextApply(VarResolverSession vr) {
			super(RestDelete.class, RestOpContext.Builder.class, vr);
		}

		@Override
		public void apply(AnnotationInfo<RestDelete> ai, RestOpContext.Builder b) {
			RestDelete a = ai.inner();

			b.httpMethod("delete");

			classes(a.encoders()).ifPresent(x -> b.encoders().set(x));
			stream(a.defaultRequestHeaders()).map(HttpHeaders::stringHeader).forEach(x -> b.defaultRequestHeaders().setDefault(x));
			stream(a.defaultResponseHeaders()).map(HttpHeaders::stringHeader).forEach(x -> b.defaultResponseHeaders().setDefault(x));
			stream(a.defaultRequestAttributes()).map(BasicNamedAttribute::ofPair).forEach(x -> b.defaultRequestAttributes().add(x));
			stream(a.defaultRequestQueryData()).map(HttpParts::basicPart).forEach(x -> b.defaultRequestQueryData().setDefault(x));
			string(a.defaultAccept()).map(HttpHeaders::accept).ifPresent(x -> b.defaultRequestHeaders().setDefault(x));
			b.guards().append(a.guards());
			b.matchers().append(a.matchers());
			string(a.clientVersion()).ifPresent(b::clientVersion);
			string(a.defaultCharset()).map(Charset::forName).ifPresent(b::defaultCharset);
			stream(a.path()).forEach(b::path);
			string(a.value()).ifPresent(b::path);
			cdl(a.rolesDeclared()).forEach(b::rolesDeclared);
			string(a.roleGuard()).ifPresent(b::roleGuard);
			string(a.debug()).map(Enablement::fromString).ifPresent(b::debug);
		}

	}

	private static class Object extends AppliedAnnotationObject implements RestDelete {

		private final String[] description;
		private final Class<? extends RestGuard>[] guards;
		private final Class<? extends RestMatcher>[] matchers;
		private final Class<? extends Encoder>[] encoders;
		private final OpSwagger swagger;
		private final String clientVersion;
		private final String debug;
		private final String defaultAccept;
		private final String defaultCharset;
		private final String rolesDeclared;
		private final String roleGuard;
		private final String summary;
		private final String value;
		private final String[] defaultRequestQueryData;
		private final String[] defaultRequestAttributes;
		private final String[] defaultRequestHeaders;
		private final String[] defaultResponseHeaders;
		private final String[] allowedParserOptions;
		private final String[] allowedSerializerOptions;
		private final String[] noInherit;
		private final String[] path;

		Object(RestDeleteAnnotation.Builder b) {
			super(b);
			description = copyOf(b.description);
			clientVersion = b.clientVersion;
			debug = b.debug;
			defaultAccept = b.defaultAccept;
			defaultCharset = b.defaultCharset;
			defaultRequestQueryData = copyOf(b.defaultRequestQueryData);
			defaultRequestAttributes = copyOf(b.defaultRequestAttributes);
			defaultRequestHeaders = copyOf(b.defaultRequestHeaders);
			defaultResponseHeaders = copyOf(b.defaultResponseHeaders);
			encoders = copyOf(b.encoders);
			guards = copyOf(b.guards);
			matchers = copyOf(b.matchers);
			allowedParserOptions = copyOf(b.allowedParserOptions);
			allowedSerializerOptions = copyOf(b.allowedSerializerOptions);
			noInherit = copyOf(b.noInherit);
			path = copyOf(b.path);
			roleGuard = b.roleGuard;
			rolesDeclared = b.rolesDeclared;
			summary = b.summary;
			swagger = b.swagger;
			value = b.value;
		}

		@Override /* Overridden from RestDelete */
		public String clientVersion() {
			return clientVersion;
		}

		@Override /* Overridden from RestDelete */
		public String debug() {
			return debug;
		}

		@Override /* Overridden from RestDelete */
		public String defaultAccept() {
			return defaultAccept;
		}

		@Override /* Overridden from RestDelete */
		public String defaultCharset() {
			return defaultCharset;
		}

		@Override /* Overridden from RestDelete */
		public String[] defaultRequestAttributes() {
			return defaultRequestAttributes;
		}

		@Override /* Overridden from RestDelete */
		public String[] defaultRequestHeaders() {
			return defaultRequestHeaders;
		}

		@Override /* Overridden from RestDelete */
		public String[] defaultRequestQueryData() {
			return defaultRequestQueryData;
		}

		@Override /* Overridden from RestDelete */
		public String[] defaultResponseHeaders() {
			return defaultResponseHeaders;
		}

		@Override /* Overridden from RestDelete */
		public Class<? extends Encoder>[] encoders() {
			return encoders;
		}

		@Override /* Overridden from RestDelete */
		public Class<? extends RestGuard>[] guards() {
			return guards;
		}

		@Override /* Overridden from RestDelete */
		public Class<? extends RestMatcher>[] matchers() {
			return matchers;
		}

		@Override /* Overridden from RestDelete */
		public String[] path() {
			return path;
		}

		@Override /* Overridden from RestDelete */
		public String[] allowedParserOptions() {
			return allowedParserOptions;
		}

		@Override /* Overridden from RestDelete */
		public String[] allowedSerializerOptions() {
			return allowedSerializerOptions;
		}

		@Override /* Overridden from RestDelete */
		public String[] noInherit() {
			return noInherit;
		}

		@Override /* Overridden from RestDelete */
		public String roleGuard() {
			return roleGuard;
		}

		@Override /* Overridden from RestDelete */
		public String rolesDeclared() {
			return rolesDeclared;
		}

		@Override /* Overridden from RestDelete */
		public String summary() {
			return summary;
		}

		@Override /* Overridden from RestDelete */
		public OpSwagger swagger() {
			return swagger;
		}

		@Override /* Overridden from RestDelete */
		public String value() {
			return value;
		}

		@Override /* Overridden from annotation */
		public String[] description() {
			return description;
		}
	}

	/** Default value */
	public static final RestDelete DEFAULT = create().build();

	/**
	 * Instantiates a new builder for this class.
	 *
	 * @return A new builder object.
	 */
	public static Builder create() {
		return new Builder();
	}
}