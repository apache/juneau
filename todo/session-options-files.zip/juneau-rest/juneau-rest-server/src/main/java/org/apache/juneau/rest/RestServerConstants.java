/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.juneau.rest;

/**
 * Static literals for {@code juneau-rest-server}: {@link org.apache.juneau.commons.settings.Settings} keys,
 * and other module-internal constants that should stay centralized.
 *
 * <p>
 * HTTP wire names shared with clients belong on {@link RestSharedConstants} instead.
 *
 * <h5 class='section'>See Also:</h5><ul>
 * 	<li class='jm'>{@link RestSharedConstants}
 * </ul>
 */
@SuppressWarnings({
	"java:S115", // SETTING_ + camelCase segments group settings keys; not strict UPPER_SNAKE_CASE
})
public final class RestServerConstants {

	private RestServerConstants() {}

	/**
	 * {@link org.apache.juneau.rest.annotation.Rest#allowedParserOptions()} attribute name for {@code noInherit} matching and related checks.
	 */
	public static final String PROPERTY_allowedParserOptions = "allowedParserOptions";

	/**
	 * {@link org.apache.juneau.rest.annotation.Rest#allowedSerializerOptions()} attribute name for {@code noInherit} matching and related checks.
	 */
	public static final String PROPERTY_allowedSerializerOptions = "allowedSerializerOptions";

	public static final String PROPERTY_noInherit = "noInherit";

}

