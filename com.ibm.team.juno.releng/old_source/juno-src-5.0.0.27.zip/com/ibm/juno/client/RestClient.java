package com.ibm.juno.client;

import java.net.*;
import java.util.*;

import com.ibm.juno.core.encoders.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.urlencoding.*;

/**
 * Utility class for interfacing with remote REST interfaces.
 *
 *
 * <h6 class='topic'>Features</h6>
 * <ul>
 * 	<li>Automatic negotiation of <code>charsets</code>.
 * 	<li>Automatic negotiation of <code>Content-Encoding</code> through {@link Encoder} class.
 * 	<li>Convert POJOs directly to HTTP request message bodies using {@link ISerializer} class.
 * 	<li>Convert HTTP response message bodies directly to POJOs using {@link IParser} class.
 * 	<li>Pluggable authenticator API using {@link Auth} class.
 * 	<li>Fluent interface.
 * 	<li>Designed for reuse.
 * 	<li>Thread safe.
 * </ul>
 *
 *
 * <h6 class='topic'>Additional Information</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#RestClient'>com.ibm.juno.client &gt; REST client API</a> for more information and code examples.
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestClient {

	private List<Auth> auths = new LinkedList<Auth>();
	Map<String,Object> headers = new TreeMap<String,Object>(String.CASE_INSENSITIVE_ORDER);
	ISerializer<?> serializer;
	IParser<?> parser;
	Encoder encoder;
	String accept, contentType;
	Proxy proxy = Proxy.NO_PROXY;		// The proxy server (if any)

	/**
	 * Create a new client with no serializer or parser.
	 */
	public RestClient() {}

	/**
	 * Create a new client with the specified serializer and parser instances.
	 *
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 */
	public RestClient(ISerializer<?> s, IParser<?> p) {
		setSerializer(s);
		setParser(p);
	}

	/**
	 * Create a new client with the specified serializer and parser classes.
	 *
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 * @throws InstantiationException If serializer or parser could not be instantiated.
	 */
	public RestClient(Class<? extends ISerializer<?>> s, Class<? extends IParser<?>> p) throws InstantiationException {
		setSerializer(s);
		setParser(p);
	}

	/**
	 * Associates an {@link Auth} with this client.
	 * <p>
	 * 	The purpose of authenticator is to add authentication headers to all REST requests created by this client.
	 *
	 * @param auth The authenticator to associate with this client.
	 * @return This object (for method chaining).
	 */
	public RestClient addAuthenticator(Auth auth) {
		this.auths.add(auth);
		return this;
	}

	/**
	 * Specifies a request header property to add to all requests created by this client.
	 *
	 * @param name The HTTP header name.
	 * @param value The HTTP header value.
	 * @return This object (for method chaining).
	 */
	public RestClient setHeader(String name, Object value) {
		this.headers.put(name, value);
		return this;
	}

	/**
	 * Sets the serializer used for serializing POJOs to the HTTP request message body.
	 *
	 * @param serializer The serializer.
	 * @return This object (for method chaining).
	 */
	public RestClient setSerializer(ISerializer<?> serializer) {
		this.serializer = serializer;
		contentType = serializer.getResponseContentType();
		if (contentType == null)
			contentType = serializer.getMediaTypes()[0];
		return this;
	}

	/**
	 * Same as {@link #setSerializer(ISerializer)}, except takes in a serializer class that
	 * 	will be instantiated through a no-arg constructor.
	 *
	 * @param c The serializer class.
	 * @return This object (for method chaining).
	 * @throws InstantiationException If serializer could not be instantiated.
	 */
	public RestClient setSerializer(Class<? extends ISerializer<?>> c) throws InstantiationException {
		try {
			return setSerializer(c.newInstance());
		} catch (IllegalAccessException e) {
			throw new InstantiationException(e.getLocalizedMessage());
		}
	}

	/**
	 * Sets the parser used for parsing POJOs from the HTTP response message body.
	 *
	 * @param parser The parser.
	 * @return This object (for method chaining).
	 */
	public RestClient setParser(IParser<?> parser) {
		this.parser = parser;
		this.accept = parser.getMediaTypes()[0];
		return this;
	}

	/**
	 * Same as {@link #setParser(IParser)}, except takes in a parser class that
	 * 	will be instantiated through a no-arg constructor.
	 *
	 * @param c The parser class.
	 * @return This object (for method chaining).
	 * @throws InstantiationException If parser could not be instantiated.
	 */
	public RestClient setParser(Class<? extends IParser<?>> c) throws InstantiationException {
		try {
			return setParser(c.newInstance());
		} catch (IllegalAccessException e) {
			throw new InstantiationException(e.getLocalizedMessage());
		}
	}

	/**
	 * Sets the encoder to use for compressing requests and responses.
	 * <p>
	 * 	When specified, request message body will be compressed and a <code>Content-Encoding</code> header
	 * 		will be set on the request.
	 * 	If the response contains a matching <code>Content-Encoding</code> header, the response message body
	 * 		will be decompressed.
	 *
	 * @param encoder The encoder.
	 * @return This object (for method chaining).
	 */
	public RestClient setEncoder(Encoder encoder) {
		this.encoder = encoder;
		return this;
	}

	/**
	 * Same as {@link #setEncoder(Encoder)}, except takes in an encoder class that
	 * 	will be instantiated through a no-arg constructor.
	 *
	 * @param c The encoder class.
	 * @return This object (for method chaining).
	 * @throws InstantiationException If encoder could not be instantiated.
	 */
	public RestClient setEncoder(Class<? extends Encoder> c) throws InstantiationException {
		try {
			return setEncoder(c.newInstance());
		} catch (IllegalAccessException e) {
			throw new InstantiationException(e.getLocalizedMessage());
		}
	}

	/**
	 * Sets the proxy configuration if this connection passes through a forward proxy.
	 *
	 * @param proxy The proxy settings.  If <jk>null</jk>, gets set to {@link Proxy#NO_PROXY}.
	 * @return This object (for method chaining).
	 */
	public RestClient setProxy(Proxy proxy) {
		this.proxy = proxy;
		return this;
	}

	/**
	 * Returns the serializer currently associated with this client.
	 *
	 * @return The serializer currently associated with this client, or <jk>null</jk> if no serializer is currently associated.
	 */
	public ISerializer<?> getSerializer() {
		return serializer;
	}

	/**
	 * Returns the parser currently associated with this client.
	 *
	 * @return The parser currently associated with this client, or <jk>null</jk> if no parser is currently associated.
	 */
	public IParser<?> getParser() {
		return parser;
	}

	/**
	 * Sets the value for the <js>"Accept"</js> request header.
	 * <p>
	 * 	This overrides the media type specified on the parser, but is overridden by calling <code>setHeader(<js>"Accept"</js>, newvalue);</code>
	 *
	 * @param accept The new header value.
	 * @return This object (for method chaining).
	 */
	public RestClient setAccept(String accept) {
		this.accept = accept;
		return this;
	}

	/**
	 * Sets the value for the <js>"Content-Type"</js> request header.
	 * <p>
	 * 	This overrides the media type specified on the serializer, but is overridden by calling <code>setHeader(<js>"Content-Type"</js>, newvalue);</code>
	 * @param contentType The new header value.
	 *
	 * @return This object (for method chaining).
	 */
	public RestClient setContentType(String contentType) {
		this.contentType = contentType;
		return this;
	}

	/**
	 * Perform a <js>"GET"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doGet(Object url) throws RestCallException {
		authenticate();
		return new RestCall(this, "GET", url);
	}

	/**
	 * Perform a <js>"PUT"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doPut(Object url, Object o) throws RestCallException {
		authenticate();
		return new RestCall(this, "PUT", url).setInput(o);
	}

	/**
	 * Perform a <js>"POST"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doPost(Object url, Object o) throws RestCallException {
		authenticate();
		return new RestCall(this, "POST", url).setInput(o);
	}

	/**
	 * Perform a <js>"DELETE"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doDelete(Object url) throws RestCallException {
		authenticate();
		return new RestCall(this, "DELETE", url);
	}

	/**
	 * Perform an <js>"OPTIONS"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doOptions(Object url) throws RestCallException {
		authenticate();
		return new RestCall(this, "OPTIONS", url);
	}

	/**
	 * Perform a <js>"POST"</js> request with a content type of <js>"application/x-www-form-urlencoded"</js> against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request, serialized as a form post
	 * 	using the {@link UrlEncodingSerializer#DEFAULT} serializer.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doFormPost(Object url, Object o) throws RestCallException {
		authenticate();
		try {
			return new RestCall(this, "POST", url)
				.setHeader("Content-Type", "application/x-www-form-urlencoded")
				.setInput(UrlEncodingSerializer.DEFAULT.serialize(o).substring(1));
		} catch (SerializeException e) {
			throw new RestCallException(e);
		}
	}

	/**
	 * Perform a generic REST call.
	 *
	 * @param method The method name (e.g. <js>"GET"</js>, <js>"OPTIONS"</js>).
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doCall(String method, Object url) throws RestCallException {
		authenticate();
		return new RestCall(this, method, url);
	}

	private void authenticate() throws RestCallException {
		for (Auth auth : auths) {
			auth.authenticate(this);
		}
	}
}
