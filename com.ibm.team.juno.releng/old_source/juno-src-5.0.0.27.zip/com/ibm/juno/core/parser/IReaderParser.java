package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Top-level interface for all character-based parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	In addition to methods defined in {@link IParser}, this method defines two additional
 * 	convenience methods for parsing directly from <code>Strings</code>.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface IReaderParser extends IParser<Reader> {

	@Override
	public <T> T parse(Reader in, ClassType<T> type, ParserContext ctx) throws ParseException, IOException;

	@Override
	public <T> T parse(Reader in, Class<T> type) throws ParseException, IOException;

	/**
	 * Same as <code>parse(Reader, ClassType, ParserContext)</code> except parses from a <code>String</code>.
	 *
	 * @param in The string containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassTypeConst#OBJECT}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @param ctx The runtime context.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 */
	public <T> T parse(CharSequence in, ClassType<T> type, ParserContext ctx) throws ParseException;


	/**
	 * Same as <code>parse(Reader, ClassType)</code> except parses from a <code>String</code>.
	 *
	 * @param in The string containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassTypeConst#OBJECT}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 */
	public <T> T parse(CharSequence in, Class<T> type) throws ParseException;
}
