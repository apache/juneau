package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Top-level interface for all parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This interface describes the methods that all parsers must implement.  It has the following two direct subclasses:
 * <ul>
 * 	<li>{@link IReaderParser} - Parsers that read from {@link Reader Readers}.
 * 	<li>{@link IInputStreamParser} - Parsers that read from {@link InputStream InputStreams}.
 * </ul>
 * <p>
 * 	Implementer will typically subclass directly from {@link ReaderParser} or {@link InputStreamParser} which
 * 	will already provide implementations for some of these methods.
 *
 *
 * <h6 class='topic'>Additional Information</h6>
 * <p>
 * 	Refer to the <a href='package-summary.html'>package javadocs</a> for an overall description of the parser API.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <R> The input stream or reader class type.
 */
public interface IParser<R> {

	/**
	 * Parses the content of the reader and creates an object of the specified type.
	 *
	 * @param in The input stream or reader containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassTypeConst#OBJECT}, object type is based on what's being parsed.
	 * 	For example, when parsing JSON text, it may return a <code>String</code>, <code>Number</code>, <code>ObjectMap</code>, etc...
	 * @param ctx The runtime context object returned by {@link #createContext(ClassType, ObjectMap, String, String)}.<br>
	 * 	Can be <jk>null</jk>.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T parse(R in, ClassType<T> type, ParserContext ctx) throws ParseException, IOException;

	/**
	 * Shortcut method for parsing the specified type.
	 *
	 * @param <T> The class type of the object to create.
	 * @param in The input stream or reader containing the input.
	 * @param type The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T parse(R in, Class<T> type) throws ParseException, IOException;

	/**
	 * Create the context object that will be passed in to the parse method.
	 * <p>
	 * 	It's up to implementers to decide what the context object looks like, although typically
	 * 	it's going to be a subclass of {@link ParserContext}.
	 *
	 * @param type The class type being parsed.
	 * @param properties Optional additional properties.
	 * @param mediaType The media type being consumed.
	 * 	For example, when using the REST servlet API, this value is set to the Content-Type value that was matched against.
	 * @param charset The input charset.
	 * @return The new context.
	 * @throws ParseException If any errors were encountered.  This causes parse to abort.
	 */
	public ParserContext createContext(ClassType<?> type, ObjectMap properties, String mediaType, String charset) throws ParseException;

	/**
	 * Returns the list of media types that this parser can handle.
	 * <p>
	 * 	For example, a JSON parser will typically return <code>{<js>"application/json"</js>,<js>"text/json"</js>}</code> indicating
	 * 	it can parse those media types.
	 * <p>
	 * 	This information is used by the {@link ParserGroup#getParser(String)} method to find the appropriate
	 * 	parser by the media types it handles.
	 * <p>
	 * 	This method can also return media ranges (per RFC2616/14.1) such as <js>"text/*"</js> or <js>"*\/*"</js>.
	 * <p>
	 * 	This method must return at least one value.
	 *
	 * @return The list of media types the parser handles.  Never <jk>null</jk> or empty.
	 */
	public String[] getMediaTypes();

	/**
	 * Sets a configuration property on this parser.
	 * <p>
	 * 	It's up to parsers to define what properties are available.
	 *
	 * @param property The property name.
	 * @param value The property value.
	 * @return This object (for method chaining).
	 * @throws LockedException If {@link #lock()} has previously been called on this object.
	 */
	public IParser<R> setProperty(String property, Object value) throws LockedException;

	/**
	 * Returns the {@link BeanContext} object used by this parser.
	 * @return The {@link BeanContext} object used by this parser.  Can be <jk>null</jk> if parser does not
	 * 	use a bean context.
	 */
	public BeanContext getBeanContext();

	/**
	 * Locks this parser so that the properties can no longer be changed.
	 * <p>
	 * 	Allows parser instances to be safely reused without the properties being changed.
	 *
	 * @return This object (for method chaining).
	 */
	public IParser<R> lock();

	/**
	 * Clones this parser.
	 * <p>
	 * 	This method should return a new instance of a parser with identical configuration properties.
	 * <p>
	 * 	If cloning is not supported, this method should throw a {@link CloneNotSupportedException}.
	 *
	 * @return The cloned parser.
	 * @throws CloneNotSupportedException If this class does not support cloning.
	 */
	public IParser<R> clone() throws CloneNotSupportedException;
}
