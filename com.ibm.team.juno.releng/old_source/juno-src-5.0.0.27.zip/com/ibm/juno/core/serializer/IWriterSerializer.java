package com.ibm.juno.core.serializer;

import java.io.*;

/**
 * Top-level interface for all character-based serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	In addition to methods defined in {@link ISerializer}, this method defines two additional
 * 	convenience methods for serializing directly to <code>Strings</code>.
 *
 * @param <W> The writer class type.
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface IWriterSerializer<W extends Writer> extends ISerializer<W> {

	@Override
	public void serialize(Object o, W out, SerializerContext ctx) throws IOException, SerializeException;

	/**
	 * Same as {@link IWriterSerializer#serialize(Object, Object, SerializerContext)} except serializes to a <code>String</code>.
	 *
	 * @param o The object to serialize.
	 * @param ctx The serialize context.  Can be <jk>null</jk>.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o, SerializerContext ctx) throws SerializeException;

	/**
	 * Same as {@link #serialize(Object, SerializerContext)} with <jk>null</jk> context.
	 *
	 * @param o The object to serialize.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o) throws SerializeException;

	/**
	 * Wraps the specified writer in a language-specific writer.
	 *
	 * @param w The writer being wrapped.
	 * @param ctx The serialize context.  Can be <jk>null</jk>.
	 * @return The wrapped writer.
	 */
	public W createWriter(Writer w, SerializerContext ctx);
}
