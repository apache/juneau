package com.ibm.juno.core.xml;

import static com.ibm.juno.core.xml.XmlSerializerProperties.*;

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.utils.*;

/**
 * Context object that lives for the duration of a single serialization of the {@link XmlSerializer}.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlSerializerContext extends SerializerContext {

	private final boolean
		addJsonTypeAttrs,
		addJsonStringTypeAttrs,
		autoDetectNamespaces,
		enableNamespaces,
		addNamespaceUrlsToRoot;

	private final Namespace
		defaultNamespace,
		xsiNamespace,
		xsNamespace;

	private final Namespace[] defaultNamespaces;

	private List<Namespace> namespaces = new IdentityList<Namespace>();

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param xsp Default XML serializer properties.
	 * @param op Override properties.
	 */
	public XmlSerializerContext(BeanContext beanContext, SerializerProperties sp, XmlSerializerProperties xsp, ObjectMap op) {
		super(beanContext, sp, op);
		if (op == null || op.isEmpty()) {
			addJsonTypeAttrs = xsp.addJsonTypeAttrs;
			addJsonStringTypeAttrs = xsp.addJsonStringTypeAttrs;
			enableNamespaces = xsp.enableNamespaces;
			autoDetectNamespaces = xsp.autoDetectNamespaces;
			addNamespaceUrlsToRoot = xsp.addNamespaceUrlsToRoot;
			defaultNamespace = xsp.defaultNamespace;
			xsiNamespace = xsp.xsiNamespace;
			xsNamespace = xsp.xsNamespace;
			defaultNamespaces = xsp.defaultNamespaces;
		} else {
			addJsonTypeAttrs = op.getBoolean(ADD_JSON_TYPE_ATTRS, xsp.addJsonTypeAttrs);
			addJsonStringTypeAttrs = op.getBoolean(ADD_JSON_STRING_TYPE_ATTRS, xsp.addJsonStringTypeAttrs);
			enableNamespaces = op.getBoolean(ENABLE_NAMESPACES, xsp.enableNamespaces);
			autoDetectNamespaces = op.getBoolean(AUTO_DETECT_NAMESPACES, xsp.autoDetectNamespaces);
			addNamespaceUrlsToRoot = op.getBoolean(ADD_NAMESPACE_URIS_TO_ROOT, xsp.addNamespaceUrlsToRoot);

			if (op.containsKey(DEFAULT_NAMESPACE_URI))
				defaultNamespace = NamespaceFactory.get(null, op.getString(DEFAULT_NAMESPACE_URI));
			else
				defaultNamespace = xsp.defaultNamespace;

			if (op.containsKey(XSI_NAMESPACE))
				xsiNamespace = (Namespace)op.get(XSI_NAMESPACE);
			else
				xsiNamespace = xsp.xsiNamespace;

			if (op.containsKey(XS_NAMESPACE))
				xsNamespace = (Namespace)op.get(XS_NAMESPACE);
			else
				xsNamespace = xsp.xsNamespace;

			if (op.containsKey(DEFAULT_NAMESPACES))
				defaultNamespaces = parseNamespaces(op.get(DEFAULT_NAMESPACES));
			else
				defaultNamespaces = xsp.defaultNamespaces;
		}
	}

	/**
	 * Returns the list of namespaces being used in the current XML serialization.
	 * @return The list of namespaces being used in the current XML serialization.
	 */
	public List<Namespace> getNamespaces() {
		return namespaces;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ADD_JSON_TYPE_ATTRS} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ADD_JSON_TYPE_ATTRS} setting value in this context.
	 */
	public final boolean isAddJsonTypeAttrs() {
		return addJsonTypeAttrs;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ADD_JSON_STRING_TYPE_ATTRS} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ADD_JSON_STRING_TYPE_ATTRS} setting value in this context.
	 */
	public final boolean isAddJsonStringTypeAttrs() {
		return addJsonStringTypeAttrs;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#AUTO_DETECT_NAMESPACES} setting value in this context.
	 * @return The {@link XmlSerializerProperties#AUTO_DETECT_NAMESPACES} setting value in this context.
	 */
	public final boolean isAutoDetectNamespaces() {
		return autoDetectNamespaces;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ENABLE_NAMESPACES} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ENABLE_NAMESPACES} setting value in this context.
	 */
	public final boolean isEnableNamespaces() {
		return enableNamespaces;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ADD_NAMESPACE_URIS_TO_ROOT} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ADD_NAMESPACE_URIS_TO_ROOT} setting value in this context.
	 */
	public final boolean isAddNamespaceUrlsToRoot() {
		return addNamespaceUrlsToRoot;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#DEFAULT_NAMESPACE_URI} setting value in this context.
	 * @return The {@link XmlSerializerProperties#DEFAULT_NAMESPACE_URI} setting value in this context.
	 */
	public final Namespace getDefaultNamespace() {
		return defaultNamespace;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#DEFAULT_NAMESPACES} setting value in this context.
	 * @return The {@link XmlSerializerProperties#DEFAULT_NAMESPACES} setting value in this context.
	 */
	public final Namespace[] getDefaultNamespaces() {
		return defaultNamespaces;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#XSI_NAMESPACE} setting value in this context.
	 * @return The {@link XmlSerializerProperties#XSI_NAMESPACE} setting value in this context.
	 */
	public final Namespace getXsiNamespace() {
		return xsiNamespace;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#XS_NAMESPACE} setting value in this context.
	 * @return The {@link XmlSerializerProperties#XS_NAMESPACE} setting value in this context.
	 */
	public final Namespace getXsNamespace() {
		return xsNamespace;
	}
}
