package com.ibm.juno.core.serializer;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static java.lang.String.*;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.utils.*;

/**
 * Parent class for all Juno serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Base serializer class that provides default implementations for the following interfaces:
 * <ul>
 * 	<li>{@link ISerializer}
 * 	<li>{@link ICoreApiSerializer}
 * </ul>
 * <p>
 * 	The only remaining abstract method that needs implementation is {@link #serialize(Object, Object, ObjectMap, String)}.
 *
 *
 * <h6 class='topic'>@Produces annotation</h6>
 * <p>
 * 	The media types that this serializer can produce is specified through the {@link Produces @Produces} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()}
 * 		and {@link #getResponseContentType()} methods.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * 	See {@link SerializerProperties} for a list of configurable properties that can be set on this class
 * 	using the {@link #setProperty(String, Object)} method.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <O> Must be either {@link InputStream} or {@link Reader}
 */
public abstract class Serializer<O> extends CoreApi implements ICoreApiSerializer<O> {

	/** General serializer properties currently set on this serializer. */
	protected transient SerializerProperties sp = new SerializerProperties();
	private String[] mediaTypes;
	private String contentType;


	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer
	abstract public void serialize(Object o, O out, ObjectMap properties, String mediaType) throws IOException, SerializeException;


	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	/**
	 * Converts the contents of the specified object array to a list.
	 * <p>
	 * 	Works on both object and primitive arrays.
	 * <p>
	 * 	In the case of multi-dimensional arrays, the outgoing list will
	 * 	contain elements of type n-1 dimension.  i.e. if {@code type} is <code><jk>int</jk>[][]</code>
	 * 	then {@code list} will have entries of type <code><jk>int</jk>[]</code>.
	 *
	 * @param type The type of array.
	 * @param array The array being converted.
	 * @return The array as a list.
	 */
	protected final List<Object> toList(Class<?> type, Object array) {
		Class<?> componentType = type.getComponentType();
		if (componentType.isPrimitive()) {
			int l = Array.getLength(array);
			List<Object> list = new ArrayList<Object>(l);
			for (int i = 0; i < l; i++)
				list.add(Array.get(array, i));
			return list;
		}
		return Arrays.asList((Object[])array);
	}

	/**
	 * Generalize the specified object if a filter is associated with it.
	 *
	 * @param o The object to generalize.
	 * @return The generalized object, or null if the object is null.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected final Object generalize(Object o) throws SerializeException {
		if (o == null)
			return null;
		PojoFilter filter = beanContext.getPojoFilter(o.getClass());
		if (filter == null)
			return o;
		return filter.filter(o, beanContext);
	}

	/**
	 * Returns true if the specified property should not be serialized.
	 */
	protected final boolean canIgnoreProperty(SerializerContext ctx, BeanPropertyMeta<?> pMeta) {
		if (pMeta.isHidden())
			return true;
		return false;
	}

	/**
	 * Returns true if the specified value should not be serialized.
	 */
	protected final boolean canIgnoreValue(SerializerContext ctx, ClassType<?> ct, Object value) {

		if (ctx.isTrimNulls() && value == null)
			return true;

		if (value == null)
			return false;

		if (ct == null)
			ct = ClassType.OBJECT;

		if (ctx.isTrimEmptyLists()) {
			if (ct.isArray() || (ct.isObject() && value.getClass().isArray())) {
				for (Object o : (Object[])value)
					if (! canIgnoreValue(ctx, ct.getElementType(), o))
						return false;
				return true;
			}
			if (ct.isCollection() || (ct.isObject() && Collection.class.isAssignableFrom(value.getClass()))) {
				for (Object o : (Collection<?>)value)
					if (! canIgnoreValue(ctx, ct.getElementType(), o))
						return false;
				return true;
			}
		}

		if (ctx.isTrimEmptyMaps()) {
			if (ct.isMap() || (ct.isObject() && Map.class.isAssignableFrom(value.getClass()))) {
				for (Object o : ((Map<?,?>)value).values())
					if (! canIgnoreValue(ctx, ct.getValueType(), o))
						return false;
				return true;
			}
		}

		return false;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	/**
	 * Returns the media types handled based on the value of the {@link Produces} annotation on the serializer class.
	 * <p>
	 * This method can be overridden by subclasses to determine the media types programatically.
	 */
	@Override // ISerializer
	public String[] getMediaTypes() {
		if (mediaTypes == null) {
			Produces p = ReflectionUtils.findAnnotation(Produces.class, getClass());
			if (p == null)
				throw new RuntimeException(format("Class '%s' is missing the @Produces annotation", getClass().getName()));
			mediaTypes = p.value();
		}
		return mediaTypes;
	}

	@Override // ISerializer
	public ObjectMap getResponseHeaders(ObjectMap properties) {
		return new ObjectMap().setBeanContext(beanContext);
	}

	@Override // ISerializer
	public String getResponseContentType() {
		if (contentType == null) {
			Produces p = ReflectionUtils.findAnnotation(Produces.class, getClass());
			contentType = (p == null ? "" : p.contentType());
		}
		return (contentType.isEmpty() ? null : contentType);
	}

	@Override // ISerializer
	public Serializer<O> setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (sp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // ICoreApiSerialier, CoreApi
	public Serializer<O> addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiSerialier, CoreApi
	public Serializer<O> addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiSerialier, CoreApi
	public Serializer<O> addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiSerialier, CoreApi
	public <T> Serializer<O> addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // ISerializer, CoreApi
	public Serializer<O> lock() {
		super.lock();
		return this;
	}

	@Override // ISerializer, CoreApi
	@SuppressWarnings("unchecked")
	public Serializer<O> clone() throws CloneNotSupportedException {
		Serializer<O> c = (Serializer<O>)super.clone();
		c.sp = sp.clone();
		return c;
	}
}
