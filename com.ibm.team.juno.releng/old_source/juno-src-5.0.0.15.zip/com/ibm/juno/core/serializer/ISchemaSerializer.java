package com.ibm.juno.core.serializer;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Interface that defines serializers that also produce schema documents.
 */
public interface ISchemaSerializer {

	/**
	 * Produces the schema of the output produced by calling {@link ISerializer#serialize(Object, Object, ObjectMap, String)}.
	 * @param o The object to serialize.
	 * @param out The writer to write to.
	 * @param properties Optional run-time properties.  Can be <jk>null</jk>.
	 * @param mediaType The matched media type.  Can be <jk>null</jk>.
	 *
	 * @return The writer passed in (for method chaining).
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public Writer serializeSchema(Object o, Writer out, ObjectMap properties, String mediaType) throws IOException, SerializeException;

	/**
	 * Same as {@link #serializeSchema(Object, Writer, ObjectMap, String)} except serializes to a <code>String</code>.
	 *
	 * @param o The object to serialize.
	 * @param properties Optional run-time properties.  Can be <jk>null</jk>.
	 *
	 * @return The writer passed in (for method chaining).
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serializeSchema(Object o, ObjectMap properties) throws IOException, SerializeException;
}
