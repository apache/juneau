package com.ibm.juno.core.rdfxml;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.serializer.SerializerProperties.*;
import static com.ibm.juno.core.xml.XmlSerializerProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Serializes POJO models to RDF.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>text/xml+rdf</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>text/xml+rdf</code>
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link RdfXmlSerializerProperties}
 * 	<li>{@link XmlSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * <h6 class='topic'>Behavior-specific subclasses</h6>
 * <p>
 * 	The following direct subclasses are provided for convenience:
 * <ul>
 * 	<li>{@link RdfXmlSerializer.Sq} - Default serializer with single quotes.
 * 	<li>{@link RdfXmlSerializer.SqReadable} - Default serializer, single quotes, whitespace added.
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "rawtypes", "unchecked", "hiding" })
@Produces("text/xml+rdf")
public class RdfXmlSerializer extends XmlSerializer {

	/** Default serializer, all default settings.*/
	public static final RdfXmlSerializer DEFAULT = new RdfXmlSerializer().lock();

	/** Default serializer, single quotes.*/
	public static final RdfXmlSerializer DEFAULT_SQ = new RdfXmlSerializer.Sq().lock();

	/** Default serializer, single quotes, whitespace added.*/
	public static final RdfXmlSerializer DEFAULT_SQ_READABLE = new RdfXmlSerializer.SqReadable().lock();

	/** Default serializer, single quotes.*/
	public static class Sq extends RdfXmlSerializer {
		/** Constructor */
		public Sq() {
			setProperty(QUOTE_CHAR, '\'');
		}
	}

	/** Default serializer, single quotes, whitespace added.*/
	public static class SqReadable extends Sq {
		/** Constructor */
		public SqReadable() {
			setProperty(USE_INDENTATION, true);
		}
	}


	/** RDF/XML specific properties currently defined on this class */
	protected transient RdfXmlSerializerProperties rxsp = new RdfXmlSerializerProperties();

	/**
	 * Default constructor with default unlocked bean context.
	 */
	public RdfXmlSerializer() {
		setProperty(ENABLE_NAMESPACES, true);
		setProperty(DEFAULT_NAMESPACE_URI, "http://www.ibm.com/juno#");
	}

	/**
	 * Shortcut for serializing directly to a String.
	 * @param o The object to serialize.
	 * @param properties Override properties.
	 * @param rootUrl The url of the root document.
	 * @return The serialized results as a string.
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o, String rootUrl, ObjectMap properties) throws IOException, SerializeException {
		StringWriter sw = new StringWriter();
		serialize(sw, o, rootUrl, properties);
		return sw.toString();
	}

	/**
	 * @param out The output writer.
	 * @param o The object to serialize.
	 * @param properties Override properties.
	 * @param rootUrl The url of the root document.
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serialize(Writer out, Object o, String rootUrl, ObjectMap properties) throws IOException, SerializeException {
		RdfXmlSerializerContext ctx = new RdfXmlSerializerContext(beanContext, sp, xsp, rxsp, properties);
		XmlSerializerWriter w = (out instanceof XmlSerializerWriter ? (XmlSerializerWriter)out : new XmlSerializerWriter(out, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority()));
		doSerialize(o, w, ctx, rootUrl);
	}

	/**
	 * Main serialization routine.
	 *
	 * @param o The object being serialized.
	 * @param w The writer to serialize to.
	 * @param ctx The serialization context object.
	 *
	 * @return The same writer passed in.
	 * @throws IOException If a problem occurred trying to send output to the writer.
	 */
	protected XmlSerializerWriter doSerialize(Object o, XmlSerializerWriter w, RdfXmlSerializerContext ctx, String rootUrl) throws IOException, SerializeException {
		if (ctx.isEnableNamespaces()) {
			if (ctx.isAutoDetectNamespaces())
				findNsfMappings(o, ctx);
			else
				ctx.getNamespaces().addAll(Arrays.asList(ctx.getDefaultNamespaces()));
			if (ctx.getDefaultNamespace() != null)
				ctx.getNamespaces().add(ctx.getDefaultNamespace());
		}
		serializeAnything(w, o, null, ctx, null, null, rootUrl, ctx.isEnableNamespaces() && ctx.isAddNamespaceUrlsToRoot(), true, false, null);
		return w;
	}

	/**
	 * Workhorse method.
	 *
	 * @param out The writer to send the output to.
	 * @param o The object to serialize.
	 * @param ctx The serializer context.
	 * @param elementName The root element name.
	 * @param namespaceUrl If
	 * @return The same writer passed in so that calls to the writer can be chained.
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	private boolean serializeAnything(XmlSerializerWriter out, Object o, ClassType eType, RdfXmlSerializerContext ctx,
			Namespace namespace, String elementName, String resourceUri, boolean addNamespaceUris,
			boolean mustUseDescriptionTag, boolean isInOpenTag, BeanPropertyMeta pMeta) throws IOException, SerializeException {

		int i = ctx.indent;						// Current indentation
		ClassType<?> aType = null;						// The actual type
		ClassType<?> gType = ClassType.OBJECT;		// The generic type
		if (namespace == null)
			namespace = ctx.getDefaultNamespace();
		String dns = (ctx.isEnableNamespaces() ? namespace.getName() : null);

		aType = ctx.push("", o, eType);

		if (eType == null)
			eType = ClassType.OBJECT;

		// Handle recursion
		if (aType == null) {
			o = null;
			aType = ClassType.OBJECT;
		}

		if (o != null) {

			gType = aType.getFilteredClassType();

			// Filter if necessary
			IPojoFilter filter = aType.getPojoFilter();
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == ClassType.OBJECT)
					gType = beanContext.getClassTypeForObject(o);
			}
		}

		boolean hasChildren = true;

		if (o == null || gType.isChar() && ((Character)o).charValue() == 0)
			out.tag(i, dns, elementName, true).nl();
		else if (gType.isUri() || (pMeta != null && pMeta.isUri()))
			out.oTag(i, dns, elementName).attrUri(ctx.getRdfNamespace(), "resource", o).append("/>").nl();
		else if (! (gType.isMap() || gType.isBean() || gType.isCollection() || gType.isArray()))
			out.sTag(i, dns, elementName, true)
				.encodeText(o)
				.eTag(dns, elementName, true).nl();
		else if (gType.isBean() || gType.isMap()) {
			if (elementName != null) {
				out.oTag(i, dns, elementName, true);
				if (addNamespaceUris)
					appendNamespaceUris(out, ctx);
				ctx.indent++;
			}
			if (gType.isBean())
				hasChildren = serializeBean(out, elementName, o, ctx, resourceUri, addNamespaceUris, mustUseDescriptionTag, isInOpenTag);
			else
				hasChildren = serializeMap(out, elementName, (Map)o, gType.getKeyType(), gType.getValueType(), ctx, resourceUri, addNamespaceUris, mustUseDescriptionTag, isInOpenTag);
			if (elementName != null) {
				if (hasChildren)
					out.eTag(i, dns, elementName, true).nl();
				ctx.indent--;
			}
		}
		else if (gType.isCollection())
			serializeCollection(out, namespace.getName(), elementName, (Collection)o, gType.getElementType(), ctx, resourceUri, addNamespaceUris);
		else if (gType.isArray())
			serializeCollection(out, namespace.getName(), elementName, toList(gType.getInnerClass(), o), gType.getElementType(), ctx, resourceUri, addNamespaceUris);

		ctx.pop();
		return hasChildren;
	}

	private void appendNamespaceUris(XmlSerializerWriter sw, XmlSerializerContext ctx) throws IOException {
		for (Namespace x : ctx.getNamespaces())
			if (x.getName() == null || x.getName().isEmpty())
				sw.attr("xmlns", x.getUri());
			else
				sw.attr("xmlns", x.getName(), x.getUri());
	}

	private boolean serializeMap(XmlSerializerWriter out, String elementName, Map m, ClassType<?> keyType, ClassType<?> valueType, RdfXmlSerializerContext ctx, String resourceUri, boolean addNamespaceUris, boolean isInCollection, boolean isInOpenTag) throws IOException, SerializeException {
		int i = ctx.getIndent()-1;
		String rdf = (ctx.isEnableNamespaces() ? ctx.getRdfNamespace().getName() : null);

		if (isInCollection) {
			out.oTag(i, rdf, "Description");
			if (resourceUri != null)
				out.attr(rdf, "about", resourceUri);
			if (addNamespaceUris)
				appendNamespaceUris(out, ctx);
		}
		boolean hasChildren = false;

		for (Map.Entry e : (Set<Map.Entry>)m.entrySet()) {
			Object k = e.getKey();
			if (k == null)
				k = "_x0000_";
			else
				k = generalize(k);
			Object value = e.getValue();

			if (canIgnoreValue(ctx, valueType, value))
				continue;

			if (! hasChildren) {
				if (! isInCollection) {
					if (isInOpenTag)
						out.append('>').nl();
					out.oTag(i, rdf, "Description");
					if (addNamespaceUris)
						appendNamespaceUris(out, ctx);
				}
				out.append('>').nl();
				hasChildren = true;
			}
			serializeAnything(out, value, valueType, ctx, null, k.toString(), null, false, false, true, null);
		}
		if (hasChildren)
			out.eTag(i, rdf, "Description").nl();
		else {
			if (! isInCollection) {
				if (resourceUri != null)
					out.attr(rdf, "resource", resourceUri);
				out.append("/>").nl();
			} else {
				out.append("/>").nl();
			}
			return false;
		}
		return true;
	}

	private boolean serializeBean(XmlSerializerWriter out, String elementName, Object o, RdfXmlSerializerContext ctx, String resourceUri, boolean addNamespaceUris, boolean isInCollection, boolean isInOpenTag) throws IOException, SerializeException {
		int i = ctx.indent-1;
		BeanMap m = beanContext.forBean(o);
		String rdf = ctx.getRdfNamespace().getName();

		// If this is a bean entry in a collection, create the following...
		// 	<rdf:Description rdf:about="uri"
		if (isInCollection) {
			out.oTag(i, rdf, "Description");
			if (m.getBeanUri() != null)
				out.attrUri(rdf, "about", m.getBeanUri());
			else if (resourceUri != null)
				out.attrUri(rdf, "about", resourceUri);
			if (addNamespaceUris)
				appendNamespaceUris(out, ctx);
		}
		boolean hasChildren = false;

		for (BeanMapEntry p : (Set<BeanMapEntry>)m.entrySet()) {
			BeanPropertyMeta pMeta = p.getMeta();

			if (canIgnoreProperty(ctx, pMeta) || pMeta.isBeanUri())
				continue;

			String key = p.getKey();
			Object value = null;
			try {
				value = p.getFilteredValue();
			} catch (Throwable x) {
				ctx.addWarning("Could not call getValue() on property '%s', %s", key, x.getLocalizedMessage());
			}

			if (canIgnoreValue(ctx, pMeta.getClassType(), value))
				continue;

			if (! hasChildren) {
				// This is the first child we've encountered.
				if (! isInCollection) {
					if (isInOpenTag)
						out.append('>').nl();
					out.oTag(i, rdf, "Description");
					if (m.getBeanUri() != null)
						out.attr(rdf, "about", m.getBeanUri());
					else if (resourceUri != null)
						out.attr(rdf, "about", resourceUri);
					if (addNamespaceUris)
						appendNamespaceUris(out, ctx);
				}
				out.append('>').nl();
				hasChildren = true;
			}
			Namespace ns = p.getMeta().getNamespace();
			serializeAnything(out, value, p.getMeta().getFilteredClassType(), ctx, ns, key, null, false, false, true, pMeta);
		}
		if (hasChildren)
			out.eTag(i, rdf, "Description").nl();
		else {
			if (! isInCollection) {
				if (m.getBeanUri() != null)
					out.attr(rdf, "resource", m.getBeanUri());
				else if (resourceUri != null)
					out.attr(rdf, "resource", resourceUri);
				out.append("/>").nl();
			} else {
				out.append("/>").nl();
			}
			return false;
		}
		return true;
	}

	private XmlSerializerWriter serializeCollection(XmlSerializerWriter out, String ns, String elementName, Collection c, ClassType<?> elementType, RdfXmlSerializerContext ctx, String resourceUri, boolean addNamespaceUris) throws IOException, SerializeException {
		int i = ctx.indent-1;
		String dns = (ctx.isEnableNamespaces() ? ctx.getDefaultNamespace().getName() : null);
		String rdf = (ctx.isEnableNamespaces() ? ctx.getRdfNamespace().getName() : null);

		if (elementName == null) {
			out.oTag(i, rdf, "Description");
			if (resourceUri != null)
				out.attr(rdf, "about", resourceUri);
			if (addNamespaceUris)
				appendNamespaceUris(out, ctx);
			out.append('>').nl();
			out.oTag(i+1, dns, "items").attr(rdf, "parseType", "Collection").append('>').nl();
			ctx.indent++;
		} else {
			out.oTag(i, ns == null ? dns : ns, elementName, true).attr(rdf, "parseType", "Collection").append('>').nl();
		}
		for (Object e : c) {
			ClassType ct = beanContext.getClassTypeForObject(e);

			if (canIgnoreValue(ctx, ct, e))
				continue;

			serializeAnything(out, e, ct, ctx, null, null, null, false, true, false, null);
		}
		if (elementName == null) {
			out.eTag(i+1, dns, "items").nl();
			out.eTag(i, rdf, "Description").nl();
			ctx.indent--;
		} else
			out.eTag(i, ns == null ? dns : ns, elementName, true).nl();
		return out;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer
	public void serialize(Object o, Writer out, ObjectMap properties, String mediaType) throws IOException, SerializeException {
		serialize(out, o, null, properties);
	}

	@Override // ISerializer, CoreApi
	public RdfXmlSerializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (this.rxsp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfXmlSerializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfXmlSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfXmlSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public <T> RdfXmlSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // ISerializer, Lockable
	public RdfXmlSerializer lock() {
		super.lock();
		return this;
	}

	@Override // ISerializer, Lockable
	public RdfXmlSerializer clone() {
		RdfXmlSerializer c = (RdfXmlSerializer)super.clone();
		c.rxsp = rxsp.clone();
		return c;
	}
}
