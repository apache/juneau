package com.ibm.juno.core.utils;

import java.lang.annotation.*;

/**
 * Reflection utilities.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ReflectionUtils {

	/**
	 * Recursively finds the specified annotation on this class and all parent classes/interfaces.
	 * @param a The annotation to look for.
	 * @param c The class on which we're looking for the annotation.
	 * @param <T> The annotation class type.
	 * @return The annotation, or <jk>null</jk> if annotation is not defined on specified class or parent hierarchy.
	 */
	public static <T extends Annotation> T findAnnotation(Class<T> a, Class<?> c) {
		if (c == null)
			return null;
		T t = c.getAnnotation(a);
		if (t == null)
			findAnnotation(a, c.getSuperclass());
		if (t == null) {
			for (Class<?> c2 : c.getInterfaces()) {
				t = findAnnotation(a, c2);
				if (t != null)
					break;
			}
		}
		return t;
	}
}
