/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.server;

import java.io.*;
import java.net.*;
import java.nio.charset.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.encoders.*;
import com.ibm.juno.core.jena.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Represents an HTTP response for a REST resource.
 * <p>
 * Essentially an extended {@link HttpServletResponse} with some special convenience methods
 * 	that allow you to easily output POJOs as responses.
 * <p>
 * Since this class extends {@link HttpServletResponse}, developers are free to use these
 * 	convenience methods, or revert to using lower level methods like any other servlet response.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<ja>@RestMethod</ja>(name=<js>"GET"</js>)
 * 	<jk>public void</jk> doGet(RestRequest req, RestResponse res) {
 * 		res.setProperty(HtmlSerializerProperties.<jsf>HTML_TITLE</jsf>, <js>"My title"</js>)
 * 			.setOutput(<js>"Simple string response"</js>);
 * 	}
 * </p>
 * <p>
 * 	See {@link RestServlet} for more information about usage on this class.
 *
 * @author jbognar
 */
public class RestResponse extends HttpServletResponseWrapper {

	private final RestRequest request;
	private Object output;                      // The POJO being sent to the output.
	private boolean isNullOutput;               // The output is null (as opposed to not being set at all)
	private ObjectMap properties;                 // Response properties
	SerializerGroup serializerGroup;
	private Encoder encoder;
	private RestServlet servlet;

	private static final SortedMap<String,Charset> availableCharsets = Charset.availableCharsets();

	/**
	 * Constructor.
	 */
	RestResponse(RestServlet servlet, RestRequest req, HttpServletResponse res) throws RestServletException {
		super(res);
		this.request = req;
		this.servlet = servlet;

		// Find acceptable charset
		String cs = null;
		for (MediaRange r : MediaRange.parse(req.getHeader("accept-charset", "utf-8"))) {
			if (r.getQValue() > 0) {
				if (r.getType().equals("*"))
					cs = "utf-8";
				else if (availableCharsets.containsKey(r.getType()))
					cs = r.getType();
				if (cs != null)
					break;
			}
		}

		if (cs == null)
			throw new RestException(SC_NOT_ACCEPTABLE, "No supported charsets in header ''Accept-Charset'': ''{0}''", req.getHeader("accept-charset"));
		setCharacterEncoding(cs.toLowerCase(Locale.ENGLISH));

		String ae = req.getHeader("accept-encoding");
		if (! (ae == null || ae.isEmpty())) {
			String match = servlet.getEncoders().findMatch(ae);
			if (match == null) {
				// Identity should always match unless "identity;q=0" or "*;q=0" is specified.
				if (ae.matches(".*(identity|\\*)\\s*;\\s*q\\s*=\\s*(0(?!\\.)|0\\.0).*")) {
					throw new RestException(SC_NOT_ACCEPTABLE,
						"Unsupported encoding in request header ''Accept-Encoding'': ''{0}''\n\tSupported codings: {1}",
						ae, servlet.getEncoders().getSupportedEncodings()
					);
				}
			} else {
				encoder = servlet.getEncoders().getEncoder(match);
				setHeader("content-encoding", match);
				setContentLength(-1);
			}
		}

		res.setCharacterEncoding(cs);
		for (Map.Entry<String,Object> e : servlet.getDefaultResponseHeaders().entrySet())
			setHeader(e.getKey(), e.getValue().toString());

		try {
			String passThroughHeaders = req.getHeader("x-response-headers");
			if (passThroughHeaders != null) {
				ObjectMap m = servlet.getUrlEncodingParser().parse(passThroughHeaders, ObjectMap.class);
				for (Map.Entry<String,Object> e : m.entrySet())
					setHeader(e.getKey(), e.getValue().toString());
			}
		} catch (Exception e1) {
			throw new RestException(SC_BAD_REQUEST, "Invalid format for header 'x-response-headers'.  Must be in URL-encoded format.").setCause(e1);
		}
	}

	/**
	 * Sets the serializer group for the response.
	 */
	RestResponse setSerializerGroup(SerializerGroup serializerGroup) {
		this.serializerGroup = serializerGroup;
		return this;
	}

	/**
	 * Returns the media types that are valid for <code>Accept</code> headers on the request.
	 * @return The set of media types registered in the parser group of this request.
	 */
	public List<String> getSupportedMediaTypes() {
		return serializerGroup.getSupportedMediaTypes();
	}

	/**
	 * Returns the codings that are valid for <code>Accept-Encoding</code> and <code>Content-Encoding</code> headers on the request.
	 * @return The set of media types registered in the parser group of this request.
	 */
	public List<String> getSupportedEncodings() throws RestServletException {
		return servlet.getEncoders().getSupportedEncodings();
	}

	/**
	 * Sets the HTTP output on the response.
	 * <p>
	 * 	Calling this method is functionally equivalent to returning the object in the REST Java method.
	 * <p>
	 * 	Can be of any of the following types:
	 * 	<ul>
	 * 	  <li> {@link InputStream}
	 * 	  <li> {@link Reader}
	 * 	  <li> Any serializable type defined in <a href='../core/package-summary.html#PojoCategories'>POJO Categories</a>
	 * 	</ul>
	 * <p>
	 * 	If it's an {@link InputStream} or {@link Reader}, you must also specify the content-type using the {@link #setContentType(String)} method.
	 *
	 * @param output The output to serialize to the connection.
	 * @return This object (for method chaining).
	 */
	public RestResponse setOutput(Object output) {
		this.output = output;
		this.isNullOutput = output == null;
		return this;
	}

	/**
	 * Add a serializer property to send to the serializers to override a default value.
	 * <p>
	 * Can be any value specified in the following classes:
	 * <ul>
	 * 	<li>{@link SerializerProperties}
	 * 	<li>{@link JsonSerializerProperties}
	 * 	<li>{@link XmlSerializerProperties}
	 * 	<li>{@link RdfSerializerProperties}
	 *	</ul>
	 *
	 * @param key The setting name.
	 * @param value The setting value.
	 * @return This object (for method chaining).
	 */
	public RestResponse setProperty(String key, Object value) {
		properties.put(key, value);
		return this;
	}

	/**
	 * Returns the properties set via {@link #setProperty(String, Object)}.
	 * @return A map of all the property values set.
	 */
	public ObjectMap getProperties() {
		return properties;
	}

	/**
	 * Servlet calls this method to initialize the properties.
	 */
	RestResponse setProperties(ObjectMap properties) {
		this.properties = properties;
		return this;
	}

	/**
	 * Shortcut method that allows you to use varargs to simplify setting array output.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Instead of...</jc>
	 * 	response.setOutput(<jk>new</jk> Object[]{x,y,z});
	 *
	 * 	<jc>// ...call this...</jc>
	 * 	response.setOutput(x,y,z);
	 * </p>
	 *
	 * @param output The output to serialize to the connection.
	 * @return This object (for method chaining).
	 */
	public RestResponse setOutputs(Object...output) {
		this.output = output;
		return this;
	}

	/**
	 * Returns the output that was set by calling {@link #setOutput(Object)}.
	 *
	 * @return The output object.
	 */
	public Object getOutput() {
		return output;
	}

	/**
	 * Returns <jk>true</jk> if this response has any output associated with it.
	 * @return <jk>true</jk> if {@code setInput()} has been called.
	 */
	public boolean hasOutput() {
		return output != null || isNullOutput;
	}

	/**
	 * Sets the output to a plain-text message regardless of the content type.
	 *
	 * @param text The output text to send.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to write to the writer.
	 */
	public RestResponse sendPlainText(String text) throws IOException {
		setContentType("text/plain");
		getWriter().write(text);
		return this;
	}

	/**
	 * Equivalent to {@link HttpServletResponse#getOutputStream()}, except
	 * 	wraps the output stream if an {@link Encoder} was found that matched
	 * 	the <code>Accept-Encoding</code> header.
	 */
	@Override
	public ServletOutputStream getOutputStream() throws IOException {
		ServletOutputStream os = super.getOutputStream();
		if (encoder != null) {
			final OutputStream os2 = encoder.getOutputStream(os);
			return new ServletOutputStream(){
				@Override
				public final void write(byte[] b, int off, int len) throws IOException {
					os2.write(b, off, len);
				}
				@Override
				public final void write(int b) throws IOException {
					os2.write(b);
				}
				@Override
				public final void flush() throws IOException {
					os2.flush();
				}
				@Override
				public final void close() throws IOException {
					os2.close();
				}
			};
		}
		return os;
	}

	/**
	 * Equivalent to {@link HttpServletResponse#getWriter()}, except
	 * 	wraps the output stream if an {@link Encoder} was found that matched
	 * 	the <code>Accept-Encoding</code> header.
	 */
	@Override
	public PrintWriter getWriter() throws IOException {
		// If plain text requested, override it now.
		if (request.isPlainText()) {
			setHeader("content-type", "text/plain");
		}

		try {
			if (encoder != null)
				return new PrintWriter(new BufferedWriter(new OutputStreamWriter(getOutputStream(), getCharacterEncoding())));
			return super.getWriter();
		} catch (UnsupportedEncodingException e) {
			String ce = getCharacterEncoding();
			setCharacterEncoding("UTF-8");
			throw new RestException(SC_NOT_ACCEPTABLE, "Unsupported charset in request header ''Accept-Charset'': ''{0}''", ce);
		}
	}

	/**
	 * Returns the <code>Content-Type</code> header stripped of the charset attribute if present.
	 * @return The <code>media-type</code> portion of the <code>Content-Type</code> header.
	 */
	public String getMediaType() {
		String contentType = getContentType();
		if (contentType == null)
			return null;
		int i = contentType.indexOf(';');
		if (i == -1)
			return contentType;
		return contentType.substring(0, i).trim();

	}

	/**
	 * Returns the value of the <code>Content-Charset</code> header value.
	 * <p>
	 * Defaults to <js>"UTF-8"</js> if not specified.
	 */
	@Override
	public String getCharacterEncoding() {
		String s = super.getCharacterEncoding();
		return (s == null ? "UTF-8" : s);
	}

	/**
	 * Convenience method for redirecting to a {@link URL}.
	 * @param url The URL to redirect to.
	 * @throws IOException If {@link HttpServletResponse#sendRedirect(String)} throws an exception.
	 */
	public void sendRedirect(URL url) throws IOException {
		super.sendRedirect(url.toString());
	}

	/**
	 * Convenience method for redirecting to a {@link URI}.
	 * @param uri The URL to redirect to.
	 * @throws IOException If {@link HttpServletResponse#sendRedirect(String)} throws an exception.
	 */
	public void sendRedirect(URI uri) throws IOException {
		super.sendRedirect(uri.toString());
	}

	/**
	 * Convenience method for redirecting to a URI as a {@link CharSequence} (e.g. {@link StringBuffer}).
	 * @param uri The URL to redirect to.
	 * @throws IOException If {@link HttpServletResponse#sendRedirect(String)} throws an exception.
	 */
	public void sendRedirect(CharSequence uri) throws IOException {
		super.sendRedirect(uri.toString());
	}
}
