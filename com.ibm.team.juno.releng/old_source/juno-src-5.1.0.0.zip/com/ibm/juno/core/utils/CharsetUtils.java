/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.utils;

import java.nio.charset.*;
import java.util.*;

/**
 * Utility methods for working with charsets.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class CharsetUtils {

	private static volatile Map<String,Charset> charsetCache = new HashMap<String,Charset>();

	/**
	 * Retrieves the charset with the given name or alias.
	 * <p>
	 * 	Lookup uses case-insensitive name matching, and value is cached
	 * 	to prevent expensive lookups in the future.
	 * @param name The name of the charset.
	 * @return The charset, or <jk>null</jk> if it doesn't exist in the JVM.
	 */
	public static Charset getCharset(String name) {
		if (! charsetCache.containsKey(name)) {
			synchronized(charsetCache) {
				charsetCache.put(name, null);		// Set to null initially in case it's not found below.
				loop: for (Charset cs : Charset.availableCharsets().values()) {

					// Does official name match?
					if (cs.name().equalsIgnoreCase(name)) {
						charsetCache.put(name, cs);
						break loop;
					}

					// Do one of the aliases match?
					for (String alias : cs.aliases()) {
						if (alias.equalsIgnoreCase(name)) {
							charsetCache.put(name, cs);
							break loop;
						}
					}
				}
			}
		}
		return charsetCache.get(name);
	}
}
