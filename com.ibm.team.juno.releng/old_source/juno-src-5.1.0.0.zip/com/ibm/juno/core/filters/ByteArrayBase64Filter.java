/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.filters;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.ParseException;
import com.ibm.juno.core.serializer.*;
import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.*;

/**
 * Transforms <code><jk>byte</jk>[]</code> arrays to BASE-64 encoded {@link String Strings}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ByteArrayBase64Filter extends PojoFilter<byte[],String> {

	/**
	 * Converts the specified <code><jk>byte</jk>[]</code> to a {@link String}.
	 */
	@Override
	public String filter(byte[] b, BeanContext beanContext) throws SerializeException {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			OutputStream b64os = MimeUtility.encode(baos, "base64");
			b64os.write(b);
			b64os.close();
			return new String(baos.toByteArray(), "UTF-8");
		} catch (Exception e) {
			throw new SerializeException(e);
		}
	}

	/**
	 * Converts the specified {@link String} to a <code><jk>byte</jk>[]</code>.
	 */
	@Override
	public byte[] unfilter(String s, ClassMeta<?> hint, BeanContext beanContext) throws ParseException {
		try {
			byte[] b = s.getBytes("UTF-8");
			ByteArrayInputStream bais = new ByteArrayInputStream(b);
			InputStream b64is = MimeUtility.decode(bais, "base64");
			byte[] tmp = new byte[b.length];
			int n = b64is.read(tmp);
			byte[] res = new byte[n];
			System.arraycopy(tmp, 0, res, 0, n);
			return res;
		} catch (Exception e) {
			throw new ParseException(e);
		}
	}
}
