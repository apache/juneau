package com.ibm.juno.client;

import java.util.*;

import org.apache.http.impl.cookie.*;
import org.apache.http.message.*;

/**
 * Convenience class for setting date headers in RFC2616 format.
 * <p>
 * Equivalent to the following code:
 * <p class='bcode'>
 * 	Header h = <jk>new</jk> Header(name, DateUtils.<jsm>formatDate</jsm>(value));
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class DateHeader extends BasicHeader {

	/**
	 * Creates a date request property in RFC2616 format.
	 *
	 * @param name The header name.
	 * @param value The header value.
	 */
	public DateHeader(String name, Date value) {
		super(name, DateUtils.formatDate(value));
	}
}
