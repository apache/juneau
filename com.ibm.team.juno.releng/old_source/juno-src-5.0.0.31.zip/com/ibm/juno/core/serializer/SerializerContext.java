package com.ibm.juno.core.serializer;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.serializer.SerializerProperties.*;

import java.util.*;
import java.util.logging.*;

import com.ibm.juno.core.*;


/**
 * Context object that lives for the duration of a single serialization of {@link Serializer} and its subclasses.
 * <p>
 *  	Used by serializers for the following purposes:
 * 	<ul>
 * 		<li>Keeping track of how deep it is in a model for indentation purposes.
 * 		<li>Ensuring infinite loops don't occur by setting a limit on how deep to traverse a model.
 * 		<li>Ensuring infinite loops don't occur from loops in the model (when detectRecursions is enabled.
 * 		<li>Allowing serializer properties to be overridden on method calls.
 * 	</ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SerializerContext {

	private static Logger logger = Logger.getLogger(SerializerContext.class.getName());

	private final int maxDepth, initialDepth;
	private final boolean
		detectRecursions,
		useIndentation,
		addClassAttrs,
		trimNulls,
		trimEmptyLists,
		trimEmptyMaps;
	private final char quoteChar;
	private final String uriContext, uriAuthority;
	private final String mediaType, charset;
	private final ObjectMap overrideProperties;

	/** The current indentation depth into the model. */
	public int indent;

	/** Contains the current objects in the current branch of the model. */
	private Map<Object,Object> set;

	/** Contains the current objects in the current branch of the model. */
	private LinkedList<Object> objectStack;

	/** Contains the attribute names of the current objects in the current branch of the model. */
	private LinkedList<String> attrNameStack;

	/** If 'true', then we're at a leaf in the model (i.e. a String, Number, Boolean, or null). */
	private boolean isBottom;

	/** Any warnings encountered. */
	private final List<String> warnings = new LinkedList<String>();

	/** The bean context being used in this context. */
	private final BeanContext beanContext;

	/**
	 * Create a new HashStack with the specified options.
	 *
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp The default serializer properties.
	 * @param op The override properties.
	 */
	public SerializerContext(BeanContext beanContext, SerializerProperties sp, ObjectMap op, String mediaType, String charset) {
		this.beanContext = beanContext;
		this.mediaType = mediaType;
		this.charset = charset;
		if (op == null || op.isEmpty()) {
			overrideProperties = new ObjectMap();
			maxDepth = sp.maxDepth;
			initialDepth = sp.initialDepth;
			detectRecursions = sp.detectRecursions;
			useIndentation = sp.useIndentation;
			addClassAttrs = sp.addClassAttrs;
			trimNulls = sp.trimNulls;
			trimEmptyLists = sp.trimEmptyLists;
			trimEmptyMaps = sp.trimEmptyMaps;
			quoteChar = sp.quoteChar;
			uriContext = sp.uriContext;
			uriAuthority = sp.uriAuthority;
		} else {
			overrideProperties = op;
			maxDepth = op.getInt(MAX_DEPTH, sp.maxDepth);
			initialDepth = op.getInt(INITIAL_DEPTH, sp.initialDepth);
			detectRecursions = op.getBoolean(DETECT_RECURSIONS, sp.detectRecursions);
			useIndentation = op.getBoolean(USE_INDENTATION, sp.useIndentation);
			addClassAttrs = op.getBoolean(ADD_CLASS_ATTRS, sp.addClassAttrs);
			trimNulls = op.getBoolean(TRIM_NULL_PROPERTIES, sp.trimNulls);
			trimEmptyLists = op.getBoolean(TRIM_EMPTY_LISTS, sp.trimEmptyLists);
			trimEmptyMaps = op.getBoolean(TRIM_EMPTY_MAPS, sp.trimEmptyMaps);
			quoteChar = op.getString(QUOTE_CHAR, ""+sp.quoteChar).charAt(0);
			uriContext = op.getString(URI_CONTEXT, sp.uriContext);
			uriAuthority = op.getString(URI_AUTHORITY, sp.uriAuthority);
		}
		this.indent = initialDepth;
		if (detectRecursions) {
			set = new IdentityHashMap<Object,Object>();
			objectStack = new LinkedList<Object>();
			attrNameStack = new LinkedList<String>();
		}
	}

	/**
	 * Returns the bean context associated with this context.
	 */
	public final BeanContext getBeanContext() {
		return beanContext;
	}

	/**
	 * Returns the runtime properties associated with this context.
	 */
	public final ObjectMap getProperties() {
		return overrideProperties;
	}

	/**
	 * Returns the media type being produced.
	 */
	public final String getMediaType() {
		return mediaType;
	}

	/**
	 * Returns the charset being produced.
	 */
	public final String getCharset() {
		return charset;
	}

	/**
	 * Returns the {@link SerializerProperties#MAX_DEPTH} setting value in this context.
	 * @return The {@link SerializerProperties#MAX_DEPTH} setting value in this context.
	 */
	public final int getMaxDepth() {
		return maxDepth;
	}

	/**
	 * Returns the {@link SerializerProperties#INITIAL_DEPTH} setting value in this context.
	 * @return The {@link SerializerProperties#INITIAL_DEPTH} setting value in this context.
	 */
	public final int getInitialDepth() {
		return initialDepth;
	}

	/**
	 * Returns the {@link SerializerProperties#DETECT_RECURSIONS} setting value in this context.
	 * @return The {@link SerializerProperties#DETECT_RECURSIONS} setting value in this context.
	 */
	public final boolean isDetectRecursions() {
		return detectRecursions;
	}

	/**
	 * Returns the {@link SerializerProperties#USE_INDENTATION} setting value in this context.
	 * @return The {@link SerializerProperties#USE_INDENTATION} setting value in this context.
	 */
	public final boolean isUseIndentation() {
		return useIndentation;
	}

	/**
	 * Returns the {@link SerializerProperties#ADD_CLASS_ATTRS} setting value in this context.
	 * @return The {@link SerializerProperties#ADD_CLASS_ATTRS} setting value in this context.
	 */
	public final boolean isAddClassAttrs() {
		return addClassAttrs;
	}

	/**
	 * Returns the {@link SerializerProperties#QUOTE_CHAR} setting value in this context.
	 * @return The {@link SerializerProperties#QUOTE_CHAR} setting value in this context.
	 */
	public final char getQuoteChar() {
		return quoteChar;
	}

	/**
	 * Returns the {@link SerializerProperties#TRIM_NULL_PROPERTIES} setting value in this context.
	 * @return The {@link SerializerProperties#TRIM_NULL_PROPERTIES} setting value in this context.
	 */
	public final boolean isTrimNulls() {
		return trimNulls;
	}

	/**
	 * Returns the {@link SerializerProperties#TRIM_EMPTY_LISTS} setting value in this context.
	 * @return The {@link SerializerProperties#TRIM_EMPTY_LISTS} setting value in this context.
	 */
	public final boolean isTrimEmptyLists() {
		return trimEmptyLists;
	}

	/**
	 * Returns the {@link SerializerProperties#TRIM_EMPTY_MAPS} setting value in this context.
	 * @return The {@link SerializerProperties#TRIM_EMPTY_MAPS} setting value in this context.
	 */
	public final boolean isTrimEmptyMaps() {
		return trimEmptyMaps;
	}

	/**
	 * Returns the {@link SerializerProperties#URI_CONTEXT} setting value in this context.
	 * @return The {@link SerializerProperties#URI_CONTEXT} setting value in this context.
	 */
	public final String getUriContext() {
		return uriContext;
	}

	/**
	 * Returns the {@link SerializerProperties#URI_AUTHORITY} setting value in this context.
	 * @return The {@link SerializerProperties#URI_AUTHORITY} setting value in this context.
	 */
	public final String getUriAuthority() {
		return uriAuthority;
	}

	/**
	 * Push the specified object onto the stack.
	 *
	 * @param attrName The attribute name.
	 * @param o The current object being serialized.
	 * @param eType The expected class type.
	 * @return The {@link ClassType} of the object so that <code>instanceof</code> operations
	 * 	only need to be performed once (since they can be expensive).<br>
	 */
	public ClassType<?> push(String attrName, Object o, ClassType<?> eType) {
		indent++;
		isBottom = true;
		if (o == null)
			return null;
		Class<?> c = o.getClass();
		ClassType<?> ct = (eType != null && c == eType.getClass() ? eType : beanContext.getClassType(o.getClass()));
		if (ct.isCharSequence() || ct.isNumber() || ct.isBoolean())
			return ct;
		if (detectRecursions) {
			if (objectStack.size() > maxDepth) {
				logger.warning("Depth too deep.  Possible recursion.\nStack:" + getStackString());
				return null;
			}
			try {
				if (set.containsKey(o))
					return null;				// If a recursion is detected, set it to NULL.
			} catch (Throwable e) {
				logger.warning("Exception of type ["+e.getMessage()+"] occurred on class of type ["+o.getClass().getName()+"]");
				return null;
			}
			isBottom = false;
			objectStack.addLast(o);
			attrNameStack.addLast(attrName);
			set.put(o, o);
		}
		return ct;
	}

	/**
	 * Returns <jk>true</jk> if {@link SerializerProperties#DETECT_RECURSIONS} is enabled, and the specified
	 * 	object is already higher up in the serialization chain.
	 * @param o The object to check for recursion.
	 * @return <jk>true</jk> if recursion detected.
	 */
	public boolean willRecurse(Object o) {
		if (! detectRecursions)
			return false;
		return set.containsKey(o);
	}

	/**
	 * Pop an object off the stack.
	 */
	public void pop() {
		indent--;
		if (detectRecursions && ! isBottom)  {
			Object o = objectStack.removeLast();
			String s = attrNameStack.removeLast();
			Object o2 = set.remove(o);
			if (o2 == null)
				addWarning("Couldn't remove object of type ["+o.getClass().getName()+"] on attribute ["+s+"] from object stack.");
		}
		isBottom = false;
	}

	/**
	 * The current indentation depth.
	 *
	 * @return The current indentation depth.
	 */
	public int getIndent() {
		return indent;
	}

	/**
	 * Logs a warning message.
	 *
	 * @param msg The warning message.
	 * @param args Optional printf arguments to replace in the error message.
	 */
	public void addWarning(String msg, Object... args) {
		msg = args.length == 0 ? msg : String.format(msg, args);
		logger.warning(msg);
		warnings.add(msg);
	}

	/**
	 * Returns the current branch of objects as a readable string.
	 */
	private String getStackString() {
		if (! detectRecursions)
			return null;
		StringBuilder sb = new StringBuilder("root");
		int x = objectStack.size();
		for (int i = 0; i < x; i++)
			sb.append("\n\t").append(attrNameStack.get(i) + " : " + objectStack.get(i).getClass().getName());
		return sb.toString();
	}
}
