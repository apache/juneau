package com.ibm.juno.core.json;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.ClassTypeConst.*;
import static com.ibm.juno.core.json.JsonSerializerProperties.*;
import static com.ibm.juno.core.serializer.SerializerProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJO models to JSON.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>application/json, text/json</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>application/json</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	The conversion is as follows...
 * 	<ul>
 * 		<li>Maps (e.g. {@link HashMap HashMaps}, {@link TreeMap TreeMaps}) are converted to JSON objects.
 * 		<li>Collections (e.g. {@link HashSet HashSets}, {@link LinkedList LinkedLists}) and Java arrays are converted to JSON arrays.
 * 		<li>{@link String Strings} are converted to JSON strings.
 * 		<li>{@link Number Numbers} (e.g. {@link Integer}, {@link Long}, {@link Double}) are converted to JSON numbers.
 * 		<li>{@link Boolean Booleans} are converted to JSON booleans.
 * 		<li>{@code nulls} are converted to JSON nulls.
 * 		<li>{@code arrays} are converted to JSON arrays.
 * 		<li>{@code beans} are converted to JSON objects.
 * 	</ul>
 * <p>
 * 	The types above are considered "JSON-primitive" object types.  Any non-JSON-primitive object types are transformed
 * 		into JSON-primitive object types through {@link com.ibm.juno.core.filter.Filter Filters} associated through the {@link BeanContext#addFilters(Class...)}
 * 		method.  Several default filters are provided for transforming Dates, Enums, Iterators, etc...
 * <p>
 * 	This serializer provides several serialization options.  Typically, one of the predefined DEFAULT serializers will be sufficient.
 * 	However, custom serializers can be constructed to fine-tune behavior.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link JsonSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * <h6 class='topic'>Behavior-specific subclasses</h6>
 * <p>
 * 	The following direct subclasses are provided for convenience:
 * <ul>
 * 	<li>{@link Simple} - Default serializer, single quotes, simple mode.
 * 	<li>{@link SimpleReadable} - Default serializer, single quotes, simple mode, with whitespace.
 * </ul>
 *
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Use one of the default serializers to serialize a POJO</jc>
 * 	String json = JsonSerializer.<jsf>DEFAULT</jsf>.serialize(someObject);
 *
 * 	<jc>// Create a custom serializer for lax syntax using single quote characters</jc>
 * 	JsonSerializer serializer = <jk>new</jk> JsonSerializer()
 * 		.setProperty(<jsf>LAX_MODE</jsf>, <jk>true</jk>)
 * 		.setProperty(<jsf>QUOTE_CHAR</jsf>, <js>'\''</js>);
 *
 * 	<jc>// Clone an existing serializer and modify it to use single-quotes</jc>
 * 	JsonSerializer serializer = JsonSerializer.<jsf>DEFAULT</jsf>.clone()
 * 		.setProperty(<jsf>QUOTE_CHAR</jsf>, <js>'\''</js>);
 *
 * 	<jc>// Serialize a POJO to JSON</jc>
 * 	String json = serializer.serialize(someObject);
 * </p>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Produces({"application/json","text/json"})
public class JsonSerializer extends WriterSerializer<JsonSerializerWriter> {

	/** Default serializer, all default settings.*/
	public static final JsonSerializer DEFAULT = new JsonSerializer().lock();

	/** Default serializer, single quotes, simple mode. */
	public static final JsonSerializer DEFAULT_LAX = new Simple().lock();

	/** Default serializer, single quotes, simple mode, with whitespace. */
	public static final JsonSerializer DEFAULT_LAX_READABLE = new SimpleReadable().lock();

	/** Default serializer, single quotes, simple mode. */
	@Produces(value={"application/json+simple","text/json+simple"},contentType="application/json")
	public static class Simple extends JsonSerializer {
		/** Constructor */
		public Simple() {
			setProperty(SIMPLE_MODE, true);
			setProperty(QUOTE_CHAR, '\'');
		}
	}

	/** Default serializer, single quotes, simple mode, with whitespace. */
	public static class SimpleReadable extends Simple {
		/** Constructor */
		public SimpleReadable() {
			setProperty(USE_WHITESPACE, true);
			setProperty(USE_INDENTATION, true);
		}
	}


	/** JSON serializer properties currently set on this serializer. */
	protected transient JsonSerializerProperties jsp = new JsonSerializerProperties();


	/**
	 * Workhorse method. Determines the type of object, and then calls the
	 * appropriate type-specific serialization method.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	SerializerWriter serializeAnything(JsonSerializerWriter out, Object o, ClassType<?> eType, JsonSerializerContext ctx, String attrName, BeanPropertyMeta pMeta) throws SerializeException {
		try {

			if (o == null) {
				out.append("null");
				return out;
			}

			if (eType == null)
				eType = OBJECT;

			boolean addClassAttr;		// Add "_class" attribute to element?
			ClassType<?> aType;			// The actual type
			ClassType<?> gType;			// The generic type

			aType = ctx.push(attrName, o, eType);
			boolean isRecursion = aType == null;

			// Handle recursion
			if (aType == null) {
				o = null;
				aType = OBJECT;
			}

			gType = aType.getFilteredClassType();
			addClassAttr = (ctx.isAddClassAttrs() && ! eType.equals(aType));

			// Filter if necessary
			PojoFilter filter = aType.getPojoFilter();				// The filter
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == OBJECT)
					gType = beanContext.getClassTypeForObject(o);
			}

			// '\0' characters are considered null.
			if (o == null || (gType.isChar() && ((Character)o).charValue() == 0))
				out.append("null");
			else if (gType.isNumber() || gType.isBoolean())
				out.append(o);
			else if (gType.isBean())
				serializeBeanMap(out, beanContext.forBean(o), addClassAttr, ctx);
			else if (gType.isUri() || (pMeta != null && (pMeta.isUri() || pMeta.isBeanUri())))
				out.q().appendUri(o).q();
			else if (gType.isMap()) {
				if (o instanceof BeanMap)
					serializeBeanMap(out, (BeanMap)o, addClassAttr, ctx);
				else
					serializeMap(out, (Map)o, eType, ctx);
			}
			else if (gType.isCollection()) {
				if (addClassAttr)
					serializeCollectionMap(out, (Collection)o, gType, ctx);
				else
					serializeCollection(out, (Collection) o, eType, ctx);
			}
			else if (gType.isArray()) {
				if (addClassAttr)
					serializeCollectionMap(out, toList(gType.getInnerClass(), o), gType, ctx);
				else
					serializeCollection(out, toList(gType.getInnerClass(), o), eType, ctx);
			}
			else
				out.stringValue(o);

			if (! isRecursion)
				ctx.pop();
			return out;
		} catch (SerializeException e) {
			throw e;
		} catch (Throwable e) {
			throw new SerializeException("Exception occured trying to process object of type '%s'", (o == null ? null : o.getClass().getName())).setCause(e);
		}
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeMap(JsonSerializerWriter out, Map m, ClassType<?> type, JsonSerializerContext ctx) throws IOException, SerializeException {

		ClassType<?> keyType = type.getKeyType(), valueType = type.getValueType();

		int depth = ctx.getIndent();
		out.append('{');

		Iterator mapEntries = m.entrySet().iterator();

		while (mapEntries.hasNext()) {
			Map.Entry e = (Map.Entry) mapEntries.next();
			Object value = e.getValue();

			Object key = generalize(e.getKey(), keyType);

			out.cr(depth).attr(key).append(':').s();

			serializeAnything(out, value, valueType, ctx, (key == null ? null : key.toString()), null);

			if (mapEntries.hasNext())
				out.append(',').s();
		}

		out.cr(depth-1).append('}');

		return out;
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeCollectionMap(JsonSerializerWriter out, Collection o, ClassType<?> type, JsonSerializerContext ctx) throws IOException, SerializeException {
		int i = ctx.getIndent();
		out.append('{').nl();
		out.append(i, "_class:").s().stringValue(type).append(',').nl();
		out.append(i, "items:").s();
		ctx.indent++;
		serializeCollection(out, o, type, ctx);
		ctx.indent--;
		out.cr(i-1).append('}');
		return out;
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeBeanMap(JsonSerializerWriter out, BeanMap m, boolean addClassAttr, JsonSerializerContext ctx) throws IOException, SerializeException {
		int depth = ctx.getIndent();
		out.append('{');

		Iterator mapEntries = m.entrySet().iterator();

		// Print out "_class" attribute on this bean if required.
		if (addClassAttr) {
			String attr = "_class";
			out.cr(depth).attr(attr).append(':').s().q().append(m.getClassType().getInnerClass().getName()).q();
			if (mapEntries.hasNext())
				out.append(',').s();
		}

		boolean addComma = false;

		while (mapEntries.hasNext()) {
			BeanMapEntry p = (BeanMapEntry)mapEntries.next();
			BeanPropertyMeta pMeta = p.getMeta();

			if (canIgnoreProperty(ctx, pMeta))
				continue;

			Object value = null;
			try {
				value = p.getFilteredValue();
			} catch (Throwable t) {
				ctx.addWarning("Could not call getValue() on property '%s', %s", p.getKey(), t.getLocalizedMessage());
			}

			if (canIgnoreValue(ctx, pMeta.getClassType(), value))
				continue;

			if (addComma)
				out.append(',').s();

			out.cr(depth).attr(p.getKey()).append(':').s();

			serializeAnything(out, value, pMeta.getFilteredClassType(), ctx, p.getKey(), pMeta);

			addComma = true;
		}
		out.cr(depth-1).append('}');
		return out;
	}

	@SuppressWarnings("rawtypes")
	private SerializerWriter serializeCollection(JsonSerializerWriter out, Collection c, ClassType<?> type, JsonSerializerContext ctx) throws IOException, SerializeException {

		ClassType<?> elementType = type.getElementType();

		out.append('[');
		int depth = ctx.getIndent();

		for (Iterator i = c.iterator(); i.hasNext();) {

			Object value = i.next();

			out.cr(depth);

			serializeAnything(out, value, elementType, ctx, "<iterator>", null);

			if (i.hasNext())
				out.append(',').s();
		}
		out.cr(depth-1).append(']');
		return out;
	}

	/**
	 * Returns the schema serializer based on the settings of this serializer.
	 * @return The schema serializer.
	 */
	public JsonSchemaSerializer getSchemaSerializer() {
		JsonSchemaSerializer s = new JsonSchemaSerializer();
		s.beanContext = this.beanContext;
		s.sp = this.sp;
		s.jsp = this.jsp;
		return s;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Serializer
	public JsonSerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) {
		return new JsonSerializerContext(beanContext, sp, jsp, properties, mediaType);
	}

	@Override // WriterSerializer
	public JsonSerializerWriter createWriter(Writer out, SerializerContext ctx) {
		if (! (ctx instanceof JsonSerializerContext))
			throw new RuntimeException("Context is not an instance of JsonSerializerContext");
		JsonSerializerContext ctx2 = (JsonSerializerContext)ctx;
		return new JsonSerializerWriter(out, ctx.isUseIndentation(), ctx2.isUseWhitespace(), ctx.getQuoteChar(), ctx2.isSimpleMode(), ctx.getUriContext(), ctx.getUriAuthority());
	}

	@Override // Serializer
	public void serialize(Object o, JsonSerializerWriter out, SerializerContext ctx) throws IOException, SerializeException {
		if (! (ctx instanceof JsonSerializerContext))
			throw new SerializeException("Context is not an instance of JsonSerializerContext");
		JsonSerializerContext ctx2 = (JsonSerializerContext)ctx;
		serializeAnything(out, o, null, ctx2, "root", null);
	}

	@Override // CoreApi
	public JsonSerializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (jsp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // CoreApi
	public JsonSerializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // CoreApi
	public JsonSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public JsonSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> JsonSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // Lockable
	public JsonSerializer lock() {
		super.lock();
		return this;
	}

	@Override // Lockable
	public JsonSerializer clone() {
		try {
			JsonSerializer c = (JsonSerializer)super.clone();
			c.jsp = jsp.clone();
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
