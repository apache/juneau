package com.ibm.juno.core;

import java.beans.*;

/**
 * Default property namer.
 * <p>
 * 	Examples:
 * <ul>
 * 	<li><js>"fooBar"</js> -&gt; <js>"fooBar"</js>
 * 	<li><js>"fooBarURL"</js> -&gt; <js>"fooBarURL"</js>
 * 	<li><js>"FooBarURL"</js> -&gt; <js>"fooBarURL"</js>
 * 	<li><js>"URL"</js> -&gt; <js>"URL"</js>
 * </ul>
 * <p>
 * 	See {@link Introspector#decapitalize(String)} for exact rules.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class PropertyNamerDefault implements PropertyNamer {

	@Override
	public String getPropertyName(String name) {
		return Introspector.decapitalize(name);
	}

}
