package com.ibm.juno.core;

/**
 * Static reusable constants of type {@link ClassType}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ClassTypeConst {

	/** Reusable instance that represents 'anything'. */
	public static final ClassType<Object> OBJECT = new ClassType<Object>(Object.class, null);

	/** Reusable instance that represents 'anything'. */
	public static final ClassType<String> STRING = new ClassType<String>(String.class, null);

}
