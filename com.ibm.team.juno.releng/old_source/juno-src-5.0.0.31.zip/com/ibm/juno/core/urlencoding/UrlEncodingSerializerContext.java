package com.ibm.juno.core.urlencoding;

import static com.ibm.juno.core.urlencoding.UrlEncodingSerializerProperties.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Context object that lives for the duration of a single serialization of {@link UrlEncodingSerializer}.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingSerializerContext extends SerializerContext {

	private final boolean useTypeFlags, useWhitespace;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param usp Default URL-Encoding serializer properties.
	 * @param op Override properties.
	 */
	protected UrlEncodingSerializerContext(BeanContext beanContext, SerializerProperties sp, UrlEncodingSerializerProperties usp, ObjectMap op, String mediaType) {
		super(beanContext, sp, op, mediaType, null);
		if (op == null || op.isEmpty()) {
			useTypeFlags = usp.useTypeFlags;
			useWhitespace = usp.useWhitespace;
		} else {
			useTypeFlags = op.getBoolean(USE_TYPE_FLAGS, usp.useTypeFlags);
			useWhitespace = op.getBoolean(USE_WHITESPACE, usp.useWhitespace);
		}
	}

	/**
	 * Returns the {@link UrlEncodingSerializerProperties#USE_TYPE_FLAGS} setting value in this context.
	 * @return The {@link UrlEncodingSerializerProperties#USE_TYPE_FLAGS} setting value in this context.
	 */
	public final boolean isUseTypeFlags() {
		return useTypeFlags;
	}

	/**
	 * Returns the {@link UrlEncodingSerializerProperties#USE_WHITESPACE} setting value in this context.
	 * @return The {@link UrlEncodingSerializerProperties#USE_WHITESPACE} setting value in this context.
	 */
	public final boolean isUseWhitespace() {
		return useWhitespace;
	}
}
