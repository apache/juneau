package com.ibm.juno.server;

import java.util.*;

import com.ibm.juno.server.RestServletNls.NlsClass.NlsMethod;
import com.ibm.juno.server.RestServletNls.NlsClass.NlsResponse;
import com.ibm.juno.server.annotation.*;

/**
 * Utility class for extracting messages from resource bundles identified through the {@link RestResource#messages()} annotation.
 * <p>
 * These messages are used to provide i18n support for the automatically-generated OPTIONS page.
 * <p>
 * When mutiple servlets are using the same resource bundle, the key names can be prefixed with the servlet class name
 * 	to prevent name conflicts.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th>Key name</th>
 * 		<th>Description</th></tr>
 * 	</tr>
 * 	<tr>
 * 		<td>
 * 			<ul>
 * 				<li><code>RestResource</code>
 * 				<li><code><i>[servlet]</i>.RestResource</code>
 * 			</ul>
 *			</td>
 * 		<td>
 * 			A description of the resource.<br>
 * 			Returned by {@link RestServlet#getResourceDescription(Locale)}.
 * 		</td>
 * 	</tr>
 * 	<tr>
 * 		<td>
 * 			<ul>
 * 				<li><code>RestMethod.<i>[method]</i></code>
 * 				<li><code><i>[servlet]</i>.RestMethod.<i>[method]</i></code>
 * 			</ul>
 * 		</td>
 * 		<td>
 * 			A description of a servlet Java method (i.e. a servlet method annotated with {@link RestMethod}).<br>
 * 			Returned by {@link RestServlet#getMethodDescriptions(RestRequest)}.
 * 		</td>
 * 	</tr>
 * 	<tr>
 * 		<td>
 * 			<ul>
 * 				<li><code>RestMethod.<i>[method]</i>.req.attr.<i>[name]</i></code>
 * 				<li><code><i>[servlet]</i>.RestMethod.<i>[method]</i>.req.attr.<i>[name]</i></code>
 * 			</ul>
 * 		</td>
 * 		<td>
 * 			A description of a request path pattern attribute (i.e. a parameter annotated with {@link Attr}).
 * 		</td>
 * 	</tr>
 * 	<tr>
 * 		<td>
 * 			<ul>
 * 				<li><code>RestMethod.<i>[method]</i>.req.param.<i>[name]</i></code>
 * 				<li><code><i>[servlet]</i>.RestMethod.<i>[method]</i>.req.param.<i>[name]</i></code>
 * 			</ul>
 * 		</td>
 * 		<td>
 * 			A description of a request URL parameter (i.e. a parameter annotated with {@link Param}).
 * 		</td>
 * 	</tr>
 * 	<tr>
 * 		<td>
 * 			<ul>
 * 				<li><code>RestMethod.<i>[method]</i>.req.header.<i>[name]</i></code>
 * 				<li><code><i>[servlet]</i>.RestMethod.<i>[method]</i>.req.header.<i>[name]</i></code>
 * 			</ul>
 * 		</td>
 * 		<td>
 * 			A description of a request header (i.e. a parameter annotated with {@link Header}).
 * 		</td>
 * 	</tr>
 * 	<tr>
 * 		<td>
 * 			<ul>
 * 				<li><code>RestMethod.<i>[method]</i>.req.content</code>
 * 				<li><code><i>[servlet]</i>.RestMethod.<i>[method]</i>.req.content</code>
 * 			</ul>
 * 		</td>
 * 		<td>
 * 			A description of a request body content (i.e. a parameter annotated with {@link Content}).
 * 		</td>
 * 	</tr>
 * 	<tr>
 * 		<td>
 * 			<ul>
 * 				<li><code>RestMethod.<i>[method]</i>.res.<i>[status-code]</i></code>
 * 				<li><code><i>[servlet]</i>.RestMethod.<i>[method]</i>.res.<i>[status-code]</i></code>
 * 			</ul>
 * 		</td>
 * 		<td>
 * 			A description of a possible HTTP response code.
 * 		</td>
 * 	</tr>
 * 	<tr>
 * 		<td>
 * 			<ul>
 * 				<li><code>RestMethod.<i>[method]</i>.res.<i>[status-code]</i>.header.<i>[name]</i></code>
 * 				<li><code><i>[servlet]</i>.RestMethod.<i>[method]</i>.res.<i>[status-code]</i>.header.<i>[name]</i></code>
 * 			</ul>
 * 		</td>
 * 		<td>
 * 			A description of a response header set on a particular HTTP response code.
 * 		</td>
 * 	</tr>
 * </table>
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc># REST resource description</jc>
 * 	RestResource = <js>Proof-of-concept resource that shows off the capabilities of working with POJO resources</js>
 *
 * 	RestMethod.getAll = <js>Get all people in the address book</js>
 *
 * 	RestMethod.createAddress = <js>Add an address to the address book</js>
 * 	RestMethod.createAddress.req.attr.id = <js>Person UUID</js>
 * 	RestMethod.createAddress.res.307.header.Location = <js>URL of new address</js>
 *
 * 	RestMethod.deletePerson = <js>Delete a person from the address book</js>
 * 	RestMethod.deletePerson.req.attr.id = <js>Person UUID</js>
 * 	RestMethod.deletePerson.res.200.content = <js>"DELETE successful"</js>
 * </p>
 * <p>
 * The equivalent using servlet name prefixes to avoid name conflicts...
 * <p class='bcode'>
 * 	<jc># REST resource description</jc>
 * 	AddressBookResource.RestResource = <js>Proof-of-concept resource that shows off the capabilities of working with POJO resources</js>
 *
 * 	AddressBookResource.RestMethod.getAll = <js>Get all people in the address book</js>
 *
 * 	AddressBookResource.RestMethod.createAddress = <js>Add an address to the address book</js>
 * 	AddressBookResource.RestMethod.createAddress.req.attr.id = <js>Person UUID</js>
 * 	AddressBookResource.RestMethod.createAddress.res.307.header.Location = <js>URL of new address</js>
 *
 * 	AddressBookResource.RestMethod.deletePerson = <js>Delete a person from the address book</js>
 * 	AddressBookResource.RestMethod.deletePerson.req.attr.id = <js>Person UUID</js>
 * 	AddressBookResource.RestMethod.deletePerson.res.200.content = <js>"DELETE successful"</js>
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("hiding")
public class RestServletNls {

	private Class<?> servletClass;
	private String bundlePath;
	private Map<Locale,NlsClass> classes = new HashMap<Locale,NlsClass>();
	private Map<Locale,SafeResourceBundle> bundles = new HashMap<Locale,SafeResourceBundle>();

	RestServletNls(Class<?> servletClass, String bundlePath) {
		this.servletClass = servletClass;
		this.bundlePath = bundlePath.replace('/', '.');
	}

	static class NlsClass {
		private String description;
		private Map<String,NlsMethod> methods = new HashMap<String,NlsMethod>();

		Set<NlsVar> genericRequestVars = new HashSet<NlsVar>();

		public NlsMethod getMethod(String name) {
			if (! methods.containsKey(name))
				methods.put(name, new NlsMethod());
			return methods.get(name);
		}

		public String getDescription() {
			return description;
		}

		class NlsMethod {
			String description;
			Set<NlsVar> requestVars = new HashSet<NlsVar>();
			Map<Integer,NlsResponse> responses = new HashMap<Integer,NlsResponse>();

			private NlsResponse createResponse(Integer httpStatus) {
				if (! responses.containsKey(httpStatus))
					responses.put(httpStatus, new NlsResponse(httpStatus));
				return responses.get(httpStatus);
			}

			public String getDescription() {
				return description;
			}

			public NlsVar getRequestVar(String type, String name) {
				for (NlsVar v : requestVars)
					if (v.matches(type, name))
						return v;
				for (NlsVar v : genericRequestVars)
					if (v.matches(type, name))
						return v;
				return null;
			}

			public Collection<NlsResponse> getResponses() {
				return responses.values();
			}

			public NlsResponse getResponse(Integer httpStatus) {
				return responses.get(httpStatus);
			}
		}

		static class NlsResponse {
			String description;
			Set<NlsVar> responseVars = new HashSet<NlsVar>();
			Integer httpStatus;

			private NlsResponse(Integer httpStatus) {
				this.httpStatus = httpStatus;
			}

			public NlsVar getResponseVar(String category, String name) {
				for (NlsVar v : responseVars)
					if (v.matches(category, name))
						return v;
				return null;
			}
		}
	}

	static class NlsVar {
		String category, name, description;

		private boolean matches(String category, String name) {
			if (category.equals(this.category)) {
				if (name == null || name.equals(this.name))
					return true;
			}
			return false;
		}
	}

	String getMessage(Locale locale, String key, Object...args) {
		SafeResourceBundle rb = getBundle(locale);
		return rb.getString(key, args);
	}

	synchronized NlsClass getNlsClass(Locale locale) {
		if (! classes.containsKey(locale))
			load(locale);
		return classes.get(locale);
	}

	/**
	 * Returns the resource bundle for the specified locale.
	 * Never <jk>null</jk>.
	 */
	protected SafeResourceBundle getBundle(Locale locale) {
		if (! bundles.containsKey(locale)) {
			ResourceBundle rb = null;
			ClassLoader cl = servletClass.getClassLoader();
			try {
				rb = ResourceBundle.getBundle(bundlePath, locale, cl);
			} catch (MissingResourceException e) {
				try {
					rb = ResourceBundle.getBundle(servletClass.getPackage().getName() + '.' + bundlePath, locale, cl);
				} catch (MissingResourceException e2) {
				}
			}
			bundles.put(locale, new SafeResourceBundle(rb, this.servletClass));
		}
		return bundles.get(locale);
	}

	private void load(Locale locale) {
		SafeResourceBundle rb = getBundle(locale);
		NlsClass c = new NlsClass();
		String cName = servletClass.getSimpleName();
		String cNamePrefix = cName + ".";
		for (String key : rb.keySet()) {
			if (key.startsWith(cNamePrefix) || key.startsWith("RestResource") || key.startsWith("RestMethod")) {
				String[] k = key.split("\\.");
				int i = 0;
				if (k[i].equals(cName))
					i++;
				if (k[i].equals("RestResource")) {
					i++;
					if (k.length == i)
						c.description = rb.getString(key);
				} else if (k[i].equals("RestMethod")) {
					i++;
					if (k[i].equals("req")) {
						NlsVar v = newVar(rb, key, k, i);
						if (v != null)
							c.genericRequestVars.add(v);
					} else if (k.length > i) {
						NlsMethod r = c.getMethod(k[i++]);
						if (k.length == i)
							r.description = rb.getString(key);
						else {
							if (k[i].equals("req")) {
								NlsVar v = newVar(rb, key, k, i);
								if (v != null)
									r.requestVars.add(v);
							} else if (k[i].equals("res")) {
								i++;
								if (k.length > i) {
									try {
										NlsResponse rc = r.createResponse(Integer.parseInt(k[i]));
										if (k.length == i+1)
											rc.description = rb.getString(key);
										else {
											NlsVar v = newVar(rb, key, k, i);
											if (v != null)
												rc.responseVars.add(v);
										}
									} catch (NumberFormatException e) {
										// Ignore entry.
									}
								}
							}
						}
					}
				}
			}
		}
		classes.put(locale, c);
	}

	private NlsVar newVar(SafeResourceBundle rb, String key, String[] k, int i) {
		i++;
		if (k.length > i) {
			NlsVar v = new NlsVar();
			v.category = k[i++];
			if (k.length > i)
				v.name = k[i++];
			v.description = rb.getString(key);
			return v;
		}
		return null;
	}
}
