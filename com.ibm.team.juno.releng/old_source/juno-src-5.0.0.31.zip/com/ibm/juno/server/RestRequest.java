package com.ibm.juno.server;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.server.RestServletProperties.*;
import static java.util.logging.Level.*;
import static javax.servlet.http.HttpServletResponse.*;

import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.logging.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.encoders.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.parser.ParseException;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.core.utils.*;
import com.ibm.juno.server.labels.*;

/**
 * Represents an HTTP request for a REST resource.
 * <p>
 * 	Equivalent to {@link HttpServletRequest} except with some additional convenience methods.
 * <p>
 * 	For reference, given the URL <js>"http://localhost:9080/contextRoot/servletPath/foo?bar=baz#qux"</js>, the
 * 	following methods return the following values....
 * 	<table class='styled'>
 * 		<tr><th>Method</th><th>Value</th></tr>
 * 		<tr><td>{@code getContextPath()}</td><td>{@code /contextRoot}</td></tr>
 * 		<tr><td>{@code getPathInfo()}</td><td>{@code /foo}</td></tr>
 * 		<tr><td>{@code getPathTranslated()}</td><td>{@code path-to-deployed-war-on-filesystem/foo}</td></tr>
 * 		<tr><td>{@code getQueryString()}</td><td>{@code bar=baz}</td></tr>
 * 		<tr><td>{@code getRequestURI()}</td><td>{@code /contextRoot/servletPath/foo}</td></tr>
 * 		<tr><td>{@code getRequestURL()}</td><td>{@code http://localhost:9080/contextRoot/servletPath/foo}</td></tr>
 * 		<tr><td>{@code getServletPath()}</td><td>{@code /servletPath}</td></tr>
 * 	</table>
 *
 * @author jbognar
 */
@SuppressWarnings("unchecked")
public class RestRequest extends HttpServletRequestWrapper {

	private final RestServlet servlet;
	private final BeanContext beanContext;
	private String method, remainder, content;
	private ObjectMap headers, properties;
	private final boolean allowHeaderParams, allowMethodParam, allowContentParam, debug;
	private ParserGroup parserGroup;
	private Encoder encoder;
	private int contentLength;
	private Map<String,String> lcParamMap = new LinkedHashMap<String,String>();
	private UrlEncodingParser urlEncodingParser;

	/**
	 * Constructor.
	 */
	RestRequest(RestServlet servlet, HttpServletRequest req) throws ServletException {
		super(req);

		try {
			this.servlet = servlet;
			this.beanContext = servlet.getBeanContext();
			this.urlEncodingParser = servlet.getUrlEncodingParser();

			Set<String> paramNames = urlEncodingParser.getParameterNames(req.getQueryString());
			for (String p : paramNames)
				lcParamMap.put(p.toLowerCase(), p);

			allowHeaderParams = servlet.getProperties().getBoolean(ALLOW_HEADER_PARAMS, true);
			allowMethodParam = servlet.getProperties().getBoolean(ALLOW_METHOD_PARAM, true);
			allowContentParam = servlet.getProperties().getBoolean(ALLOW_CONTENT_PARAM, true);

			// Get the HTTP method.
			// Can be overridden through a "method" GET attribute.
			method = super.getMethod();

			if (allowMethodParam) {
				String k = lcParamMap.get("method");
				if (k != null)
					method = getParameter(k);
			}

			if (allowContentParam) {
				String k = lcParamMap.get("content");
				if (k != null)
					content = getParameter(k);
			}

			if (allowHeaderParams) {
				String k = lcParamMap.get("content-type");
				if (k != null) {
					String ct = getParameter(k);
					int i = ct.indexOf("charset=");
					if (i != -1) {
						String enc = ct.substring(i+8);
						try {
							setCharacterEncoding(enc);
						} catch (UnsupportedEncodingException e) {
							throw new RestException(SC_UNSUPPORTED_MEDIA_TYPE, "Unsupported charset in request header 'Content-Type': '%s'", enc);
						}
					}
				}
			}

			headers = new ObjectMap().setInner(servlet.cDefaultRequestHeaders).setBeanContext(beanContext);
			for (Enumeration<String> e = req.getHeaderNames(); e.hasMoreElements();) {
				String h = e.nextElement();
				String v = req.getHeader(h);
				if (! v.isEmpty())
					headers.put(h.toLowerCase(Locale.ENGLISH), v);
			}

			debug = paramNames.contains("debug");

			if (debug) {
				StringBuilder sb = new StringBuilder("\n").append(getDescription()).append("\n");
				sb.append("---Headers---\n");
				for (Map.Entry<String,Object> e : headers.entrySet())
					sb.append("\t").append(e.getKey().toString()).append(": ").append(e.getValue()).append("\n");
				if (method.equals("PUT") || method.equals("POST")) {
					sb.append("---Content---\n");
					try {
						sb.append(getInputAsString()).append("\n");
					} catch (Exception e1) {
						sb.append(e1.getLocalizedMessage());
						servlet.getLogger().log(WARNING, "Error occurred while trying to read debug input.", e1);
					}
				}
				servlet.getLogger().log(Level.INFO, sb.toString());
			}

		} catch (RestException e) {
			throw e;
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

	/**
	 * Returns <jk>true</jk> if the request contains any of the specified parameters.
	 */
	public boolean hasAnyParams(String...params) {
		for (String param : params)
			if (lcParamMap.containsKey(param.toLowerCase()))
				return true;
		return false;
	}

	/**
	 * Returns a string of the form <js>"HTTP method-name full-url"</js>
	 * @return A description of the request.
	 */
	public String getDescription() {
		String qs = getQueryString();
		return "HTTP " + getMethod() + " " + getRequestURI() + (qs == null ? "" : "?" + qs);
	}

	/**
	 * Sets the parser group for this request.
	 */
	RestRequest setParserGroup(ParserGroup parserGroup) {
		this.parserGroup = parserGroup;
		return this;
	}

	/**
	 * Servlet calls this method to initialize the properties.
	 */
	RestRequest setProperties(ObjectMap properties) {
		this.properties = properties;
		return this;
	}

	/**
	 * Returns the <code>Content-Type</code> header value on the request, stripped
	 * 	of any parameters such as <js>";charset=X"</js>.
	 * <p>
	 * Example: <js>"text/json"</js>.
	 * <p>
	 * If the content type is not specified, and the content is specified via a
	 * 	<code>&content</code> query parameter, the content type is assumed to be
	 * 	<js>"application/x-www-form-urlencoded"</js>.  Otherwise, the
	 * 	content type is assumed to be <js>"text/plain"</js>.
	 *
	 * @return The <code>Accept</code> media-type header values on the request.
	 */
	public String getMediaType() {
		String ct = getHeader("content-type");
		if (ct == null) {
			if (content != null)
				return "application/x-www-form-urlencoded";
			return "text/plain";
		}
		int j = ct.indexOf(';');
		if (j != -1)
			ct = ct.substring(0, j);
		return ct;
	}

	/**
	 * Returns the media types that are valid for <code>Content-Type</code> headers on the request.
	 * @return The set of media types registered in the parser group of this request.
	 */
	public List<String> getSupportedMediaTypes() {
		return parserGroup.getSupportedMediaTypes();
	}

	/**
	 * Returns the charset specified on the <code>Content-Type</code> header, or
	 * <js>"UTF-8"</js> if not specified.
	 */
	@Override
	public String getCharacterEncoding() {
		String s = super.getCharacterEncoding();
		if (s == null)
			return "utf-8";
		return s.toLowerCase(Locale.ENGLISH);
	}

	/**
	 * Returns the specified header value, or <jk>null</jk> if the header value isn't present.
	 * <p>
	 * 	If {@code allowHeaderParams} init parameter is <jk>true</jk>, then first looks
	 * 	for {@code &HeaderName=x} in the URL query string.
	 */
	@Override
	public String getHeader(String name) {
		return getHeader(name, null);
	}

	void addDefaultHeaders(ObjectMap defaultHeaders) {
		// We're essentially just adding to the chain like so:
		// Before: actualHeaders->cDefaultHeaders.
		// After: actualHeaders->mDefaultHeaders->cDefaultHeaders.
		defaultHeaders.setInner(headers.getInner());
		headers.setInner(defaultHeaders);
	}

	/**
	 * Set the request header to the specified value.
	 * @param name The header name.
	 * @param value The header value.
	 */
	public void setHeader(String name, String value) {
		name = name.toLowerCase(Locale.ENGLISH);
		headers.put(name, value);
	}

	/**
	 * Returns the specified header value, or the specified default value if the
	 * 	header value isn't present.
	 * <p>
	 * 	If {@code allowHeaderParams} init parameter is <jk>true</jk>, then first looks
	 * 	for {@code &HeaderName=x} in the URL query string.
	 * <p>
	 * For performance reasons, use lower-case header names.
	 *
	 * @param name The HTTP header name.
	 * @param def The default value to return if the header value isn't found.
	 * @return The header value, or the default value if the header isn't present.
	 */
	public String getHeader(String name, String def) {
		name = name.toLowerCase(Locale.ENGLISH);
		if (allowHeaderParams) {
			String k = lcParamMap.get(name);
			if (k != null)
				return getParameter(k);
		}
		String h = headers.getString(name, def);
		return h;
	}

	/**
	 * Returns the method of this request.
	 * <p>
	 *		If <code>allowHeaderParams</code> init parameter is <jk>true</jk>, then first looks
	 * 	for <code>&method=xxx</code> in the URL query string.
	 */
	@Override
	public String getMethod() {
		return method;
	}

	/**
	 * Returns <jk>true</jk> if the URL parameters on this request contains the specified entry.
	 * <p>
	 * Note that this returns <jk>true</jk> even if the value is set to null (e.g. <js>"?key"</js>).
	 * @param name The URL parameter name.
	 * @return <jk>true</jk> if the URL parameters on this request contains the specified entry.
	 */
	public boolean hasParameter(String name) {
		return lcParamMap.containsKey(name.toLowerCase());
	}

	/**
	 * Returns the HTTP headers on this request as a {@link ObjectMap}.
	 * <p>
	 * Allows HTTP headers to be converted into arbitrary object types
	 * 	via the {@link ObjectMap#get(Class, String)} method.
	 * <p>
	 * Header keys are always lowercase.
	 *
	 * @return The HTTP headers.
	 */
	public ObjectMap getHeaders() {
		return headers;
	}

	/**
	 * Shortcut for calling <code>getParams().get(c, name, def);</code>
	 * <p>
	 * 	The type can be any POJO type convertable from a <code>String</code>.
	 * <p>
	 * 	Refer to <a href='../core/package-summary.html#PojoCategories' class='doclink'>POJO Categories</a> for a complete definition of supported POJOs.
	 *
	 * @param <T> The class type to convert the parameter value to.
	 * @param c The class type to convert the parameter value to.
	 * @param name The parameter name.
	 * @param def The default value if the parameter was not specified or is <jk>null</jk>.
	 * @return The parameter value converted to the specified class type.
	 */
	public <T> T getParameter(Class<T> c, String name, T def) throws ParseException {
		String val = getParameter(name);
		if (val == null)
			return def;
		return urlEncodingParser.parse(val, c);
	}

	/**
	 * Shortcut for calling <code>getParams().get(c, name);</code>
	 * <p>
	 * 	The type can be any POJO type convertable from a <code>String</code>.
	 * <p>
	 * 	Refer to <a href='../core/package-summary.html#PojoCategories' class='doclink'>POJO Categories</a> for a complete definition of supported POJOs.
	 *
	 * @param <T> The class type to convert the parameter value to.
	 * @param c The class type to convert the parameter value to.
	 * @param name The parameter name.
	 * @return The parameter value converted to the specified class type.
	 */
	public <T> T getParameter(Class<T> c, String name) throws ParseException {
		String val = getParameter(name);
		if (val == null && c.isPrimitive())
			return (T)BeanContext.getPrimitiveDefault(c);
		return urlEncodingParser.parse(val, c);
	}

	/**
	 * Same as {@link #getParameter(String)} except returns the default value
	 * if <jk>null</jk> or empty.
	 * @param name The query parameter name.
	 * @param def The default value.
	 */
	public String getParameter(String name, String def) {
		String val = getParameter(name);
		if (val == null || val.isEmpty())
			return def;
		return val;
	}

	/**
	 * Shortcut for calling <code>getHeaders().get(c, name, def);</code>
	 * <p>
	 * 	The type can be any POJO type convertable from a <code>String</code>.
	 * <p>
	 * 	Refer to <a href='../core/package-summary.html#PojoCategories' class='doclink'>POJO Categories</a> for a complete definition of supported POJOs.
	 *
	 * @param <T> The class type to convert the header value to.
	 * @param c The class type to convert the header value to.
	 * @param name The HTTP header name.
	 * @param def The default value if the header was not specified or is <jk>null</jk>.
	 * @return The parameter value converted to the specified class type.
	 */
	public <T> T getHeader(Class<T> c, String name, T def) {
		name = name.toLowerCase(Locale.ENGLISH);
		return getHeaders().get(c, name, def);
	}

	/**
	 * Shortcut for calling <code>getHeaders().get(c, name);</code>
	 * <p>
	 * 	The type can be any POJO type convertable from a <code>String</code>.
	 * <p>
	 * 	Refer to <a href='../core/package-summary.html#PojoCategories' class='doclink'>POJO Categories</a> for a complete definition of supported POJOs.
	 *
	 * @param <T> The class type to convert the header value to.
	 * @param c The class type to convert the header value to.
	 * @param name The HTTP header name.
	 * @return The parameter value converted to the specified class type.
	 */
	public <T> T getHeader(Class<T> c, String name) {
		name = name.toLowerCase(Locale.ENGLISH);
		T t = getHeaders().get(c, name);
		if (t == null && c.isPrimitive())
			return (T)BeanContext.getPrimitiveDefault(c);
		return t;
	}

	/**
	 * Returns the specified request attribute converted to the specified class type.
	 * <p>
	 * 	The type can be any POJO type convertable from a <code>String</code>.
	 * <p>
	 * 	Refer to <a href='../core/package-summary.html#PojoCategories' class='doclink'>POJO Categories</a> for a complete definition of supported POJOs.
	 *
	 * @param <T> The class type to convert the attribute value to.
	 * @param c The class type to convert the attribute value to.
	 * @param name The attribute name.
	 * @return The attribute value converted to the specified class type.
	 */
	public <T> T getAttribute(Class<T> c, String name) {
		T t = beanContext.convertToType(getAttribute(name), c);
		if (t == null && c.isPrimitive())
			return (T)BeanContext.getPrimitiveDefault(c);
		return t;
	}

	/**
	 * Same as {@link HttpServletRequest#getPathInfo()} except returns an empty
	 * 	string instead of <jk>null</jk> if the path info is <jk>null</jk> and
	 * 	{@code returnBlankForNull} is <jk>true</jk>.
	 *
	 * @param returnBlankForNull If <jk>true</jk>, returns blanks instead of <jk>true</jk>.
	 * @return The portion of the URL after the resource URL path pattern match.
	 */
	public String getPathInfo(boolean returnBlankForNull) {
		String s = getPathInfo();
		if (returnBlankForNull && s == null)
			return "";
		return s;
	}

	/**
	 * Returns the value {@link #getPathInfo()} split on the <js>'/'</js> character.
	 * <p>
	 * If path info is <jk>null</jk>, returns an empty list.
	 * <p>
	 * URL-encoded characters in segments are automatically decoded by this method.
	 * @return The decoded segments, or an empty list if path info is <jk>null</jk>.
	 */
	public String[] getPathInfoParts() {
		String s = getPathInfo(true);
		if (s.isEmpty())
			return new String[0];
		boolean needsDecode = s.indexOf('%') != -1;
		String[] l = s.split("/");
		try {
			if (needsDecode)
				for (int i = 0; i < l.length; i++)
					if (l[i].indexOf('%') != -1)
						l[i] = URLDecoder.decode(l[i], "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();  // Won't happen.
		}
		return l;
	}

	/**
	 * Same as {@link #getInput(ClassType)}, except a shortcut for passing in regular {@link Class} objects
	 * 	instead of having to look up {@link ClassType} objects.
	 *
	 * @param type The class type to instantiate.
	 * @param <T> The class type to instantiate.
	 * @return The input parsed to a POJO.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @throws ParseException If the input contains a syntax error or is malformed for the requested {@code Accept} header or is not valid for the specified type.
	 */
	public <T> T getInput(Class<T> type) throws IOException, ParseException {
		return getInput(beanContext.getClassType(type));
	}

	/**
	 * Reads the input from the HTTP request as JSON, XML, or HTML and converts the input to the specified class type.
	 * <p>
	 * 	If {@code allowHeaderParams} init parameter is <jk>true</jk>, then first looks
	 * 	for {@code &content=xxx} in the URL query string.
	 * <p>
	 * 	If type is <jk>null</jk> or {@link ClassTypeConst#OBJECT}, then the actual type will be determined automatically based on the
	 * 	following input:
	 * 	<table class='styled'>
	 * 		<tr><th>Type</th><th>JSON input</th><th>XML input</th><th>Return type</th></tr>
	 * 		<tr>
	 * 			<td>object</td>
	 * 			<td><js>"{...}"</js></td>
	 * 			<td><code><xt>&lt;object&gt;</xt>...<xt>&lt;/object&gt;</xt></code><br><code><xt>&lt;x</xt> <xa>type</xa>=<xs>'object'</xs><xt>&gt;</xt>...<xt>&lt;/x&gt;</xt></code></td>
	 * 			<td>{@link ObjectMap}</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>array</td>
	 * 			<td><js>"[...]"</js></td>
	 * 			<td><code><xt>&lt;array&gt;</xt>...<xt>&lt;/array&gt;</xt></code><br><code><xt>&lt;x</xt> <xa>type</xa>=<xs>'array'</xs><xt>&gt;</xt>...<xt>&lt;/x&gt;</xt></code></td>
	 * 			<td>{@link ObjectList}</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>string</td>
	 * 			<td><js>"'...'"</js></td>
	 * 			<td><code><xt>&lt;string&gt;</xt>...<xt>&lt;/string&gt;</xt></code><br><code><xt>&lt;x</xt> <xa>type</xa>=<xs>'string'</xs><xt>&gt;</xt>...<xt>&lt;/x&gt;</xt></code></td>
	 * 			<td>{@link String}</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>number</td>
	 * 			<td><code>123</code></td>
	 * 			<td><code><xt>&lt;number&gt;</xt>123<xt>&lt;/number&gt;</xt></code><br><code><xt>&lt;x</xt> <xa>type</xa>=<xs>'number'</xs><xt>&gt;</xt>...<xt>&lt;/x&gt;</xt></code></td>
	 * 			<td>{@link Number}</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>boolean</td>
	 * 			<td><jk>true</jk></td>
	 * 			<td><code><xt>&lt;boolean&gt;</xt>true<xt>&lt;/boolean&gt;</xt></code><br><code><xt>&lt;x</xt> <xa>type</xa>=<xs>'boolean'</xs><xt>&gt;</xt>...<xt>&lt;/x&gt;</xt></code></td>
	 * 			<td>{@link Boolean}</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>null</td>
	 * 			<td><jk>null</jk> or blank</td>
	 * 			<td><code><xt>&lt;null/&gt;</xt></code> or blank<br><code><xt>&lt;x</xt> <xa>type</xa>=<xs>'null'</xs><xt>/&gt;</xt></code></td>
	 * 			<td><jk>null</jk></td>
	 * 		</tr>
	 * 	</table>
	 * <p>
	 * 	Refer to <a href='../core/package-summary.html#PojoCategories' class='doclink'>POJO Categories</a> for a complete definition of supported POJOs.
	 *
	 * @param type The class type to instantiate.
	 * @param <T> The class type to instantiate.
	 * @return The input parsed to a POJO.
	 * @throws RestException If a problem occurred trying to read the input.
	 */
	public <T> T getInput(ClassType<T> type) throws RestException {

		try {
			if (type.isReader())
				return (T)getReader();

			if (type.isInputStream())
				return (T)getInputStream();

			String mediaType = getMediaType();
			Parser<?> p = parserGroup.getParser(mediaType);

			// If no patching parser for URL-encoding, use the one defined on the servlet.
			if (p == null && mediaType.equals("application/x-www-form-urlencoded"))
				p = urlEncodingParser;

			if (p != null) {
				try {
					ParserContext ctx = p.createContext(type, properties, mediaType, getCharacterEncoding());
					if (p instanceof InputStreamParser)
						return ((InputStreamParser)p).parse(getInputStream(), type, ctx);
					return ((ReaderParser)p).parse(getReader(), type, ctx);
				} catch (ParseException e) {
					throw new RestException(SC_BAD_REQUEST, e,
						"Could not convert request body content to class type '%s' using parser '%s'.",
						type, p.getClass().getName()
					);
				}
			}

			throw new RestException(SC_UNSUPPORTED_MEDIA_TYPE,
				"Unsupported media-type in request header 'Content-Type': '%s'\n\tSupported media-types: %s",
				getHeader("content-type"), parserGroup.getSupportedMediaTypes()
			);

		} catch (IOException e) {
			throw new RestException(SC_INTERNAL_SERVER_ERROR, e,
				"I/O exception occurred while attempting to handle request '%s'.",
				getDescription()
			);
		}
	}

	/**
	 * Returns the HTTP body content as a plain string.
	 * <p>
	 * 	If {@code allowHeaderParams} init parameter is true, then first looks
	 * 	for {@code &content=xxx} in the URL query string.
	 *
	 * @return The incoming input from the connection as a plain string.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public String getInputAsString() throws IOException {
		if (content != null)
			return content;
		content = IOUtils.read(getReader()).toString();
		return content;
	}

	/**
	 * The same as HttpRequest.getRequestURI(), except removes extra '/'
	 * 	characters at the end of the request URI if {@code trimTrailingSlashes} is <jk>true</jk>.
	 *
	 * @param trimTrailingSlashes If <jk>true</jk>, trims trailing slashes from the request URI.
	 * @return The resource URI.
	 */
	public String getRequestURI(boolean trimTrailingSlashes) {
		String s = getRequestURI();
		if (trimTrailingSlashes)
			while (s.length() > 1 && s.charAt(s.length()-1) == '/')
				s = s.substring(0, s.length()-1);
		return s;
	}

	/**
	 * The same as HttpRequest.getRequestURL(), except removes extra '/'
	 * 	characters at the end of the request URI if {@code trimTrailingSlashes} is <jk>true</jk>.
	 *
	 * @param trimTrailingSlashes If <jk>true</jk>, trims trailing slashes from the request URI.
	 * @return The resource URI.
	 */
	public StringBuffer getRequestURL(boolean trimTrailingSlashes) {
		StringBuffer s = getRequestURL();
		if (trimTrailingSlashes)
			while (s.length() > 1 && s.charAt(s.length()-1) == '/')
				s = s.deleteCharAt(s.length()-1);
		return s;
	}

	/**
	 * Returns a resolved URL.
	 * <p>
	 * <ul>
	 * 	<li>Fully-qualified absolute URLs (e.g. <js>"http://..."</js>, <js>"https://"</js>) are simply converted to a URL.
	 * 	<li>Absolute URLs (e.g. <js>"/foo/..."</js>) are interpreted as relative to the server hostname.
	 * 	<li>Relative URLs (e.g. <js>"foo/..."</js>) are interpreted as relative to this servlet path.
	 * </ul>
	 * @param path The URL path to resolve.
	 * @return The resolved URL.
	 * @throws MalformedURLException If path is not a valid URL component.
	 */
	public URL getURL(String path) throws MalformedURLException {
		if (path.startsWith("http://") || path.startsWith("https://"))
			return new URL(path);
		if (path.startsWith("/"))
			return new URL(getScheme(), getLocalName(), getLocalPort(), path);
		return new URL(getScheme(), getLocalName(), getLocalPort(), getContextPath() + getServletPath() + '/' + path);
	}

	/**
	 * Returns the HTTP body content as a {@link Reader}.
	 * <p>
	 * 	If {@code allowHeaderParams} init parameter is true, then first looks
	 * 	for {@code &content=xxx} in the URL query string.
	 * <p>
	 * 	Automatically handles GZipped input streams.
	 */
	@Override
	public BufferedReader getReader() throws IOException {
		BufferedReader r;
		if (content != null)
			r = new BufferedReader(new StringReader(content));
		else if (getEncoder() != null)
			r = new BufferedReader(new InputStreamReader(getInputStream(), getCharacterEncoding()));
		else
			r = super.getReader();
		return r;
	}

	/**
	 * Returns the HTTP body content as an {@link InputStream}.
	 * <p>
	 * 	Automatically handles GZipped input streams.
	 *
	 * @return The negotiated input stream.
	 * @throws IOException If any error occurred while trying to get the input stream or wrap it
	 * 	in the GZIP wrapper.
	 */
	@Override
	public ServletInputStream getInputStream() throws IOException {

		Encoder enc = getEncoder();

		ServletInputStream is = super.getInputStream();
		if (enc != null) {
			final InputStream is2 = enc.getInputStream(is);
			return new ServletInputStream() {
				@Override
				public final int read() throws IOException {
					return is2.read();
				}
				@Override
				public final void close() throws IOException {
					is2.close();
				}
			};
		}
		return is;
	}

	private Encoder getEncoder() {
		if (encoder == null) {
			String ce = headers.getString("content-encoding");
			if (! (ce == null || ce.isEmpty())) {
				ce = ce.trim().toLowerCase();
				encoder = servlet.cEncoders.getEncoder(ce);
				if (encoder == null)
					throw new RestException(SC_UNSUPPORTED_MEDIA_TYPE,
						"Unsupported encoding in request header 'Content-Encoding': '%s'\n\tSupported codings: %s",
						getHeader("content-encoding"), servlet.cEncoders.getSupportedEncodings()
					);
			}

			if (encoder != null)
				contentLength = -1;
		}
		// Note that if this is the identity encoder, we want to return null
		// so that we don't needlessly wrap the input stream.
		if (encoder == IdentityEncoder.INSTANCE)
			return null;
		return encoder;
	}

	@Override
	public int getContentLength() {
		return contentLength == 0 ? super.getContentLength() : contentLength;
	}

	/**
	 * Returns <jk>true</jk> if <code>&plainText</code> was specified as a URL parameter.
	 * <p>
	 * 	This indicates that the <code>Content-Type</code> of the output should always be set to <js>"text/plain"</js>
	 * 	to make it easy to render in a browser.
	 * <p>
	 * 	This feature is useful for debugging.
	 *
	 * @return <jk>true</jk> if {@code &plainText} was specified as a URL parameter
	 */
	public boolean isPlainText() {
		return hasParameter("plaintext");
	}

	/**
	 * Returns the remainder of the URL following any path pattern matches.
	 *
	 * <h6 class='topic'>Examples</h6>
	 * <p class='bcode'>
	 *		<jc>// REST method</jc>
	 * 	<ja>@RestMethod</ja>(name=<js>"GET"</js>,path=<js>"/foo/{bar}/*"</js>)
	 * 	<jk>public</jk> doGetById(RestServlet res, RestResponse res, <jk>int</jk> bar) {
	 * 		System.<jsm>err</jsm>.println(res.getRemainder());
	 * 	}
	 *
	 * 	<jc>// Prints "remainder"</jc>
	 * 	<jk>new</jk> RestCall(servletPath + <js>"/foo/123/remainder"</js>).connect();
	 * </p>
	 *
	 * @return The remainder string, or a blank string if no remainder exists.
	 */
	public String getRemainder() {
		return (remainder == null ? "" : remainder);
	}

	void setRemainder(String remainder) {
		this.remainder = remainder;
	}

	/**
	 * Shortcut method for calling {@link RestServlet#getMessage(Locale, String, Object...)} based
	 * 	on the request locale.
	 * @param key The message key.
	 * @param args Optional {@link MessageFormat} variable values in the value.
	 * @return The localized message.
	 */
	public String getMessage(String key, Object...args) {
		return servlet.getMessage(getLocale(), key, args);
	}

	/**
	 * Shortcut method for calling {@link RestServlet#getMethodDescriptions(RestRequest)} based
	 * 	on the request locale.
	 * @return The localized method descriptions.
	 */
	public Collection<MethodDescription> getMethodDescriptions() {
		return servlet.getMethodDescriptions(this);
	}

	/**
	 * Shortcut method for calling {@link RestServlet#getResourceDescription(Locale)} based
	 * 	on the request locale.
	 * @return The localized resource description.
	 */
	public String getResourceDescription() {
		return servlet.getResourceDescription(getLocale());
	}

	/**
	 * Returns the resource bundle for the request locale.
	 * @return The resource bundle.  Never <jk>null</jk>.
	 */
	public SafeResourceBundle getResourceBundle() {
		return servlet.getResourceBundle(getLocale());
	}

	/**
	 * Returns the servlet handling the request.
	 * <p>
	 * Can be used to access servlet-init parameters during requests.
	 *
	 * @return The servlet handling the request.
	 */
	public RestServlet getServlet() {
		return servlet;
	}

	/**
	 * Returns the servlet URI (e.g. <js>"/webContextPath/servletPath"</js>) of this servlet.
	 * <p>
	 * Callers can append to this string builder to create longer paths.
	 * @return The servlet URI.
	 */
	public StringBuilder getServletURI() {
		return new StringBuilder().append(getContextPath()).append(getServletPath());
	}

	/**
	 * Gets the full URL of the resource represented by this <code>RestServlet</code> object.
	 * @return The full URL of the resource represented by the <code>RestServlet</code> object.
	 */
	public String getResourceURL() {
		String s = getRequestURL().toString();
		String pathInfo = getPathInfo(true);
		String resourceURL = s.substring(0, s.length()-pathInfo.length());
		if (resourceURL.endsWith("/"))
			resourceURL = resourceURL.substring(0, resourceURL.length()-1);
		return resourceURL;
	}
}