/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.server;

import java.text.*;

/**
 * Exception thrown to trigger an error HTTP status.
 * <p>
 * 	REST methods on subclasses of {@link RestServlet} can throw
 * 	this exception to trigger an HTTP status other than the automatically-generated
 * 	<code>404</code>, <code>405</code>, and <code>500</code> statuses.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private int status;
	private int occurrence;

	/**
	 * @param status The HTTP status code.
	 * @param msg The status message.
	 * @param args Optional string format arguments.
	 */
	public RestException(int status, String msg, Object...args) {
		super(args.length == 0 ? msg : MessageFormat.format(msg, args));
		this.status = status;
	}

	/**
	 * @param status The HTTP status code.
	 * @param cause The root exception.
	 */
	public RestException(int status, Throwable cause) {
		this(status, cause.getLocalizedMessage());
		initCause(cause);
	}


	/**
	 * Sets the inner cause for this exception.
	 * @param cause The inner cause.
	 * @return This object (for method chaining).
	 */
	@Override
	public synchronized RestException initCause(Throwable cause) {
		super.initCause(cause);
		return this;
	}


	/**
	 * Returns all error messages from all errors in this stack.
	 * <p>
	 * Typically useful if you want to render all the error messages in the stack, but don't
	 * want to render all the stack traces too.
	 * @param scrubForXssVulnerabilities - If <jk>true</jk>, replaces <js>'&lt;'</js>, <js>'&gt;'</js>, and <js>'&amp;'</js> characters with spaces.
	 *
	 * @return All error messages from all errors in this stack.
	 */
	public String getFullStackMessage(boolean scrubForXssVulnerabilities) {
		String msg = getMessage();
		StringBuilder sb = new StringBuilder();
		if (msg != null) {
			if (scrubForXssVulnerabilities)
				msg = msg.replace('<', ' ').replace('>', ' ').replace('&', ' ');
			sb.append(msg);
		}
		Throwable e = getCause();
		while (e != null) {
			msg = e.getMessage();
			String cls = e.getClass().getSimpleName();
			if (msg == null)
				sb.append(MessageFormat.format("\nCaused by ({0})", cls));
			else
				sb.append(MessageFormat.format("\nCaused by ({0}): {1}", cls, msg));
			e = e.getCause();
		}
		return sb.toString();
	}

	@Override
	public int hashCode() {
		int i = 0;
		for (StackTraceElement e : getStackTrace())
			i ^= e.hashCode();
		return i;
	}

	void setOccurrence(int occurrence) {
		this.occurrence = occurrence;
	}

	/**
	 * Returns the number of times this exception occurred on this servlet.
	 * <p>
	 * This only gets set if {@link RestServletProperties#REST_useStackTraceHashes} is enabled on the servlet.
	 * @return The occurrence number if {@link RestServletProperties#REST_useStackTraceHashes} is enabled, or <code>0</code> otherwise.
	 */
	public int getOccurrence() {
		return occurrence;
	}

	/**
	 * @return The HTTP status code.
	 */
	public int getStatus() {
		return status;
	}
}
