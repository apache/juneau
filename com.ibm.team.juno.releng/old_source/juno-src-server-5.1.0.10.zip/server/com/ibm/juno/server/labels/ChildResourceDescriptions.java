/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.server.labels;

import java.util.*;

import com.ibm.juno.server.*;

/**
 * A POJO structure that describes the list of child resources associated with a resource.
 * <p>
 * Typically used in top-level GET methods of router resources to render a list of
 * 	available child resources.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public final class ChildResourceDescriptions extends LinkedList<ResourceDescription> {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 * @param servlet The servlet that this bean describes.
	 * @param req The HTTP servlet request.
	 */
	public ChildResourceDescriptions(RestServlet servlet, RestRequest req) {
		String uri = req.getRequestURI();
		Locale locale = req.getLocale();
		for (Map.Entry<String,RestServlet> e : servlet.getChildResources().entrySet())
			add(new ResourceDescription(uri, e.getKey(), e.getValue().getDescription(locale)));
	}

	/**
	 * Bean constructor.
	 */
	public ChildResourceDescriptions() {
		super();
	}
}
