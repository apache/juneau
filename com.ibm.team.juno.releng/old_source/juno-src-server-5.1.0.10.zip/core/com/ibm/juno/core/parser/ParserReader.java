/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.utils.*;

/**
 * Similar to a {@link java.io.PushbackReader} with a pushback buffer of 1 character.
 * <p>
 * 	Code is optimized to work with a 1 character buffer.
 * <p>
 * 	Additionally keeps track of current line and column number, and provides the ability to set
 * 	mark points and capture characters from the previous mark point.
 * <p>
 * 	<b>Warning:</b>  Not thread safe.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserReader extends Reader {

	/** Wrapped reader */
	protected Reader r;

	private char[] buff;       // Internal character buffer
	private int line = 1;      // Current line number
	private int column;        // Current column number
	private int iCurrent = 0;  // Current pointer into character buffer
	private int iMark = -1;    // Mark position in buffer
	private int iEnd = 0;      // The last good character position in the buffer
	private boolean endReached, holesExist;

	ParserReader() {}

	/**
	 * Constructor for input from a {@link CharSequence}.
	 *
	 * @param in The character sequence being read from.
	 */
	public ParserReader(CharSequence in) {
		this.r = new CharSequenceReader(in);
		if (in == null)
			this.buff = new char[0];
		else
			this.buff = new char[in.length() < 1024 ? in.length() : 1024];
	}

	/**
	 * Constructor for input from a {@link Reader}).
	 *
	 * @param r The Reader being wrapped.
	 * @param buffSize The buffer size to use for the buffered reader.
	 */
	public ParserReader(Reader r, int buffSize) {
		if (r instanceof ParserReader)
			this.r = ((ParserReader)r).r;
		else
			this.r = r;
		this.buff = new char[buffSize <= 0 ? 1024 : Math.max(buffSize, 20)];
	}

	/**
	 * Returns the current line number position in this reader.
	 *
	 * @return The current line number.
	 */
	public final int getLine() {
		return line;
	}

	/**
	 * Returns the current column number position in this reader.
	 *
	 * @return The current column number.
	 */
	public final int getColumn() {
		return column;
	}

	/**
	 * Reads a single character.
	 * Note that this method does NOT process extended unicode characters (i.e. characters
	 * 	above 0x10000), but rather returns them as two <jk>char</jk>s.
	 * Use {@link #readCodePoint()} to ensure proper handling of extended unicode.
	 *
	 * @return The character read, or -1 if the end of the stream has been reached.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@Override // Reader
	public final int read() throws IOException {
		int c = readFromBuff();
		if (c == -1)
			return -1;
		if (c == '\n') {
			line++;
			column = 0;
		} else {
			column++;
		}
		return c;
	}

	/**
	 * Same as {@link #read()} but detects and combines extended unicode characters (i.e. characters
	 * 	above 0x10000).
	 * @return The character read, or -1 if the end of the stream has been reached.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public final int readCodePoint() throws IOException {
		int c = read();

		// Characters that take up 2 chars.
		if (c >= 0xd800 && c <= 0xdbff) {
			int low = read();
			if (low >= 0xdc00 && low <= 0xdfff)
				c = 0x10000 + ((c - 0xd800) << 10) + (low - 0xdc00);
		}

		return c;
	}

	private final int readFromBuff() throws IOException {
		while (iCurrent >= iEnd) {
			if (endReached)
				return -1;

			// If there's still space at the end of this buffer, fill it.
			// Make sure there's at least 2 character spaces free for extended unicode characters.
			//if (false) {
			if (iEnd+1 < buff.length) {
				int x = read(buff, iCurrent, buff.length-iEnd);
				if (x == -1) {
					endReached = true;
					return -1;
				}
				iEnd += x;

			} else {
				// If we're currently marking, then we want to copy from the current mark point
				// to the beginning of the buffer and then fill in the remainder of buffer.
				if (iMark >= 0) {

					// If we're marking from the beginning of the array, we double the size of the
					// buffer.  This isn't likely to occur often.
					if (iMark == 0) {
						char[] buff2 = new char[buff.length<<1];
						System.arraycopy(buff, 0, buff2, 0, buff.length);
						buff = buff2;

					// Otherwise, we copy what's currently marked to the beginning of the buffer.
					} else {
						int copyBuff = iMark;
						System.arraycopy(buff, copyBuff, buff, 0, buff.length - copyBuff);
						iCurrent -= copyBuff;
						iMark -= copyBuff;
					}
					int expected = buff.length - iCurrent;

					int x = read(buff, iCurrent, expected);
					if (x == -1) {
						endReached = true;
						iEnd = iCurrent;
						return -1;
					}
					iEnd = iCurrent + x;
				} else {
					// Copy the last 10 chars in the buffer to the beginning of the buffer.
					int copyBuff = Math.min(iCurrent, 10);
					System.arraycopy(buff, iCurrent-copyBuff, buff, 0, copyBuff);

					// Number of characters we expect to copy on the next read.
					int expected = buff.length - copyBuff;
					int x = read(buff, copyBuff, expected);
					iCurrent = copyBuff;
					if (x == -1) {
						endReached = true;
						iEnd = iCurrent;
						return -1;
					}
					iEnd = iCurrent + x;
				}
			}
		}
		return buff[iCurrent++];
	}

	/**
	 * Start buffering the calls to read() so that the text can be gathered from the mark
	 * point on calling {@code getFromMarked()}.
	 */
	public final void mark() {
		iMark = iCurrent;
	}


	/**
	 * Peeks the next character in the stream.
	 * <p>
	 * 	This is equivalent to doing a {@code read()} followed by an {@code unread()}.
	 *
	 * @return The peeked character, or (char)-1 if the end of the stream has been reached.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public final int peek() throws IOException {
		int c = read();
		if (c != -1)
			unread();
		return c;
	}

	/**
	 * Read the specified number of characters off the stream.
	 *
	 * @param num The number of characters to read.
	 * @return The characters packaged as a String.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public final String read(int num) throws IOException {
		char[] c = new char[num];
		for (int i = 0; i < num; i++) {
			int c2 = read();
			if (c2 == -1)
				return new String(c, 0, i);
			c[i] = (char)c2;
		}
		return new String(c);
	}

	/**
	 * Pushes the last read character back into the stream.
	 *
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public final ParserReader unread() throws IOException {
		if (iCurrent <= 0)
			throw new IOException("Buffer underflow.");
		iCurrent--;
		column--;
		return this;
	}

	/**
	 * Close this reader and the underlying reader.
	 *
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@Override
	public void close() throws IOException {
		r.close();
	}

	/**
	 * Returns the contents of the reusable character buffer as a string, and
	 * resets the buffer for next usage.
	 *
	 * @return The contents of the reusable character buffer as a string.
	 */
	public final String getMarked() {
		return getMarked(0, 0);
	}

	/**
	 * Same as {@link #getMarked()} except allows you to specify offsets
	 * 	into the buffer.
	 * <p>
	 * For example, to return the marked string, but trim the first and last characters,
	 * 	call the following:
	 * <p class='bcode'>
	 * 	getFromMarked(1, -1);
	 * </p>
	 *
	 * @param offsetStart The offset of the start position.
	 * @param offsetEnd The offset of the end position.
	 * @return The contents of the reusable character buffer as a string.
	 */
	public final String getMarked(int offsetStart, int offsetEnd) {
		int offset = 0;

		// Holes are \u00FF 'delete' characters that we need to get rid of now.
		if (holesExist) {
			for (int i = iMark; i < iCurrent; i++) {
				char c = buff[i];
				if (c == 127)
					offset++;
				else
					buff[i-offset] = c;
			}
			holesExist = false;
		}
		int start = iMark + offsetStart, len = iCurrent - iMark + offsetEnd - offsetStart - offset;
		String s = new String(buff, start, len);
		iMark = -1;
		return s;
	}

	/**
	 * Trims off the last character in the marking buffer.
	 * Useful for removing escape characters from sequences.
	 */
	public final ParserReader delete() {
		return delete(1);
	}

	/**
	 * Trims off the specified number of last characters in the marking buffer.
	 * Useful for removing escape characters from sequences.
	 */
	public final ParserReader delete(int count) {
		for (int i = 0; i < count; i++)
			buff[iCurrent-i-1] = 127;
		holesExist = true;
		return this;
	}

	/**
	 * Replaces the last character in the marking buffer with the specified character.
	 * <code>offset</code> must be at least <code>1</code> for normal characters, and
	 * <code>2</code> for extended unicode characters in order for the replacement
	 * to fit into the buffer.
	 */
	public final ParserReader replace(int c, int offset) throws IOException {
		if (c < 0x10000) {
			if (offset < 1)
				throw new IOException("Buffer underflow.");
			buff[iCurrent-offset] = (char)c;
		} else {
			if (offset < 2)
				throw new IOException("Buffer underflow.");
			c -= 0x10000;
			buff[iCurrent-offset] = (char)(0xd800 + (c >> 10));
			buff[iCurrent-offset+1] = (char)(0xdc00 + (c & 0x3ff));
			offset--;
		}
		// Fill in the gap with DEL characters.
		for (int i = 1; i < offset; i++)
			buff[iCurrent-i] = 127;
		holesExist |= (offset > 1);
		return this;
	}

	/**
	 * Replace the last read character in the buffer with the specified character.
	 */
	public final ParserReader replace(char c) throws IOException {
		return replace(c, 1);
	}

	/**
	 * Subclasses can override this method to provide additional filtering (e.g. {#link UrlEncodingParserReader}).
	 * Default implementation simply calls the same method on the underlying reader.
	 */
	@Override
	public int read(char[] cbuf, int off, int len) throws IOException {
		return r.read(cbuf, off, len);
	}
}
