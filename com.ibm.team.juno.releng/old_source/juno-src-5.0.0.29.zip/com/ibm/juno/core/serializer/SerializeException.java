package com.ibm.juno.core.serializer;

import static java.lang.String.*;

//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************


/**
 * General exception thrown whenever an error occurs during serialization.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SerializeException extends Exception {

	private Throwable cause;

	/**
	 * @param msg The error message.
	 * @param args Optional printf arguments to replace in the error message.
	 */
	public SerializeException(String msg, Object... args) {
		super(format(msg, args));
	}

	/**
	 * @param cause The cause.
	 */
	public SerializeException(Throwable cause) {
		super(cause == null ? null : cause.getLocalizedMessage());
		this.cause = cause;
	}

	@Override
	public Throwable getCause() {
		return cause;
	}

	/**
	 * Sets the inner cause for this exception.
	 * @param cause The inner cause.
	 * @return This object (for method chaining).
	 */
	public SerializeException setCause(Throwable cause) {
		this.cause = cause;
		return this;
	}
}
