package com.ibm.juno.core.serializer;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.soap.*;

/**
 * Top-level interface for all serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This interface describes the methods that all serializers must implement.  It has the following two direct subclasses:
 * <ul>
 * 	<li>{@link IWriterSerializer} - Serializers that write to {@link Writer Writers}.
 * 	<li>{@link IOutputStreamSerializer} - Serializer that write to {@link OutputStream OutputStreams}.
 * </ul>
 * <p>
 * 	Implementer will typically subclass directly from {@link WriterSerializer} or {@link OutputStreamSerializer} which
 * 	will already provide implementations for some of these methods.
 * <p>
 * 	Refer to the <a href='package-summary.html'>package javadocs</a> for an overall description of the serializer API.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <W> The output stream or writer class type.
 */
public interface ISerializer<W> {

	/**
	 * Create the context object that will be passed in to the serialize method.
	 * <p>
	 * 	It's up to implementers to decide what the context object looks like, although typically
	 * 	it's going to be a subclass of {@link SerializerContext}.
	 *
	 * @param o The POJO that's going to be serialized.
	 * @param properties Optional additional properties.
	 * @param mediaType The media type being produced.
	 * 	For example, when using the REST servlet API, this value is set to the accept value that was matched against.
	 * @param charset The output charset.
	 * @return The new context.
	 * @throws SerializeException If any errors were encountered.  This causes serialization to abort.
	 */
	public SerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) throws SerializeException;

	/**
	 * Serializes a POJO to the specified output stream or writer.
	 *
	 * @param o The object to serialize.
	 * @param out The writer or output stream to write to.
	 * @param ctx The serializer context object return by {@link #createContext(Object, ObjectMap, String, String)}.<br>
	 * 	Can be <jk>null</jk>.
	 *
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serialize(Object o, W out, SerializerContext ctx) throws IOException, SerializeException;

	/**
	 * Returns the list of media types that this serializer can handle.
	 * <p>
	 * 	For example, a JSON serializer will typically return <code>{<js>"application/json"</js>,<js>"text/json"</js>}</code> indicating
	 * 	it can serialize those media types.
	 * <p>
	 * 	This method can also return media ranges (per RFC2616/14.1) such as <js>"text/*"</js> or <js>"*\/*"</js>.
	 * <p>
	 * 	This information is used by the {@link SerializerGroup#getSerializer(String)} method to find the appropriate
	 * 	serializer by the media types it handles.
	 * <p>
	 * 	This method must return at least one value.
	 *
	 * @return The list of media types the serializer handles.  Never <jk>null</jk> or empty.
	 */
	public String[] getMediaTypes();

	/**
	 * Optional method that specifies HTTP request headers for this serializer.
	 * <p>
	 * 	For example, {@link SoapXmlSerializer} needs to set a <code>SOAPAction</code> header.
	 * <p>
	 * 	This method is typically meaningless if the serializer is being used standalone (i.e. outside of a REST server or client).
	 *
	 * @param properties Optional run-time properties (the same that are passed to {@link IWriterSerializer#serialize(Object, Writer, SerializerContext)}.
	 * 	Can be <jk>null</jk>.
	 * @return The HTTP headers to set on HTTP requests.
	 * 	Can be <jk>null</jk>.
	 */
	public ObjectMap getResponseHeaders(ObjectMap properties);

	/**
	 * Optional method that returns the response <code>Content-Type</code> for this serializer if it is different from the matched media type.
	 * <p>
	 * 	This method is specified to override the content type for this serializer.
	 * 	For example, the {@link com.ibm.juno.core.json.JsonSerializer.Simple} class returns that it handles media type <js>"text/json+simple"</js>, but returns
	 * 	<js>"text/json"</js> as the actual content type.
	 * 	This allows clients to request specific 'flavors' of content using specialized <code>Accept</code> header values.
	 * <p>
	 * 	This method is typically meaningless if the serializer is being used standalone (i.e. outside of a REST server or client).
	 * @return The response content type.  If <jk>null</jk>, then the matched media type is used.
	 */
	public String getResponseContentType();

	/**
	 * Sets a configuration property on this serializer.
	 * <p>
	 * 	It's up to serializer to define what properties are available.
	 *
	 * @param property The property name.
	 * @param value The property value.
	 * @return This object (for method chaining).
	 * @throws LockedException If {@link #lock()} has previously been called on this object.
	 */
	public ISerializer<W> setProperty(String property, Object value) throws LockedException;

	/**
	 * Locks this serializer so that the properties can no longer be changed.
	 * <p>
	 * 	Allows serializer instances to be safely reused without the properties being changed.
	 *
	 * @return This object (for method chaining).
	 */
	public ISerializer<W> lock();

	/**
	 * Clones this serializer.
	 * <p>
	 * 	This method should return a new instance of a serializer with identical configuration properties.
	 * <p>
	 * 	If cloning is not supported, this method should throw a {@link CloneNotSupportedException}.
	 * <p>
	 * 	Cloned serializers should always start off unlocked.
	 *
	 * @return The cloned serializer.
	 * @throws CloneNotSupportedException If this class does not support cloning.
	 */
	public ISerializer<W> clone() throws CloneNotSupportedException;
}
