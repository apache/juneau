package com.ibm.juno.core.jena;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;


/**
 * Configurable properties on the {@link RdfParser} class.
 * <p>
 * 	Use the {@link RdfParser#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link RdfParser}.
 * <ul>
 * 	<li>{@link RdfProperties}
 * 	<li>{@link ParserProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfParserProperties extends RdfProperties implements Cloneable {


	/**
	 * Trim whitespace from text elements ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, whitespace in text elements will be automatically trimmed.
	 */
	public static final String TRIM_WHITESPACE = "RdfParser.trimWhitespace";

	boolean trimWhitespace = false;

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	@Override
	public boolean setProperty(String property, Object value) {
		if (property.equals(TRIM_WHITESPACE))
			trimWhitespace = BeanContext.DEFAULT.convertToType(value, boolean.class);
		else
			return super.setProperty(property, value);
		return true;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Cloneable
	public RdfParserProperties clone() {
		try {
			return (RdfParserProperties)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen.
		}
	}
}
