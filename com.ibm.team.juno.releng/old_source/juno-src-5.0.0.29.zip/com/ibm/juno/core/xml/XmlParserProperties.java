package com.ibm.juno.core.xml;

import javax.xml.stream.*;
import javax.xml.stream.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;

/**
 * Configurable properties on the {@link XmlParser} class.
 * <p>
 * 	Use the {@link XmlParser#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link XmlParser}.
 * <ul>
 * 	<li>{@link ParserProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlParserProperties implements Cloneable {

	/**
	 * XMLSchema-instance namespace URI ({@link String}, default=<js>"http://www.w3.org/2001/XMLSchema-instance"</js>).
	 * <p>
	 * The XMLSchema namespace.
	 */
	public static final String XSI_NS = "XmlParser.xsiNs";

	/**
	 * Trim whitespace from text elements ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, whitespace in text elements will be automatically trimmed.
	 */
	public static final String TRIM_WHITESPACE = "XmlParser.trimWhitespace";

	/**
	 * Set validating mode ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, XML document will be validated.
	 * See {@link XMLInputFactory#IS_VALIDATING} for more info.
	 */
	public static final String VALIDATING = "XmlParser.validating";

	/**
	 * Set coalescing mode ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, XML text elements will be coalesced.
	 * See {@link XMLInputFactory#IS_COALESCING} for more info.
	 */
	public static final String COALESCING = "XmlParser.coalescing";

	/**
	 * Replace entity references ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * If <jk>true</jk>, entity references will be replace during parsing.
	 * See {@link XMLInputFactory#IS_REPLACING_ENTITY_REFERENCES} for more info.
	 */
	public static final String REPLACE_ENTITY_REFERENCES = "XmlParser.replaceEntityReferences";

	/**
	 * XML reporter ({@link XMLReporter}, default=<jk>null</jk>).
	 * <p>
	 * Associates an {@link XMLReporter} with this parser.
	 * <p>
	 * Note:  Reporters are not copied to new parsers during a clone.
	 */
	public static final String REPORTER = "XmlParser.reporter";

	/**
	 * XML resolver ({@link XMLResolver}, default=<jk>null</jk>).
	 * <p>
	 * Associates an {@link XMLResolver} with this parser.
	 */
	public static final String RESOLVER = "XmlParser.resolver";

	/**
	 * XML event allocator. ({@link XMLEventAllocator}, default=<jk>false</jk>).
	 * <p>
	 * Associates an {@link XMLEventAllocator} with this parser.
	 */
	public static final String EVENT_ALLOCATOR = "XmlParser.eventAllocator";

	private String xsiNs = "http://www.w3.org/2001/XMLSchema-instance";
	private boolean
		trimWhitespace = false,
		validating = false,
		coalescing = false,
		replaceEntityReferences = true;
	private XMLReporter reporter;
	private XMLResolver resolver;
	private XMLEventAllocator eventAllocator;

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	protected boolean setProperty(String property, Object value) throws LockedException {
		BeanContext bc = BeanContext.DEFAULT;
		if (property.equals(TRIM_WHITESPACE))
			trimWhitespace = bc.convertToType(value, Boolean.class);
		else if (property.equals(VALIDATING))
			validating = bc.convertToType(value, Boolean.class);
		else if (property.equals(COALESCING))
			coalescing = bc.convertToType(value, Boolean.class);
		else if (property.equals(REPLACE_ENTITY_REFERENCES))
			replaceEntityReferences = bc.convertToType(value, Boolean.class);
		else if (property.equals(XSI_NS))
			xsiNs = value.toString();
		else if (property.equals(REPORTER) && value instanceof XMLReporter)
			reporter = (XMLReporter)value;
		else if (property.equals(RESOLVER) && value instanceof XMLResolver)
			resolver = (XMLResolver)value;
		else if (property.equals(EVENT_ALLOCATOR) && value instanceof XMLEventAllocator)
			eventAllocator = (XMLEventAllocator)value;
		else
			return false;
		return true;
	}

	/**
	 * Returns the current {@link #XSI_NS} value.
	 * @return The current {@link #XSI_NS} value.
	 */
	public String getXsiNs() {
		return xsiNs;
	}

	/**
	 * Returns the current {@link #TRIM_WHITESPACE} value.
	 * @return The current {@link #TRIM_WHITESPACE} value.
	 */
	public boolean isTrimWhitespace() {
		return trimWhitespace;
	}

	/**
	 * Returns the current {@link #VALIDATING} value.
	 * @return The current {@link #VALIDATING} value.
	 */
	public boolean isValidating() {
		return validating;
	}

	/**
	 * Returns the current {@link #COALESCING} value.
	 * @return The current {@link #COALESCING} value.
	 */
	public boolean isCoalescing() {
		return coalescing;
	}

	/**
	 * Returns the current {@link #REPLACE_ENTITY_REFERENCES} value.
	 * @return The current {@link #REPLACE_ENTITY_REFERENCES} value.
	 */
	public boolean isReplaceEntityReferences() {
		return replaceEntityReferences;
	}

	/**
	 * Returns the current {@link #REPORTER} value.
	 * @return The current {@link #REPORTER} value.
	 */
	public XMLReporter getReporter() {
		return reporter;
	}

	/**
	 * Returns the current {@link #REPORTER} value.
	 * @return The current {@link #REPORTER} value.
	 */
	public XMLResolver getResolver() {
		return resolver;
	}

	/**
	 * Returns the current {@link #EVENT_ALLOCATOR} value.
	 * @return The current {@link #EVENT_ALLOCATOR} value.
	 */
	public XMLEventAllocator getEventAllocator() {
		return eventAllocator;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override
	public XmlParserProperties clone() {
		try {
			return (XmlParserProperties)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen.
		}
	}
}
