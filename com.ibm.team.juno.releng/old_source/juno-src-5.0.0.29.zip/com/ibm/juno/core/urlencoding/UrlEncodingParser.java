package com.ibm.juno.core.urlencoding;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2013
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.ClassTypeConst.*;
import static com.ibm.juno.core.utils.StringUtils.*;

import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;

import javax.servlet.http.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.utils.*;

/**
 * Parses URL-encoded text into POJO models.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Content-Type</code> types: <code>application/x-www-form-urlencoded</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This parser uses a state machine, which makes it very fast and efficient.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link ParserProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@Consumes("application/x-www-form-urlencoded")
public class UrlEncodingParser extends ReaderParser implements IExtendedParser {

	/** Default parser, all default settings.*/
	public static final UrlEncodingParser DEFAULT = new UrlEncodingParser().lock();

	@Override
	public <K,V> Map<K,V> parseIntoMap(Reader in, Map<K,V> m, Type keyType, Type valueType) throws ParseException, IOException {
		ParserReader r2 = wrapReader(in);
		ClassType<?> ct = beanContext.getMapClassType(m.getClass(), keyType, valueType);
		m = parseIntoMap2(createContext(ct, null, null, null), r2, m, beanContext.getClassType(keyType), beanContext.getClassType(valueType));
		validateEnd(r2);
		return m;
	}

	@Override
	public <E> Collection<E> parseIntoCollection(Reader in, Collection<E> c, Type elementType) throws ParseException, IOException {
		ParserReader r2 = wrapReader(in);
		ClassType<?> ct = beanContext.getCollectionClassType(c.getClass(), elementType);
		c = parseIntoCollection2(createContext(ct, null, null, null), r2, c, beanContext.getClassType(elementType));
		validateEnd(r2);
		return c;
	}

	@Override
	public Object[] parseArgs(Reader in, ClassType<?>[] argTypes) throws ParseException, IOException {
		ParserReader r2 = wrapReader(in);
		Object[] r = parseArgs(r2, argTypes);
		validateEnd(r2);
		return r;
	}

	private <T> T parseAnything(ClassType<T> nt, UrlEncodingParserContext ctx, ParserReader r, BeanPropertyMeta p, boolean isTop) throws ParseException {

		if (nt == null)
			nt = (ClassType<T>)OBJECT;
		PojoFilter<T,Object> filter = (p == null ? null : p.getFilter());
		if (filter == null)
			filter = (PojoFilter<T,Object>)nt.getPojoFilter();
		ClassType<?> ft = (p == null ? nt.getFilteredClassType() : p.getFilteredClassType());

		int line = r.getLine();
		int column = r.getColumn();
		Object o = null;
		try {
			skipCommentsAndSpace(r);
			int c = r.peek();
			char flag = 0;
			if (c == '(' && ! (ft.isMap() || ft.isBean())) {
				r.read();
				flag = (char)r.read();
				c = r.read();
				if (c != ')')
					throw new ParseException(line, column, "Unexpected character '%s' found in flag construct.  Expected ')'.", c);
				c = r.peek();
			}
			if (c == -1) {
				o = "";
			} else if (flag == 0 && c == '%' && (ft.isBoolean() || ft.isNumber() || ft.isCollection() || ft.isArray() || ft.isEnum())) {
				parseKeyword("%00", r);
			} else if (ft.isObject()) {
				if (flag == 0) {
					if (c == '{') {
						ObjectMap m2 = new ObjectMap();
						parseIntoMap2(ctx, r, m2, STRING, OBJECT);
						o = m2.cast();
					} else if (c == '[') {
						o = parseIntoCollection2(ctx, r, new ObjectList(), OBJECT);
					} else {
						o = parseObject(ctx, r, isTop);
					}
				} else if (flag == 'b') {
					if (c == 't') {
						parseKeyword("true", r);
						o = Boolean.TRUE;
					} else {
						parseKeyword("false", r);
						o = Boolean.FALSE;
					}
				} else if (flag == 'd') {
					o = parseNumber(r, Double.class);
				} else if (flag == 'f') {
					o = parseNumber(r, Float.class);
				} else if (flag == 'l') {
					o = parseNumber(r, Long.class);
				} else if (flag == 'i') {
					o = parseNumber(r, Integer.class);
				} else if (flag == 's') {
					o = parseString(r, true);
				} else {
					throw new ParseException(line, column, "Unexpected flag character '%s'.", flag);
				}
			} else if (ft.isBoolean()) {
				if (c == 't') {
					parseKeyword("true", r);
					o = Boolean.TRUE;
				} else {
					parseKeyword("false", r);
					o = Boolean.FALSE;
				}
			} else if (ft.isCharSequence()) {
				o = parseString(r, flag != 0);
			} else if (ft.isChar()) {
				String s = parseString(r, flag != 0);
				o = s == null ? null : s.charAt(0);
			} else if (ft.isNumber()) {
				o = parseNumber(r, (Class<? extends Number>)ft.getInnerClass());
			} else if (ft.isEnum()) {
				o = Enum.valueOf((Class<Enum>)ft.getInnerClass(), parseString(r, flag != 0));
			} else if (ft.isMap()) {
				Map m = (ft.canCreateNewInstance() ? (Map)ft.newInstance() : new ObjectMap());
				o = parseIntoMap2(ctx, r, m, ft.getKeyType(), ft.getValueType());
			} else if (ft.isCollection()) {
				if (c == '{') {
					ObjectMap m = new ObjectMap();
					parseIntoMap2(ctx, r, m, STRING, OBJECT);
					o = m.cast();
				} else {
					Collection l = (ft.canCreateNewInstance() ? (Collection)ft.newInstance() : new ObjectList());
					o = parseIntoCollection2(ctx, r, l, ft.getElementType());
				}
			} else if (ft.isBean() && ft.canCreateNewInstance()) {
				BeanMap m = beanContext.newBeanMap(ft.getInnerClass());
				m = parseIntoBeanMap2(ctx, r, m);
				o = m == null ? null : m.getBean();
			} else if (ft.canCreateNewInstanceFromString()) {
				o = ft.newInstance(parseString(r, flag != 0));
			} else if (ft.isArray()) {
				if (c == '{') {
					ObjectMap m = new ObjectMap();
					parseIntoMap2(ctx, r, m, STRING, OBJECT);
					o = m.cast();
				} else {
					ArrayList l = (ArrayList)parseIntoCollection2(ctx, r, new ArrayList(), ft.getElementType());
					o = beanContext.toArray(ft, l);
				}
			} else {
				Map m = new ObjectMap();
				parseIntoMap2(ctx, r, m, ft.getKeyType(), ft.getValueType());
				if (m.containsKey("_class"))
					o = ((ObjectMap)m).cast();
				else {
					if (ft.isBean())
						throw new ParseException(line, column, "Class does not have a public no-arg constructor.");
					throw new ParseException(line, column, "Class is not a bean.  Reason:  %s", ft.getNotABeanReason());
				}
			}

			if (filter != null && o != null)
				o = filter.unfilter(o, nt, beanContext);

			return (T)o;

		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			if (p == null)
				throw new ParseException("Error occurred trying to parse into class '%s'", ft).setCause(e);
			throw new ParseException("Error occurred trying to parse value for bean property '%s' on class '%s'",
				p.getName(), p.getBeanMeta().getClassType()
			).setCause(e);
		}
	}

	private <K,V> Map<K,V> parseIntoMap2(UrlEncodingParserContext ctx, ParserReader r, Map<K,V> m, ClassType<K> keyType, ClassType<V> valueType) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		if (keyType == null)
			keyType = (ClassType<K>)STRING;

		int S0=0; // Looking for outer {
		int S1=1; // Looking for attrName start.
		int S3=3; // Found attrName end, looking for :.
		int S4=4; // Found :, looking for valStart: { [ " ' LITERAL.
		int S5=5; // Looking for , or }
		boolean isInEscape = false;

		int state = S0;
		if (r.peek() != '{')
			state = S1;
		String currAttr = null;
		int c = 0;
		while (c != -1) {
			c = r.read();
			if (! isInEscape) {
				if (state == S0) {
					if (c == '{')
						state = S1;
				} else if (state == S1) {
					if (c == '}' || c == -1) {
						return m;
					} else if (c == '/') {
						skipCommentsAndSpace(r.unread());
					} else if (! Character.isWhitespace(c)) {
						boolean hasFlag = c == '(';
						if (hasFlag)
							r.read(3);
						currAttr = parseString(r.unread(), hasFlag);
						state = S3;
						c = 0; // Avoid isInEscape if c was '\'
					}
				} else if (state == S3) {
					if (c == '=')
						state = S4;
					else if (c == -1 || c == '&' || c == ',' || c == '}') {
						if (currAttr == null)  // Value was '%00'
							return null;
						K key = convertAttrToType(currAttr, keyType);
						m.put(key, null);
						if (c == '}' || c == -1)
							return m;
						state = S1;
					}
				} else if (state == S4) {
					if (c == '/') {
						skipCommentsAndSpace(r.unread());
					} else if (c == -1 || c == '&' || c == ',' || c == '}') {
						K key = convertAttrToType(currAttr, keyType);
						V value = convertAttrToType("", valueType);
						m.put(key, value);
						if (c == -1 || c == '}')
							return m;
						state = S1;
					} else if (! Character.isWhitespace(c)) {
						K key = convertAttrToType(currAttr, keyType);
						V value = parseAnything(valueType, ctx, r.unread(), null, false);
						m.put(key, value);
						state = S5;
						c = 0; // Avoid isInEscape if c was '\'
					}
				} else if (state == S5) {
					if (c == ',' || c == '&')
						state = S1;
					else if (c == '/')
						skipCommentsAndSpace(r.unread());
					else if (c == '}' || c == -1) {
						return m;
					}
				}
			}
			isInEscape = (c == '\\' && ! isInEscape);
		}
		if (state == S0)
			throw new ParseException(line, column, "Expected '{' at beginning of object.");
		if (state == S1)
			throw new ParseException(line, column, "Could not find attribute name on object.");
		if (state == S3)
			throw new ParseException(line, column, "Could not find '=' following attribute name on object.");
		if (state == S4)
			throw new ParseException(line, column, "Expected one of the following characters: {,[,',\",LITERAL.");
		if (state == S5)
			throw new ParseException(line, column, "Could not find '}' marking end of object.");

		return null; // Unreachable.
	}

	private <E> Collection<E> parseIntoCollection2(UrlEncodingParserContext ctx, ParserReader r, Collection<E> l, ClassType<E> elementType) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		int S0=0; // Looking for outermost [
		int S1=1; // Looking for starting [ or { or LITERAL of first entry.
		int S2=2; // Looking for starting [ or { or LITERAL of subsequent entries.
		int S3=3; // Looking for , or ] after first entry.
		int S4=4; // Looking for , or ] after subsequent entries.
		boolean isInEscape = false;

		int state = S0;
		int c = 0;
		while (c != -1) {
			c = r.read();
			if (! isInEscape) {
				if (state == S0) {
					if (c == '[')
						state = S1;
				} else if (state == S1 || state == S2) {
					if (c == ']') {
						if (state == S2) {
							l.add(parseAnything(elementType, ctx, r.unread(), null, false));
							r.read();
						}
						return l;
					} else if (c == '/') {
						skipCommentsAndSpace(r.unread());
					} else if (! Character.isWhitespace(c)) {
						l.add(parseAnything(elementType, ctx, r.unread(), null, false));
						state = (state == S2 ? S4 : S3);
					}
				} else if (state == S3 || state == S4) {
					if (c == ',' || c == '&') {
						state = S2;
					} else if (c == '/') {
						skipCommentsAndSpace(r.unread());
					} else if (c == ']') {
						return l;
					}
				}
			}
			isInEscape = (c == '\\' && ! isInEscape);
		}
		if (state == S0)
			throw new ParseException(line, column, "Expected '[' at beginning of array.");
		if (state == S1)
			throw new ParseException(line, column, "Expected one of the following characters: {,[,LITERAL.");
		if (state == S3)
			throw new ParseException(line, column, "Expected ',' or ']'.");

		return null;  // Unreachable.
	}

	private <T> BeanMap<T> parseIntoBeanMap2(UrlEncodingParserContext ctx, ParserReader r, BeanMap<T> m) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		int S0=0; // Looking for outer {
		int S1=1; // Looking for attrName start.
		int S3=3; // Found attrName end, looking for =.
		int S4=4; // Found =, looking for valStart: { [ " ' LITERAL.
		int S5=5; // Looking for , or }
		boolean isInEscape = false;

		int state = S0;
		if (r.peek() != '{')
			state = S1;
		String currAttr = "";
		int c = 0;
		int currAttrLine = -1, currAttrCol = -1;
		while (c != -1) {
			c = r.read();
			if (! isInEscape) {
				if (state == S0) {
					if (c == '{')
						state = S1;
				} else if (state == S1) {
					if (c == '}' || c == -1) {
						return m;
					} else if (c == '/') {
						skipCommentsAndSpace(r.unread());
					} else if (! Character.isWhitespace(c)) {
						r.unread();
						currAttrLine= r.getLine();
						currAttrCol = r.getColumn();
						boolean hasFlag = c == '(';
						if (hasFlag)
							r.read(2);
						currAttr = parseString(r, hasFlag);
						if (currAttr == null)  // Value was '%00'
							return null;
						state = S3;
					}
				} else if (state == S3) {
					if (c == '=')
						state = S4;
					else if (c == -1 || c == '&' || c == ',' || c == '}') {
						m.put(currAttr, null);
						if (c == '}' || c == -1)
							return m;
						state = S1;
					}
				} else if (state == S4) {
					if (c == '/') {
						skipCommentsAndSpace(r.unread());
					} else if (c == -1 || c == '&' || c == ',' || c == '}') {
						if (! currAttr.equals("_class")) {
							BeanPropertyMeta pMeta = m.getPropertyMeta(currAttr);
							if (pMeta == null) {
								onUnknownProperty(currAttr, m, currAttrLine, currAttrCol);
							} else {
								Object value = beanContext.convertToType("", pMeta.getClassType());
								pMeta.set(m, value);
							}
						}
						if (c == -1 || c == '}')
							return m;
						state = S1;
					} else if (! Character.isWhitespace(c)) {
						if (! currAttr.equals("_class")) {
							BeanPropertyMeta pMeta = m.getPropertyMeta(currAttr);
							if (pMeta == null) {
								onUnknownProperty(currAttr, m, currAttrLine, currAttrCol);
								parseAnything(OBJECT, ctx, r.unread(), null, false); // Read content anyway to ignore it
							} else {
								Object value = parseAnything(pMeta.getClassType(), ctx, r.unread(), pMeta, false);
								pMeta.set(m, value);
							}
						}
						state = S5;
					}
				} else if (state == S5) {
					if (c == ',' || c == '&')
						state = S1;
					else if (c == '/')
						skipCommentsAndSpace(r.unread());
					else if (c == '}' || c == -1) {
						return m;
					}
				}
			}
			isInEscape = (c == '\\' && ! isInEscape);
		}
		if (state == S0)
			throw new ParseException(line, column, "Expected '{' at beginning of object.");
		if (state == S1)
			throw new ParseException(line, column, "Could not find attribute name on object.");
		if (state == S3)
			throw new ParseException(line, column, "Could not find '=' following attribute name on object.");
		if (state == S4)
			throw new ParseException(line, column, "Expected one of the following characters: {,[,',\",LITERAL.");
		if (state == S5)
			throw new ParseException(line, column, "Could not find '}' marking end of object.");

		return null; // Unreachable.
	}

	private Object parseObject(UrlEncodingParserContext ctx, ParserReader r, boolean isTop) throws ParseException, IOException {

		String s = parseArg(r);
		int c = r.peek();

		// Special case when we're parsing the input as an unknown type and the string contains
		// '=' or '&' meaning it's a map.
		if (isTop && (c == '=' || c == '&')) {
			StringWriter sw = new StringWriter().append(s);
			IOUtils.pipe(r, sw, false, false);
			r = new ParserStringReader(sw.toString());
			ObjectMap m = new ObjectMap();
			parseIntoMap2(ctx, r, m, STRING, OBJECT);
			return m.cast();
		}

		if (s == null)
			return null;
		if (s.length() > 0) {
			if (s.equals("%00"))
				return null;
			return decode(s);
		}
		return "";
	}

	// Parses the next token up to the next delimiter character (, &, } ] =).
	// Does not do any decoding yet.
	private String parseArg(ParserReader r) throws IOException  {
		r.mark();
		int c = 0;
		boolean isInEscape = false;
		while (c != -1) {
			c = r.read();
			if (! isInEscape) {
				if (c == ',' || c == '&' || c == '}' || c == ']' || c == '=') {
					r.unread();
					c = -1;
				}
			}
			isInEscape = c == '\\' && ! isInEscape;
		}
		return r.getFromMarked();
	}

	private String parseString(ParserReader r, boolean hasFlag) throws IOException {
		String s = parseArg(r);

		if (s.length() > 0) {
			if (s.equals("%00") && ! hasFlag)
				return null;
		}

		s = decode(s);

		return s;
	}

	private String decode(String s) throws IOException {

		// Decode if necessary.
		boolean isEncoded = false;
		for (int i = 0; i < s.length() && ! isEncoded; i++) {
			char c = s.charAt(i);
			if (c == '%' || c == '+')
				isEncoded = true;
		}
		if (isEncoded)
			s = URLDecoder.decode(s, "UTF-8");

		if (s.indexOf('\\') != -1) {
			StringBuilder sb = new StringBuilder(s.length());
			boolean isInEscape = false;
			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (c == '\\' && ! isInEscape)
					isInEscape = true;
				else {
					sb.append(c);
					isInEscape = false;
				}
			}
			s = sb.toString();
		}

		return s;
	}

	private ParserReader wrapReader(Reader in) {
		if (in instanceof ParserReader)
			return (ParserReader)in;
		return new ParserReader(in, 1024);
	}

	/*
	 * Looks for the keywords true, false, or null.
	 * Throws an exception if any of these keywords are not found at the specified position.
	 */
	private void parseKeyword(String keyword, ParserReader r) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();
		try {
			String s = r.read(keyword.length());
			if (s.equals(keyword))
				return;
			throw new ParseException(line, column, "Unrecognized syntax.  Expected '%s', actual '%s'.", keyword, s);
		} catch (IndexOutOfBoundsException e) {
			throw new ParseException(line, column, "Unrecognized syntax.  Expected '%s'.", keyword);
		}
	}

	/*
	 * Doesn't actually parse anything, but moves the position beyond any whitespace or comments.
	 * If positionOnNext is 'true', then the cursor will be set to the point immediately after
	 * the comments and whitespace.  Otherwise, the cursor will be set to the last position of
	 * the comments and whitespace.
	 */
	private void skipCommentsAndSpace(ParserReader r) throws ParseException, IOException {
		int c = 0;
		while ((c = r.read()) != -1) {
			if (! Character.isWhitespace(c)) {
				if (c == '/')
					skipComments(r);
				else {
					r.unread();
					return;
				}
			}
		}
	}

	/*
	 * Doesn't actually parse anything, but when positioned at the beginning of comment,
	 * it will move the pointer to the last character in the comment.
	 */
	private void skipComments(ParserReader r) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();
		int c = r.read();
		//  "/* */" style comments
		if (c == '*') {
			while (c != -1)
				if (r.read() == '*')
					if (r.read() == '/')
						return;
		//  "//" style comments
		} else if (c == '/') {
			while (c != -1) {
				c = r.read();
				if (c == -1 || c == '\n')
					return;
			}
		}
		throw new ParseException(line, column, "Open ended comment.");
	}

	/*
	 * Call this method after you've finished a parsing a string to make sure that if there's any
	 * remainder in the input, that it consists only of whitespace and comments.
	 */
	private void validateEnd(ParserReader r) throws ParseException, IOException {
		skipCommentsAndSpace(r);
		int c = r.read();
		if (c != -1)
			throw new ParseException(r.getLine(), r.getColumn(), "Remainder after parse: ["+(char)c+"]");
	}

	/**
	 * Parses the specified query string and returns the list of parameter names found.
	 * <p>
	 * 	This method will also return query parameters without values (e.g. <js>"?foo&bar"</js>).
	 * @param queryString The query string such as that returned by {@link HttpServletRequest#getQueryString()}
	 * @return The set of parameter names found in the query strings.
	 * @throws ParseException If a syntax error was found in the query string.
	 */
	public Set<String> getParameterNames(String queryString) throws ParseException {
		Set<String> set = new LinkedHashSet<String>();
		if (queryString == null)
			return set;
		if (queryString.startsWith("?"))
			queryString = queryString.substring(1);

		try {
			ParserReader r = new ParserStringReader(queryString);

			// &foo&bar=xxx
			int S1=1; // Looking for attrName start.
			int S3=3; // Found attrName end, looking for = or &.
			int S4=4; // Found =, looking for & or END.
			int S5=5; // Looking for END
			boolean isInEscape = false;

			int state = S1;
			String currAttr = "";
			int c = 0;
			while (c != -1) {
				c = r.read();
				if (! isInEscape) {
					if (state == S1) {
						if (c == -1) {
							return set;
						} else if (! Character.isWhitespace(c)) {
							r.unread();
							boolean hasFlag = c == '(';
							if (hasFlag)
								r.read(3);
							currAttr = parseString(r, hasFlag);
							if (currAttr == null)  // Value was '%00'
								return set;
							set.add(currAttr);
							state = S3;
						}
					} else if (state == S3) {
						if (c == '=')
							state = S4;
						else if (c == '&')
							state = S1;
						else if (c == -1)
							return set;
					} else if (state == S4) {
						if (c == '&')
							state = S1;
						else if (c == -1)
							return set;
					} else if (state == S5) {
						if (c == '&')
							state = S1;
						else if (c == -1) {
							return set;
						}
					}
				}
				isInEscape = (c == '\\' && ! isInEscape);
			}
			if (state == S1)
				throw new ParseException("Could not find attribute name on object.");
			if (state == S3)
				throw new ParseException("Could not find '=' following attribute name on object.");
			if (state == S4)
				throw new ParseException("Expected one of the following characters: {,[,',\",LITERAL.");
			if (state == S5)
				throw new ParseException("Could not find '}' marking end of object.");
		} catch (IOException e) {
			throw new ParseException(e);  // Won't happen, since we're parsing a string.
		}

		return null; // Unreachable.
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override
	public UrlEncodingParserContext createContext(ClassType<?> type, ObjectMap properties, String mediaType, String charset) throws ParseException {
		return new UrlEncodingParserContext(type, beanContext, pp, properties, mediaType, charset);
	}

	@Override // IParser
	public <T> T parse(Reader r, ClassType<T> type, ParserContext ctx) throws ParseException, IOException {
		if (! (ctx instanceof UrlEncodingParserContext))
			throw new ParseException("Context is not an instance of UrlEncodingParserContext");
		UrlEncodingParserContext ctx2 = (UrlEncodingParserContext)ctx;
		type = beanContext.normalizeClassType(type);
		ParserReader r2 = wrapReader(r);
		T o = parseAnything(type, ctx2, r2, null, true);
		validateEnd(r2);
		return o;
	}

	@Override // IParser
	public UrlEncodingParser setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public UrlEncodingParser setProperties(ObjectMap properties) throws LockedException {
		super.setProperties(properties);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public UrlEncodingParser addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public UrlEncodingParser addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public UrlEncodingParser addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public <T> UrlEncodingParser addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}


	@Override // IParser, Lockable
	public UrlEncodingParser lock() {
		super.lock();
		return this;
	}

	@Override // IParser, Lockable
	public UrlEncodingParser clone() {
		try {
			return (UrlEncodingParser)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
