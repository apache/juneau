package com.ibm.juno.server.annotation;

/**
 * Denotes possible values for {@link Property#type()}
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public enum PropertyType {

	/** Normal property type. */
	NORMAL,

	/** Property value denotes an entry in a resource bundle. */
	NLS,

	/** Property value denotes a system property key. */
	SYSTEM
}
