/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.server.jaxrs;

import javax.ws.rs.*;
import javax.ws.rs.ext.*;

import com.ibm.juno.core.json.*;

/**
 * JAX-RS provider for JSON support using the Juno JSON serializer and parser.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Provider
@Produces({"application/json","text/json"})
@Consumes({"application/json","text/json"})
@JunoProvider(
	serializers=JsonSerializer.class,
	parsers=JsonParser.class
)
public final class JsonProvider extends BaseProvider {}

