/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.server;

import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.server.annotation.*;

/**
 * Configurable properties for the {@link RestServlet} class.
 * <p>
 * Properties can be set on the {@link RestServlet} class using the {@link RestResource#properties} or {@link RestMethod#properties} annotations.
 * <p>
 * These properties can also be passed in as servlet init parameters.
 * <p>
 * These properties are only valid at the class level, not the method level.  Setting them on {@link RestMethod#properties()} has no effect.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public final class RestServletProperties {

	/**
	 * Allow header URL parameters ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * When enabled, headers such as <js>"Accept"</js> and <js>"Content-Type"</js> to be passed in as URL query parameters.
	 * For example:  <js>"?Accept=text/json&Content-Type=text/json"</js>
	 * <p>
	 * Parameter names are case-insensitive.
	 * <p>
	 * Useful for debugging REST interface using only a browser.
	 */
	public static final String ALLOW_HEADER_PARAMS = "RestServlet.allowHeaderParams";

	/**
	 * Allow <js>"method"</js> URL parameter ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * When enabled, the HTTP method can be overrided by passing in a <js>"method"</js> URL parameter.
	 * For example:  <js>"?method=OPTIONS"</js>
	 * <p>
	 * This option is required to allow the <code>options</code> link to get rendered in the HTML view.
	 * <p>
	 * Parameter name is case-insensitive.
	 * <p>
	 * Useful for debugging non-GET methods using only a browser.
	 */
	public static final String ALLOW_METHOD_PARAM = "RestServlet.allowMethodParam";

	/**
	 * Allow <js>"content"</js> URL parameter ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * When enabled, the HTTP body content on PUT and POST requests can be passed in as text using the <js>"content"</js> URL parameter.
	 * For example:  <js>"?content={name:'John%20Smith',age:45}"</js>
	 * <p>
	 * Parameter name is case-insensitive.
	 * <p>
	 * Useful for debugging PUT and POST methods using only a browser.
	 */
	public static final String ALLOW_CONTENT_PARAM = "RestServlet.allowContentParam";

	/**
	 * Render stack traces in HTTP response bodies when errors occur ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * When enabled, Java stack traces will be rendered in the output response.
	 * Useful for debugging, although allowing stack traces to be rendered may cause security concerns.
	 */
	public static final String RENDER_RESPONSE_STACK_TRACES = "RestServlet.renderResponseStackTraces";

	/**
	 * Use stack trace hashes ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * When enabled, the number of times an exception has occurred will be determined based on stack trace hashsums,
	 * made available through the {@link RestException#getOccurrence()} method.
	 */
	public static final String USE_STACK_TRACE_HASHES = "RestServlet.useStackTraceHashes";

	/**
	 * Trim trailing slashes from request URIs ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * When enabled, URLs returned by {@link RestRequest#getRequestURI()} will have trailing slashes
	 * 	trimmed (e.g. <js>".../foo"</js> instead of <js>".../foo/"</js>).
	 */
	public static final String TRIM_TRAILING_REQUEST_URI_SLASHES = "RestServlet.trimTrailingUriSlashes";

	/**
	 * Return blanks for null path infos ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * When enabled, the path info returned by {@link RestRequest#getPathInfo()} will return an empty
	 * 	string in place of a <jk>null</js>.
	 */
	public static final String PATH_INFO_BLANK_FOR_NULL = "RestServlet.pathInfoBlankForNull";

	/**
	 * Specify the classpath folder containing externally-addressable hypertext documents ({@link String}, default=<js>"htdocs"</js>).
	 * <p>
	 * Servlets can specify subfolders that contain files that can be served up under a subpath.
	 * For example, for servlet <code>com.ibm.MyServlet</code> at URI <code>/myApp/myServlet</code> and <code>htDocsFolder</code>=<js>"xdocs"</js>, then
	 * 	the embedded file <js>"/com/ibm/MyServlet/xdocs/MyFile.html"</js> can be accessed through the URL <code>/myApp/myServlet/xdocs/MyFile.html</code>.
	 * <p>
	 * The <code>Content-Type</code> on the response is controlled by the {@link RestServlet#getMimetypesFileTypeMap()} method.
	 */
	public static final String HTDOCS_FOLDER = "RestServlet.htDocsFolder";


	//--------------------------------------------------------------------------------
	// Automatically added properties.
	//--------------------------------------------------------------------------------

	/**
	 * The request servlet path.
	 * <p>
	 * Automatically added to properties return by {@link RestServlet#createRequestProperties(com.ibm.juno.core.ObjectMap, RestRequest)}
	 * 	and are therefore available through {@link SerializerContext#getProperties()} and {@link ParserContext#getProperties()}.
	 * <p>
	 * Equivalent to the value returned by {@link RestRequest#getServletPath()}
	 */
	public static final String URI_SERVLET_PATH = "RestServlet.servletPath";

	/**
	 * The request URI path info.
	 * <p>
	 * Automatically added to properties return by {@link RestServlet#createRequestProperties(com.ibm.juno.core.ObjectMap, RestRequest)}
	 * 	and are therefore available through {@link SerializerContext#getProperties()} and {@link ParserContext#getProperties()}.
	 * <p>
	 * Equivalent to the value returned by {@link RestRequest#getPathInfo()}
	 */
	public static final String URI_PATH_INFO = "RestServlet.pathInfo";

	/**
	 * The request URI.
	 * <p>
	 * Automatically added to properties return by {@link RestServlet#createRequestProperties(com.ibm.juno.core.ObjectMap, RestRequest)}
	 * 	and are therefore available through {@link SerializerContext#getProperties()} and {@link ParserContext#getProperties()}.
	 * <p>
	 * Equivalent to the value returned by {@link RestRequest#getRequestURI()}
	 */
	public static final String URI_REQUEST = "RestServlet.requestURI";

	/**
	 * The request method.
	 * <p>
	 * Automatically added to properties return by {@link RestServlet#createRequestProperties(com.ibm.juno.core.ObjectMap, RestRequest)}
	 * 	and are therefore available through {@link SerializerContext#getProperties()} and {@link ParserContext#getProperties()}.
	 * <p>
	 * Equivalent to the value returned by {@link RestRequest#getMethod()}
	 */
	public static final String METHOD = "RestServlet.method";
}
