/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2013, 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.urlencoding;

import static com.ibm.juno.core.urlencoding.UrlEncodingParserProperties.*;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import javax.servlet.http.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.utils.*;

/**
 * Parses URL-encoded text into POJO models.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Content-Type</code> types: <code>application/x-www-form-urlencoded</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This parser uses a state machine, which makes it very fast and efficient.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link UrlEncodingParserProperties}
 * 	<li>{@link ParserProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@Consumes("application/x-www-form-urlencoded")
public class UrlEncodingParser extends ReaderParser {

	/** Reusable instance of {@link UrlEncodingParser}, all default settings. */
	public static final UrlEncodingParser DEFAULT = new UrlEncodingParser().lock();

	/** Reusable instance of {@link UrlEncodingParser.Decoding}. */
	public static final UrlEncodingParser DEFAULT_ENCODED = new Decoding().lock();

	/**
	 * Equivalent to <code><jk>new</jk> UrlEncodingParser().setProperty(<jsf>DECODE_CHARS</jsf>,<jk>true</jk>);</code>.
	 */
	public static class Decoding extends UrlEncodingParser {
		/** Constructor */
		public Decoding() {
			setProperty(DECODE_CHARS, true);
		}
	}

	/** URL-encoding parser properties currently set on this serializer. */
	protected transient UrlEncodingParserProperties upp = new UrlEncodingParserProperties();

	private Object[] parseArgs(UrlEncodingParserContext ctx, ParserReader r, ClassMeta<?>[] argTypes) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		final int S1=1; // Looking for start of entry
		final int S2=2; // Looking for , or )

		Object[] o = new Object[argTypes.length];
		int i = 0;

		int c = r.read();
		if (c == -1)
			return null;
		if (c != '(')
			throw new ParseException("Expected '(' at beginning of args array.");

		int state = S1;
		while (c != -1) {
			c = r.read();
			if (state == S1) {
				if (c == ')')
					return o;
				o[i] = parseAnything(argTypes[i], ctx, r.unread(), null, true, null);
				i++;
				state = S2;
			} else if (state == S2) {
				if (c == ',') {
					state = S1;
				} else if (c == ')') {
					return o;
				}
			}
		}

		throw new ParseException(line, column, "Did not find ')' at the end of args array.");
	}

	private <T> T parseAnything(ClassMeta<T> nt, UrlEncodingParserContext ctx, ParserReader r, BeanPropertyMeta p, boolean isTop, Object outer) throws ParseException {

		BeanContext bc = ctx.getBeanContext();
		if (nt == null)
			nt = (ClassMeta<T>)object();
		PojoFilter<T,Object> filter = getPojoFilter(p, nt);
		ClassMeta<?> ft = getFilteredType(filter, nt);

		int line = r.getLine();
		int column = r.getColumn();
		Object o = null;
		try {
			// Parse type flag '$x'
			char flag = readFlag(r, (char)0);

			int c = r.peek();

			if (c == -1) {
				// End of output.
				o = "";
			} else if (ft.isObject()) {
				if (flag == 0) {
					o = parseString(r, isTop);
				} else if (flag == 'b') {
					o = parseBoolean(r);
				} else if (flag == 'n') {
					o = parseNumber(r, null);
				} else if (flag == 'o') {
					ObjectMap m = new ObjectMap();
					parseIntoMap2(ctx, r, m, string(), object());
					o = m.cast();
				} else if (flag == 'a') {
					Collection l = new ObjectList();
					o = parseIntoCollection2(ctx, r, l, ft.getElementType());
				} else {
					throw new ParseException(line, column, "Unexpected flag character ''{0}''.", flag);
				}
			} else if (ft.isBoolean()) {
				o = parseBoolean(r);
			} else if (ft.isCharSequence()) {
				o = parseString(r, isTop);
			} else if (ft.isChar()) {
				String s = parseString(r, isTop);
				o = s == null ? null : s.charAt(0);
			} else if (ft.isNumber()) {
				o = parseNumber(r, (Class<? extends Number>)ft.getInnerClass());
			} else if (ft.isMap()) {
				Map m = (ft.canCreateNewInstance(outer) ? (Map)ft.newInstance(outer) : new ObjectMap());
				o = parseIntoMap2(ctx, r, m, ft.getKeyType(), ft.getValueType());
			} else if (ft.isCollection()) {
				if (flag == 'o') {
					ObjectMap m = new ObjectMap();
					parseIntoMap2(ctx, r, m, string(), object());
					o = m.cast();
				} else {
					Collection l = (ft.canCreateNewInstance(outer) ? (Collection)ft.newInstance(outer) : new ObjectList());
					o = parseIntoCollection2(ctx, r, l, ft.getElementType());
				}
			} else if (ft.canCreateNewBean(outer)) {
				BeanMap m = bc.newBeanMap(outer, ft.getInnerClass());
				m = parseIntoBeanMap2(ctx, r, m);
				o = m == null ? null : m.getBean();
			} else if (ft.canCreateNewInstanceFromString(outer)) {
				String s = parseString(r, isTop);
				if (s != null)
					o = ft.newInstanceFromString(outer, s);
			} else if (ft.isArray()) {
				if (flag == 'o') {
					ObjectMap m = new ObjectMap();
					parseIntoMap2(ctx, r, m, string(), object());
					o = m.cast();
				} else {
					ArrayList l = (ArrayList)parseIntoCollection2(ctx, r, new ArrayList(), ft.getElementType());
					o = bc.toArray(ft, l);
				}
			} else if (flag == 'o') {
				// It could be a non-bean with _class attribute.
				ObjectMap m = new ObjectMap();
				parseIntoMap2(ctx, r, m, string(), object());
				if (m.containsKey("_class"))
					o = m.cast();
				else
					throw new ParseException(line, column, "Class ''{0}'' could not be instantiated.  Reason: ''{1}''", ft.getInnerClass().getName(), ft.getNotABeanReason());
			} else {
				throw new ParseException(line, column, "Class ''{0}'' could not be instantiated.  Reason: ''{1}''", ft.getInnerClass().getName(), ft.getNotABeanReason());
			}

			if (filter != null && o != null)
				o = filter.unfilter(o, nt);

			return (T)o;

		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			if (p == null)
				throw new ParseException("Error occurred trying to parse into class ''{0}''", ft).initCause(e);
			throw new ParseException("Error occurred trying to parse value for bean property ''{0}'' on class ''{1}''",
				p.getName(), p.getBeanMeta().getClassMeta()
			).initCause(e);
		}
	}

	private <K,V> Map<K,V> parseIntoMap2(UrlEncodingParserContext ctx, ParserReader r, Map<K,V> m, ClassMeta<K> keyType, ClassMeta<V> valueType) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		if (keyType == null)
			keyType = (ClassMeta<K>)string();

		int c = r.read();
		if (c == -1 || c == '\u0000')
			return null;
		if (c != '(')
			throw new ParseException(line, column, "Expected '(' at beginning of object.");

		final int S1=1; // Looking for attrName start.
		final int S2=2; // Found attrName end, looking for :.
		final int S3=3; // Found :, looking for valStart.
		final int S4=4; // Looking for , or )
		boolean isInEscape = false;

		int state = S1;
		K currAttr = null;
		while (c != -1) {
			c = r.read();
			if (! isInEscape) {
				if (state == S1) {
					if (c == ')' || c == -1)
						return m;
					currAttr = parseAnything(keyType, ctx, r.unread(), null, false, m);
					state = S2;
					c = 0; // Avoid isInEscape if c was '\'
				} else if (state == S2) {
					if (c == '=')
						state = S3;
					else if (c == -1 || c == ',' || c == ')') {
						if (currAttr == null) {
							// Value was '%00'
							r.unread();
							return null;
						}
						m.put(currAttr, null);
						if (c == ')' || c == -1)
							return m;
						state = S1;
					}
				} else if (state == S3) {
					if (c == -1 || c == ',' || c == ')') {
						V value = convertAttrToType(m, "", valueType);
						m.put(currAttr, value);
						if (c == -1 || c == ')')
							return m;
						state = S1;
					} else  {
						V value = parseAnything(valueType, ctx, r.unread(), null, false, m);
						m.put(currAttr, value);
						state = S4;
						c = 0; // Avoid isInEscape if c was '\'
					}
				} else if (state == S4) {
					if (c == ',')
						state = S1;
					else if (c == ')' || c == -1) {
						return m;
					}
				}
			}
			isInEscape = (c == '\\' && ! isInEscape);
		}
		if (state == S1)
			throw new ParseException(line, column, "Could not find attribute name on object.");
		if (state == S2)
			throw new ParseException(line, column, "Could not find '=' following attribute name on object.");
		if (state == S3)
			throw new ParseException(line, column, "Dangling '=' found in object entry");
		if (state == S4)
			throw new ParseException(line, column, "Could not find ')' marking end of object.");

		return null; // Unreachable.
	}

	private <E> Collection<E> parseIntoCollection2(UrlEncodingParserContext ctx, ParserReader r, Collection<E> l, ClassMeta<E> elementType) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		int c = r.read();
		if (c == -1 || c == '\u0000')
			return null;
		if (c != '(')
			throw new ParseException(line, column, "Expected '(' at beginning of array.");

		final int S1=1; // Looking for starting of first entry.
		final int S2=2; // Looking for starting of subsequent entries.
		final int S3=3; // Looking for , or ) after first entry.
		final int S4=4; // Looking for , or ) after subsequent entries.
		boolean isInEscape = false;

		int state = S1;
		while (c != -1) {
			c = r.read();
			if (! isInEscape) {
				if (state == S1 || state == S2) {
					if (c == ')') {
						if (state == S2) {
							l.add(parseAnything(elementType, ctx, r.unread(), null, false, l));
							r.read();
						}
						return l;
					}
					l.add(parseAnything(elementType, ctx, r.unread(), null, false, l));
					state = (state == S2 ? S4 : S3);
				} else if (state == S3 || state == S4) {
					if (c == ',') {
						state = S2;
					} else if (c == ')') {
						return l;
					}
				}
			}
			isInEscape = (c == '\\' && ! isInEscape);
		}
		if (state == S1 || state == S2)
			throw new ParseException(line, column, "Could not find start of entry in array.");
		if (state == S3 || state == S4)
			throw new ParseException(line, column, "Could not find end of entry in array.");

		return null;  // Unreachable.
	}

	private <T> BeanMap<T> parseIntoBeanMap2(UrlEncodingParserContext ctx, ParserReader r, BeanMap<T> m) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		int c = r.read();
		if (c == -1 || c == '\u0000')
			return null;
		if (c != '(')
			throw new ParseException(line, column, "Expected '(' at beginning of object.");

		final int S1=1; // Looking for attrName start.
		final int S2=2; // Found attrName end, looking for =.
		final int S3=3; // Found =, looking for valStart.
		final int S4=4; // Looking for , or }
		boolean isInEscape = false;

		int state = S1;
		String currAttr = "";
		int currAttrLine = -1, currAttrCol = -1;
		while (c != -1) {
			c = r.read();
			if (! isInEscape) {
				if (state == S1) {
					if (c == ')' || c == -1) {
						return m;
					}
					r.unread();
					currAttrLine= r.getLine();
					currAttrCol = r.getColumn();
					currAttr = parseString(r, false);
					if (currAttr == null)  // Value was '%00'
						return null;
					state = S2;
				} else if (state == S2) {
					if (c == '=')
						state = S3;
					else if (c == -1 || c == ',' || c == ')') {
						m.put(currAttr, null);
						if (c == ')' || c == -1)
							return m;
						state = S1;
					}
				} else if (state == S3) {
					if (c == -1 || c == ',' || c == ')') {
						if (! currAttr.equals("_class")) {
							BeanPropertyMeta pMeta = m.getPropertyMeta(currAttr);
							if (pMeta == null) {
								if (m.isSubTyped()) {
									m.put(currAttr, "");
								} else {
									onUnknownProperty(ctx, currAttr, m, currAttrLine, currAttrCol);
								}
							} else {
								Object value = ctx.getBeanContext().convertToType("", pMeta.getClassMeta());
								pMeta.set(m, value);
							}
						}
						if (c == -1 || c == ')')
							return m;
						state = S1;
					} else {
						if (! currAttr.equals("_class")) {
							BeanPropertyMeta pMeta = m.getPropertyMeta(currAttr);
							if (pMeta == null) {
								if (m.isSubTyped()) {
									m.put(currAttr, parseAnything(object(), ctx, r.unread(), null, false, m.getBean(false)));
								} else {
									onUnknownProperty(ctx, currAttr, m, currAttrLine, currAttrCol);
									parseAnything(object(), ctx, r.unread(), null, false, m.getBean(false)); // Read content anyway to ignore it
								}
							} else {
								Object value = parseAnything(pMeta.getClassMeta(), ctx, r.unread(), pMeta, false, m.getBean(false));
								pMeta.set(m, value);
							}
						}
						state = S4;
					}
				} else if (state == S4) {
					if (c == ',')
						state = S1;
					else if (c == ')' || c == -1) {
						return m;
					}
				}
			}
			isInEscape = (c == '\\' && ! isInEscape);
		}
		if (state == S1)
			throw new ParseException(line, column, "Could not find attribute name on object.");
		if (state == S2)
			throw new ParseException(line, column, "Could not find '=' following attribute name on object.");
		if (state == S3)
			throw new ParseException(line, column, "Could not find value following '=' on object.");
		if (state == S4)
			throw new ParseException(line, column, "Could not find ')' marking end of object.");

		return null; // Unreachable.
	}

	private String parseString(ParserReader r, boolean isTop) throws IOException {

		// If string is of form '(xxx)', we're looking for ')' at the end.
		// Otherwise, we're looking for ',' or ')' or -1 denoting the end of this string.

		r.mark();
		int c = r.peek();
		boolean isInParens = (c == '(');
		if (isInParens)
			r.read();

		boolean isInEscape = false;
		while (c != -1) {
			c = r.read();
			if (! isInEscape) {
				if (isInParens) {
					if (c == ')')
						c = -1;
				} else {
					if ((! isTop) && (c == ')' || c == ',' || c == '=')) {
						r.unread();
						c = -1;
					}
				}
			}
			isInEscape = c == '~' && ! isInEscape;
			if (isInEscape)
				r.delete();  // Remove '~' character from marking buffer.
		}

		if (isInParens)
			return r.getMarked(1, -1);

		String s = r.getMarked();
		if (s.equals("\u0000"))
			return null;

		return s;
	}

	private Boolean parseBoolean(ParserReader r) throws IOException, ParseException {
		readFlag(r, 'b');
		String s = parseString(r, false);
		if (s == null)
			return null;
		if (s.equals("true"))
			return true;
		if (s.equals("false"))
			return false;
		throw new ParseException(r.getLine(), r.getColumn(), "Unrecognized syntax for boolean.  ''{0}''.", s);
	}

	private Number parseNumber(ParserReader r, Class<? extends Number> c) throws IOException, ParseException {
		readFlag(r, 'n');
		String s = parseString(r, false);
		if (s == null)
			return null;
		return StringUtils.parseNumber(s, c);
	}

	/*
	 * Call this method after you've finished a parsing a string to make sure that if there's any
	 * remainder in the input, that it consists only of whitespace and comments.
	 */
	private void validateEnd(ParserReader r) throws ParseException, IOException {
		int c = r.read();
		if (c != -1)
			throw new ParseException(r.getLine(), r.getColumn(), "Remainder after parse: ''{0}''.", (char)c);
	}

	/**
	 * Parses the specified query string and returns the list of parameter names found.
	 * <p>
	 * 	This method will also return query parameters without values (e.g. <js>"?foo&bar"</js>).
	 * @param queryString The query string such as that returned by {@link HttpServletRequest#getQueryString()}
	 * @return The set of parameter names found in the query strings.
	 * @throws ParseException If a syntax error was found in the query string.
	 */
	public Set<String> getEmptyParameterNames(String queryString) throws ParseException {
		Set<String> set = new LinkedHashSet<String>();
		if (queryString == null)
			return set;
		if (queryString.startsWith("?"))
			queryString = queryString.substring(1);

		ParserReader r = new ParserReader(queryString);
		try {

			// &foo&bar=xxx
			int S1=1; // Looking for attrName start.
			int S2=2; // Found attrName end, looking for = or &.
			int S3=3; // Found =, looking for & or END.
			boolean isInEscape = false;

			int state = S1;
			String currAttr = "";
			int c = 0;
			while (c != -1) {
				c = r.read();
				if (! isInEscape) {
					if (state == S1) {
						if (c == -1)
							return set;
						r.unread();
						r.mark();
						state = S2;
					} else if (state == S2) {
						if (c == '=')
							state = S3;
						else if (c == '&' || c == -1) {
							currAttr = decode(r.getMarked(0, c == -1 ? 0 : -1));
							set.add(currAttr);
							if (c == '&')
								state = S1;
							else if (c == -1)
								return set;
						}
					} else if (state == S3) {
						if (c == '&' || c == -1) {
							if (c == '&')
								state = S1;
							else if (c == -1)
								return set;
						}
					}
				}
				isInEscape = (c == '\\' && ! isInEscape);
				if (isInEscape)
					r.delete();
			}
			if (state == S1)
				throw new ParseException("Could not find attribute name on object.");
			if (state == S2)
				throw new ParseException("Could not find '=' following attribute name on object.");
			if (state == S3)
				throw new ParseException("Expected one of the following characters: {,[,',\",LITERAL.");
		} catch (IOException e) {
			throw new ParseException(e);  // Won't happen, since we're parsing a string.
		} finally {
			try {
				r.close();
			} catch (IOException e) {
				throw new ParseException(e);
			}
		}

		return null; // Unreachable.
	}

	private String decode(String s) throws IOException {
		if (s.isEmpty())
			return s;
		char c = s.charAt(0);
		boolean needsDecode = (c == '$' || c == '(');

		for (int i = 0; i < s.length() && ! needsDecode; i++) {
			c = s.charAt(i);
			if (c == '%' || c == '+')
				needsDecode = true;
		}

		if (! needsDecode)
			return s;

		return parseString(new UrlEncodingParserReader(wrapReader(s), Math.min(8096, s.length()), upp.decodeChars), true);
	}

	/**
	 * Reads flag character from "$x(" construct if flag is present.
	 * Returns 0 if no flag is present.
	 */
	private char readFlag(ParserReader r, char expected) throws IOException, ParseException {
		char c = (char)r.peek();
		if (c == '$') {
			r.read();
			char f = (char)r.read();
			if (expected != 0 && f != expected)
				throw new ParseException(r.getLine(), r.getColumn(), "Unexpected flag character: ''{0}''.  Expected ''{1}''.", f, expected);
			c = (char)r.peek();
			// Type flag must be followed by '('
			if (c != '(')
				throw new ParseException(r.getLine(), r.getColumn(), "Unexpected character following flag: ''{0}''.", c);
			return f;
		}
		return 0;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Parser
	public UrlEncodingParserContext createContext(ObjectMap properties, Method javaMethod) {
		return new UrlEncodingParserContext(getBeanContext(), pp, upp, properties, javaMethod);
	}

	@Override // Parser
	protected <T> T doParse(Reader in, int estimatedSize, ClassMeta<T> type, ParserContext ctx) throws ParseException, IOException {
		UrlEncodingParserContext uctx = (UrlEncodingParserContext)ctx;
		type = ctx.getBeanContext().normalizeClassMeta(type);
		UrlEncodingParserReader r = uctx.getUrlEncodingParserReader(in, estimatedSize);
		T o = parseAnything(type, uctx, r, null, true, null);
		validateEnd(r);
		return o;
	}

	@Override // ReaderParser
	protected <K,V> Map<K,V> doParseIntoMap(Reader in, int estimatedSize, Map<K,V> m, Type keyType, Type valueType, ParserContext ctx) throws ParseException, IOException {
		UrlEncodingParserContext uctx = (UrlEncodingParserContext)ctx;
		UrlEncodingParserReader r = uctx.getUrlEncodingParserReader(in, estimatedSize);
		readFlag(r, 'o');
		m = parseIntoMap2(uctx, r, m, ctx.getBeanContext().getClassMeta(keyType), ctx.getBeanContext().getClassMeta(valueType));
		validateEnd(r);
		return m;
	}

	@Override // ReaderParser
	protected <E> Collection<E> doParseIntoCollection(Reader in, int estimatedSize, Collection<E> c, Type elementType, ParserContext ctx) throws ParseException, IOException {
		UrlEncodingParserContext uctx = (UrlEncodingParserContext)ctx;
		UrlEncodingParserReader r = uctx.getUrlEncodingParserReader(in, estimatedSize);
		readFlag(r, 'a');
		c = parseIntoCollection2(uctx, r, c, ctx.getBeanContext().getClassMeta(elementType));
		validateEnd(r);
		return c;
	}

	@Override // ReaderParser
	protected Object[] doParseArgs(Reader in, int estimatedSize, ClassMeta<?>[] argTypes, ParserContext ctx) throws ParseException, IOException {
		UrlEncodingParserContext uctx = (UrlEncodingParserContext)ctx;
		UrlEncodingParserReader r = uctx.getUrlEncodingParserReader(in, estimatedSize);
		readFlag(r, 'a');
		Object[] a = parseArgs(uctx, r, argTypes);
		return a;
	}

	@Override // Parser
	public UrlEncodingParser setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (! upp.setProperty(property, value))
			super.setProperty(property, value);
		return this;
	}

	@Override // CoreApi
	public UrlEncodingParser setProperties(ObjectMap properties) throws LockedException {
		for (Map.Entry<String,Object> e : properties.entrySet())
			setProperty(e.getKey(), e.getValue());
		return this;
	}

	@Override // CoreApi
	public UrlEncodingParser addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public UrlEncodingParser addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> UrlEncodingParser addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // Lockable
	public UrlEncodingParser lock() {
		super.lock();
		return this;
	}

	@Override // Lockable
	public UrlEncodingParser clone() {
		try {
			UrlEncodingParser c = (UrlEncodingParser)super.clone();
			c.upp = upp.clone();
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
