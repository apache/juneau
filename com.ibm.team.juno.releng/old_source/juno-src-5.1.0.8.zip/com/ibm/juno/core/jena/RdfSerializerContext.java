/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.jena;

import static com.ibm.juno.core.jena.Constants.*;
import static com.ibm.juno.core.jena.RdfProperties.*;
import static com.ibm.juno.core.jena.RdfSerializerProperties.*;

import java.lang.reflect.*;
import java.util.*;

import com.hp.hpl.jena.rdf.model.*;
import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Context object that lives for the duration of a single serialization of {@link RdfSerializer}.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public final class RdfSerializerContext extends XmlSerializerContext {

	final String rdfLanguage;
	final Namespace junoNs, junoBpNs;
	final boolean addLiteralTypes, addRootProperty;
	final Property pRoot, pValue, pClass;
	final Model model;
	final RDFWriter writer;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param jsp Default Jena serializer properties.
	 * @param op Override properties.
	 * @param javaMethod Java method that invoked this serializer.
	 * 	When using the REST API, this is the Java method invoked by the REST call.
	 * 	Can be used to access annotations defined on the method or class.
	 */
	protected RdfSerializerContext(BeanContext beanContext, SerializerProperties sp, XmlSerializerProperties xsp, RdfSerializerProperties jsp, ObjectMap op, Method javaMethod) {
		super(beanContext, sp, xsp, op, javaMethod);
		ObjectMap jenaSettings = new ObjectMap();
		jenaSettings.put("tab", isUseIndentation() ? 2 : 0);
		jenaSettings.put("attributeQuoteChar", Character.toString(getQuoteChar()));
		jenaSettings.putAll(jsp.jenaSettings);
		if (op == null || op.isEmpty()) {
			this.rdfLanguage = jsp.rdfLanguage;
			this.junoNs = jsp.junoNs;
			this.junoBpNs = jsp.junoBpNs;
			this.addLiteralTypes = jsp.addLiteralTypes;
			this.addRootProperty = jsp.addRootProperty;
		} else {
			this.rdfLanguage = op.getString(RDF_LANGUAGE, jsp.rdfLanguage);
			this.junoNs = (op.containsKey(JUNO_NS) ? NamespaceFactory.parseNamespace(op.get(JUNO_NS)) : jsp.junoNs);
			this.junoBpNs = (op.containsKey(JUNO_BEAN_PROP_NS) ? NamespaceFactory.parseNamespace(op.get(JUNO_BEAN_PROP_NS)) : jsp.junoBpNs);
			this.addLiteralTypes = op.getBoolean(ADD_LITERAL_TYPES, jsp.addLiteralTypes);
			this.addRootProperty = op.getBoolean(ADD_ROOT_PROPERTY, jsp.addRootProperty);
			for (Map.Entry<String,Object> e : op.entrySet()) {
				String key = e.getKey();
				if (key.startsWith("RdfSerializer.")) {
					key = key.substring(14);
					if (key.startsWith("jena."))
						jenaSettings.put(key.substring(5), e.getValue());
 				}
			}
		}
		this.model = ModelFactory.createDefaultModel();
		addModelPrefix(junoNs);
		addModelPrefix(junoBpNs);
		for (Namespace ns : this.getNamespaces())
			addModelPrefix(ns);
		this.pRoot = model.createProperty(junoNs.getUri(), JUNO_NS_ROOT);
		this.pValue = model.createProperty(junoNs.getUri(), JUNO_NS_VALUE);
		this.pClass = model.createProperty(junoNs.getUri(), JUNO_NS_CLASS);
		writer = model.getWriter(rdfLanguage);

		// Note: NTripleWriter throws an exception if you try to set any properties on it.
		if (! rdfLanguage.equals(LANG_NTRIPLE)) {
			for (Map.Entry<String,Object> e : jenaSettings.entrySet())
				writer.setProperty(e.getKey(), e.getValue());
		}
	}

	/**
	 * Adds the specified namespace as a model prefix.
	 * @param ns The XML namespace.
	 */
	public void addModelPrefix(Namespace ns) {
		model.setNsPrefix(ns.getName(), ns.getUri());
	}
}
