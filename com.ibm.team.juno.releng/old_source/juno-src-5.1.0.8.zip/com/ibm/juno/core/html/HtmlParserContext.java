package com.ibm.juno.core.html;

import java.io.*;
import java.lang.reflect.*;

import javax.xml.stream.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.utils.*;

/**
 * Context object that lives for the duration of a single parsing of {@link HtmlParser}.
 * <p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public final class HtmlParserContext extends ParserContext {

	private XMLEventReader xmlEventReader;

	/**
	 * Create a new parser context with the specified options.
	 *
	 * @param beanContext The bean context being used.
	 * @param pp The default generic parser properties.
	 * @param hpp The default HTML parser properties.
	 * @param properties The override properties.
	 * @param javaMethod The java method that called this parser, usually the method in a REST servlet.
	 */
	public HtmlParserContext(BeanContext beanContext, ParserProperties pp, HtmlParserProperties hpp, ObjectMap properties, Method javaMethod) {
		super(beanContext, pp, properties, javaMethod);
	}

	/**
	 * Wraps the specified reader in an {@link XMLEventReader}.
	 * This event reader gets closed by the {@link #close()} method.
	 */
	protected XMLEventReader getReader(Reader in, int estimatedSize) throws ParseException {
		try {
			in = IOUtils.getBufferedReader(in, estimatedSize);
			XMLInputFactory factory = XMLInputFactory.newInstance();
			factory.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, false);
			this.xmlEventReader = factory.createXMLEventReader(in);
		} catch (Error e) {
			throw new ParseException(e.getLocalizedMessage());
		} catch (XMLStreamException e) {
			throw new ParseException(e);
		}
		return xmlEventReader;
	}

	@Override
	public void close() throws ParseException {
		if (xmlEventReader != null) {
			try {
				xmlEventReader.close();
			} catch (XMLStreamException e) {
				throw new ParseException(e);
			}
		}
		super.close();
	}
}
