/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.ini;

import java.io.*;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.*;

/**
 * Simply XOR+Base64 encoder for obscuring passwords and other sensitive data in INI config files.
 * <p>
 * This is not intended to be used as strong encryption.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("restriction")
public final class XorEncoder implements Encoder {
   private static final String key = "nuy7og796Vh6G9O6bG230SHK0cc8QYkH";	// The super-duper-secret key

	@Override
	public String encode(String in) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			OutputStream b64os = MimeUtility.encode(baos, "base64");

			for (int i = 0; i < in.length(); i++) {
				int j = i % key.length();
				b64os.write(in.charAt(i) ^ key.charAt(j));
			}

			b64os.close();
			return new String(baos.toByteArray(), "UTF-8");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public String decode(String in) {
		try {
			byte[] b = in.getBytes("UTF-8");
			ByteArrayInputStream bais = new ByteArrayInputStream(b);
			InputStream b64is = MimeUtility.decode(bais, "base64");
			byte[] tmp = new byte[b.length];

			int n = b64is.read(tmp);

			StringBuilder sb = new StringBuilder(n);
			for (int i = 0; i < n; i++) {
				int j = i % key.length();
				sb.append((char)(tmp[i] ^ key.charAt(j)));
			}

			return sb.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
