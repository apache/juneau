@XmlSchema(
	prefix="atom",
	xmlNs={
		@XmlNs(prefix="atom", namespaceURI="http://www.w3.org/2005/Atom/"),
		@XmlNs(prefix="xml", namespaceURI="http://www.w3.org/XML/1998/namespace")
	}
)
package com.ibm.juno.core.dto.atom;

import com.ibm.juno.core.xml.annotation.*;

