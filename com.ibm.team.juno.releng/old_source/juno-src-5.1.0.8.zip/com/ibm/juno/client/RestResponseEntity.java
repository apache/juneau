/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.client;

import java.io.*;

import org.apache.http.*;
import org.apache.http.entity.*;
import org.apache.http.message.*;

import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.utils.*;

/**
 * HttpEntity for serializing POJOs as the body of HTTP requests.
 * <p>
 * Internal class.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public final class RestResponseEntity extends BasicHttpEntity {
	final Object output;
	final RestCall restCall;

	/**
	 * Constructor.
	 * @param input The POJO to serialize.  Can also be a {@link Reader} or {@link InputStream}.
	 * @param restCall The RestCall that created this response.
	 */
	protected RestResponseEntity(Object input, RestCall restCall) {
		this.output = input;
		this.restCall = restCall;
	}

	@Override
	public void writeTo(OutputStream os) throws IOException {
		if (output instanceof InputStream) {
			IOUtils.pipe((InputStream)output, os);
			os.close();
		} else if (output instanceof Reader) {
			Writer w = new OutputStreamWriter(os, "UTF-8");
			IOUtils.pipe((Reader)output, w);
			w.close();
		} else {
			try {
				Serializer<?> serializer = restCall.getSerializer();
				if (serializer instanceof OutputStreamSerializer) {
					OutputStreamSerializer s2 = (OutputStreamSerializer)serializer;
					s2.serialize(output, os);
					os.close();
				} else {
					Writer w = new OutputStreamWriter(os, "UTF-8");
					WriterSerializer s2 = (WriterSerializer)serializer;
					s2.serialize(output, w);
					w.close();
				}
			} catch (SerializeException e) {
				throw new com.ibm.juno.client.RestCallException(e);
			}
		}
	}

	@Override
	public Header getContentType() {
		return restCall.getRequest().getFirstHeader("Content-Type");
	}

	@Override
	public Header getContentEncoding() {
		return new BasicHeader("Content-Encoding", "identity");
	}
}
