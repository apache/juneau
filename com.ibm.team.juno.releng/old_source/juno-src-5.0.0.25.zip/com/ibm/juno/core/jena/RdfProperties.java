package com.ibm.juno.core.jena;

import java.util.*;

import com.ibm.juno.core.xml.*;

/**
 * Configurable properties common to both the {@link RdfSerializer} and {@link RdfParser} classes.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfProperties {

	/**
	 * The RDF language to serialize to ({@link String}, default=<js>"RDF/XML-ABBREV"</js>).
	 * <p>
	 * 	Can be any of the following:
	 * <ul>
	 * 	<li><js>"RDF/XML"</js>
	 * 	<li><js>"N-TRIPLE"</js>
	 * 	<li><js>"TURTLE"</js>
	 * 	<li><js>"N3"</js>
	 * </ul>
	 */
	public static final String RDF_LANGUAGE = "Rdf.rdfLanguage";

	/**
	 * The XML namespace for Juno properties ({@link Namespace}, default=<js>{j:'http://www.ibm.com/juno/'}</js>).
	 */
	public static final String JUNO_NS = "Rdf.junoNs";

	/**
	 * The default XML namespace for bean properties ({@link Namespace}, default=<js>{j:'http://www.ibm.com/junobp/'}</js>).
	 */
	public static final String JUNO_BEAN_PROP_NS = "Rdf.junoBpNs";

	/**
	 * ARP property: <code>iri_rules</code> ({@link String}, default=<js>"lax"</js>).
	 * <p>
	 *  	Set the engine for checking and resolving.
	 * <p>
	 * 	Possible values:
	 * <ul>
	 * 	<li><js>"lax"</js> - The rules for RDF URI references only, which does permit spaces although the use of spaces is not good practice.
	 * 	<li><js>"strict"</js> - Sets the IRI engine with rules for valid IRIs, XLink and RDF; it does not permit spaces in IRIs.
	 * 	<li><js>"iri"</js> - Sets the IRI engine to IRI (<a href='http://www.ietf.org/rfc/rfc3986.txt'>RFC 3986</a>, <a href='http://www.ietf.org/rfc/rfc3987.txt'>RFC 3987</a>).
	 * </ul>
	 */
	public static final String ARP_IRI_RULES = "Rdf.jena.iri-rules";

	/**
	 * ARP property: <code>error-mode</code> ({@link String}, default=<js>"lax"</js>).
	 * <p>
	 * 	This allows a coarse-grained approach to control of error handling.
	 * <p>
	 * 	Possible values:
	 * <ul>
	 * 	<li><js>"default"</js>
	 * 	<li><js>"lax"</js>
	 * 	<li><js>"strict"</js>
	 * 	<li><js>"strict-ignore"</js>
	 * 	<li><js>"strict-warning"</js>
	 * 	<li><js>"strict-error"</js>
	 * 	<li><js>"strict-fatal"</js>
	 * </ul>
	 * <p>
	 * 	See also:
	 * <ul>
	 * 	<li><a href='http://jena.sourceforge.net/javadoc/com/hp/hpl/jena/rdf/arp/ARPOptions.html#setDefaultErrorMode()'>ARPOptions.setDefaultErrorMode()</a>
	 * 	<li><a href='http://jena.sourceforge.net/javadoc/com/hp/hpl/jena/rdf/arp/ARPOptions.html#setLaxErrorMode()'>ARPOptions.setLaxErrorMode()</a>
	 * 	<li><a href='http://jena.sourceforge.net/javadoc/com/hp/hpl/jena/rdf/arp/ARPOptions.html#setStrictErrorMode()'>ARPOptions.setStrictErrorMode()</a>
	 * 	<li><a href='http://jena.sourceforge.net/javadoc/com/hp/hpl/jena/rdf/arp/ARPOptions.html#setStrictErrorMode(int)'>ARPOptions.setStrictErrorMode(int)</a>
	 * </ul>
	 */
	public static final String ARP_ERROR_MODE = "Rdf.jena.error-mode";

	/**
	 * ARP property: <code>embedding</code> ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * 	Sets ARP to look for RDF embedded within an enclosing XML document.
	 * <p>
	 * 	See also:
	 * <ul>
	 * 	<li><a href='http://jena.sourceforge.net/javadoc/com/hp/hpl/jena/rdf/arp/ARPOptions.html#setEmbedding(boolean)'>ARPOptions.setEmbedding(boolean)</a>
	 * </ul>
	 */
	public static final String ARP_EMBEDDING = "Rdf.jena.embedding";

	/**
	 * ARP property: <code>ERR_xxx</code> ({@link String}).
	 * <p>
	 * 	Provides fine-grained control over detected error conditions.
	 * <p>
	 * 	Possible values:
	 * <ul>
	 * 	<li><js>"EM_IGNORE"</js>
	 * 	<li><js>"EM_WARNING"</js>
	 * 	<li><js>"EM_ERROR"</js>
	 * 	<li><js>"EM_FATAL"</js>
	 * </ul>
	 * <p>
	 * 	See also:
	 * <ul>
	 * 	<li><a href='http://jena.sourceforge.net/javadoc/com/hp/hpl/jena/rdf/arp/ARPErrorNumbers.html'>ARPErrorNumbers</a>
	 * 	<li><a href='http://jena.sourceforge.net/javadoc/com/hp/hpl/jena/rdf/arp/ARPOptions.html#setErrorMode(int,%20int)'>ARPOptions.setErrorMode(int, int)</a>
	 * </ul>
	 */
	public static final String ARP_ERR_ = "Rdf.jena.ERR_";

	/**
	 * ARP property: <code>WARN_xxx</code> ({@link String}).
	 * <p>
	 * 	See {@link #ARP_ERR_} for details.
	 */
	public static final String ARP_WARN_ = "Rdf.jena.WARN_";

	/**
	 * ARP property: <code>IGN_xxx</code> ({@link String}).
	 * <p>
	 * 	See {@link #ARP_ERR_} for details.
	 */
	public static final String ARP_IGN_ = "Rdf.jena.IGN_";

	/**
	 * RDF/XML property: <code>xmlbase</code> ({@link String}, default=<jk>null</jk>).
	 * <p>
	 * 	The value to be included for an <xa>xml:base</xa> attribute on the root element in the file.
	 */
	public static final String RDFXML_XMLBASE = "Rdf.jena.xmlbase";

	/**
	 * RDF/XML property: <code>longId</code> ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 *  	Whether to use long ID's for anon resources.
	 *  	Short ID's are easier to read, but can run out of memory on very large models.
	 */
	public static final String RDFXML_LONGID = "Rdf.jena.longId";

	/**
	 * RDF/XML property: <code>allowBadURIs</code> ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * 	URIs in the graph are, by default, checked prior to serialization.
	 */
	public static final String RDFXML_ALLOW_BAD_URIS = "Rdf.jena.allowBadURIs";

	/**
	 * RDF/XML property: <code>relativeURIs</code> ({@link String}).
	 * <p>
	 * 	What sort of relative URIs should be used.
	 * <p>
	 * 	A comma separate list of options:
	 * <ul>
	 * 	<li><js>"same-document"</js> - Same-document references (e.g. <js>""</js> or <js>"#foo"</js>)
	 * 	<li><js>"network"</js>  - Network paths (e.g. <js>"//example.org/foo"</js> omitting the URI scheme)
	 * 	<li><js>"absolute"</js> - Absolute paths (e.g. <js>"/foo"</js> omitting the scheme and authority)
	 * 	<li><js>"relative"</js> - Relative path not begining in <js>"../"</js>
	 * 	<li><js>"parent"</js> - Relative path begining in <js>"../"</js>
	 * 	<li><js>"grandparent"</js> - Relative path begining in <js>"../../"</js>
	 * </ul>
	 * <p>
	 * 	The default value is <js>"same-document, absolute, relative, parent"</js>.
	 * 	To switch off relative URIs use the value <js>""</js>.
	 * 	Relative URIs of any of these types are output where possible if and only if the option has been specified.
	 */
	public static final String RDFXML_RELATIVE_URIS = "Rdf.jena.relativeURIs";

	/**
	 * RDF/XML property: <code>showXmlDeclaration</code> ({@link String}, default=<js>"default"</js>).
	 * <p>
	 * 	Possible values:
	 * <ul>
	 * 	<li><js>"true"</js> - Add XML Declaration to the output.
	 * 	<li><js>"false"</js> - Don't add XML Declaration to the output.
	 * 	<li><js>"default"</js> - Only add an XML Declaration when asked to write to an <code>OutputStreamWriter</code> that uses some encoding other than <code>UTF-8</code> or <code>UTF-16</code>.
	 * 		In this case the encoding is shown in the XML declaration.
	 * </ul>
	 */
	public static final String RDFXML_SHOW_XML_DECL = "Rdf.jena.showXmlDeclaration";

	/**
	 * RDF/XML property: <code>showDoctypeDeclaration</code> ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * 	If true, an XML Doctype declaration is included in the output.
	 * 	This declaration includes a <code>!ENTITY</code> declaration for each prefix mapping in the model, and any attribute value that starts with the URI of that mapping is written as starting with the corresponding entity invocation.
	 */
	public static final String RDFXML_SHOW_DOCTYPE_DECL = "Rdf.jena.showDoctypeDeclaration";

	/**
	 * RDF/XML property: <code>tab</code> ({@link Integer}, default=<code>2</code>).
	 * <p>
	 * 	The number of spaces with which to indent XML child elements.
	 */
	public static final String RDFXML_TAB = "Rdf.jena.tab";

	/**
	 * RDF/XML property: <code>attributeQuoteChar</code> ({@link Character}, default=<js>'"'</js>).
	 * <p>
	 * 	The XML attribute quote character.
	 */
	public static final String RDFXML_ATTR_QUOTE_CHAR = "Rdf.jena.attributeQuoteChar";

	/**
	 * RDF/XML property: <code>blockRules</code> ({@link String}, default=<js>""</js>).
	 * <p>
	 * 	A list of <code>Resource</code> or a <code>String</code> being a comma separated list of fragment IDs from <a href='http://www.w3.org/TR/rdf-syntax-grammar'>RDF Syntax Grammar</a> indicating grammar rules that will not be used.
	 */
	public static final String RDFXML_BLOCK_RULES = "Rdf.jena.blockRules";

	/**
	 * N3 property: <code>minGap</code> ({@link Integer}, default=<code>1</code>).
	 * <p>
	 * 	Minimum gap between items on a line.
	 */
	public static final String N3_MIN_GAP = "Rdf.jena.minGap";

	/**
	 * N3 property: <code>objectLists</code> ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * 	Print object lists as comma separated lists.
	 */
	public static final String N3_OBJECT_LISTS = "Rdf.jena.objectLists";

	/**
	 * N3 property: <code>subjectColumn</code> ({@link Integer}, default=indentProperty).
	 * <p>
	 * 	If the subject is shorter than this value, the first property may go on the same line.
	 */
	public static final String N3_SUBJECT_COLUMN = "Rdf.jena.subjectColumn";

	/**
	 * N3 property: <code>propertyColumn</code> ({@link Integer}, default=<code>8</code>).
	 * <p>
	 *  	Width of the property column.
	 */
	public static final String N3_PROPERTY_COLUMN = "Rdf.jena.propertyColumn";

	/**
	 * N3 property: <code>indentProperty</code> ({@link Integer}, default=<code>6</code>).
	 * <p>
	 * 	Width to indent properties.
	 */
	public static final String N3_INDENT_PROPERTY = "Rdf.jena.indentProperty";

	/**
	 * N3 property: <code>widePropertyLen</code> ({@link Integer}, default=<code>20</code>).
	 * <p>
	 * 	Width of the property column.
	 * 	Must be longer than <code>propertyColumn</code>.
	 */
	public static final String N3_WIDE_PROPERTY_LENGTH = "Rdf.jena.widePropertyLen";

	/**
	 * N3 property: <code>abbrevBaseURI</code> ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * 	Control whether to use abbreviations <code>&lt;&gt;</code> or <code>&lt;#&gt;</code>.
	 */
	public static final String N3_ABBREV_BASE_URI = "Rdf.jena.abbrevBaseURI";

	/**
	 * N3 property: <code>usePropertySymbols</code> ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * 	Control whether to use <code>a</code>, <code>=</code> and <code>=&gt;</code> in output
	 */
	public static final String N3_USE_PROPERTY_SYMBOLS = "Rdf.jena.usePropertySymbols";

	/**
	 * N3 property: <code>useTripleQuotedStrings</code> ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * 	Allow the use of <code>"""</code> to delimit long strings.
	 */
	public static final String N3_USE_TRIPLE_QUOTED_STRINGS = "Rdf.jena.useTripleQuotedStrings";

	/**
	 * N3 property: <code>useDoubles</code> ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * 	Allow the use doubles as <code>123.456</code>.
	 */
	public static final String N3_USE_DOUBLES = "Rdf.jena.useDoubles";


	String rdfLanguage = "RDF/XML-ABBREV";
	Namespace junoNs = NamespaceFactory.get("j", "http://www.ibm.com/juno/");
	Namespace junoBpNs = NamespaceFactory.get("jp", "http://www.ibm.com/junobp/");
	Map<String,Object> jenaSettings = new HashMap<String,Object>();

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		if (property.equals(RDF_LANGUAGE))
			rdfLanguage = value.toString();
		else if (property.equals(JUNO_NS))
			junoNs = NamespaceFactory.parseNamespace(value);
		else if (property.equals(JUNO_BEAN_PROP_NS))
			junoBpNs = NamespaceFactory.parseNamespace(value);
		else if (property.startsWith("Rdf.jena."))
			jenaSettings.put(property.substring(9), value);
		else
			return false;
		return true;
	}
}
