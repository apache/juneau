package com.ibm.juno.core.xml;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.xml.annotation.XmlFormat.*;

import java.io.*;
import java.util.*;
import java.util.regex.*;

import javax.xml.*;
import javax.xml.transform.stream.*;
import javax.xml.validation.*;

import org.w3c.dom.bootstrap.*;
import org.w3c.dom.ls.*;
import org.xml.sax.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.utils.*;
import com.ibm.juno.core.xml.annotation.*;

/**
 * Serializes POJO metadata to HTTP responses as XML.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>text/xml+schema</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>text/xml</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Produces the XML-schema representation of the XML produced by the {@link XmlSerializer} class with the same properties.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link XmlSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Produces(value="text/xml+schema",contentType="text/xml")
public class XmlSchemaSerializer extends XmlSerializer {

	@Override // ISerializer, XmlSerializer
	public void serialize(Object o, XmlSerializerWriter w, SerializerContext ctx) throws IOException, SerializeException {
		if (ctx == null)
			ctx = createContext(o, null, null, null);
		XmlSerializerContext ctx2 = (XmlSerializerContext)ctx;

		Namespace xs = ctx2.getXsNamespace();
		Namespace[] allNs = ArrayUtils.append(new Namespace[]{ctx2.getDefaultNamespace()}, ctx2.getNamespaces());

		Schemas s = new Schemas(xs, ctx2.getDefaultNamespace(), allNs, ctx2);
		s.process(o);
		s.serializeTo(w);
	}

	/**
	 * Returns an XML-Schema validator based on the output returned by {@link #serialize(Object, XmlSerializerWriter, SerializerContext)};
	 * @param o The object to serialize.
	 * @param ctx The serializer context object return by {@link #createContext(Object, ObjectMap, String, String)}.<br>
	 * 	Can be <jk>null</jk>.
	 *
	 * @throws SAXException If a problem was detected in the XML-Schema output produced by this serializer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public Validator getValidator(Object o, SerializerContext ctx) throws SerializeException, SAXException {
		String xmlSchema = serialize(o, ctx);

		// create a SchemaFactory capable of understanding WXS schemas
		SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

		if (xmlSchema.indexOf('\u0000') != -1) {

			// Break it up into a map of namespaceURI->schema document
			final Map<String,String> schemas = new HashMap<String,String>();
			String[] ss = xmlSchema.split("\u0000");
			xmlSchema = ss[0];
			for (String s : ss) {
				Matcher m = pTargetNs.matcher(s);
				if (m.find())
					schemas.put(m.group(1), s);
			}

			// Create a custom resolver
			factory.setResourceResolver(
				new LSResourceResolver() {

					@Override
					public LSInput resolveResource(String type, String namespaceURI, String publicId, String systemId, String baseURI) {

						String schema = schemas.get(namespaceURI);
						if (schema == null)
							throw new RuntimeException(String.format("No schema found for namespaceURI '%s'", namespaceURI));

						try {
							DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
							DOMImplementationLS domImplementationLS = (DOMImplementationLS)registry.getDOMImplementation("LS 3.0");
							LSInput in = domImplementationLS.createLSInput();
							in.setCharacterStream(new StringReader(schema));
							in.setSystemId(systemId);
							return in;

						} catch (Exception e) {
							throw new RuntimeException(e);
						}
					}
				}
			);
		}
		return factory.newSchema(new StreamSource(new StringReader(xmlSchema))).newValidator();
	}

	private static Pattern pTargetNs = Pattern.compile("targetNamespace=['\"]([^'\"]+)['\"]");


	@Override // IWriterSerializer, XmlSerializer
	public XmlSerializerWriter createWriter(Writer w, SerializerContext ctx) {
		if (w instanceof XmlSerializerWriter)
			return (XmlSerializerWriter)w;
		if (ctx == null)
			ctx = new XmlSerializerContext(beanContext, sp, xsp, null, null);
		// This serializer must always have namespaces enabled.
		XmlSerializerContext ctx2 = (XmlSerializerContext)ctx;
		return new XmlSerializerWriter(w, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority(), true, ctx2.getDefaultNamespace());
	}

	/* An instance of a global element, global attribute, or XML type to be serialized. */
	private class QueueEntry {
		Namespace ns;
		String name;
		ClassType<?> ct;
		QueueEntry(Namespace ns, String name, ClassType<?> ct) {
			this.ns = ns;
			this.name = name;
			this.ct = ct;
		}
	}

	/* An encapsulation of all schemas present in the metamodel of the serialized object. */
	private class Schemas extends LinkedHashMap<Namespace,Schema> {

		private Namespace defaultNs;
		private LinkedList<QueueEntry>
			elementQueue = new LinkedList<QueueEntry>(),
			attributeQueue = new LinkedList<QueueEntry>(),
			typeQueue = new LinkedList<QueueEntry>();

		public Schemas(Namespace xs, Namespace defaultNs, Namespace[] allNs, XmlSerializerContext ctx) throws IOException {
			this.defaultNs = defaultNs;
			for (Namespace ns : allNs)
				put(ns, new Schema(this, xs, ns, defaultNs, allNs, ctx));
		}

		private Schema getSchema(Namespace ns) {
			if (ns == null)
				ns = defaultNs;
			Schema s = get(ns);
			if (s == null)
				throw new RuntimeException("No schema defined for namespace '"+ns+"'");
			return s;
		}

		public void process(Object o) throws IOException {
			ClassType<?> ct = beanContext.getClassTypeForObject(o);
			Namespace ns = defaultNs;
			if (ct == null)
				queueElement(ns, "null", ClassType.OBJECT);
			else {
				if (ct.getElementName() != null && ct.getNamespace() != null)
					ns = ct.getNamespace();
				queueElement(ns, ct.getElementName(), ct);
			}
			processQueue();
		}


		public void processQueue() throws IOException {
			boolean b;
			do {
				b = false;
				while (! elementQueue.isEmpty()) {
					QueueEntry q = elementQueue.removeFirst();
					b |= getSchema(q.ns).processElement(q.name, q.ct);
				}
				while (! typeQueue.isEmpty()) {
					QueueEntry q = typeQueue.removeFirst();
					b |= getSchema(q.ns).processType(q.name, q.ct);
				}
				while (! attributeQueue.isEmpty()) {
					QueueEntry q = attributeQueue.removeFirst();
					b |= getSchema(q.ns).processAttribute(q.name, q.ct);
				}
			} while (b);
		}

		public void queueElement(Namespace ns, String name, ClassType<?> ct) {
			elementQueue.add(new QueueEntry(ns, name, ct));
		}

		public void queueType(Namespace ns, String name, ClassType<?> ct) {
			if (name == null)
				name = XmlUtils.encodeElementName(ct.toString());
			typeQueue.add(new QueueEntry(ns, name, ct));
		}

		public void queueAttribute(Namespace ns, String name, ClassType<?> ct) {
			attributeQueue.add(new QueueEntry(ns, name, ct));
		}

		public void serializeTo(Writer w) throws IOException {
			boolean b = false;
			for (Schema s : values()) {
				if (b)
					w.append('\u0000');
				w.append(s.toString());
				b = true;
			}
		}
	}

	/* An encapsulation of a single schema. */
	private class Schema {
		private StringWriter sw = new StringWriter();
		private XmlSerializerWriter w;
		private XmlSerializerContext ctx;
		private Namespace defaultNs, targetNs;
		private Schemas schemas;
		private Set<String>
			processedTypes = new HashSet<String>(),
			processedAttributes = new HashSet<String>(),
			processedElements = new HashSet<String>();

		public Schema(Schemas schemas, Namespace xs, Namespace targetNs, Namespace defaultNs, Namespace[] allNs, XmlSerializerContext ctx) throws IOException {
			this.schemas = schemas;
			this.defaultNs = defaultNs;
			this.targetNs = targetNs;
			this.ctx = ctx;
			w = new XmlSerializerWriter(sw, ctx.isUseIndentation(), ctx.getQuoteChar(), null, null, true, null);
			int i = ctx.getIndent();
			w.oTag(i, "schema");
			w.attr("xmlns", xs.getUri());
			w.attr("targetNamespace", targetNs.getUri());
			w.attr("elementFormDefault", "qualified");
			if (targetNs != defaultNs)
				w.attr("attributeFormDefault", "qualified");
			for (Namespace ns2 : allNs)
				w.attr("xmlns", ns2.name, ns2.uri);
			w.append('>').nl();
			for (Namespace ns : allNs) {
				if (ns != targetNs) {
					w.oTag(i+1, "import")
						.attr("namespace", ns.getUri())
						.attr("schemaLocation", ns.getName()+".xsd")
						.append("/>").nl();
				}
			}
		}

		public boolean processElement(String name, ClassType<?> ct) throws IOException {
			if (processedElements.contains(name))
				return false;
			processedElements.add(name);

			ClassType<?> ft = ct.getFilteredClassType();
			int i = ctx.getIndent() + 1;
			if (name == null)
				name = getElementName(ft);
			Namespace ns = first(ft.getNamespace(), defaultNs);
			String type = getXmlType(ns, ft);

			w.oTag(i, "element")
				.attr("name", XmlUtils.encodeElementName(name))
				.attr("type", type)
				.append('/').append('>').nl();

			schemas.queueType(ns, null, ft);
			schemas.processQueue();
			return true;
		}

		public boolean processAttribute(String name, ClassType<?> ct) throws IOException {
			if (processedAttributes.contains(name))
				return false;
			processedAttributes.add(name);

			int i = ctx.getIndent() + 1;
			String type = getXmlAttrType(ct);

			w.oTag(i, "attribute")
				.attr("name", name)
				.attr("type", type)
				.append('/').append('>').nl();

			return true;
		}

		public boolean processType(String name, ClassType<?> ct) throws IOException {
			if (processedTypes.contains(name))
				return false;
			processedTypes.add(name);

			int i = ctx.getIndent() + 1;

			ct = ct.getFilteredClassType();

			w.oTag(i, "complexType")
				.attr("name", name);

			if (ct.isBean() && ct.getBeanMeta().getXmlContentProperty() != null)
				w.attr("mixed", "true");

			w.cTag().nl();

			if (! (ct.isMap() || ct.isBean() || ct.isCollection() || ct.isArray() || ct.isAbstract() || ct.isObject())) {
				String base = getXmlAttrType(ct);
				w.sTag(i+1, "simpleContent").nl();
				w.oTag(i+2, "extension")
					.attr("base", base);
				if (ctx.isAddJsonTypeAttrs() || (ctx.isAddJsonStringTypeAttrs() && base.equals("string"))) {
					w.cTag().nl();
					w.oTag(i+3, "attribute")
						.attr("name", "type")
						.attr("type", "string")
						.ceTag().nl();
					w.eTag(i+2, "extension").nl();
				} else {
					w.ceTag().nl();
				}
				w.eTag(i+1, "simpleContent").nl();

			} else {

				//----- Bean -----
				if (ct.isBean()) {
					BeanMeta<?> bm = ct.getBeanMeta();

					boolean hasChildElements = false;

					for (BeanPropertyMeta<?> pMeta : bm.getMetaProperties())
						if (pMeta.getXmlFormat() != XmlFormat.ATTR && pMeta.getXmlFormat() != XmlFormat.CONTENT)
							hasChildElements = true;

					if (bm.getXmlContentProperty() != null) {
						w.sTag(i+1, "sequence").nl();
						w.oTag(i+2, "any")
							.attr("processContents", "skip")
							.attr("minOccurs", 0)
							.ceTag().nl();
						w.eTag(i+1, "sequence").nl();

					} else if (hasChildElements) {
						w.sTag(i+1, "sequence").nl();

						boolean hasOtherNsElement = false;

						for (BeanPropertyMeta<?> pMeta : bm.getMetaProperties()) {
							if (pMeta.getXmlFormat() != XmlFormat.ATTR && ! pMeta.isHidden()) {
								boolean isCollapsed = pMeta.getXmlFormat() == COLLAPSED;
								ClassType<?> ct2 = pMeta.getClassType();
								String childName = pMeta.getName();
								if (isCollapsed) {
									if (pMeta.getChildName() != null)
										childName = pMeta.getChildName();
									ct2 = pMeta.getClassType().getElementType();
								}
								Namespace cNs = first(pMeta.getNamespace(), ct2.getNamespace(), ct.getNamespace(), defaultNs);
								if (pMeta.getNamespace() == null) {
									w.oTag(i+2, "element")
										.attr("name", childName, true)
										.attr("type", getXmlType(cNs, ct2));
									if (isCollapsed) {
										w.attr("minOccurs", 0);
										w.attr("maxOccurs", "unbounded");
									} else {
										if (! ctx.isTrimNulls())
											w.attr("nillable", true);
										else
											w.attr("minOccurs", 0);
									}

									w.ceTag().nl();
								} else {
									// Child element is in another namespace.
									schemas.queueElement(cNs, pMeta.getName(), ct2);
									hasOtherNsElement = true;
								}

							}
						}

						// If this bean has any child elements in another namespace,
						// we need to add an <any> element.
						if (hasOtherNsElement)
							w.oTag(i+2, "any")
								.attr("minOccurs", 0)
								.attr("maxOccurs", "unbounded")
								.ceTag().nl();
						w.eTag(i+1, "sequence").nl();
					}

					for (BeanPropertyMeta<?> pMeta : bm.getXmlAttrProperties().values()) {
						Namespace pNs = pMeta.getNamespace();
						if (pNs == null)
							pNs = defaultNs;

						// If the bean attribute has a different namespace than the bean, then it needs to
						// be added as a top-level entry in the appropriate schema file.
						if (pNs != targetNs) {
							schemas.queueAttribute(pNs, pMeta.getName(), pMeta.getClassType());
							w.oTag(i+1, "attribute")
							//.attr("name", pMeta.getName(), true)
							.attr("ref", pNs.getName() + ':' + pMeta.getName())
							.ceTag().nl();
						}

						// Otherwise, it's just a plain attribute of this bean.
						else {
							w.oTag(i+1, "attribute")
								.attr("name", pMeta.getName(), true)
								.attr("type", getXmlAttrType(pMeta.getClassType()))
								.ceTag().nl();
						}
					}

				//----- Collection -----
				} else if (ct.isCollection() || ct.isArray()) {
					ClassType<?> elementType = ct.getElementType();
					if (elementType == ClassType.OBJECT) {
						w.sTag(i+1, "sequence").nl();
						w.oTag(i+2, "any")
							.attr("processContents", "skip")
							.attr("maxOccurs", "unbounded")
							.attr("minOccurs", "0")
							.ceTag().nl();
						w.eTag(i+1, "sequence").nl();
					} else {
						Namespace cNs = first(elementType.getNamespace(), ct.getNamespace(), defaultNs);
						schemas.queueType(cNs, null, elementType);
						w.sTag(i+1, "sequence").nl();
						w.oTag(i+2, "choice")
							.attr("minOccurs", 0)
							.attr("maxOccurs", "unbounded")
							.cTag().nl();
						w.oTag(i+3, "element")
							.attr("name", XmlUtils.encodeElementName(getElementName(elementType)))
							.attr("type", getXmlType(cNs, elementType))
							.ceTag().nl();
						w.oTag(i+3, "element")
							.attr("name", "null")
							.attr("type", "string")
							.ceTag().nl();
						w.eTag(i+2, "choice").nl();
						w.eTag(i+1, "sequence").nl();
					}

				//----- Map -----
				} else if (ct.isMap() || ct.isAbstract() || ct.isObject()) {
					w.sTag(i+1, "sequence").nl();
					w.oTag(i+2, "any")
						.attr("processContents", "skip")
						.attr("maxOccurs", "unbounded")
						.attr("minOccurs", "0")
						.ceTag().nl();
					w.eTag(i+1, "sequence").nl();
				}

				if (ctx.isAddClassAttrs()) {
					w.oTag(i+1, "attribute")
						.attr("name", "_class")
						.attr("type", "string")
						.ceTag().nl();
				}
				if (ctx.isAddJsonTypeAttrs()) {
					w.oTag(i+1, "attribute")
						.attr("name", "type")
						.attr("type", "string")
						.ceTag().nl();
				}
			}

			w.eTag(i, "complexType").nl();
			schemas.processQueue();

			return true;
		}

		private String getElementName(ClassType<?> ct) {
			ct = ct.getFilteredClassType();
			String name = ct.getElementName();

			if (name == null) {
				if (ct.isBoolean())
					name = "boolean";
				else if (ct.isNumber())
					name = "number";
				else if (ct.isArray() || ct.isCollection())
					name = "array";
				else if (! (ct.isMap() || ct.isBean() || ct.isCollection() || ct.isArray() || ct.isObject() || ct.isAbstract()))
					name = "string";
				else
					name = "object";
			}
			return name;
		}

		@Override
		public String toString() {
			try {
				w.eTag(ctx.getIndent(), "schema").nl();
			} catch (IOException e) {
				throw new RuntimeException(e); // Shouldn't happen.
			}
			return sw.toString();
		}

		private String getXmlType(Namespace currentNs, ClassType<?> ct) {
			String name = null;
			ct = ct.getFilteredClassType();
			if (currentNs == targetNs && ! ctx.isAddJsonTypeAttrs()) {
				if (ct.isBoolean())
					name = "boolean";
				else if (ct.isNumber()) {
					if (ct.isDecimal())
						name = "decimal";
					else
						name = "integer";
				}
				if (name == null && ! ctx.isAddJsonStringTypeAttrs()) {
					if (! (ct.isMap() || ct.isBean() || ct.isCollection() || ct.isArray() || ct.isObject() || ct.isAbstract()))
						name = "string";
				}
			}
			if (name == null) {
				name = XmlUtils.encodeElementName(ct.toString());
				schemas.queueType(currentNs, name, ct);
				return currentNs.getName() + ":" + name;
			}

			return name;
		}
	}

	private <T> T first(T...tt) {
		for (T t : tt)
			if (t != null)
				return t;
		return null;
	}


	private static String getXmlAttrType(ClassType<?> ct) {
		if (ct.isBoolean())
			return "boolean";
		if (ct.isNumber()) {
			if (ct.isDecimal())
				return "decimal";
			return "integer";
		}
		return "string";
	}
}
