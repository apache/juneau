package com.ibm.juno.core.utils;

import static com.ibm.juno.core.utils.ArrayUtils.*;
import static java.lang.String.*;

import java.util.*;

/**
 * An instance of a <code>Map</code> where the keys and values
 * 	are simple <code>String[]</code> and <code>Object[]</code> arrays.
 * <p>
 * 	Typically more efficient than <code>HashMaps</code> for small maps (e.g. &lt;10 entries).
 * <p>
 * 	Does not support adding or removing entries.
 * <p>
 * 	Setting values overwrites the value on the underlying value array.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SimpleMap extends AbstractMap<String,Object> {

	private final String[] keys;
	private final Object[] values;
	private final Map.Entry<String,Object>[] entries;

	/**
	 * Constructor.
	 * @param keys The map keys.
	 * @param values The map values.
	 */
	public SimpleMap(String[] keys, Object[] values) {
		if (keys == null)
			throw new NullPointerException("Cannot pass null keys to SimpleMap");
		if (values == null)
			throw new NullPointerException("Cannot pass null values to SimpleMap");
		if (keys.length != values.length)
			throw new IllegalArgumentException(format("keys[%s] and values[%s] array lengths differ", keys.length, values.length));

		this.keys = keys;
		this.values = values;
		entries = new SimpleMapEntry[keys.length];
		for (int i = 0; i < keys.length; i++)
			entries[i] = new SimpleMapEntry(i);
	}

	@Override
	public Set<Map.Entry<String,Object>> entrySet() {
		return asSet(entries);
	}

	@Override
	public Object get(Object key) {
		for (int i = 0; i < keys.length; i++)
			if (keys[i].equals(key))
				return values[i];
		return null;
	}

	@Override
	public Set<String> keySet() {
		return asSet(keys);
	}

	@Override
	public Object put(String key, Object value) {
		for (int i = 0; i < keys.length; i++) {
			if (keys[i].equals(key)) {
				Object v = values[i];
				values[i] = value;
				return v;
			}
		}
		throw new RuntimeException(format("No key '%s' defined in map", key));
	}

	private class SimpleMapEntry implements Map.Entry<String,Object> {

		private int index;

		private SimpleMapEntry(int index) {
			this.index = index;
		}

		@Override
		public String getKey() {
			return keys[index];
		}

		@Override
		public Object getValue() {
			return values[index];
		}

		@Override
		public Object setValue(Object val) {
			Object v = values[index];
			values[index] = val;
			return v;
		}
	}
}
