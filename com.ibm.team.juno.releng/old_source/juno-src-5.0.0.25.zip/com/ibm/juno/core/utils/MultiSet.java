package com.ibm.juno.core.utils;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;

/**
 * Encapsulates multiple collections so they can be iterated over as if they
 * were all part of the same collection.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <E> The object type of this set.
 */
public class MultiSet<E> extends AbstractSet<E> {

	/** Inner collections. */
	private List<Collection<E>> l = new LinkedList<Collection<E>>();

	/**
	 * Create a new Set that consists as a coalesced set of the specified collections.
	 * @param c Zero or more collections to add to this set.
	 */
	public MultiSet(Collection<E>...c) {
		for (Collection<E> cc : c)
			l.add(cc);
	}

	/**
	 * Appends the specified collection to this set of collections.
	 * @param c The collection to append to this set of collections.
	 * @return This object (for method chaining).
	 */
	public MultiSet<E> append(Collection<E> c) {
		l.add(c);
		return this;
	}

	/**
	 * Iterates over all entries in all collections.
	 */
	@Override
	public Iterator<E> iterator() {
		return new Iterator<E>() {
			Iterator<Collection<E>> i1 = l.iterator();
			Iterator<E> i2 = i1.next().iterator();

			@Override
			public boolean hasNext() {
				return i1.hasNext() || i2.hasNext();
			}

			@Override
			public E next() {
				if ((! i2.hasNext()) && i1.hasNext())
					i2 = i1.next().iterator();
				return i2.next();
			}

			@Override
			public void remove() {
				i2.remove();
			}
		};
	}

	@Override
	public int size() {
		int i = 0;
		for (Collection<E> c : l)
			i += c.size();
		return i;
	}
}