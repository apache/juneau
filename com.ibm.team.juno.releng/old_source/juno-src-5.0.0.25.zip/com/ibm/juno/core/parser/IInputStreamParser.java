package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Top-level interface for all byte-based parsers.
 */
public interface IInputStreamParser extends IParser<InputStream> {

	@Override
	public <T> T parse(InputStream in, ClassType<T> type, ParserContext ctx) throws ParseException, IOException;

	@Override
	public <T> T parse(InputStream in, Class<T> type) throws ParseException, IOException;

}