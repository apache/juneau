package com.ibm.juno.client;

import java.io.*;
import java.net.*;

import javax.net.ssl.*;

/**
 * Authenticator for logging into Jazz Team Servers using form-based authentication.
 * <p>
 * Bean property setters provided so that instances can be instantiated through parsers.
 * <p class='bcode'>
 * 	<jc>// Construct authenticator instance from JSON</jc>
 * 	String json = <js>"{_class:'com.ibm.juno.client.JazzFormAuth',jtsUrl:'https://localhost:9443/jts',user:'ADMIN',password:'ADMIN'}"</js>;
 * 	Auth a = JsonParser.<jsf>DEFAULT</jsf>.parse(json, Auth.<jk>class</jk>);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JazzFormAuth implements Auth {
	private String jtsUrl, user, pw;
	private volatile String jsessionid = "";

	/** Bean constructor. */
	public JazzFormAuth() {}

	/**
	 * Constructor.
	 * @param jtsUrl URL of Jazz Team Server (e.g. <js>"https://localhost:9443/jts"</js>).
	 * @param user Jazz username.
	 * @param pw Jazz password.
	 */
	public JazzFormAuth(String jtsUrl, String user, String pw) {
		this.jtsUrl = jtsUrl;
		this.user = user;
		this.pw = pw;
	}

	/**
	 * Returns the JTS URL property.
	 * @return The JTS URL property.
	 */
	public String getJtsUrl() {
		return jtsUrl;
	}

	/**
	 * Sets the JTS URL property.
	 * @param jtsUrl URI of Jazz Team Server (e.g. <js>"https://localhost:9443/jts"</js>).
	 * @return This object (for method chaining).
	 */
	public JazzFormAuth setJtsUrl(String jtsUrl) {
		this.jtsUrl = jtsUrl;
		return this;
	}

	/**
	 * Returns the Jazz authentication username.
	 * @return The Jazz authentication username.
	 */
	public String getUser() {
		return user;
	}

	/**
	 * Sets the Jazz authentication username.
	 * @param user Jazz username.
	 * @return This object (for method chaining).
	 */
	public JazzFormAuth setUser(String user) {
		this.user = user;
		return this;
	}

	/**
	 * Returns the Jazz authentication password.
	 * @return The Jazz authentication password.
	 */
	public String getPassword() {
		return pw;
	}

	/**
	 * Sets the Jazz authentication password.
	 * @param pw Jazz password.
	 * @return This object (for method chaining).
	 */
	public JazzFormAuth setPassword(String pw) {
		this.pw = pw;
		return this;
	}

	/**
	 * Adds a <js>"Cookie"</js> header to all requests with the value
	 * <js>"net-jazz-ajax-cookie-rememberUserId=; JSESSIONID=xxx; JazzFormAuth=Form"</js>
	 */
	@Override
	public void authenticate(RestClient client) throws RestCallException {
		if (jsessionid.isEmpty()) {
			synchronized(jsessionid) {
				if (jsessionid.isEmpty()) {
					try {

						SSLUtils.trustAllCerts();

						URL url = new URL(jtsUrl + "/auth/j_security_check");
						HttpURLConnection c = (HttpsURLConnection)url.openConnection(Proxy.NO_PROXY);
						c.setRequestMethod("POST");
						c.setDoInput(true);
						c.setDoOutput(true);
						c.setInstanceFollowRedirects(false);
						c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
						c.setRequestProperty("Connection", "close");
						c.setRequestProperty("Accept", "text/json");
						c.connect();
						OutputStream os = c.getOutputStream();
						os.write(("j_username="+user+"&j_password="+pw).getBytes("UTF-8"));
						os.flush();
						os.close();

						// A non-null auth response is a failure.
						String authResponse = c.getHeaderField("X-com-ibm-team-repository-web-auth-msg");
						if (authResponse != null) {
							if (authResponse.equals("authfailed"))
								throw new RestCallException("The user name, password, or both are invalid");
							throw new RestCallException("Unexpected servlet response: " + authResponse);
						}

						String cookie = c.getHeaderField("Set-Cookie");
						jsessionid = cookie.substring(11, cookie.indexOf(';'));
						c.disconnect();

					} catch (Exception e) {
						throw new RestCallException(e);
					}
				}
			}
		}

		client.setHeader("Cookie", "net-jazz-ajax-cookie-rememberUserId=; JSESSIONID="+jsessionid+"; JazzFormAuth=Form");
		client.setHeader("X-Jazz-CSRF-Prevent", jsessionid);
	}
}
