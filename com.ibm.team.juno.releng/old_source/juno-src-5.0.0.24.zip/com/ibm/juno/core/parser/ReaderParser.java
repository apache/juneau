package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;


/**
 * Subclass of {@link Parser} for characters-based parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all character-based parsers since it implements all
 * 	of the following interfaces...
 * <ul>
 * 	<li>{@link IParser}
 * 	<li>{@link ICoreApiParser}
 * 	<li>{@link IReaderParser}
 * </ul>
 * <p>
 * 	...and only has 1 remaining abstract method to implement...
 * <ul>
 * 	<li><code>parse(Reader, ClassType, ParserContext)</code>
 * </ul>
 *
 *
 * <h6 class='topic'>@Consumes annotation</h6>
 * <p>
 * 	The media types that this parser can handle is specified through the {@link Consumes @Consumes} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()} method.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class ReaderParser extends Parser<Reader> implements IReaderParser {


	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	public abstract <T> T parse(Reader in, ClassType<T> type, ParserContext ctx) throws ParseException, IOException;


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override
	public ParserContext createContext(ClassType<?> type, ObjectMap properties, String mediaType, String charset) throws ParseException {
		return super.createContext(type, properties, mediaType, charset);
	}

	@Override // IReaderParser
	public <T> T parse(CharSequence in, ClassType<T> type, ParserContext ctx) throws ParseException {
		if (in == null)
			return null;
		if (ctx == null)
			ctx = createContext(type, null, null, null);
		try {
			return parse(new StringReader(in.toString()), type, ctx);
		} catch (IOException e) {
			throw new ParseException(e); // Shouldn't happen.
		}
	}

	@Override // IReaderParser
	public <T> T parse(CharSequence in, Class<T> type) throws ParseException {
		return parse(in, beanContext.getClassType(type), null);
	}
}
