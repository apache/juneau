package com.ibm.juno.core.urlencoding;

import java.io.*;
import java.net.*;

import com.ibm.juno.core.json.*;

/**
 * Specialized writer for serializing URL-Encoded strings.
 * <p>
 * 	<b>Note:  This class is not intended for external use.</b>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingSerializerWriter extends JsonSerializerWriter {

	UrlEncodingSerializerWriter(Writer out, boolean useIndentation, char quoteChar, String uriContext, String uriAuthority) {
		super(out, useIndentation, false, quoteChar, true, uriContext, uriAuthority);
	}

	/**
	 * Serializes and encodes a parameter value.
	 *
	 * @param o The object to serialize and encode.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to write to the writer.
	 */
	public UrlEncodingSerializerWriter encode(Object o) throws IOException {
		encode(out, o);
		return this;
	}

	/**
	 * Appends the specified object as an encoded URI.
	 * <p>
	 * Object is converted to a <code>String</code> using <code>toString()</code>, so this will work on {@link URL} or {@link URI} objects,
	 * or any other type that returns a URI via it's <code>toString()</code> method.
	 * <p>
	 * If the URI is relative (i.e. without a schema and not prepended with <js>'/'</js>) the URI
	 * will be prepended with {@link #uriAuthority} and {@link #uriContext}.
	 * <p>
	 * If the URI is context-absolute (i.e. without a schema, but prepended with <js>'/'</js>)
	 * the URI will be prepended with {@link #uriAuthority}.
	 *
	 * @param uri The URI to serialize.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to write to the writer.
	 */
	public UrlEncodingSerializerWriter encodeUri(Object uri) throws IOException {
		String s = uri.toString();
		if (s.indexOf(':') == -1) {
			append(uriAuthority);
			if ((! s.startsWith("/")) && ! uriContext.isEmpty())
				append(uriContext).append("/");
		}
		encode(s);
		return this;
	}

	/**
	 * Encodes a parameter and sends the results to the specified writer.
	 *
	 * @param out The output writer.
	 * @param o The object to serialize and encode.
	 * @throws IOException If a problem occurred trying to write to the writer.
	 */
	public static void encode(Writer out, Object o) throws IOException {
		try {
			if (o == null) {
				out.append("%00");
				return;
			}
			String s = o.toString();
			boolean needsReplace = false;
			for (int i = 0; i < s.length() && ! needsReplace ; i++) {
				char c = s.charAt(i);
				if (c == ' ' || c == '&' || c == '?' || c == '=' || c > 127)
					needsReplace = true;
			}

			if (! needsReplace) {
				out.append(s);
				return;
			}

			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (c == ' ')
					out.append('+');
				else if (c == '&' || c == '?' || c == '=' || c > 127)
					out.append(URLEncoder.encode(""+c, "UTF-8"));
				else
					out.append(c);
			}

		} catch (UnsupportedEncodingException e) {
			// Should never happen.
			e.printStackTrace();
		}
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter cr(int depth) throws IOException {
		super.cr(depth);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter appendln(int indent, String text) throws IOException {
		super.appendln(indent, text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter appendln(String text) throws IOException {
		super.appendln(text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(int indent, String text) throws IOException {
		super.append(indent, text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(int indent, char c) throws IOException {
		super.append(indent, c);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter s() throws IOException {
		super.s();
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter q() throws IOException {
		super.q();
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter i(int indent) throws IOException {
		super.i(indent);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter nl() throws IOException {
		super.nl();
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(Object text) throws IOException {
		super.append(text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(String text) throws IOException {
		super.append(text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter appendIf(boolean b, String text) throws IOException {
		super.appendIf(b, text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter appendIf(boolean b, char c) throws IOException {
		super.appendIf(b, c);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(char c) throws IOException {
		super.append(c);
		return this;
	}
}
