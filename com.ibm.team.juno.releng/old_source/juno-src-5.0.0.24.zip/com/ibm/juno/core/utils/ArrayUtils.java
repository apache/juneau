package com.ibm.juno.core.utils;

import java.lang.reflect.*;

/**
 * Quick and dirty utilities for working with arrays.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ArrayUtils {

	/**
	 * Appends one or more elements to an array.
	 * @param <T> The element type.
	 * @param array The array to append to.
	 * @param newElements The new elements to append to the array.
	 * @return A new array with the specified elements appended.
	 */
	@SuppressWarnings("unchecked")
	public static <T> T[] append(T[] array, T...newElements) {
		if (newElements.length == 0)
			return array;
		T[] a = (T[])Array.newInstance(newElements[0].getClass(), array.length + newElements.length);
		for (int i = 0; i < array.length; i++)
			a[i] = array[i];
		for (int i = 0; i < newElements.length; i++)
			a[i+array.length] = newElements[i];
		return a;
	}

	/**
	 * Creates a new array with reversed entries.
	 * @param <T> The class type of the array.
	 * @param array The array to reverse.
	 * @return A new array with reversed entries.
	 */
	@SuppressWarnings("unchecked")
	public static <T> T[] reverse(T[] array) {
		Class<T> c = (Class<T>)array.getClass().getComponentType();
		T[] a2 = (T[])Array.newInstance(c, array.length);
		for (int i = 0; i < array.length; i++)
			a2[a2.length-i-1] = array[i];
		return a2;
	}
}
