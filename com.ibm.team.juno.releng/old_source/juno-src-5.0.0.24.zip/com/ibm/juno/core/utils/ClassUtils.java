package com.ibm.juno.core.utils;

import com.ibm.juno.core.*;

/**
 * Class-related utility methods.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ClassUtils {

	/**
	 * Given the specified list of objects, return the object class type strings.
	 * @param o The objects.
	 * @return An array of class type strings.
	 */
	public static ObjectList getClassTypeStrings(Object[] o) {
		ObjectList l = new ObjectList();
		for (int i = 0; i < o.length; i++)
			l.add(o[i] == null ? "null" : o[i].getClass().getName());
		return l;
	}
}
