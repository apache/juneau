package com.ibm.juno.core.utils;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import com.ibm.juno.core.*;

/**
 * Convenience class for creating maps.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Create a map factory</jc>
 * 	MapFactory mf = <jk>new</jk> MapFactory(<js>"key1"</js>,<js>"key2"</js>,<js>"key3"</js>);
 *
 * 	<jc>// Create a map using the factory</jc>
 * 	Map m = mf.getMap(1,<jk>true</jk>,<js>"foo"</js>);  <jc>// m={key1:1, key2:true, key3:"foo"}</jc>
 * </p>
 *
 * @author jbognar
 */
public class MapFactory {

	/** The keys that generated maps will contain. */
	private String[] keys;

	/**
	 * Create a factory to create maps with the specified keys.
	 *
	 * @param keys The keys that generated maps will contain.
	 */
	public MapFactory(String...keys) {
		this.keys = keys;
	}

	/**
	 * Create a map with the specified values mapped to the keys passed in through the constructor.
	 * <p>
	 * 	If more values are passed in than keys, then the extra values will be ignored.
	 * <p>
	 * 	If fewer values are passed in than keys, then the extra keys will not be added to the map.
	 *
	 * @param vals The values that this map will contain.
	 * @return A new map with keys specified in the constructor, and values specified in this method.
	 */
	public ObjectMap getMap(Object...vals) {
		ObjectMap m = new ObjectMap();
		int x = Math.min(keys.length, vals.length);
		for (int i = 0; i < x; i++)
			m.put(keys[i], vals[i]);
		return m;
	}
}
