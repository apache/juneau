package com.ibm.juno.core.filter;

import com.ibm.juno.core.*;

/**
 * Parent class for all bean and POJO filters.
 *
 *
 * <h6 class='topic'>Description</h6>
 *	<p>
 *		Filters are used to alter how POJOs are handled by bean contexts (and subsequently serializers and parsers).
 *		The are a very powerful feature of the Juno framework that allows virtually any POJO to be serialized and parsed.
 *		For example, they can be used to...
 * <ul>
 * 	<li>Convert a non-serializable POJO into a serializable POJO during serialization (and optionally vis-versa during parsing).
 * 	<li>Hide properties on beans during serialization/parsing.
 * </ul>
 * <p>
 * 	There are 2 subclasses of filters:
 * <ul>
 * 	<li>{@link IPojoFilter} / {@link PojoFilter} - Non-bean filters for converting POJOs into serializable equivalents.
 * 	<li>{@link IBeanFilter} / {@link BeanFilter} - Bean filters for altering the visibility of bean properties.
 * </ul>
 *	<p>
 *		Filters are associated with bean contexts (and serializers/parsers) through the {@link BeanContext#addFilters(Class[])}
 *			and {@link CoreApi#addFilters(Class[])} methods.
 *
 *
 * <h6 class='topic'>Additional information</h6>
 * 	See {@link com.ibm.juno.core.filter} for more information.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface IFilter {

	/** Represents no filter. */
	public static interface NULL extends IFilter {}

	/**
	 * Returns the class that this filter applies to.
	 *
	 * @return The class that this filter applies to.
	 */
	public Class<?> forClass();

	/**
	 * Returns whether this filter is an instance of {@link IBeanFilter}.
	 * <p>
	 * Used to avoid unnecessary introspection.
	 *
	 * @return <jk>true</jk> if instance of {@link IBeanFilter}.
	 */
	public boolean isBeanFilter();
}
