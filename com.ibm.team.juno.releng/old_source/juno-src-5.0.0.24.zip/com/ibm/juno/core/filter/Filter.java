package com.ibm.juno.core.filter;

/**
 * Base class for {@link BeanFilter} and {@link PojoFilter}.
 *
 *
 * <h6 class='topic'>Additional information</h6>
 * 	See {@link com.ibm.juno.core.filter} for more information.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class Filter implements IFilter {

	/** The class that this filter applies to. */
	protected Class<?> forClass;
	private final boolean isBeanFilter;

	Filter(Class<?> forClass, boolean isBeanFilter) {
		this.forClass = forClass;
		this.isBeanFilter = isBeanFilter;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override
	public Class<?> forClass() {
		return forClass;
	}

	@Override
	public final boolean isBeanFilter() {
		return isBeanFilter;
	}
}
