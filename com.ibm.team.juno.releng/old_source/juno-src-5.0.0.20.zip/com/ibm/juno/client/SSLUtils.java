package com.ibm.juno.client;

import javax.net.ssl.*;

/**
 * Utilities for working with secure HTTP connections.
 */
public class SSLUtils {

	/**
	 * Call this method if you want to connect to <js>"https://..."</js> URLs and want to
	 * ignore certificate errors.
	 */
	public static void trustAllCerts() {
		try {
			// Create a trust manager that does not validate certificate chains
			TrustManager[] tm = new TrustManager[] {
				new X509TrustManager() {
					@Override
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						return null;
					}

					@Override
					public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}

					@Override
					public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
				}
			};

			// This is used to fix the problem where the hostname in the
			// certificate doesn't match the host in the URL.
			// This can occur if you're trying to connect using 'localhost'
			// instead of a real hostname.
			HostnameVerifier hv = new HostnameVerifier() {
				@Override
				public boolean verify(String urlHost, SSLSession session) {
					return true;
				}
			};

			// Install the all-trusting trust manager and hostname verifier.
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, tm, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(hv);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
