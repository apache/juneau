package com.ibm.juno.core.xml;

import java.io.*;

import com.ibm.juno.core.utils.*;

/**
 * XML utility methods.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlUtils {

	//--------------------------------------------------------------------------------
	// Encode URI part
	//--------------------------------------------------------------------------------

	/**
	 * Encodes invalid XML text characters.
	 * <p>
	 * Encodes <js>'&'</js>, <js>'&lt;'</js>, and <js>'&gt;'</js> as XML entities.<br>
	 * Encodes any other invalid XML text characters to <code>_x####_</code> sequences.
	 *
	 * @param o The object being encoded.
	 * @return The encoded string.
	 */
	public static final String encodeText(Object o) {

		if (o == null)
			return "_x0000_";

		String s = o.toString();

		try {
			if (needsTextEncoding(s))
				return encodeTextInner(new StringBuilderWriter(s.length()*2), s).toString();
		} catch (IOException e) {
			throw new RuntimeException(e); // Never happens
		}

		return s;
	}

	/**
	 * Same as {@link #encodeText(Object)}, but does not convert <js>'&'</js>, <js>'&lt;'</js>, and <js>'&gt;'</js>
	 * 	to entities.
	 *
	 * @param o The object being encoded.
	 * @return The encoded string.
	 */
	public static final String encodeTextShallow(Object o) {

		if (o == null)
			return "_x0000_";

		String s = o.toString();

		try {
			if (needsTextEncoding(s))
				return encodeTextShallowInner(new StringBuilderWriter(s.length()*2), s).toString();
		} catch (IOException e) {
			throw new RuntimeException(e); // Never happens
		}

		return s;
	}

	/**
	 * Encodes any invalid XML text characters to <code>_x####_</code> sequences and sends the response
	 * 	to the specified writer.
	 * @param w The writer to send the output to.
	 * @param o The object being encoded.
	 * @return The same writer passed in.
	 * @throws IOException Thrown from the writer.
	 */
	public static final Writer encodeText(Writer w, Object o) throws IOException {

		if (o == null)
			return w.append("_x0000_");

		String s = o.toString();

		if (needsTextEncoding(s))
			return encodeTextInner(w, s);

		w.append(s);

		return w;
	}

	private static final Writer encodeTextInner(Writer w, String s) throws IOException {
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '&')
				w.append("&amp;");
			else if (c == '<')
				w.append("&lt;");
			else if (c == '>')
				w.append("&gt;");
			else if (c == '_' && isEscapeSequence(s,i))
				appendPaddedHexChar(w, c);
			else if (isValidXmlCharacter(c))
				w.append(c);
			else
				appendPaddedHexChar(w, c);
		}
		return w;
	}

	private static final Writer encodeTextShallowInner(Writer w, String s) throws IOException {
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '_' && isEscapeSequence(s,i))
				appendPaddedHexChar(w, c);
			else if (isValidXmlCharacter(c))
				w.append(c);
			else
				appendPaddedHexChar(w, c);
		}
		return w;
	}

	private static final boolean needsTextEncoding(String s) {
		// See if we need to convert the string.
		// Conversion is somewhat expensive, so make sure we need to do so before hand.
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '&' || c == '<' || c == '>' || c == '\n' || ! isValidXmlCharacter(c) || (c == '_' && isEscapeSequence(s,i)))
				return true;
		}
		return false;
	}


	//--------------------------------------------------------------------------------
	// Decode XML text
	//--------------------------------------------------------------------------------

	/**
	 * Translates any _x####_ sequences (introduced by the various encode methods) back into their original characters.
	 * @param s The string being decoded.
	 * @return The decoded string.
	 */
	public static String decode(String s) {
		if (s == null) return null;
		if (s.length() == 0)
			return s;
		if (s.indexOf('_') == -1)
			return s;

		StringBuffer sb = new StringBuffer(s.length());
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '_' && isEscapeSequence(s,i)) {

				int x = Integer.parseInt(s.substring(i+2, i+6), 16);

				// If we find _x0000_, then that means a null.
				if (x == 0)
					return null;

				sb.append((char)x);
				i+=6;
			} else {
				sb.append(c);
			}
		}
		return sb.toString();
	}


	//--------------------------------------------------------------------------------
	// Encode XML attributes
	//--------------------------------------------------------------------------------

	/**
	 * Serializes and encodes the specified object as valid XML attribute name.
	 * @param w The writer to send the output to.
	 * @param o The object being serialized.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public static final Writer encodeAttr(Writer w, Object o) throws IOException {

		if (o == null)
			return w.append("_x0000_");

		String s = o.toString();

		if (needsAttributeEncoding(s))
			return encodeAttrInner(w, s);

		w.append(s);
		return w;
	}

	private static final Writer encodeAttrInner(Writer w, String s) throws IOException {
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '&')
				w.append("&amp;");
			else if (c == '<')
				w.append("&lt;");
			else if (c == '>')
				w.append("&gt;");
			else if (c == '\'')
				w.append("&apos;");
			else if (c == '"')
				w.append("&quot;");
			else if (c == '_' && isEscapeSequence(s,i))
				appendPaddedHexChar(w, c);
			else if (isValidXmlCharacter(c))
				w.append(c);
			else
				appendPaddedHexChar(w, c);
		}
		return w;
	}

	private static boolean needsAttributeEncoding(String s) {
		// See if we need to convert the string.
		// Conversion is somewhat expensive, so make sure we need to do so before hand.
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '&' || c == '<' || c == '>' || c == '\n' || c == '\'' || c == '"' || ! isValidXmlCharacter(c))
				return true;
		}
		return false;
	}


	//--------------------------------------------------------------------------------
	// Encode XML element names
	//--------------------------------------------------------------------------------

	/**
	 * Encodes any invalid XML element name characters to <code>_x####_</code> sequences.
	 * @param w The writer to send the output to.
	 * @param o The object being encoded.
	 * @return The same writer passed in.
	 * @throws IOException Throw by the writer.
	 */
	public static final Writer encodeElementName(Writer w, Object o) throws IOException {

		if (o == null)
			return w.append("_x0000_");

		String s = o.toString();

		if (needsElementNameEncoding(s))
			return encodeElementNameInner(w, s);

		w.append(s);
		return w;
	}

	/**
	 * Encodes any invalid XML element name characters to <code>_x####_</code> sequences.
	 * @param o The object being encoded.
	 * @return The encoded element name string.
	 */
	public static final String encodeElementName(Object o) {
		if (o == null)
			return "_x0000_";

		String s = o.toString();

		try {
			if (needsElementNameEncoding(s))
				return encodeElementNameInner(new StringBuilderWriter(s.length() * 2), s).toString();
		} catch (IOException e) {
			throw new RuntimeException(e); // Never happens
		}

		return s;
	}

	private static final Writer encodeElementNameInner(Writer w, String s) throws IOException {
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if ((c >= 'A' && c <= 'Z')
					|| (c == '_' && ! isEscapeSequence(s,i))
					|| (c >= 'a' && c <= 'z')
					|| (i != 0 && (
							c == '-'
							|| c == '.'
							|| (c >= '0' && c <= '9')
							|| c == '\u00b7'
							|| (c >= '\u0300' && c <= '\u036f')
							|| (c >= '\u203f' && c <= '\u2040')
						))
					|| (c >= '\u00c0' && c <= '\u00d6')
					|| (c >= '\u00d8' && c <= '\u00f6')
					|| (c >= '\u00f8' && c <= '\u02ff')
					|| (c >= '\u0370' && c <= '\u037d')
					|| (c >= '\u037f' && c <= '\u1fff')
					|| (c >= '\u200c' && c <= '\u200d')
					|| (c >= '\u2070' && c <= '\u218f')
					|| (c >= '\u2c00' && c <= '\u2fef')
					|| (c >= '\u3001' && c <= '\ud7ff')
					|| (c >= '\uf900' && c <= '\ufdcf')
					|| (c >= '\ufdf0' && c <= '\ufffd')) {
				w.append(c);
			}  else {
				appendPaddedHexChar(w, c);
			}
		}
		return w;
	}

	private static final boolean needsElementNameEncoding(String s) {
		// Note that this doesn't need to be perfect, just fast.
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (! (c >= '0' && c <= '9' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z'))
				return true;
			if (i == 0 && (c >= '0' && c <= '9'))
				return true;
		}
		return false;
	}


	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	// Returns true if the specified character can safely be used in XML text or an attribute.
	private static final boolean isValidXmlCharacter(char c) {
		return (c >= 0x20 && c <= 0xD7FF) /*|| c == 0xA || c == 0xD*/ || (c >= 0xE000 && c <= 0xFFFD) || (c >= 0x10000 && c <= 0x10FFFF);
	}

	// Returns true if the string at the specified position is of the form "_x####_"
	// where '#' are hexadecimal characters.
	private static final boolean isEscapeSequence(String s, int i) {
		return s.length() > i+6
			&& s.charAt(i) == '_'
			&& s.charAt(i+1) == 'x'
			&& isHexCharacter(s.charAt(i+2))
			&& isHexCharacter(s.charAt(i+3))
			&& isHexCharacter(s.charAt(i+4))
			&& isHexCharacter(s.charAt(i+5))
			&& s.charAt(i+6) == '_';
	}

	// Returns true if the character is a hexadecimal character
	private static final boolean isHexCharacter(char c) {
		return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F');
	}

	// Converts an integer to a hexadecimal string padded to 4 places.
	private static final Writer appendPaddedHexChar(Writer out, int num) throws IOException {
		out.append("_x");
		char[] n = new char[4];
		int a = num%16;
		n[3] = (char)(a > 9 ? 'A'+a-10 : '0'+a);
		int base = 16;
		for (int i = 1; i < 4; i++) {
			a = (num/base)%16;
			base <<= 4;
			n[3-i] = (char)(a > 9 ? 'A'+a-10 : '0'+a);
		}
		for (int i = 0; i < 4; i++)
			out.append(n[i]);
		return out.append('_');
	}
}
