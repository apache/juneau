package com.ibm.juno.server.annotation;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.*;

import java.lang.annotation.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.encoders.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.jena.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;
import com.ibm.juno.server.*;

/**
 * Optionally used to associate metadata on an instance of {@link RestServlet}.
 *
 * <h5 class='topic'>Example usages</h5>
 *
 * <h6 class='topic'>Associating NLS resource bundles with a class</h6>
 * The {@link #nls} annotation can be used to associate a resource bundle with a servlet class.
 * <p>
 * Convenience methods are provided for accessing localized messages based on the client locale.
 * <p class='bcode'>
 * 	<jc>// Servlet with associated resource bundle</jc>
 * 	<ja>@RestResource</ja>(nls=<js>"nls/MyMessages"</js>)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 *
 * 		<jc>// Returns the localized greeting from the "greeting" key in MyMessages.properties</jc>
 * 		<ja>@RestMethod</ja>(name=<js>"GET"</js>, pattern=<js>"/"</js>)
 * 		<jk>public</jk> String printLocalizedGreeting(RestRequest req) {
 * 			<jk>return</jk> req.getMessage(<js>"greeting"</js>);
 * 		}
 * </p>
 * <p>
 * The resource bundle is also used for providing localized strings on the automatically-generated OPTIONS page...
 * <p>
 * <img class='bordered' src="doc-files/NlsOptions.png"/>
 *
 * <h6 class='topic'>Adding class-level guards</h6>
 * The {@link #guards} annotation can be used to associate one or more class-level {@link RestGuard guards} with a servlet.
 * <p>
 * <p class='bcode'>
 * 	<jc>// Servlet with class-level guard applied</jc>
 * 	<ja>@RestResource</ja>(guards=BillyGuard.<jk>class</jk>)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 *
 * 		<jc>// Delete method that only Billy is allowed to call.</jc>
 * 		<jk>public</jk> doDelete(RestRequest req, RestResponse res) <jk>throws</jk> Exception {...}
 * 	}
 *
 * 	<jc>// Define a guard that only lets Billy make a request</jc>
 * 	<jk>public</jk> BillyGuard <jk>extends</jk> RestGuard {
 *
 * 		<ja>@Override</ja>
 * 		<jk>public boolean</jk> isRequestAllowed(RestRequest req) {
 * 			return req.getUserPrincipal().getName().contains(<js>"Billy"</js>);
 * 		}
 * 	}
 * </p>
 * <p>
 * When guards are associated at the class-level, it's equivalent to associating guards on all Java methods on the servlet.
 *
 * <h6 class='topic'>Specifying class-level serializers and parsers</h6>
 * The {@link #serializers()} and {@link #parsers()} annotations can be used to identify the list
 * 	of serializers and parsers that the servlet can use.
 * <p>
 * <p class='bcode'>
 * 	<jc>// Servlet with only JSON and XML support</jc>
 * 	<ja>@RestResource</ja>(
 * 		serializers={JsonSerializer.<jk>class</jk>, XmlSerializer.<jk>class</jk>},
 * 		parsers={JsonParser.<jk>class</jk>, XmlParser.<jk>class</jk>}
 * 	)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 * 		...
 * 	}
 * </p>
 *
 * <h6 class='topic'>Adding POJO filters</h6>
 * The {@link #filters()} annotation can be used as a convenient way to add POJO filters to the serializers and parsers
 * 	registered with the servlet.
 * <p>
 * <p class='bcode'>
 * 	<jc>// Servlet with filters applied</jc>
 * 	<ja>@RestResource</ja>(
 * 		filters={
 * 			<jc>// Calendars should be serialized/parsed as ISO8601 date-time strings</jc>
 * 			CalendarFilter.<jsf>DEFAULT_ISO8601DT</jsf>.<jk>class</jk>,
 *
 * 			<jc>// Byte arrays should be serialized/parsed as BASE64-encoded strings</jc>
 * 			ByteArrayBase64Filter.<jk>class</jk>,
 *
 * 			<jc>// Subclasses of MyInterface will be treated as MyInterface objects.</jc>
 * 			<jc>// Bean properties not defined on that interface will be ignored.</jc>
 * 			MyInterface.<jk>class</jk>
 * 		}
 * 	)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 * 		...
 * 	}
 * </p>
 *
 * <h6 class='topic'>Adding class-level serializer/parser properties</h6>
 * The {@link #properties()} annotation can be used as a convenient way to set various serializer and parser
 * 	properties to all serializers and parsers registered with the servlet.
 * <p>
 * <p class='bcode'>
 * 	<jk>import static</jk> com.ibm.juno.core.SerializerProperties.*;
 * 	<jk>import static</jk> com.ibm.juno.core.xml.XmlSerializerProperties.*;
 * 	<jk>import static</jk> com.ibm.juno.server.serializers.HtmlSerializerProperties.*;
 *
 * 	<jc>// Servlet with properties applied</jc>
 * 	<ja>@RestResource</ja>(
 * 		properties={
 * 			<jc>// Nulls should not be serialized</jc>
 * 			<ja>@Property</ja>(name=<jsf>TRIM_NULLS</jsf>, value=<js>"true"</js>),
 *
 * 			<jc>// Empty lists should not be serialized</jc>
 * 			<ja>@Property</ja>(name=<jsf>TRIM_EMPTY_LISTS</jsf>, value=<js>"true"</js>),
 *
 * 			<jc>// Specify the default namespaces for the XML serializer</jc>
 * 			<ja>@Property</ja>(name=<jsf>DEFAULT_NAMESPACES</jsf>,
 * 				value=<js>"{jp06:'http://jazz.net/xmlns/prod/jazz/process/0.6/',jp:'http://jazz.net/xmlns/prod/jazz/process/1.0/'}"</js>),
 *
 * 			<jc>// Specify a default title for the HtmlSerializer serializer</jc>
 * 			<ja>@Property</ja>(name=<jsf>TITLE</jsf>, value=<js>"My resource"</js>)
 * 		}
 * 	)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 * 		...
 * 	}
 * </p>
 *
 * <h6 class='topic'>Adding class-level response converters</h6>
 * The {@link #converters} annotation can be used as a convenient way to add {@link RestConverter response converters} to
 * 	all Java REST methods on a servlet.
 * <p>
 * <p class='bcode'>
 * 	<jc>// Associate the Traversable converter to all Java REST methods in this servlet</jc>
 * 	<ja>@RestResource</ja>(converters=Traversable.<jk>class</jk>)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 * 		...
 * 	}
 * </p>
 *
 * <h6 class='topic'>Adding default request and response headers.</h6>
 * The {@link #defaultRequestHeaders()} annotation can be used to specify a default value to
 * 	have returned by the {@link RestRequest#getHeader(String)} method when the client
 * 	does not specify a value.
 * <p>
 * The {@link #defaultResponseHeaders()} annotation can be used to specify a default header
 * 	value to add to all responses.
 * <p>
 * <p class='bcode'>
 * 	<jc>// Servlet with default headers</jc>
 * 	<ja>@RestResource</ja>(
 *
 * 		<jc>// Assume "text/json" Accept value when Accept not specified</jc>
 * 		defaultRequestHeaders={<js>"Accept: text/json"</js>},
 *
 * 		<jc>// Add a version header attribute to all responses</jc>
 * 		defaultResponseHeaders={<js>"X-Version: 1.0"</js>}
 * 	)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 * 		...
 * 	}
 * </p>
 *
 * <h6 class='topic'>Inheritance</h6>
 * This annotation can be used on parent classes and interfaces.
 * When multiple annotations are defined at different levels, the annotation values
 * 	are combined.
 * Child annotation values always take precidence over parent annotation values.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Documented
@Target(TYPE)
@Retention(RUNTIME)
@Inherited
public @interface RestResource {

	/**
	 * Identifies the location of the resource bundle for this class.
	 * <p>
	 * This annotation is used to provide localized messages for the following methods:
	 * <ul>
	 * 	<li>{@link RestServlet#getMessage(java.util.Locale, String, Object...)}
	 * 	<li>{@link RestServlet#getMethodDescriptions(RestRequest)}
	 * 	<li>{@link RestServlet#getResourceDescription(java.util.Locale)}
	 * </ul>
	 * <p>
	 * Refer to the {@link RestServletNls} class for a description of the message key formats
	 * 	used in the properties file.
	 * <p>
	 * The value can be a relative path like <js>"nls/Messages"</js>, indicating to look for the
	 * 	resource bundle <js>"com.ibm.sample.nls.Messages"</js> if the resource class
	 * 	is in <js>"com.ibm.sample"</js>, or it can be an absolute path, like <js>"com.ibm.sample.nls.Messages"</js>
	 */
	String nls() default "";

	/**
	 * Class-level guards.
	 * <p>
	 * Associates one or more {@link RestGuard RestGuards} with all REST methods defined
	 * 	in this class.
	 * These guards get called immediately before execution of any REST method in this class.
	 * <p>
	 * Typically, guards will be used for permissions checking on the user making the request,
	 * 	but it can also be used for other purposes like pre-call validation of a request.
	 */
	Class<? extends RestGuard>[] guards() default {};

	/**
	 * Class-level converters.
	 * <p>
	 * Associates one or more {@link RestConverter converters} with a resource class.
	 * These converters get called immediately after execution of the REST method in the same
	 * 	order specified in the annotation.
	 * <p>
	 * Can be used for performing post-processing on the response object before serialization.
	 * <p>
	 * Default converter implementations are provided in the {@link com.ibm.juno.server.converters} package.
	 */
	Class<? extends RestConverter>[] converters() default {};

	/**
	 * Class-level POJO filters.
	 * <p>
	 *	Shortcut to add POJO filters to the bean contexts of the objects returned by the following methods:
	 *	<ul>
	 *		<li>{@link RestServlet#createBeanContext()}
	 *		<li>{@link RestServlet#createSerializerGroup()}
	 *		<li>{@link RestServlet#createParserGroup()}
	 *	</ul>
	 * <p>
	 * If the specified class is an instance of {@link Filter}, then that filter is added.
	 * Any other classes are wrapped in a {@link BeanFilter} to indicate that subclasses should
	 * 	be treated as the specified class type.
	 */
	Class<?>[] filters() default {};

	/**
	 * Class-level properties.
	 * <p>
	 *		Shortcut for specifying class-level properties on this servlet to the objects returned by the following methods:
	 *	<ul>
	 *		<li>{@link RestServlet#createBeanContext()}
	 *		<li>{@link RestServlet#createSerializerGroup()}
	 *		<li>{@link RestServlet#createParserGroup()}
	 *	</ul>
	 *	<p>
	 *		Any of the following property names can be specified:
	 *	<ul>
	 *		<li>{@link RestServletProperties}
	 *		<li>{@link BeanContextProperties}
	 *		<li>{@link SerializerProperties}
	 *		<li>{@link ParserProperties}
	 *		<li>{@link JsonSerializerProperties}
	 *		<li>{@link RdfSerializerProperties}
	 *		<li>{@link RdfParserProperties}
	 *		<li>{@link RdfProperties}
	 *		<li>{@link XmlSerializerProperties}
	 *		<li>{@link XmlParserProperties}
	 *	</ul>
	 * <p>
	 * Property values will be converted to the appropriate type.
	 * <p>
	 * In some cases, properties can be overridden at runtime through the {@link RestResponse#setProperty(String, Object)} method
	 * 	or through a {@link Properties @Properties} annotated method parameter.
	 */
	Property[] properties() default {};

	/**
	 * Specifies a list of {@link ISerializer} classes to add to the list of serializers available for this servlet.
	 * <p>
	 * This is equivalent to overriding the {@link RestServlet#createSerializerGroup()} method and adding the serializers programmatically,
	 * but the annotation is often cleaner to read, and makes it more obvious what <code>Accept</code> types the servlet will handle.
	 * <p>
	 * This annotation can only be used on {@link ISerializer} classes that have no-arg constructors.
	 */
	Class<? extends ISerializer>[] serializers() default {};

	/**
	 * Specifies a list of {@link IParser} classes to add to the list of parsers available for this servlet.
	 * <p>
	 * This is equivalent to overriding the {@link RestServlet#createParserGroup()} method and adding the parsers programmatically,
	 * but the annotation is often cleaner to read, and makes it more obvious what <code>Content-Type</code> types the servlet will handle.
	 * <p>
	 * This annotation can only be used on {@link IParser} classes that have no-arg constructors.
	 */
	Class<? extends IParser>[] parsers() default {};

	/**
	 * Specifies a list of {@link Encoder} to associate with this servlet.
	 * <p>
	 * These can be used to enable various kinds of compression (e.g. <js>"gzip"</js>) on requests and responses.
	 * <p>
	 * This annotation can only be used on {@link Encoder} classes that have no-arg constructors.
	 * <p>
	 * <h6 class='topic'>Example</h6>
	 * <p class='bcode'>
	 * 	<jc>// Servlet with automated support for GZIP compression</jc>
	 * 	<ja>@RestResource</ja>(encoders={GzipEncoder.<jk>class</jk>})
	 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
	 * 		...
	 * 	}
	 * </p>
	 */
	Class<? extends Encoder>[] encoders() default {};

	/**
	 * Specifies default values for request headers.
	 * <p>
	 * Strings are of the format <js>"Header-Name: header-value"</js>.
	 * <p>
	 * Affects values returned by {@link RestRequest#getHeader(String)} when the header is not present on the request.
	 * <p>
	 * The most useful reason for this annotation is to provide a default <code>Accept</code> header when one is not specified
	 * 	so that a particular default {@link ISerializer} is picked.
	 * <p>
	 * Only one header value can be specified per entry (i.e. it's not a delimited list of header entries).
	 * <p>
	 * <h6 class='figure'>Example</h6>
	 * <p class='bcode'>
	 * 	<jc>// Assume "text/json" Accept value when Accept not specified</jc>
	 * 	<ja>@RestResource</ja>(defaultRequestHeaders={<js>"Accept: text/json"</js>})
	 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
	 * 		...
	 * 	}
	 * </p>
	 */
	String[] defaultRequestHeaders() default {};

	/**
	 * Specifies default values for response headers.
	 * <p>
	 * Strings are of the format <js>"Header-Name: header-value"</js>.
	 * <p>
	 * This is equivalent to calling {@link RestResponse#setHeader(String, String)} programmatically in each of the Java methods.
	 * <p>
	 * The header value will not be set if the header value has already been specified (hence the 'default' in the name).
	 * <p>
	 * Only one header value can be specified per entry (i.e. it's not a delimited list of header entries).
	 * <p>
	 * <h6 class='figure'>Example</h6>
	 * <p class='bcode'>
	 * 	<jc>// Add a version header attribute to all responses</jc>
	 * 	<ja>@RestResource</ja>(defaultResponseHeaders={<js>"X-Version: 1.0"</js>})
	 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
	 * 		...
	 * 	}
	 * </p>
	 */
	String[] defaultResponseHeaders() default {};
}
