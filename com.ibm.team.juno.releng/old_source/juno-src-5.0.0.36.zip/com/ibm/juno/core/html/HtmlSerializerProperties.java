package com.ibm.juno.core.html;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Configurable properties on the {@link HtmlSerializer} class.
 * <p>
 * 	Use the {@link HtmlSerializer#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link HtmlSerializer}.
 * <ul>
 * 	<li>{@link XmlSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlSerializerProperties implements Cloneable {

	/**
	 * Anchor text source ({@link String}, default={@link #TO_STRING}).
	 * <p>
	 * When creating anchor tags (e.g. <code><xt>&lt;a</xt> <xa>href</xa>=<xs>'...'</xs><xt>&gt;</xt>text<xt>&lt;/a&gt;</xt></code>)
	 * 	in HTML, this setting defines what to set the inner text to.
	 * <p>
	 * Possible values:
	 * <ul>
	 * 	<li>{@link #TO_STRING} / <js>"toString"</js> - Set to whatever is returned by {@link #toString()} on the object.
	 * 	<li>{@link #URI} / <js>"uri"</js> - Set to the URI value.
	 * 	<li>{@link #LAST_TOKEN} / <js>"lastToken"</js> - Set to the last token of the URI value.
	 * 	<li>{@link #PROPERTY_NAME} / <js>"propertyName"</js> - Set to the bean property name.
	 * </ul>
	 * <h6 class='topic'>Examples</h6>
	 * <p>
	 * 	Given the following bean...
	 * <p>
	 * <p class='bcode'>
	 * 	<jc>// Bean with URI property</jc>
	 * 	<jk>public class</jk> MyBean {
	 * 		<jk>public</jk> URI getBeanUri() {
	 * 			...
	 * 		}
	 * 	}
	 * </p>
	 *	<p>
	 *		...this table shows the possible output...
	 * <p>
	 * <table class='styled'>
	 * 	<tr>
	 * 		<th><jsf>URI</jsf></th>
	 * 		<th><jsf>URI_AUTHORITY</jsf></th>
	 * 		<th><jsf>URI_CONTEXT</jsf></th>
	 * 		<th><jsf>URI_ANCHOR_TEXT</jsf></th>
	 * 		<th>Serialized value</th>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>http://myhost:9080/foo/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>TO_STRING<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>http://myhost:9080/foo/bar/baz<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>TO_STRING<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>bar/baz<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>/foo/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>TO_STRING<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>/foo/bar/baz<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>http://myhost:9080/foo/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>URI<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>http://myhost:9080/foo/bar/baz<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>URI<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>http://myhost:9080/foo/bar/baz<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>/foo/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>URI<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>http://myhost:9080/foo/bar/baz<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>http://myhost:9080/foo/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>LAST_TOKEN<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>baz<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>LAST_TOKEN<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>baz<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>/foo/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>LAST_TOKEN<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>baz<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>http://myhost:9080/foo/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>PROPERTY_NAME<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>beanUri<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>PROPERTY_NAME<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>beanUri<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>/foo/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080<code></td>
	 * 		<td><code>/foo</code></td>
	 * 		<td><jsf>PROPERTY_NAME<jsf></td>
	 * 		<td><code><xt>&lt;a</xt> <xa>href</xa>=<xs>'http://myhost:9080/foo/bar/baz'</xs><xt>&gt;</xt>beanUri<xt>&lt;/a&gt;</xt></code></td>
	 * 	</tr>
	 * </table>
	 */
	public static final String URI_ANCHOR_TEXT = "HtmlSerializer.uriAnchorText";

	/** Constant for {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} property. */
	public static final String PROPERTY_NAME = "propertyName";
	/** Constant for {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} property. */
	public static final String TO_STRING = "toString";
	/** Constant for {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} property. */
	public static final String URI = "uri";
	/** Constant for {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} property. */
	public static final String LAST_TOKEN = "lastToken";

	String uriAnchorText = TO_STRING;

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		if (property.equals(URI_ANCHOR_TEXT))
			uriAnchorText = (value == null ? null : value.toString());
		else
			return false;
		return true;
	}

	@Override // Cloneable
	public HtmlSerializerProperties clone() {
		try {
			return (HtmlSerializerProperties)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
