package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.BeanContextProperties.*;
import static com.ibm.juno.core.ClassMetaConst.*;

import java.io.*;
import java.lang.reflect.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;

import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.filter.Filter;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.parser.ParseException;
import com.ibm.juno.core.serializer.*;

/**
 * Core class of the Juno architecture.
 * <p>
 * 	This class servers multiple purposes:
 * 	<ul>
 * 		<li>Provides the ability to wrap beans inside {@link Map} interfaces.
 * 		<li>Serves as a repository for metadata on POJOs, such as associated {@link Filter filters}, {@link PropertyNamer property namers}, etc...
 * 			which are used to tailor how POJOs are serialized and parsed.
 * 		<li>Serves as a common utility class for all {@link Serializer Serializers} and {@link Parser Parsers}
 * 				for serializing and parsing Java beans.
 * 	</ul>
 *
 *
 * <h5 class='topic'>Bean Contexts</h5>
 * <p>
 * 	Typically, it will be sufficient to use the existing {@link #DEFAULT} contexts for creating
 * 	bean maps.  However, if you want to tweak any of the settings on the context, you must
 * 	either clone the default context or create a new one from scratch (whichever is simpler for you).
 * 	You'll notice that this context class uses a fluent interface for defining settings.
 * <p>
 *		Bean contexts can be locked using the {@link #lock()} method.  This makes the context settings
 *		read-only.  Attempting to change a setting on a locked context will cause a {@link LockedException}
 *		to be thrown.  The default context is locked by default.  Cloning a locked context using the
 *		{@link #clone()} method produces a new unlocked context.  Locking a context is optional, although
 *		it can prevent errors where bean contexts, parsers, or serializers start behaving differently
 *		because a setting was changed.  As a general rule, if you want to change a setting on an existing
 *		context, you should clone it, modify the setting(s), and then lock the new context.
 *
 *
 * <h5 class='topic'>BeanContext settings</h5>
 * 	<code>BeanContexts</code> have several settings that can be used to tweak behavior on how beans are handled.
 * <p>
 * 	Some settings (e.g. {@link BeanContextProperties#BEANS_REQUIRE_DEFAULT_CONSTRUCTOR}) are used to differentiate between bean and non-bean classes.
 * 	Attempting to create a bean map around one of these objects will throw a {@link BeanRuntimeException}.
 * 	The purpose for this behavior is so that the serializers can identify these non-bean classes and convert them to plain strings using the {@link Object#toString()} method.
 * <p>
 * 	Some settings (e.g. {@link BeanContextProperties#INCLUDE_BEAN_FIELD_PROPERTIES}) are used to determine what kinds of properties are detected on beans.
 * <p>
 * 	Some settings (e.g. {@link BeanContextProperties#BEANMAP_PUT_RETURNS_OLD_VALUE}) change the runtime behavior of bean maps.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * 	This class has configurable properties that can be set through the {@link #setProperty(String, Object)} method.
 * <p>
 * 	See {@link BeanContextProperties} for settings applicable to this class.
 *
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Construct a context from scratch and lock it.</jc>
 * 	BeanContext beanContext = <jk>new</jk> BeanContext()
 * 		.setProperty(<jsf>REQUIRE_DEFAULT_CONSTRUCTOR</jsf>, <jk>true</jk>)
 * 		.addNotBeanClasses(Foo.<jk>class</jk>)
 * 		.lock();
 *
 * 	<jc>// Clone an existing context.</jc>
 * 	BeanContext beanContext = BeanContext.<jsf>DEFAULT</jsf>.clone()
 * 		.setProperty(<jsf>REQUIRE_DEFAULT_CONSTRUCTOR</jsf>, <jk>true</jk>)
 * 		.addNotBeanClasses(Foo.<jk>class</jk>)
 * 		.lock();
 * </p>
 *
 *
 * <h5 class='topic'>Bean Maps</h5>
 * <p>
 * 	{@link BeanMap BeanMaps} are wrappers around Java beans that allow properties to be retrieved and
 * 	set using the common {@link Map#put(Object,Object)} and {@link Map#get(Object)} methods.<br>
 * 	<br>
 * 	Bean maps are created in two ways...
 * 	<ol>
 * 		<li> {@link BeanContext#forBean(Object) BeanContext.forBean()} - Wraps an existing bean inside a {@code Map} wrapper.
 * 		<li> {@link BeanContext#newBeanMap(Class) BeanContext.newInstance()} - Create a new bean instance wrapped in a {@code Map} wrapper.
 * 	</ol>
 *
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// A sample bean class</jc>
 * 	<jk>public class</jk> Person {
 * 		<jk>public</jk> String getName();
 * 		<jk>public void</jk> setName(String name);
 * 		<jk>public int</jk> getAge();
 * 		<jk>public void</jk> setAge(<jk>int</jk> age);
 * 	}
 *
 * 	<jc>// Wrap an existing bean in a new bean map</jc>
 * 	BeanMap&lt;Person&gt; m1 = BeanContext.<jsf>DEFAULT</jsf>.forBean(<jk>new</jk> Person());
 * 	m1.put(<js>"name"</js>, <js>"John Smith"</js>);
 * 	m1.put(<js>"age"</js>, 45);
 *
 * 	<jc>// Create a new bean instance wrapped in a new bean map</jc>
 * 	BeanMap&lt;Person&gt; m2 = BeanContext.<jsf>DEFAULT</jsf>.newInstance(Person.<jk>class</jk>);
 * 	m2.put(<js>"name"</js>, <js>"John Smith"</js>);
 * 	m2.put(<js>"age"</js>, 45);
 * 	Person p = m2.getBean();  <jc>// Get the bean instance that was created.</jc>
 * </p>
 *
 *
 * <h5 class='topic'>Bean Annotations</h5>
 * <p>
 * 	This package contains annotations that can be applied to
 * 	class definitions to override what properties are detected on a bean.
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Bean class definition where only property 'name' is detected.</jc>
 * 	<ja>&#64;Bean</ja>(properties={<js>"name"</js>})
 * 	<jk>public class</jk> Person {
 * 		<jk>public</jk> String getName();
 * 		<jk>public void</jk> setName(String name);
 * 		<jk>public int</jk> getAge();
 * 		<jk>public void</jk> setAge(<jk>int</jk> age);
 * 	}
 * <p>
 * 	See {@link Bean @Bean} and {@link BeanProperty @BeanProperty} for more information.
 *
 *
 * <h5 class='topic'>Beans with read-only properties</h5>
 * <p>
 * 	Bean maps can also be defined on top of beans with read-only properties by adding a
 * 	{@link BeanConstructor @BeanConstructor} annotation to one of the constructors on the
 * 	bean class.  This will allow read-only properties to be set through constructor arguments.
 * <p>
 * 	When the <code>@BeanConstructor</code> annotation is present, bean instantiation is delayed until the call to {@link BeanMap#getBean()}.
 * 	Until then, bean property values are stored in a local cache until <code>getBean()</code> is called.
 * 	Because of this additional caching step, parsing into read-only beans tends to be slower and use
 * 	more memory than parsing into beans with writable properties.
 * <p>
 * 	Attempting to call {@link BeanMap#put(String,Object)} on a read-only property after calling {@link BeanMap#getBean()}
 * 	will result in a {@link BeanRuntimeException} being thrown.
 * 	Multiple calls to {@link BeanMap#getBean()} will return the same bean instance.
 * <p>
 * 	Beans can be defined with a combination of read-only and read-write properties.
 * <p>
 * 	See {@link BeanConstructor @BeanConstructor} for more information.
 *
 *
 * <h5 class='topic'>Filters</h5>
 * <p>
 * 	{@link Filter Filters} are used to tailor how beans and non-beans are handled.<br>
 * 	There are two subclasses of filters:
 * 	<ol>
 * 		<li>{@link BeanFilter} - Allows you to tailor handling of bean classes.
 * 			This class can be considered a programmatic equivalent to the {@link Bean} annotation when
 * 			annotating classes are not possible (e.g. you don't have access to the source).
 * 		<li>{@link PojoFilter} - Allows you to convert objects to serializable forms.
 * 	</ol>
 * <p>
 * 	See {@link com.ibm.juno.core.filter} for more information.
 *
 *
 * <h5 class='topic'>ClassMetas</h5>
 * <p>
 * 	The {@link ClassMeta} class is a wrapper around {@link Class} object that provides cached information
 * 	about that class (e.g. whether it's a {@link Map} or {@link Collection} or bean).
 * <p>
 * 	As a general rule, it's best to reuse bean contexts (and therefore serializers and parsers too)
 * 	whenever possible since it takes some time to populate the internal {@code ClassMeta} object cache.
 * 	By reusing bean contexts, the class type metadata only needs to be calculated once which significantly
 * 	improves performance.
 * <p>
 * 	See {@link ClassMeta} for more information.
 *
 * @author Barry M. Caceres
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({"unchecked","rawtypes"})
public final class BeanContext extends Lockable {

	//--------------------------------------------------------------------------------
	// Static constants
	//--------------------------------------------------------------------------------

	/**
	 * The default package pattern exclusion list.
	 * Any beans in packages in this list will not be considered beans.
	 */
	private static final String DEFAULT_NOTBEAN_PACKAGES =
		"java.lang,java.lang.annotation,java.lang.ref,java.lang.reflect,java.io,java.net,java.nio.*,java.util.*";

	/**
	 * The default bean class exclusion list.
	 * Anything in this list will not be considered beans.
	 */
	private static final Class<?>[] DEFAULT_NOTBEAN_CLASSES = {
		Map.class,
		Collection.class,
		Reader.class,
		Writer.class,
		InputStream.class,
		OutputStream.class,
		Throwable.class
	};

	/** Default context.  All default settings. */
	public static final BeanContext DEFAULT = new BeanContext();


	//--------------------------------------------------------------------------------
	// Properties
	//--------------------------------------------------------------------------------

	boolean
		beansRequireDefaultConstructor = false,
		beansRequireSerializable = false,
		beansRequireSettersForGetters = false,
		beansRequireSomeProperties = true,
		beanMapPutReturnsOldValue = false,
		includeBeanFieldProperties = true,
		includeBeanMethodProperties = true,
		useInterfaceProxies = true,
		ignoreUnknownBeanProperties = false,
		ignoreUnknownNullBeanProperties = true,
		ignorePropertiesWithoutSetters = true,
		ignoreInvocationExceptionsOnGetters = false,
		ignoreInvocationExceptionsOnSetters = false;

	private transient Set<String> notBeanPackages = new LinkedHashSet<String>();
	private transient String[] notBeanPackageNames = new String[0];
	private transient String[] notBeanPackagePrefixes = new String[0];
	private transient Map<Class<?>,Filter> filters = new ConcurrentHashMap<Class<?>,Filter>();
	private transient Set<Class<?>> notBeanClasses = new HashSet<Class<?>>();
	private transient Map<Class<?>,Class<?>> implClasses = new ConcurrentHashMap<Class<?>, Class<?>>();
	private transient Map<String,String> uriVars = new ConcurrentHashMap<String,String>();

	// Cache of previously encountered ClassMeta objects for this context.
	private Map<Class,ClassMeta> classMetaCache;

	// Cache of all instances of classMetaCache for all bean contexts keyed by
	// the hashcode of the bean context during creation.
	// TODO - Convert these to soft references.
	private static final Map<Integer,Map<Class,ClassMeta>> classMetaCacheCache = new ConcurrentHashMap<Integer,Map<Class,ClassMeta>>();

	// Holds all properties currently set on this bean context.
	private ObjectMap properties = new ObjectMap();

	// Holds pending ClassMetas (created, but not yet initialized).
	private Deque<ClassMeta> pendingClassMetas = new LinkedList();


	//--------------------------------------------------------------------------------
	// Methods
	//--------------------------------------------------------------------------------

	/**
	 * Default constructor.
	 */
	public BeanContext() {
		addNotBeanClasses(DEFAULT_NOTBEAN_CLASSES);
		setProperty(ADD_NOTBEAN_PACKAGES, DEFAULT_NOTBEAN_PACKAGES);
	}

	/*
	 * Returns the ClassMeta cache for this bean context (lazy loaded).
	 */
	private final Map<Class,ClassMeta> getClassMetaCache() {
		if (classMetaCache != null)
			return classMetaCache;

		int hc = hashCodeForClassMetaCache();
		synchronized (classMetaCacheCache) {
			if (! classMetaCacheCache.containsKey(hc))
				classMetaCacheCache.put(hc, getDefaultClassMetaCache());
			classMetaCache = classMetaCacheCache.get(hc);
			return classMetaCache;
		}
	}

	/*
	 * Returns <jk>true</jk> if this and the specified bean contexts share the same class type cache.
	 * @param bc The comparison bean context.
	 * @return <jk>true</jk> if this and the specified bean contexts share the same class type cache.
	 */
	private boolean equals(BeanContext bc) {
		return bc.getClassMetaCache() == this.getClassMetaCache();
	}

	/**
	 * Returns <jk>true</jk> if the specified bean context shares the same cache as this bean context.
	 * Useful for testing purposes.
	 *
	 * @param bc The bean context to compare to.
	 * @return <jk>true</jk> if the bean contexts have equivalent settings and thus share caches.
	 */
	protected boolean hasSameCache(BeanContext bc) {
		return equals(bc);
	}

	/*
	 * Creates a hashcode based on all the current settings of this context.
	 * Bean contexts that have the same hashcode can share ClassMeta caches.
	 */
	private int hashCodeForClassMetaCache() {
		int i =
			  (beansRequireDefaultConstructor ? 1<<1 : 0)
			+ (beansRequireSerializable ? 1<<2 : 0)
			+ (beansRequireSettersForGetters ? 1<<3 : 0)
			+ (beansRequireSomeProperties ? 1<<4 : 0)
			+ (beanMapPutReturnsOldValue ? 1<<5 : 0)
			+ (includeBeanFieldProperties ? 1<<6 : 0)
			+ (includeBeanMethodProperties ? 1<<7 : 0)
			+ (useInterfaceProxies ? 1<<8 : 0)
			+ (ignoreUnknownBeanProperties ? 1<<9 : 0)
			+ (ignoreUnknownNullBeanProperties ? 1<<10 : 0)
			+ (ignorePropertiesWithoutSetters ? 1<<11 : 0)
			+ (ignoreInvocationExceptionsOnGetters ? 1<<12 : 0)
			+ (ignoreInvocationExceptionsOnSetters ? 1<<13 : 0)
		;

		for (String p : notBeanPackages)
			i += p.hashCode();
		for (Filter f : filters.values()) {
			i += f.getClass().getName().hashCode();
			i += f.forClass().getName().hashCode();
		}
		i += notBeanClasses.hashCode();
		i += implClasses.keySet().hashCode();
		i += uriVars.hashCode();
		return i;
	}

	/*
	 * Creates the default ClassMeta cache.
	 */
	private Map<Class,ClassMeta> getDefaultClassMetaCache() {
		Map<Class,ClassMeta> m = new IdentityHashMap<Class,ClassMeta>();
		m.put(Object.class, OBJECT);
		m.put(String.class, STRING);
		return m;
	}


	//--------------------------------------------------------------------------------
	// Configuration property methods
	//--------------------------------------------------------------------------------

	/**
	 * Sets a property on this context.
	 * <p>
	 * 	Refer to {@link BeanContextProperties} for a description of available properties.
	 * @param property The property whose value is getting changed.
	 * @param value The new value.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public BeanContext setProperty(String property, Object value) throws LockedException {
		checkLock();

		// Note:  Have to use the default bean context to set these properties since calling
		// convertToType will cause the cache object to be initialized.

		if (property.equals(BEANS_REQUIRE_DEFAULT_CONSTRUCTOR))
			beansRequireDefaultConstructor = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(BEANS_REQUIRE_SERIALIZABLE))
			beansRequireSerializable = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(BEANS_REQUIRE_SETTERS_FOR_GETTERS))
			beansRequireSettersForGetters = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(BEANS_REQUIRE_SOME_PROPERTIES))
			beansRequireSomeProperties = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(BEANMAP_PUT_RETURNS_OLD_VALUE))
			beanMapPutReturnsOldValue = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(INCLUDE_BEAN_FIELD_PROPERTIES))
			includeBeanFieldProperties = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(INCLUDE_BEAN_METHOD_PROPERTIES))
			includeBeanMethodProperties = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(USE_INTERFACE_PROXIES))
			useInterfaceProxies = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(IGNORE_UNKNOWN_BEAN_PROPERTIES))
			ignoreUnknownBeanProperties = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(IGNORE_UNKNOWN_NULL_BEAN_PROPERTIES))
			ignoreUnknownNullBeanProperties = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(IGNORE_PROPERTIES_WITHOUT_SETTERS))
			ignorePropertiesWithoutSetters = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(IGNORE_INVOCATION_EXCEPTIONS_ON_GETTERS))
			ignoreInvocationExceptionsOnGetters = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(IGNORE_INVOCATION_EXCEPTIONS_ON_SETTERS))
			ignoreInvocationExceptionsOnSetters = DEFAULT.convertToType(value, Boolean.class);
		else if (property.equals(ADD_NOTBEAN_PACKAGES)) {
			Set<String> set = new LinkedHashSet<String>(notBeanPackages);
			for (String s : value.toString().split(","))
				set.add(s.trim());
			notBeanPackages = set;
			updateNotBeanPackages();
			value = set;
		} else if (property.equals(REMOVE_NOTBEAN_PACKAGES)) {
			Set<String> set = new LinkedHashSet<String>(notBeanPackages);
			for (String s : value.toString().split(","))
				set.remove(s.trim());
			notBeanPackages = set;
			updateNotBeanPackages();
			value = set;
		}
		properties.put(property, value);
		return this;
	}

	/**
	 * Sets multiple properties on this context.
	 * <p>
	 * 	Refer to {@link BeanContextProperties} for a description of available properties.
	 * @param properties The properties to set.  Ignored if <jk>null</jk>.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public BeanContext setProperties(ObjectMap properties) throws LockedException {
		if (properties != null) {
			checkLock();
			for (Map.Entry<String,Object> e : properties.entrySet())
				setProperty(e.getKey(), e.getValue());
		}
		return this;
	}

	/**
	 * Returns all properties currently set on this bean context.
	 * @return The set of properties currently set on this bean context.
	 */
	public ObjectMap getProperties() {
		return properties;
	}


	/**
	 * Adds an explicit list of Java classes to be excluded from consideration as being beans.
	 *
	 * @param classes One or more fully-qualified Java class names.
	 * @return This object (for method chaining).
	 */
	public BeanContext addNotBeanClasses(Class<?>...classes) {
		checkLock();
		this.notBeanClasses.addAll(Arrays.asList(classes));
		return this;
	}

	/**
	 * Add filters to this context.
	 * <p>
	 * 	There are two category of classes that can be passed in through this method:
	 * <ul>
	 * 	<li>Subclasses of {@link PojoFilter} and {@link BeanFilter}.
	 * 	<li>Any other class.
	 * </ul>
	 * <p>
	 * 	When <code>IFilter</code> classes are specified, they identify objects that need to be
	 * 		transformed into some other type during serialization (and optionally the reverse during parsing).
	 * <p>
	 * 	When non-<code>IFilter</code> classes are specified, they are wrapped inside {@link BeanFilter BeanFilters}.
	 * 	For example, if you have an interface <code>IFoo</code> and a subclass <code>Foo</code>, and you
	 * 		only want properties defined on <code>IFoo</code> to be visible as bean properties for <code>Foo</code> objects,
	 * 		you can simply pass in <code>IFoo.<jk>class</jk></code> to this method.
	 *
	 * @param classes One or more classes to add as filters to this context.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public BeanContext addFilters(Class<?>...classes) throws LockedException {
		checkLock();
		for (Class<?> c : classes)
			if (Filter.class.isAssignableFrom(c)) {
				try {
					Filter f = (Filter)c.newInstance();
					filters.put(f.forClass(), f);
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			} else {
				BeanFilter f = new InterfaceBeanFilter(c);
				f.setInterfaceClass(c);
				filters.put(f.forClass(), f);
			}
		return this;
	}

	/**
	 * Specifies an implementation class for an interface or abstract class.
	 * <p>
	 * 	For interfaces and abstract classes this method can be used to specify an implementation
	 *		class for the interface/abstract class so that instances of the implementation
	 * 	class are used when instantiated (e.g. during a parse).
	 *
	 * @param <T> The interface class.
	 * @param interfaceClass The interface class.
	 * @param implClass The implementation of the interface class.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public <T> BeanContext addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		checkLock();
		this.implClasses.put(interfaceClass, implClass);
		return this;
	}

	/**
	 * Returns the current value for the {@link BeanContextProperties#IGNORE_UNKNOWN_BEAN_PROPERTIES} setting.
	 *
	 * @return The current setting value.
	 */
	public boolean isIgnoreUnknownBeanProperties() {
		return ignoreUnknownBeanProperties;
	}

	//--------------------------------------------------------------------------------
	// Other methods.
	//--------------------------------------------------------------------------------

	private void updateNotBeanPackages() {
		List<String> l1 = new LinkedList<String>();
		List<String> l2 = new LinkedList<String>();
		for (String s : notBeanPackages) {
			if (s.endsWith(".*"))
				l2.add(s.substring(0, s.length()-2));
			else
				l1.add(s);
		}
		notBeanPackageNames = l1.toArray(new String[l1.size()]);
		notBeanPackagePrefixes = l2.toArray(new String[l2.size()]);
	}

	/**
	 * Determines whether the specified class is ignored as a bean class based on the various
	 * 	exclusion parameters specified on this context class.
	 *
	 * @param c The class type being tested.
	 * @return <jk>true</jk> if the specified class matches any of the exclusion parameters.
	 */
	protected boolean isNotABean(Class<?> c) {
		if (c.isArray() || c.isPrimitive() || c.isEnum() || c.isAnnotation())
			return true;
		Package p = c.getPackage();
		if (p != null) {
			for (String p2 : notBeanPackageNames)
				if (p.getName().equals(p2))
					return true;
			for (String p2 : notBeanPackagePrefixes)
				if (p.getName().startsWith(p2))
					return true;
		}
		for (Class exclude : notBeanClasses)
			if (exclude.isAssignableFrom(c))
				return true;
		return false;
	}

	/**
	 * Prints ClassMeta cache statistics to System.out.
	 */
	protected static void dumpCacheStats() {
		try {
			int ctCount = 0;
			for (Map<Class,ClassMeta> cm : classMetaCacheCache.values())
				ctCount += cm.size();
			System.out.println(MessageFormat.format("ClassMeta cache: {0} instances in {1} caches", ctCount, classMetaCacheCache.size()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Wraps an object inside a {@link BeanMap} object (i.e. a modifiable {@link Map}).
	 * <p>
	 * 	If object is not a true bean, then throws a {@link BeanRuntimeException} with an explanation of why it's not a bean.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a bean map around a bean instance</jc>
	 * 	BeanMap&lt;Person&gt; bm = BeanContext.<jsf>DEFAULT</jsf>.forBean(<jk>new</jk> Person());
	 * </p>
	 *
	 * @param <T> The class of the object being wrapped.
	 * @param o The object to wrap in a map interface.  Must not be null.
	 * @return The wrapped object.
	 */
	public <T> BeanMap<T> forBean(T o) {
		return this.forBean(o, (Class<T>)o.getClass());
	}

	/**
	 * Determines whether the specified object matches the requirements on this context of being a bean.
	 *
	 * @param o The object being tested.
	 * @return <jk>true</jk> if the specified object is considered a bean.
	 */
	public boolean isBean(Object o) {
		if (o == null)
			return false;
		return isBean(o.getClass());
	}

	/**
	 * Determines whether the specified class matches the requirements on this context of being a bean.
	 *
	 * @param c The class being tested.
	 * @return <jk>true</jk> if the specified class is considered a bean.
	 */
	public boolean isBean(Class<?> c) {
		return getBeanMeta(c) != null;
	}

	/**
	 * Wraps an object inside a {@link BeanMap} object (i.e.: a modifiable {@link Map})
	 * defined as a bean for one of its class, a super class, or an implemented interface.
	 * <p>
	 * 	If object is not a true bean, throws a {@link BeanRuntimeException} with an explanation of why it's not a bean.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a bean map for new bean using only properties defined in a superclass</jc>
	 * 	BeanMap&lt;MySubBean&gt; bm = BeanContext.<jsf>DEFAULT</jsf>.forBean(<jk>new</jk> MySubBean(), MySuperBean.<jk>class</jk>);
	 *
	 * 	<jc>// Construct a bean map for new bean using only properties defined in an interface</jc>
	 * 	BeanMap&lt;MySubBean&gt; bm = BeanContext.<jsf>DEFAULT</jsf>.forBean(<jk>new</jk> MySubBean(), MySuperInterface.<jk>class</jk>);
	 * </p>
	 *
	 * @param <T> The class of the object being wrapped.
	 * @param o The object to wrap in a bean interface.  Must not be null.
	 * @param c The superclass to narrow the bean properties to.  Must not be null.
	 * @return The bean representation, or <jk>null</jk> if the object is not a true bean.
	 * @throws NullPointerException If either parameter is null.
	 * @throws IllegalArgumentException If the specified object is not an an instance of the specified class.
	 * @throws BeanRuntimeException If specified object is not a bean according to the bean rules
	 * 		specified in this context class.
	 */
	public <T> BeanMap<T> forBean(T o, Class<? super T> c) throws BeanRuntimeException {

		// check for null
		if (o == null || c == null)
			throw new NullPointerException("Neither the specified object nor class may be null.  " + "class=[ " + c + " ], object=[ " + o + " ]");

		if (! c.isInstance(o))
			throw new IllegalArgumentException("The specified object is not an instance of the " + "specified class.  class=[ " + c.getName()
				+ " ], objectClass=[ " + o.getClass().getName() + " ], object=[ " + o + " ]");

		ClassMeta cm = getClassMeta(c);

		BeanMeta m = cm.getBeanMeta();
		if (m == null)
			throw new BeanRuntimeException(c, "Class is not a bean.  Reason=''{0}''", cm.getNotABeanReason());
		return new BeanMap<T>(o, m);
	}

	/**
	 * Creates a new {@link BeanMap} object (i.e. a modifiable {@link Map}) of the given class with uninitialized property values.
	 * <p>
	 * 	If object is not a true bean, then throws a {@link BeanRuntimeException} with an explanation of why it's not a bean.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a new bean map wrapped around a new Person object</jc>
	 * 	BeanMap&lt;Person&gt; bm = BeanContext.<jsf>DEFAULT</jsf>.newBeanMap(Person.<jk>class</jk>);
	 * </p>
	 *
	 * @param <T> The class of the object being wrapped.
	 * @param c The name of the class to create a new instance of.
	 * @return A new instance of the class.
	 */
	public <T> BeanMap<T> newBeanMap(Class<T> c) {
		return newBeanMap(c, (Map)null);
	}

	/**
	 * Same as {@code newInstance(Class, Map)}, except allows you to initialize the property values on the new object.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a new bean map wrapped around a new Person object and initialize with values</jc>
	 * 	BeanMap&lt;Person&gt; bm = BeanContext.<jsf>DEFAULT</jsf>.newBeanMap(Person.<jk>class</jk>, <js>"{name:'John Smith',age:21}"</js>);
	 * </p>
	 *
	 * @param <T> The class of the object being wrapped.
	 * @param c The class to create a new instance of.
	 * @param initProperties JSON string of key/values to initialize the properties on the newly-created instance of the class.
	 * @return A new initialized instance of the class.
	 * @throws BeanRuntimeException If the specified class is not a valid bean.
	 * @throws ParseException If {@code initProperties} string contains a syntax error or is malformed.
	 */
	public <T> BeanMap<T> newBeanMap(Class<T> c, String initProperties) throws BeanRuntimeException, ParseException {
		return newBeanMap(c, new ObjectMap(initProperties));
	}

	/**
	 * Creates a new {@link BeanMap} object (i.e. a modifiable {@link Map}) of the given class, and initializes the property
	 * values with the values specified in {@code initProperties}.
	 * <p>
	 * 	If object is not a true bean, then throws a {@link BeanRuntimeException} with an explanation of why it's not a bean.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a new bean map wrapped around a new Person object and initialize with values</jc>
	 * 	BeanMap&lt;Person&gt; bm = BeanContext.<jsf>DEFAULT</jsf>.newInstances(Person.<jk>class</jk>, initPropertyMap);
	 * </p>
	 *
	 * @param <T> The class of the object being wrapped.
	 * @param c The class to create a new instance of.
	 * @param initProperties Map of key/values to initialize the properties on the newly-created instance of the class.
	 * @return A new initialized instance of the class.
	 */
	public <T> BeanMap<T> newBeanMap(Class<T> c, Map initProperties) {
		BeanMeta m = getBeanMeta(c);
		if (m == null)
			return null;
		T bean = null;
		if (m.readOnlyConstructor == null) {
			bean = newBean(c);
			// Beans with subtypes won't be instantiated until the sub type property is specified.
			if (bean == null && ! m.getClassMeta().hasSubTypes())
				return null;
		}
		BeanMap<T> b = new BeanMap<T>(bean, m);
		if (initProperties != null)
			b.putAll(initProperties);
		return b;
	}

	/**
	 * Creates a new empty bean of the specified type.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a new instance of the specified bean class</jc>
	 * 	Person p = BeanContext.<jsf>DEFAULT</jsf>.newBean(Person.<jk>class</jk>);
	 * </p>
	 *
	 * @param <T> The class type of the bean being created.
	 * @param c The class type of the bean being created.
	 * @return A new bean object.
	 * @throws BeanRuntimeException If the specified class is not a valid bean.
	 */
	public <T> T newBean(Class<T> c) throws BeanRuntimeException {
		ClassMeta<T> cm = getClassMeta(c);
		BeanMeta m = cm.getBeanMeta();
		if (m == null)
			return null;
		try {
			T o = cm.newInstance();
			if (o == null) {
				// Beans with subtypes won't be instantiated until the sub type property is specified.
				if (cm.beanFilter != null && cm.beanFilter.getSubTypeProperty() != null)
					return null;
				throw new BeanRuntimeException(c, "Class does not have a no-arg constructor.");
			}
			return o;
		} catch (BeanRuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new BeanRuntimeException(e);
		}
	}

	/**
	 * Parses the contents of the specified reader and converts it into a bean.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a new instance of the specified bean class initialized with the JSON contents of the reader</jc>
	 * 	Person p = BeanContext.<jsf>DEFAULT</jsf>.newBean(Person.<jk>class</jk>, reader, <jsf>JSON</jsf>);
	 * </p>
	 *
	 * @param <T> The class type of the bean being created.
	 * @param c The class type of the bean being created.
	 * @param r The reader being read from.
	 * @param df The data format of the text being read.  Either XML or JSON.
	 * @return A new bean object.
	 * @throws BeanRuntimeException If the specified class is not a valid bean.
	 * @throws ParseException If the input contains a syntax error or is malformed.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T newBean(Class<T> c, Reader r, DataFormat df) throws BeanRuntimeException, ParseException, IOException {
		return newBeanMap(c, new ObjectMap(r, df)).getBean();
	}

	/**
	 * Converts a generic {@link Map} into an instance of a bean.
	 *
	 * <h6>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a new instance of the specified bean class initialized with the contents of the map</jc>
	 * 	Person p = BeanContext.<jsf>DEFAULT</jsf>.newBean(Person.<jk>class</jk>, initPropertyMap);
	 * </p>
	 *
	 * @param <T> The class type of the bean being created.
	 * @param c The class type of the bean being created.
	 * @param initProperties The resulting class will be initialized with values in this map.
	 * @return A new bean object.
	 * @throws BeanRuntimeException If the specified class is not a valid bean.
	 */
	public <T> T newBean(Class<T> c, Map initProperties) throws BeanRuntimeException {
		return newBeanMap(c, initProperties).getBean();
	}

	/**
	 * Converts JSON text into a bean.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a new instance of the specified bean class initialized with the contents of the JSON text</jc>
	 * 	Person p = BeanContext.<jsf>DEFAULT</jsf>.newBean(Person.<jk>class</jk>, <js>"{name:'John Smith',age:21}"</js>);
	 * </p>
	 *
	 * @param <T> The class type of the bean being created.
	 * @param c The class type of the bean being created.
	 * @param initProperties The JSON text that will be converted into a bean.
	 * @return A new bean object.
	 * @throws BeanRuntimeException If the specified class is not a valid bean.
	 * @throws ParseException If the input contains a syntax error or is malformed.
	 */
	public <T> T newBean(Class<T> c, String initProperties) throws BeanRuntimeException, ParseException {
		return newBeanMap(c, initProperties).getBean();
	}

	/**
	 * Returns the {@link BeanMeta} class for the specified class.
	 *
	 * @param <T> The class type to get the meta-data on.
	 * @param c The class to get the meta-data on.
	 * @return The {@link BeanMeta} for the specified class, or <jk>null</jk> if the class
	 * 	is not a bean per the settings on this context.
	 */
	public <T> BeanMeta<T> getBeanMeta(Class<T> c) {
		if (c == null)
			return null;
		return getClassMeta(c).getBeanMeta();
	}

	/**
	 * Returns the class type bound to this bean context if the specified class type
	 * 	is from another bean context.
	 * <p>
	 * For example, this method allows you to pass in an object from <code>BeanContext.<jsf>DEFAULT</jsf>.getMapClassMeta(...)</code>
	 * 	to any of the <code>ReaderParser.parse(Reader, ClassMeta, ParserContext)</code> methods, and the parsers
	 * 	will use this method to replace the class type with the one registered with the parser.
	 * This ensures that registered filters are applied correctly.
	 *
	 * @param <T> The class type.
	 * @param cm The class type.
	 * @return The class type bound by this bean context.
	 */
	public <T> ClassMeta<T> normalizeClassMeta(ClassMeta<T> cm) {
		if (cm == null)
			return (ClassMeta<T>)OBJECT;
		if (cm.beanContext == null || cm.beanContext == this || cm.beanContext.equals(this))
			return cm;
		if (cm.isMap()) {
			ClassMeta<Map> cm2 = (ClassMeta<Map>)cm;
			cm2 = getMapClassMeta(cm2.getInnerClass(), cm2.getKeyType().getClass(), cm2.getValueType().getClass());
			return (ClassMeta<T>)cm2;
		}
		if (cm.isCollection()) {
			ClassMeta<Collection> cm2 = (ClassMeta<Collection>)cm;
			cm2 = getCollectionClassMeta(cm2.getInnerClass(), cm2.getElementType().getClass());
		}
		return getClassMeta(cm.getInnerClass());
	}

	/**
	 * Construct a {@code ClassMeta} wrapper around a {@link Class} object.
	 *
	 * @param <T> The class type being wrapped.
	 * @param c The class being wrapped.
	 * 	of type {@link Class} or {@link ClassMeta}.
	 * @return
	 * 	If the class is not an array, returns a cached {@link ClassMeta} object.
	 * 	Otherwise, returns a new {@link ClassMeta} object every time.<br>
	 */
	public <T> ClassMeta<T> getClassMeta(Class<T> c) {

		// If this is an array, then we want it wrapped in an uncached ClassMeta object.
		// Note that if it has a pojo filter, we still want to cache it so that
		// we can cache something like byte[] with ByteArrayBase64Filter.
		if (c.isArray() && filters.get(c) == null)
			return new ClassMeta(c, this);

		ClassMeta<T> cm = getClassMetaCache().get(c);
		if (cm == null) {

			synchronized (this) {

				// Make sure someone didn't already set it while this thread was blocked.
				cm = classMetaCache.get(c);
				if (cm == null) {

					// Note:  Bean properties add the possibility that class reference loops exist.
					// To handle this possibility, we create a set of pending ClassMetas, and
					// call init (which finds the bean properties) after it's been added to the pending set.
					for (ClassMeta pcm : pendingClassMetas)
						if (pcm.innerClass == c)
							return pcm;

					cm = new ClassMeta<T>(c, this, true);
					pendingClassMetas.addLast(cm);
					cm.init();
					pendingClassMetas.removeLast();
					getClassMetaCache().put(c, cm);
				}
			}
		}
		return cm;
	}

	/**
	 * Construct a {@code ClassMeta} wrapper around a {@link Map} object.
	 *
	 * @param <K> The map key class type.
	 * @param <V> The map value class type.
	 * @param <T> The map class type.
	 * @param c The map class type.
	 * @param keyType The map key class type.
	 * @param valueType The map value class type.
	 * @return
	 * 	If the key and value types are OBJECT, returns a cached {@link ClassMeta} object.<br>
	 * 	Otherwise, returns a new {@link ClassMeta} object every time.
	 */
	public <K,V,T extends Map<K,V>> ClassMeta<T> getMapClassMeta(Class<T> c, ClassMeta<K> keyType, ClassMeta<V> valueType) {
		if (keyType == OBJECT && valueType == OBJECT)
			return getClassMeta(c);
		return new ClassMeta(c, this).setKeyType(keyType).setValueType(valueType);
	}

	/**
	 * Construct a {@code ClassMeta} wrapper around a {@link Map} object.
	 *
	 * @param <K> The map key class type.
	 * @param <V> The map value class type.
	 * @param <T> The map class type.
	 * @param c The map class type.
	 * @param keyType The map key class type.
	 * @param valueType The map value class type.
	 * @return
	 * 	If the key and value types are Object, returns a cached {@link ClassMeta} object.<br>
	 * 	Otherwise, returns a new {@link ClassMeta} object every time.
	 */
	public <K,V,T extends Map<K,V>> ClassMeta<T> getMapClassMeta(Class<T> c, Class<K> keyType, Class<V> valueType) {
		return getMapClassMeta(c, getClassMeta(keyType), getClassMeta(valueType));
	}

	/**
	 * Construct a {@code ClassMeta} wrapper around a {@link Map} object.
	 *
	 * @param <T> The map class type.
	 * @param c The map class type.
	 * @param keyType The map key class type.
	 * @param valueType The map value class type.
	 * @return
	 * 	If the key and value types are Object, returns a cached {@link ClassMeta} object.<br>
	 * 	Otherwise, returns a new {@link ClassMeta} object every time.
	 */
	public <T extends Map> ClassMeta<T> getMapClassMeta(Class<T> c, Type keyType, Type valueType) {
		return getMapClassMeta(c, getClassMeta(keyType), getClassMeta(valueType));
	}

	/**
	 * Construct a {@code ClassMeta} wrapper around a {@link Collection} object.
	 *
	 * @param <E> The collection element class type.
	 * @param <T> The collection class type.
	 * @param c The collection class type.
	 * @param elementType The collection element class type.
	 * @return
	 * 	If the element type is OBJECT, returns a cached {@link ClassMeta} object.<br>
	 * 	Otherwise, returns a new {@link ClassMeta} object every time.
	 */
	public <E,T extends Collection<E>> ClassMeta<T> getCollectionClassMeta(Class<T> c, ClassMeta<E> elementType) {
		if (elementType == ClassMetaConst.OBJECT)
			return getClassMeta(c);
		return new ClassMeta(c, this).setElementType(elementType);
	}

	/**
	 * Construct a {@code ClassMeta} wrapper around a {@link Collection} object.
	 *
	 * @param <E> The collection element class type.
	 * @param <T> The collection class type.
	 * @param c The collection class type.
	 * @param elementType The collection element class type.
	 * @return
	 * 	If the element type is OBJECT, returns a cached {@link ClassMeta} object.<br>
	 * 	Otherwise, returns a new {@link ClassMeta} object every time.
	 */
	public <E,T extends Collection<E>> ClassMeta<T> getCollectionClassMeta(Class<T> c, Class<E> elementType) {
		return getCollectionClassMeta(c, getClassMeta(elementType));
	}

	/**
	 * Construct a {@code ClassMeta} wrapper around a {@link Collection} object.
	 *
	 * @param <T> The collection class type.
	 * @param c The collection class type.
	 * @param elementType The collection element class type.
	 * @return
	 * 	If the element type is OBJECT, returns a cached {@link ClassMeta} object.<br>
	 * 	Otherwise, returns a new {@link ClassMeta} object every time.
	 */
	public <T extends Collection> ClassMeta<T> getCollectionClassMeta(Class<T> c, Type elementType) {
		return getCollectionClassMeta(c, getClassMeta(elementType));
	}

	/**
	 * Constructs a ClassMeta object given the specified object and parameters.
	 *
	 * @param o The parent class type.
	 * 	Can be any of the following types:
	 * 	<ul>
	 * 		<li>{@link ClassMeta} object, which just returns the same object.
	 * 		<li>{@link Class} object (e.g. <code>String.<jk>class</jk></code>).
	 * 		<li>{@link Type} object (e.g. {@link ParameterizedType} or {@link GenericArrayType}.
	 * 		<li>Anything else is interpreted as {@code getClassMeta(o.getClass(), parameters);}
	 * 	</ul>
	 * @return a ClassMeta object, or <jk>null</jk> if the object is null.
	 */
	public ClassMeta getClassMeta(Type o) {
		return getClassMeta(o, null);
	}

	ClassMeta getClassMeta(Type o, Map<Class<?>,Class<?>[]> typeVarImpls) {
		if (o == null)
			return null;

		if (o instanceof ClassMeta)
			return (ClassMeta)o;

		Class c = null;
		if (o instanceof Class) {
			c = (Class)o;
		} else if (o instanceof ParameterizedType) {
			// A parameter (e.g. <String>.
			c = (Class<?>)((ParameterizedType)o).getRawType();
		} else if (o instanceof GenericArrayType) {
			// An array parameter (e.g. <byte[]>.
			GenericArrayType gat = (GenericArrayType)o;
			Type gatct = gat.getGenericComponentType();
			if (gatct instanceof Class) {
				Class gatctc = (Class)gatct;
				c = Array.newInstance(gatctc, 0).getClass();
			} else {
				return null;
			}
		} else if (o instanceof TypeVariable) {
			if (typeVarImpls != null) {
				TypeVariable t = (TypeVariable) o;
				String varName = t.getName();
				int varIndex = -1;
				Class gc = (Class)t.getGenericDeclaration();
				TypeVariable[] tv = gc.getTypeParameters();
				for (int i = 0; i < tv.length; i++) {
					if (tv[i].getName().equals(varName)) {
						varIndex = i;
					}
				}
				if (varIndex != -1) {

					// If we couldn't find a type variable implementation, that means
					// the type was defined at runtime (e.g. Bean b = new Bean<Foo>();)
					// in which case the type is lost through erasure.
					// Assume java.lang.Object as the type.
					if (! typeVarImpls.containsKey(gc))
						return ClassMetaConst.OBJECT;

					return getClassMeta(typeVarImpls.get(gc)[varIndex]);
				}
			}
			return null;
		} else {
			// This can happen when trying to resolve the "E getFirst()" method on LinkedList, whose type is a TypeVariable
			// We don't support these yet.
			return null;
		}

		ClassMeta rawType = getClassMeta(c);

		// If this is a Map or Collection, and the parameter types aren't part
		// of the class definition itself (e.g. class AddressBook extends List<Person>),
		// then we need to figure out the parameters.
		if (rawType.isMap() || rawType.isCollection()) {
			ClassMeta[] params = findParameters(o, c);
			if (params == null)
				return rawType;
			if (rawType.isMap()) {
				if (params.length != 2)
					return rawType;
				if (params[0] == OBJECT && params[1] == OBJECT)
					return rawType;
				return new ClassMeta(rawType.innerClass, this).setKeyType(params[0]).setValueType(params[1]);
			}
			if (rawType.isCollection()) {
				if (params.length != 1)
					return rawType;
				if (params[0] == OBJECT)
					return rawType;
				return new ClassMeta(rawType.innerClass, this).setElementType(params[0]);
			}
		}

		return rawType;
	}

	ClassMeta[] findParameters(Type o, Class c) {
		if (o == null)
			o = c;

		// Loop until we find a ParameterizedType
		if (! (o instanceof ParameterizedType)) {
			loop: do {
				o = c.getGenericSuperclass();
				if (o instanceof ParameterizedType)
					break loop;
				for (Type t : c.getGenericInterfaces()) {
					o = t;
					if (o instanceof ParameterizedType)
						break loop;
				}
				c = c.getSuperclass();
			} while (c != null);
		}

		if (o instanceof ParameterizedType) {
			ParameterizedType pt = (ParameterizedType)o;
			if (! pt.getRawType().equals(Enum.class)) {
				List<ClassMeta<?>> l = new LinkedList<ClassMeta<?>>();
				for (Type pt2 : pt.getActualTypeArguments()) {
					if (pt2 instanceof WildcardType || pt2 instanceof TypeVariable)
						return null;
					l.add(getClassMeta(pt2, null));
				}
				if (l.isEmpty())
					return null;
				return l.toArray(new ClassMeta[l.size()]);
			}
		}

		return null;
	}

	/**
	 * Shortcut for calling {@code getClassMeta(o.getClass())}.
	 *
	 * @param <T> The class of the object being passed in.
	 * @param o The class to find the class type for.
	 * @return The ClassMeta object, or <jk>null</jk> if {@code o} is <jk>null</jk>.
	 */
	public <T> ClassMeta<T> getClassMetaForObject(T o) {
		if (o == null)
			return null;
		return (ClassMeta<T>)getClassMeta(o.getClass());
	}


	/**
	 * Used for determining the class type on a method or field where a {@code @BeanProperty} annotation
	 * 	may be present.
	 *
	 * @param <T> The class type we're wrapping.
	 * @param p The property annotation on the type if there is one.
	 * @param t The type.
	 * @param typeVarImpls Contains known resolved type parameters on the specified class so
	 * 	that we can result {@code ParameterizedTypes} and {@code TypeVariables}.<br>
	 * 	Can be <jk>null</jk> if the information is not known.
	 * @return The new {@code ClassMeta} object wrapped around the {@code Type} object.
	 */
	protected <T> ClassMeta<T> getClassMeta(BeanProperty p, Type t, Map<Class<?>,Class<?>[]> typeVarImpls) {
		ClassMeta<T> cm = getClassMeta(t, typeVarImpls);
		ClassMeta<T> cm2 = cm;
		if (p != null) {

			if (p.type() != Object.class)
				cm2 = getClassMeta(p.type(), typeVarImpls);

			if (cm2.isMap()) {
				Class<?>[] pParams = (p.params().length == 0 ? new Class[]{Object.class, Object.class} : p.params());
				if (pParams.length != 2)
					throw new RuntimeException("Invalid number of parameters specified for Map (must be 2): " + pParams.length);
				ClassMeta<?> keyType = resolveType(pParams[0], cm2.getKeyType(), cm.getKeyType());
				ClassMeta<?> valueType = resolveType(pParams[1], cm2.getValueType(), cm.getValueType());
				if (keyType == OBJECT && valueType == OBJECT)
					return cm2;
				return new ClassMeta<T>(cm2.innerClass, this).setKeyType(keyType).setValueType(valueType);
			}

			if (cm2.isCollection()) {
				Class<?>[] pParams = (p.params().length == 0 ? new Class[]{Object.class} : p.params());
				if (pParams.length != 1)
					throw new RuntimeException("Invalid number of parameters specified for Collection (must be 1): " + pParams.length);
				ClassMeta<?> elementType = resolveType(pParams[0], cm2.getElementType(), cm.getElementType());
				if (elementType == OBJECT)
					return cm2;
				return new ClassMeta<T>(cm2.innerClass, this).setElementType(elementType);
			}

			return cm2;
		}

		return cm;
	}

	private ClassMeta<?> resolveType(Type...t) {
		for (Type tt : t) {
			if (tt != null) {
				ClassMeta<?> cm = getClassMeta(tt);
				if (tt != OBJECT)
					return cm;
			}
		}
		return OBJECT;
	}

	/**
	 * Converts class name strings to ClassMeta objects.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <ul>
	 * 	<li>{@code java.lang.String}
	 * 	<li>{@code com.ibm.sample.MyBean[]}
	 * 	<li>{@code java.util.HashMap<java.lang.String,java.lang.Integer>}
	 * 	<li>{@code [Ljava.lang.String;} (i.e. the value of <code>String[].<jk>class</jk>.getName()</code>
	 * </ul>
	 *
	 * @param s The class name.
	 * @return The ClassMeta corresponding to the class name string.
	 */
	public ClassMeta<?> getClassMetaFromString(String s) {
		int d = 0;
		if (s == null || s.isEmpty())
			return null;

		// Check for Class.getName() on array class types.
		if (s.charAt(0) == '[') {
			try {
				return getClassMeta(Class.forName(s));
			} catch (ClassNotFoundException e) {
				throw new RuntimeException(e);
			}
		}

		int i1 = 0;
		int i2 = 0;
		int dim = 0;
		List<ClassMeta<?>> p = null;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '<') {
				if (d == 0) {
					i1 = i;
					i2 = i+1;
					p = new LinkedList<ClassMeta<?>>();
				}
				d++;
			} else if (c == '>') {
				d--;
				if (d == 0 && p != null)
					p.add(getClassMetaFromString(s.substring(i2, i)));
			} else if (c == ',' && d == 1) {
				if (p != null)
					p.add(getClassMetaFromString(s.substring(i2, i)));
				i2 = i+1;
			}
			if (c == '[') {
				if (i1 == 0)
					i1 = i;
				dim++;
			}
		}
		if (i1 == 0)
			i1 = s.length();
		try {
			String name = s.substring(0, i1).trim();
			char x = name.charAt(0);
			Class<?> c = null;
			if (x >= 'b' && x <= 's') {
				if (x == 'b' && name.equals("boolean"))
					c = boolean.class;
				else if (x == 'b' && name.equals("byte"))
					c = byte.class;
				else if (x == 'c' && name.equals("char"))
					c = char.class;
				else if (x == 'd' && name.equals("double"))
					c = double.class;
				else if (x == 'i' && name.equals("int"))
					c = int.class;
				else if (x == 'l' && name.equals("long"))
					c = long.class;
				else if (x == 's' && name.equals("short"))
					c = short.class;
				else
					c = Class.forName(name);
			} else {
				c = Class.forName(name);
			}

			ClassMeta<?> cm = getClassMeta(c);

			if (p != null) {
				if (cm.isMap())
					cm = new ClassMeta(c, this).setKeyType(p.get(0)).setValueType(p.get(1));
				if (cm.isCollection())
					cm = new ClassMeta(c, this).setElementType(p.get(0));
			}

			while (dim > 0) {
				cm = new ClassMeta(Array.newInstance(cm.getInnerClass(), 0).getClass(), this);
				dim--;
			}

			return cm;
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Returns the {@link Filter} associated with the specified class, or <jk>null</jk> if there is no
	 * filter associated with the class.
	 *
	 * @param <T> The class associated with the filter.
	 * @param c The class associated with the filter.
	 * @return The filter associated with the class, or null if there is no association.
	 */
	public final <T> Filter findFilter(Class<T> c) {
		if (c != null)
			for (Filter f : filters.values())
				if (f.forClass().isAssignableFrom(c))
					return f;
		return null;
	}

	/**
	 * Gets the no-arg constructor for the specified class.
	 *
	 * @param <T> The class.
	 * @param c The class
	 * @return The no arg constructor, or null if the class has no no-arg constructor.
	 */
	protected <T> Constructor<? extends T> getConstructor(Class<T> c) {
		if (! implClasses.isEmpty()) {
			Class cc = c;
			while (cc != null) {
				Class implClass = implClasses.get(cc);
				if (implClass != null)
					return getNoArgConstructor(implClass);
				for (Class ic : cc.getInterfaces()) {
					implClass = implClasses.get(ic);
					if (implClass != null)
						return getNoArgConstructor(implClass);
				}
				cc = cc.getSuperclass();
			}
		}
		return getNoArgConstructor(c);
	}

	private <T> Constructor<? extends T> getNoArgConstructor(Class<T> c) {
		int mod = c.getModifiers();
		if (Modifier.isAbstract(mod) || ! Modifier.isPublic(mod))
			return null;
		for (Constructor cc : c.getConstructors()) {
			mod = cc.getModifiers();
			if (cc.getParameterTypes().length == 0 && Modifier.isPublic(mod))
				return cc;
		}
		return null;
	}

	/**
	 * Converts the specified value to the specified class type.
	 * <p>
	 * 	See {@link #convertToType(Object, ClassMeta)} for the list of valid conversions.
	 * @param <T> The class type to convert the value to.
	 * @param value The value to convert.
	 * @param type The class type to convert the value to.
	 * @throws InvalidDataConversionException If the specified value cannot be converted to the specified type.
	 * @return The converted value.
	 */
	public <T> T convertToType(Object value, Class<T> type) throws InvalidDataConversionException {
		return convertToType(value, getClassMeta(type));
	}

	/**
	 * Casts the specified value into the specified type.
	 * <p>
	 * 	If the value isn't an instance of the specified type, then converts
	 * 	the value if possible.<br>
	 * <p>
	 * 	The following conversions are valid:
	 * 	<table class='styled'>
	 * 		<tr><th>Convert to type</th><th>Valid input value types</th><th>Notes</th></tr>
	 * 		<tr>
	 * 			<td>
	 * 				A class that is the normal type of a registered {@link PojoFilter}.
	 * 			</td>
	 * 			<td>
	 * 				A value whose class matches the filtered type of that registered {@link PojoFilter}.
	 * 			</td>
	 * 			<td>&nbsp;</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 * 				A class that is the filtered type of a registered {@link PojoFilter}.
	 * 			</td>
	 * 			<td>
	 * 				A value whose class matches the normal type of that registered {@link PojoFilter}.
	 * 			</td>
	 * 			<td>&nbsp;</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 * 				{@code Number} (e.g. {@code Integer}, {@code Short}, {@code Float},...)<br>
	 *					<code>Number.<jsf>TYPE</jsf></code> (e.g. <code>Integer.<jsf>TYPE</jsf></code>, <code>Short.<jsf>TYPE</jsf></code>, <code>Float.<jsf>TYPE</jsf></code>,...)
	 * 			</td>
	 * 			<td>
	 * 				{@code Number}, {@code String}, <jk>null</jk>
	 * 			</td>
	 * 			<td>
	 * 				For primitive {@code TYPES}, <jk>null</jk> returns the JVM default value for that type.
	 * 			</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 * 				{@code Map} (e.g. {@code Map}, {@code HashMap}, {@code TreeMap}, {@code ObjectMap})
	 * 			</td>
	 * 			<td>
	 * 				{@code Map}
	 * 			</td>
	 * 			<td>
	 * 				If {@code Map} is not constructible, a {@code ObjectMap} is created.
	 * 			</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 *				{@code Collection} (e.g. {@code List}, {@code LinkedList}, {@code HashSet}, {@code ObjectList})
	 * 			</td>
	 * 			<td>
	 * 				{@code Collection<Object>}<br>
	 * 				{@code Object[]}
	 * 			</td>
	 * 			<td>
	 * 				If {@code Collection} is not constructible, a {@code ObjectList} is created.
	 * 			</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 *					{@code X[]} (array of any type X)<br>
	 * 			</td>
	 * 			<td>
	 * 				{@code List<X>}<br>
	 * 			</td>
	 * 			<td>&nbsp;</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 *					{@code X[][]} (multi-dimensional arrays)<br>
	 * 			</td>
	 * 			<td>
	 * 				{@code List<List<X>>}<br>
	 * 				{@code List<X[]>}<br>
	 * 				{@code List[]<X>}<br>
	 * 			</td>
	 * 			<td>&nbsp;</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 * 				{@code Enum}<br>
	 * 			</td>
	 * 			<td>
	 * 				{@code String}<br>
	 * 			</td>
	 * 			<td>&nbsp;</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 * 				Bean<br>
	 * 			</td>
	 * 			<td>
	 * 				{@code Map}<br>
	 * 			</td>
	 * 			<td>&nbsp;</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 * 				{@code String}<br>
	 * 			</td>
	 * 			<td>
	 * 				Anything<br>
	 * 			</td>
	 * 			<td>
	 * 				Arrays are converted to JSON arrays<br>
	 * 			</td>
	 * 		</tr>
	 * 		<tr>
	 * 			<td>
	 * 				Anything with one of the following methods:<br>
	 * 				<code><jk>public static</jk> T fromString(String)</code><br>
	 * 				<code><jk>public static</jk> T valueOf(String)</code><br>
	 * 				<code><jk>public<jk> T(String)</code><br>
	 * 			</td>
	 * 			<td>
	 * 				<code>String</code><br>
	 * 			</td>
	 * 			<td>
	 * 				<br>
	 * 			</td>
	 * 		</tr>
	 * 	</table>
	 *
	 * @param <T> The class type to convert the value to.
	 * @param value The value to be converted.
	 * @param type The target object type.
	 * @return The converted type.
	 * @throws InvalidDataConversionException If the specified value cannot be converted to the specified type.
	 */
	public <T> T convertToType(Object value, ClassMeta<T> type) throws InvalidDataConversionException {
		if (type == null)
			type = (ClassMeta<T>)OBJECT;

		try {
			// Handle the case of a null value.
			if (value == null) {

				// If it's a primitive, then use the converters to get the default value for the primitive type.
				if (type.isPrimitive())
					return (T)getPrimitiveDefault(type.getInnerClass());

				// Otherwise, just return null.
				return null;
			}

			Class<T> tc = type.getInnerClass();

			// If no conversion needed, then just return the value.
			// Don't include maps or collections, because child elements may need conversion.
			if (tc.isInstance(value))
				if (! ((type.isMap() && type.getValueType() != OBJECT) || (type.isCollection() && type.getElementType() != OBJECT)))
					return (T)value;

			if (type.getPojoFilter() != null) {
				PojoFilter f = type.getPojoFilter();
				Class<?> nc = f.getNormalClass(), fc = f.getFilteredClass();
				if (nc.isAssignableFrom(tc) && fc.isAssignableFrom(value.getClass()))
					return (T)f.unfilter(value, type, this);
			}

			ClassMeta<?> vt = getClassMetaForObject(value);
			if (vt.getPojoFilter() != null) {
				PojoFilter f = vt.getPojoFilter();
				Class<?> nc = f.getNormalClass(), fc = f.getFilteredClass();
				if (nc.isAssignableFrom(vt.getInnerClass()) && fc.isAssignableFrom(tc))
					return (T)f.filter(value, this);
			}

			if (type.isPrimitive()) {
				if (type.isNumber()) {
					if (value instanceof Number) {
						Number n = (Number)value;
						if (tc == Integer.TYPE)
							return (T)Integer.valueOf(n.intValue());
						if (tc == Short.TYPE)
							return (T)Short.valueOf(n.shortValue());
						if (tc == Long.TYPE)
							return (T)Long.valueOf(n.longValue());
						if (tc == Float.TYPE)
							return (T)Float.valueOf(n.floatValue());
						if (tc == Double.TYPE)
							return (T)Double.valueOf(n.doubleValue());
						if (tc == Byte.TYPE)
							return (T)Byte.valueOf(n.byteValue());
					} else {
						String n = value.toString();
						if (tc == Integer.TYPE)
							return (T)new Integer(n);
						if (tc == Short.TYPE)
							return (T)new Short(n);
						if (tc == Long.TYPE)
							return (T)new Long(n);
						if (tc == Float.TYPE)
							return (T)new Float(n);
						if (tc == Double.TYPE)
							return (T)new Double(n);
						if (tc == Byte.TYPE)
							return (T)new Byte(n);
					}
				} else if (type.isChar()) {
					String s = value.toString();
					return (T)Character.valueOf(s.length() == 0 ? 0 : s.charAt(0));
				} else if (type.isBoolean()) {
					return (T)Boolean.valueOf(value.toString());
				}
			}

			if (type.isNumber() && value instanceof Number) {
				Number n = (Number)value;
				if (tc == Integer.class)
					return (T)Integer.valueOf(n.intValue());
				if (tc == Short.class)
					return (T)Short.valueOf(n.shortValue());
				if (tc == Long.class)
					return (T)Long.valueOf(n.longValue());
				if (tc == Float.class)
					return (T)Float.valueOf(n.floatValue());
				if (tc == Double.class)
					return (T)Double.valueOf(n.doubleValue());
				if (tc == Byte.class)
					return (T)Byte.valueOf(n.byteValue());
			}

			if (type.isChar()) {
				String s = value.toString();
				return (T)Character.valueOf(s.length() == 0 ? 0 : s.charAt(0));
			}

			// Handle setting of array properties
			if (type.isArray()) {
				if (value instanceof List)
					return (T)toArray(type, (List)value);
				else if (value.getClass().isArray())
					return (T)toArray(type, Arrays.asList((Object[])value));
				else if (value.toString().startsWith("["))
					return (T)toArray(type, new ObjectList(value.toString()));
			}

			// Target type is some sort of Map that needs to be converted.
			if (type.isMap()) {
				try {
					if (value instanceof Map) {
						Map m = type.canCreateNewInstance() ? (Map)type.newInstance() : new ObjectMap();
						ClassMeta keyType = type.getKeyType(), valueType = type.getValueType();
						for (Map.Entry e : (Set<Map.Entry>)((Map)value).entrySet()) {
							Object k = e.getKey();
							if (keyType != OBJECT) {
								if (keyType == STRING)
									k = k.toString();
								else
									k = convertToType(k, keyType);
							}
							Object v = e.getValue();
							if (valueType != OBJECT)
								v = convertToType(v, valueType);
							m.put(k, v);
						}
						return (T)m;
					} else if (!type.canCreateNewInstanceFromString()) {
						ObjectMap m = new ObjectMap(value.toString());
						return convertToType(m, type);
					}
				} catch (Exception e) {
					throw new InvalidDataConversionException(value.getClass(), tc, e);
				}
			}

			// Target type is some sort of Collection
			if (type.isCollection()) {
				try {
					Collection l = type.canCreateNewInstance() ? (Collection)type.newInstance() : new ObjectList();
					ClassMeta elementType = type.getElementType();

					if (value.getClass().isArray())
						for (Object o : (Object[])value)
							l.add(elementType == OBJECT ? o : convertToType(o, elementType));
					else if (value instanceof Collection)
						for (Object o : (Collection)value)
							l.add(elementType == OBJECT ? o : convertToType(o, elementType));
					else if (value instanceof Map)
						l.add(elementType == OBJECT ? value : convertToType(value, elementType));
					return (T)l;
				} catch (Exception e) {
					throw new InvalidDataConversionException(value.getClass(), tc, e);
				}
			}

			if (type.isString()) {
				Class<?> c = value.getClass();
				if (c.isArray()) {
					if (c.getComponentType().isPrimitive()) {
						ObjectList l = new ObjectList();
						int size = Array.getLength(value);
						for (int i = 0; i < size; i++)
							l.add(Array.get(value, i));
						return (T)l.toString();
					}
					return (T)new ObjectList((Object[])value).toString();
				}
				return (T)value.toString();
			}

			if (type.isCharSequence()) {
				Class<?> c = value.getClass();
				if (c.isArray()) {
					if (c.getComponentType().isPrimitive()) {
						ObjectList l = new ObjectList();
						int size = Array.getLength(value);
						for (int i = 0; i < size; i++)
							l.add(Array.get(value, i));
						value = l;
					}
					value = new ObjectList((Object[])value);
				}

				return type.newInstance(value.toString());
			}

			// It's a bean being initialized with a Map
			if (type.isBean() && value instanceof Map)
				return newBean(tc, (Map<?,?>) value);

			if (type.canCreateNewInstanceFromString())
				return type.newInstance(value.toString());

			if (type.isBean())
				return newBean(type.getInnerClass(), value.toString());

		} catch (Exception e) {
			throw new InvalidDataConversionException(value, type.getInnerClass(), e);
		}

		throw new InvalidDataConversionException(value, type.getInnerClass(), null);
	}

	/**
	 * Converts the contents of the specified list into an array.
	 * <p>
	 * 	Works on both object and primitive arrays.
	 * <p>
	 * 	In the case of multi-dimensional arrays, the incoming list must
	 * 	contain elements of type n-1 dimension.  i.e. if {@code type} is <code><jk>int</jk>[][]</code>
	 * 	then {@code list} must have entries of type <code><jk>int</jk>[]</code>.
	 *
	 * @param type The type to convert to.  Must be an array type.
	 * @param list The contents to populate the array with.
	 * @return A new object or primitive array.
	 */
	public Object toArray(ClassMeta<?> type, List<?> list) {
		ClassMeta<?> componentType = type.getElementType();
		Object array = Array.newInstance(componentType.getInnerClass(), list.size());
		for (int i = 0; i < list.size(); i++) {
			Object o = list.get(i);
			if (! type.getInnerClass().isInstance(o)) {
				if (componentType.isArray() && o instanceof List)
					o = toArray(componentType, (List<?>)o);
				else if (o == null && componentType.isPrimitive())
					o = getPrimitiveDefault(componentType.getInnerClass());
				else
					o = convertToType(o, componentType);
			}
			try {
				Array.set(array, i, o);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
				throw e;
			}
		}
		return array;
	}

	/**
	 * Returns the default value for primitives as an Object.
	 *
	 * @param c The primitive class.
	 * @return The default value as an Object.
	 */
	public static Object getPrimitiveDefault(Class<?> c) {
		if (c.isPrimitive()) {
			if (c == Boolean.TYPE)
				return BOOLEAN_DEFAULT;
			else if (c == Character.TYPE)
				return CHARACTER_DEFAULT;
			else if (c == Short.TYPE)
				return SHORT_DEFAULT;
			else if (c == Integer.TYPE)
				return INTEGER_DEFAULT;
			else if (c == Long.TYPE)
				return LONG_DEFAULT;
			else if (c == Float.TYPE)
				return FLOAT_DEFAULT;
			else if (c == Double.TYPE)
				return DOUBLE_DEFAULT;
			else if (c == Byte.TYPE)
				return BYTE_DEFAULT;
		} else {
			if (c == Boolean.class)
				return BOOLEAN_DEFAULT;
			else if (c == Character.class)
				return CHARACTER_DEFAULT;
			else if (c == Short.class)
				return SHORT_DEFAULT;
			else if (c == Integer.class)
				return INTEGER_DEFAULT;
			else if (c == Long.class)
				return LONG_DEFAULT;
			else if (c == Float.class)
				return FLOAT_DEFAULT;
			else if (c == Double.class)
				return DOUBLE_DEFAULT;
			else if (c == Byte.class)
				return BYTE_DEFAULT;
		}
		throw new RuntimeException("Invalid primitive type: ["+c.getClass().getName()+"]");
	}

	private static Boolean BOOLEAN_DEFAULT = false;
	private static Character CHARACTER_DEFAULT = (char)0;
	private static Short SHORT_DEFAULT = (short)0;
	private static Integer INTEGER_DEFAULT = 0;
	private static Long LONG_DEFAULT = 0l;
	private static Float FLOAT_DEFAULT = 0f;
	private static Double  DOUBLE_DEFAULT = 0d;
	private static Byte BYTE_DEFAULT = (byte)0;

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public BeanContext lock() {
		if (! isLocked()) {
			super.lock();
			notBeanPackages = Collections.unmodifiableSet(notBeanPackages);
			filters = Collections.unmodifiableMap(filters);
			notBeanClasses = Collections.unmodifiableSet(notBeanClasses);
			implClasses = Collections.unmodifiableMap(implClasses);
			uriVars = Collections.unmodifiableMap(uriVars);
			classMetaCache = getClassMetaCache();
		}
		return this;
	}

	@Override
	public void checkLock() {
		super.checkLock();
		classMetaCache = null;
		// Note: Don't reset filterCache...that happens when the filters are modified.
	}

	@Override
	public BeanContext clone() {
		try {
			return (BeanContext)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen.
		}
	}

	@Override
	public void onUnclone() {
		notBeanPackages = new LinkedHashSet<String>(notBeanPackages);
		filters = new ConcurrentHashMap<Class<?>,Filter>(filters);
		notBeanClasses = new HashSet<Class<?>>(notBeanClasses);
		implClasses = new IdentityHashMap<Class<?>,Class<?>>(implClasses);
		uriVars = new HashMap<String,String>(uriVars);
		classMetaCache = null;
		// Note: Don't reset filterCache...that happens when the filters are modified.
	}
}
