package com.ibm.juno.core.parser;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.utils.*;

/**
 * Similar to a {@link java.io.PushbackReader} with a pushback buffer of 1 character.
 * <p>
 *		Code is optimized to work with a 1 character buffer.
 * <p>
 * 	Additionally keeps track of current line and column number, and provides the ability to set
 * 	mark points and capture characters from the previous mark point.
 * <p>
 * 	<b>Warning:</b>  Not thread safe.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserReader extends Reader {

	private Reader in;		// Wrapped reader.
	int lastChar;				// Last character.
	int line = 1;				// Current line number.
	int column;					// Current column number.
	int length;
	boolean isUnread;			// Tracks whether unread() has been called.
	boolean isMarking;

	private char[] buff;		// Reusable character buffer.
	private int buffPos;		// The current position in the reusable buffer.

	ParserReader() {
	}

	/**
	 * Constructor.
	 * <p>
	 * 	Automatically wraps the reader in a {@link BufferedReader} if it isn't already a buffered reader.
	 *
	 * @param in The Reader being wrapped.
	 * @param buffSize The buffer size to use for the buffered reader.
	 */
	public ParserReader(Reader in, int buffSize) {
		this.in = IOUtils.getBufferedReader(in, buffSize);
	}

	/**
	 * Returns the current line number position in this reader.
	 *
	 * @return The current line number.
	 */
	public int getLine() {
		return line;
	}

	/**
	 * Returns the current column number position in this reader.
	 *
	 * @return The current column number.
	 */
	public int getColumn() {
		return column;
	}

	/**
	 * Reads a single character.
	 *
	 * @return The character read, or -1 if the end of the stream has been reached.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@Override // Reader
	public int read() throws IOException {
		if (isUnread) {
			isUnread = false;
			if (isMarking)
				addBuff((char)lastChar);
			return lastChar;
		}
		int x = in.read();
		length++;
		lastChar = x;
		if (lastChar == '\n') {
			line++;
			column = 0;
		} else {
			column++;
		}
		if (isMarking && x != -1)
			addBuff((char)lastChar);
		return x;
	}

	/**
	 * Start buffering the calls to read() so that the text can be gathered from the mark
	 * point on calling {@code getFromMarked()}.
	 */
	public void mark() {
		isMarking = true;
		buffPos = 0;
	}


	/**
	 * Returns the number of characters that were parsed in this stream.
	 *
	 * @return The character count.
	 */
	public int getLength() {
		return length;
	}

	/**
	 * Peeks the next character in the stream.
	 * <p>
	 * 	This is equivalent to doing a {@code read()} followed by an {@code unread()}.
	 *
	 * @return The peeked character, or (char)-1 if the end of the stream has been reached.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public int peek() throws IOException {
		int c = read();
		unread();
		return c;
	}

	/**
	 * Read the specified number of characters off the stream.
	 *
	 * @param num The number of characters to read.
	 * @return The characters packaged as a String.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public String read(int num) throws IOException {
		StringBuilder sb = new StringBuilder(num);
		for (int i = 0; i < num; i++)
			sb.append((char)read());
		return sb.toString();
	}

	/**
	 * Pushes the last read character back into the stream.
	 *
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public ParserReader unread() throws IOException {
		if (isUnread)
			throw new IOException("Buffer overflow.  Cannot unread more than one character.");
		if (lastChar != -1) {
			isUnread = true;
			if (isMarking)
				buffPos--;
		}
		return this;
	}

	/**
	 * Close this reader and the underlying reader.
	 *
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@Override
	public void close() throws IOException {
		in.close();
	}

	/**
	 * Adds a character to the reusable character buffer.
	 *
	 * @param c The character to add to the reusable buffer.
	 */
	private void addBuff(char c) {
		if (buff == null)
			 buff = new char[64];
		if (buffPos == buff.length) {
			char[] oldBuff = buff;
			buff = new char[oldBuff.length << 1];
			System.arraycopy(oldBuff, 0, buff, 0, oldBuff.length);
		}
		buff[buffPos++] = c;
	}

	/**
	 * Returns the contents of the reusable character buffer as a string, and
	 * resets the buffer for next usage.
	 *
	 * @return The contents of the reusable character buffer as a string.
	 */
	public String getFromMarked() {
		if (buff == null)
			return "";
		String s = new String(buff, 0, buffPos);
		buffPos = 0;
		isMarking = false;
		return s;
	}

	@Override
	public int read(char[] cbuf, int off, int len) throws IOException {
		for (int i = 0; i < len; i++) {
			int c = read();
			if (c == -1) {
				if (i == 0)
					return -1;
				return i;
			}
			cbuf[off+i] = (char)c;
		}
		return len;
	}
}
