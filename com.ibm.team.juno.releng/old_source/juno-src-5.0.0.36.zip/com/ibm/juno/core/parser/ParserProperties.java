package com.ibm.juno.core.parser;


/**
 * Configurable properties common to all {@link Parser} classes.
 * <p>
 * 	Use the {@link Parser#setProperty(String, Object)} method to set property values.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserProperties implements Cloneable {

	// Placeholder for potential future parser properties.

	@Override
	public ParserProperties clone() throws CloneNotSupportedException {
		return (ParserProperties)super.clone();
	}
}
