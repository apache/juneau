package com.ibm.juno.core.filter;

import com.ibm.juno.core.*;


/**
 * Simple bean filter that simply identifies a class to be used as an interface
 * 	class for all child classes.
 * <p>
 * 	These objects are created when you pass in non-<code>Filter</code> classes to {@link BeanContext#addFilters(Class...)},
 * 		and are equivalent to adding a <code><ja>@Bean</ja>(interfaceClass=Foo.<jk>class</jk>)</code> annotation on the <code>Foo</code> class.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <T> The class type that this filter applies to.
 */
public class InterfaceBeanFilter<T> extends BeanFilter<T> {

	/**
	 * Constructor.
	 * @param interfaceClass The class to use as an interface on all child classes.
	 */
	public InterfaceBeanFilter(Class<T> interfaceClass) {
		super(interfaceClass);
		setInterfaceClass(interfaceClass);
	}
}
