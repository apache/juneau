package com.ibm.juno.core.urlencoding;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.ClassMetaConst.*;
import static com.ibm.juno.core.serializer.SerializerProperties.*;
import static com.ibm.juno.core.urlencoding.UrlEncodingSerializerProperties.*;

import java.io.*;
import java.util.*;

import javax.servlet.http.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJO models to URL GET parameter notation (e.g. <js>"foo=bar&amp;baz=bing"</js>).
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>application/x-www-form-urlencoded</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>application/x-www-form-urlencoded</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This serializer provides several serialization options.  Typically, one of the predefined DEFAULT serializers will be sufficient.
 * 	However, custom serializers can be constructed to fine-tune behavior.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link UrlEncodingSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Serialize a Map</jc>
 * 	Map m = <jk>new</jk> ObjectMap(<js>"{a:'b',c:1,d:false,e:['f',1,false],g:{h:'i'}}"</js>);
 *
 * 	<jc>// Produces "a=b&amp;c=1&amp;d=false&amp;e=[f,1,false]&amp;g={h=i}"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT</jsf>.serialize(s);
 *
 * 	<jc>// Serialize a bean</jc>
 * 	<jk>public class</jk> Person {
 * 		<jk>public</jk> Person(String s);
 * 		<jk>public</jk> String getName();
 * 		<jk>public int</jk> getAge();
 * 		<jk>public</jk> Address getAddress();
 * 		<jk>public boolean</jk> deceased;
 * 	}
 *
 * 	<jk>public class</jk> Address {
 * 		<jk>public</jk> String getStreet();
 * 		<jk>public</jk> String getCity();
 * 		<jk>public</jk> String getState();
 * 		<jk>public int</jk> getZip();
 * 	}
 *
 * 	Person p = <jk>new</jk> Person(<js>"John Doe"</js>, 23, <js>"123 Main St"</js>, <js>"Anywhere"</js>, <js>"NY"</js>, 12345, <jk>false</jk>);
 *
 * 	<jc>// Produces "name=John%20Doe&amp;age=23&amp;address={street=123%20Main%20St,city=Anywhere,state=NY,zip=12345}&amp;deceased=false"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT</jsf>.serialize(s);
 * </p>
 *
 *
 * <h6 class='topic'>Escape sequences</h6>
 * <p>
 * 	During serialization, the following characters are escaped with <js>'\'</js> (i.e. <js>"%5C"</js> after encoding):
 * 		<code>"&,{}[]=\</code>
 * <p>
 * 	This escaping allows URL encoded strings to be parsed into their original form regardless of
 * 		whether the string has been URL-decoded before being passed to <code>UrlEncodingParser.parse(Reader, Class)</code>.
 * 	Therefore, both the entire query string (e.g. {@link HttpServletRequest#getQueryString()}) or just a single
 * 		parameter (e.g. {@link HttpServletRequest#getParameter(String)} can be parsed by the parser even though
 * 		the former is URL-encoded and the later is not.
 *
 *
 * <h6 class='topic'>Type flags</h6>
 * <p>
 * 	The {@link UrlEncodingSerializerProperties#USE_TYPE_FLAGS} setting can be used to prepend type flags (e.g. <js>"(b)"</js>, <js>"(i)"</js>)
 * 		to the beginning of booleans and integers to differentiate them from string values (e.g. <js>"true"</js>, <js>"false"</js>, <js>"123"</js>).
 * <p>
 * 	This can be useful for preserving object types during parsing when the data type cannot be inferred from inflection
 * 	(e.g. parsing into a field of type <code>Object</code>).
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Produces("application/x-www-form-urlencoded")
public class UrlEncodingSerializer extends WriterSerializer {

	/** Default serializer, all default settings.*/
	public static final UrlEncodingSerializer DEFAULT = new Simple().lock();

	/**
	 * Default serializer, single quotes, safe mode.
	 * This serializer will quote numeric and boolean string literals (e.g. <code>"true"</code>, <code>"false"</code>, <code>"123"</code>)
	 * 	so that the data type will be preserved when it cannot be inferred though reflection by the parser (e.g. when parsing
	 * 	into an <code>Object</code> field.
	 */
	public static final UrlEncodingSerializer DEFAULT_SAFE = new Safe().lock();

	/** Default serializer, single quotes, simple mode, with whitespace. */
	public static final UrlEncodingSerializer DEFAULT_READABLE = new Simple().setProperty(USE_WHITESPACE, true).lock();

	/** Default serializer, single quotes, simple mode. */
	@Produces(value={"application/json+simple","text/json+simple"},contentType="application/json")
	public static class Simple extends UrlEncodingSerializer {
		/** Constructor */
		public Simple() {
			setProperty(QUOTE_CHAR, '\'');
		}
	}

	/** Default serializer, single quotes, simple mode, with whitespace. */
	public static class Safe extends Simple {
		/** Constructor */
		public Safe() {
			setProperty(USE_TYPE_FLAGS, true);
		}
	}


	/** JSON serializer properties currently set on this serializer. */
	protected transient UrlEncodingSerializerProperties usp = new UrlEncodingSerializerProperties();


	/**
	 * Workhorse method. Determines the type of object, and then calls the
	 * appropriate type-specific serialization method.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	SerializerWriter serializeAnything(UrlEncodingSerializerWriter out, Object o, ClassMeta<?> eType, UrlEncodingSerializerContext ctx, String attrName, BeanPropertyMeta pMeta, boolean isTop, boolean quoteEmptyStrings) throws SerializeException {
		try {

			if (o == null) {
				out.appendObject(null, false);
				return out;
			}

			if (eType == null)
				eType = OBJECT;

			boolean addClassAttr;		// Add "_class" attribute to element?
			ClassMeta<?> aType;			// The actual type
			ClassMeta<?> gType;			// The generic type

			aType = ctx.push(attrName, o, eType);
			boolean isRecursion = aType == null;

			// Handle recursion
			if (aType == null) {
				o = null;
				aType = OBJECT;
			}

			gType = aType.getFilteredClassMeta();
			addClassAttr = (ctx.isAddClassAttrs() && ! eType.equals(aType));

			// Filter if necessary
			PojoFilter filter = aType.getPojoFilter();				// The filter
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == OBJECT)
					gType = beanContext.getClassMetaForObject(o);
			}

			// '\0' characters are considered null.
			if (o == null || (gType.isChar() && ((Character)o).charValue() == 0))
				out.appendObject(null, false);
			else if (gType.isBean())
				serializeBeanMap(out, beanContext.forBean(o), addClassAttr, ctx, isTop);
			else if (gType.isUri() || (pMeta != null && (pMeta.isUri() || pMeta.isBeanUri())))
				out.appendUri(o);
			else if (gType.isMap()) {
				if (o instanceof BeanMap)
					serializeBeanMap(out, (BeanMap)o, addClassAttr, ctx, isTop);
				else
					serializeMap(out, (Map)o, eType, ctx, isTop);
			}
			else if (gType.isCollection()) {
				if (addClassAttr)
					serializeCollectionMap(out, (Collection)o, gType, ctx);
				else
					serializeCollection(out, (Collection) o, eType, ctx);
			}
			else if (gType.isArray()) {
				if (addClassAttr)
					serializeCollectionMap(out, toList(gType.getInnerClass(), o), gType, ctx);
				else
					serializeCollection(out, toList(gType.getInnerClass(), o), eType, ctx);
			}
			else {
				out.appendObject(o, quoteEmptyStrings);
			}

			if (! isRecursion)
				ctx.pop();
			return out;
		} catch (SerializeException e) {
			throw e;
		} catch (Throwable e) {
			throw new SerializeException("Exception occured trying to process object of type ''{0}''", (o == null ? null : o.getClass().getName())).setCause(e);
		}
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeMap(UrlEncodingSerializerWriter out, Map m, ClassMeta<?> type, UrlEncodingSerializerContext ctx, boolean isTop) throws IOException, SerializeException {

		ClassMeta<?> keyType = type.getKeyType(), valueType = type.getValueType();

		char esc = isTop ? '&' : ',';  // Entry separator character.

		int depth = ctx.getIndent();
		out.appendIf(!isTop, '{');

		Iterator mapEntries = m.entrySet().iterator();

		while (mapEntries.hasNext()) {
			Map.Entry e = (Map.Entry) mapEntries.next();
			Object value = e.getValue();

			Object key = generalize(e.getKey(), keyType);

			out.cr(depth).attr(key).append('=').s();

			serializeAnything(out, value, valueType, ctx, (key == null ? null : key.toString()), null, false, false);

			if (mapEntries.hasNext())
				out.append(esc).s();
		}

		out.cr(depth-1).appendIf(!isTop,'}');

		return out;
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeCollectionMap(UrlEncodingSerializerWriter out, Collection o, ClassMeta<?> type, UrlEncodingSerializerContext ctx) throws IOException, SerializeException {
		int i = ctx.getIndent();
		out.append('{').nl();
		out.append(i, "_class=").s().appendObject(type, false).append(',').nl();
		out.append(i, "items=").s();
		ctx.indent++;
		serializeCollection(out, o, type, ctx);
		ctx.indent--;
		out.cr(i-1).append('}');
		return out;
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeBeanMap(UrlEncodingSerializerWriter out, BeanMap m, boolean addClassAttr, UrlEncodingSerializerContext ctx, boolean isTop) throws IOException, SerializeException {
		int depth = ctx.getIndent();
		out.appendIf(!isTop, '{');

		char esc = isTop ? '&' : ',';  // Entry separator character.

		Iterator mapEntries = m.entrySet().iterator();

		// Print out "_class" attribute on this bean if required.
		if (addClassAttr) {
			String attr = "_class";
			out.cr(depth).attr(attr).append('=').s().append(m.getClassMeta().getInnerClass().getName());
			if (mapEntries.hasNext())
				out.append(esc).s();
		}

		boolean addComma = false;

		while (mapEntries.hasNext()) {
			BeanMapEntry p = (BeanMapEntry)mapEntries.next();
			BeanPropertyMeta pMeta = p.getMeta();

			if (canIgnoreProperty(ctx, pMeta))
				continue;

			Object value = null;
			try {
				value = p.getFilteredValue();
			} catch (Throwable t) {
				ctx.addWarning("Could not call getValue() on property ''{0}'', {1}", p.getKey(), t.getLocalizedMessage());
			}

			if (canIgnoreValue(ctx, pMeta.getClassMeta(), value))
				continue;

			if (addComma)
				out.append(esc).s();

			out.cr(depth).attr(p.getKey()).append('=').s();

			serializeAnything(out, value, pMeta.getFilteredClassMeta(), ctx, p.getKey(), pMeta, false, false);

			addComma = true;
		}
		out.cr(depth-1).appendIf(!isTop,'}');
		return out;
	}

	@SuppressWarnings("rawtypes")
	private SerializerWriter serializeCollection(UrlEncodingSerializerWriter out, Collection c, ClassMeta<?> type, UrlEncodingSerializerContext ctx) throws IOException, SerializeException {

		ClassMeta<?> elementType = type.getElementType();

		out.append('[');
		int depth = ctx.getIndent();
		boolean quoteEmptyString = c.size() == 1;

		for (Iterator i = c.iterator(); i.hasNext();) {

			Object value = i.next();

			out.cr(depth);

			serializeAnything(out, value, elementType, ctx, "<iterator>", null, false, quoteEmptyString);

			if (i.hasNext())
				out.append(',').s();
		}
		out.cr(depth-1).append(']');
		return out;
	}

	//--------------------------------------------------------------------------------
	// Methods for constructing individual parameter values.
	//--------------------------------------------------------------------------------

	/**
	 * Identical to {@link #serialize(Object, Writer, SerializerContext)} except
	 * 	converts top-level maps and beans to format <js>"{key1=val1,key2=val2}"</js> instead of <js>"key1=val1&key2=val2"</js>.
	 * <p>
	 * Intended to be used when constructing just a single query parameter value instead of an entire query string.
	 *
	 * @param o The object to serialize.
	 * @param out The writer or output stream to write to.
	 * @param ctx The serializer context object return by {@link #createContext(Object, ObjectMap, String, String)}.<br>
	 * 	Can be <jk>null</jk>.
	 *
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serializeParam(Object o, UrlEncodingSerializerWriter out, UrlEncodingSerializerContext ctx) throws IOException, SerializeException {
		serializeAnything(out, o, null, ctx, "root", null, false, false);
	}

	/**
	 * Identical to {@link #serialize(Object, Writer)} except
	 * 	converts top-level maps and beans to format <js>"{key1=val1,key2=val2}"</js> instead of <js>"key1=val1&key2=val2"</js>.
	 * <p>
	 * Intended to be used when constructing just a single query parameter value instead of an entire query string.
	 *
	 * @param o The object to serialize.
	 * @param out The writer or output stream to write to.
	 *
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serializeParam(Object o, Writer out) throws IOException, SerializeException {
		UrlEncodingSerializerContext ctx = createContext(out, null, null, null);
		UrlEncodingSerializerWriter w = wrapWriter(out, ctx);
		serializeParam(o, w, ctx);
	}

	/**
	 * Identical to {@link #serialize(Object, SerializerContext)} except
	 * 	converts top-level maps and beans to format <js>"{key1=val1,key2=val2}"</js> instead of <js>"key1=val1&key2=val2"</js>.
	 * <p>
	 * Intended to be used when constructing just a single query parameter value instead of an entire query string.
	 *
	 * @param o The object to serialize.
	 * @param ctx The serialize context.  Can be <jk>null</jk>.
	 *
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 * @return The output serialized to a string.
	 */
	public String serializeParam(Object o, UrlEncodingSerializerContext ctx) throws SerializeException {
		try {
			StringWriter w = new StringWriter();
			UrlEncodingSerializerWriter writer = wrapWriter(w, ctx);
			serializeParam(o, writer, ctx);
			return w.toString();
		} catch (IOException e) { // Shouldn't happen.
			throw new RuntimeException(e);
		}
	}

	/**
	 * Identical to {@link #serialize(Object)} except
	 * 	converts top-level maps and beans to format <js>"{key1=val1,key2=val2}"</js> instead of <js>"key1=val1&key2=val2"</js>.
	 * <p>
	 * Intended to be used when constructing just a single query parameter value instead of an entire query string.
	 *
	 * @param o The object to serialize.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 * @return The output serialized to a string.
	 */
	public String serializeParam(Object o) throws SerializeException {
		return serializeParam(o, createContext(o, null, null, null));
	}

	UrlEncodingSerializerWriter wrapWriter(Writer out, UrlEncodingSerializerContext ctx) {
		if (out instanceof UrlEncodingSerializerWriter)
			return (UrlEncodingSerializerWriter)out;
		return new UrlEncodingSerializerWriter(out, ctx.isUseIndentation(), ctx.isUseWhitespace(), ctx.isUseTypeFlags(), ctx.getUriContext(), ctx.getUriAuthority());
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Serializer
	public UrlEncodingSerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) {
		return new UrlEncodingSerializerContext(beanContext, sp, usp, properties, mediaType);
	}

	@Override // Serializer
	public void serialize(Object o, Writer out, SerializerContext ctx) throws IOException, SerializeException {
		UrlEncodingSerializerContext ctx2 = narrow(ctx, UrlEncodingSerializerContext.class);
		serializeAnything(wrapWriter(out, ctx2), o, null, ctx2, "root", null, true, true);
	}

	@Override // CoreApi
	public UrlEncodingSerializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (usp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // CoreApi
	public UrlEncodingSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public UrlEncodingSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> UrlEncodingSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // Lockable
	public UrlEncodingSerializer lock() {
		super.lock();
		return this;
	}

	@Override // Lockable
	public UrlEncodingSerializer clone() {
		try {
			UrlEncodingSerializer c = (UrlEncodingSerializer)super.clone();
			c.usp = usp.clone();
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
