package com.ibm.juno.core.json;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.ClassMetaConst.*;
import static com.ibm.juno.core.json.JsonParserProperties.*;
import static com.ibm.juno.core.utils.StringUtils.*;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.*;

/**
 * Parses any valid JSON text into a POJO model.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Content-Type</code> types: <code>application/json, text/json</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This parser uses a state machine, which makes it very fast and efficient.  It parses JSON in about 70% of the
 * 	time that it takes the built-in Java DOM parsers to parse equivalent XML.
 * <p>
 * 	This parser handles all valid JSON syntax.
 * 	In addition, when strict mode is disable, the parser also handles the following:
 * 	<ul>
 * 		<li> Javascript comments (both {@code /*} and {@code //}) are ignored.
 *			<li> Both single and double quoted strings.
 *			<li> Automatically joins concatenated strings (e.g. <code><js>"aaa"</js> + <js>'bbb'</js></code>).
 *			<li> Unquoted attributes.
 * 	</ul>
 * 	Also handles negative, decimal, hexadecimal, octal, and double numbers, including exponential notation.
 * <p>
 * 	This parser handles the following input, and automatically returns the corresponding Java class.
 * 	<ul>
 * 		<li> JSON objects (<js>"{...}"</js>) are converted to {@link ObjectMap ObjectMaps}.  <br>
 * 				Note:  If a <code><xa>_class</xa>=<xs>'xxx'</xs></code> attribute is specified on the object, then an attempt is made to convert the object
 * 				to an instance of the specified Java bean class.  See the classProperty setting on the {@link BeanContext} for more information
 * 				about parsing beans from JSON.
 * 		<li> JSON arrays (<js>"[...]"</js>) are converted to {@link ObjectList ObjectLists}.
 * 		<li> JSON string literals (<js>"'xyz'"</js>) are converted to {@link String Strings}.
 * 		<li> JSON numbers (<js>"123"</js>, including octal/hexadecimal/exponential notation) are converted to {@link Integer Integers},
 * 				{@link Long Longs}, {@link Float Floats}, or {@link Double Doubles} depending on whether the number is decimal, and the size of the number.
 * 		<li> JSON booleans (<js>"false"</js>) are converted to {@link Boolean Booleans}.
 * 		<li> JSON nulls (<js>"null"</js>) are converted to <jk>null</jk>.
 * 		<li> Input consisting of only whitespace or JSON comments are converted to <jk>null</jk>.
 * 	</ul>
 * <p>
 * 	Input can be any of the following:<br>
 * 	<ul>
 * 		<li> <js>"{...}"</js> - Converted to a {@link ObjectMap} or an instance of a Java bean if a <xa>_class</xa> attribute is present.
 *  		<li> <js>"[...]"</js> - Converted to a {@link ObjectList}.
 *  		<li> <js>"123..."</js> - Converted to a {@link Number} (either {@link Integer}, {@link Long}, {@link Float}, or {@link Double}).
 *  		<li> <js>"true"</js>/<js>"false"</js> - Converted to a {@link Boolean}.
 *  		<li> <js>"null"</js> - Returns <jk>null</jk>.
 *  		<li> <js>"'xxx'"</js> - Converted to a {@link String}.
 *  		<li> <js>"\"xxx\""</js> - Converted to a {@link String}.
 *  		<li> <js>"'xxx' + \"yyy\""</js> - Converted to a concatenated {@link String}.
 * 	</ul>
  * <p>
 * 	TIP:  If you know you're parsing a JSON object or array, it can be easier to parse it using the {@link ObjectMap#ObjectMap(CharSequence) ObjectMap(CharSequence)}
 * 		or {@link ObjectList#ObjectList(CharSequence) ObjectList(CharSequence)} constructors instead of using this class.  The end result should be the same.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link ParserProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@Consumes({"application/json","text/json"})
public class JsonParser extends ExtendedReaderParser {

	/** Default parser, all default settings.*/
	public static final JsonParser DEFAULT = new JsonParser().lock();

	/** Default parser, all default settings.*/
	public static final JsonParser DEFAULT_STRICT = new JsonParser().setProperty(STRICT_MODE, true).lock();

	/** JSON specific properties currently defined on this class */
	protected transient JsonParserProperties jpp = new JsonParserProperties();


	@Override
	public <K,V> Map<K,V> parseIntoMap(Reader in, Map<K,V> m, Type keyType, Type valueType) throws ParseException, IOException {
		try {
			ClassMeta cm = beanContext.getMapClassMeta(m.getClass(), keyType, valueType);
			JsonParserContext ctx = createContext(cm, null, null, null);
			ParserReader r2 = wrapReader(in);
			m = parseIntoMap2(ctx, r2, m, beanContext.getClassMeta(keyType), beanContext.getClassMeta(valueType));
			validateEnd(ctx, r2);
			return m;
		} catch (Exception e) {
			throw new ParseException(e);
		}
	}

	@Override
	public <E> Collection<E> parseIntoCollection(Reader in, Collection<E> c, Type elementType) throws ParseException, IOException {
		try {
			ClassMeta cm = beanContext.getCollectionClassMeta(c.getClass(), elementType);
			JsonParserContext ctx = createContext(cm, null, null, null);
			ParserReader r2 = wrapReader(in);
			c = parseIntoCollection2(ctx, r2, c, beanContext.getClassMeta(elementType));
			validateEnd(ctx, r2);
			return c;
		} catch (Exception e) {
			throw new ParseException(e);
		}
	}

	@Override
	public Object[] parseArgs(Reader in, ClassMeta<?>[] argTypes) throws ParseException, IOException {
		try {
			JsonParserContext ctx = createContext(ClassMetaConst.OBJECT, null, null, null);
			ParserReader r2 = wrapReader(in);
			Object[] r = parseArgs(ctx, r2, argTypes);
			validateEnd(ctx, r2);
			return r;
		} catch (Exception e) {
			throw new ParseException(e);
		}
	}

	private <T> T parseAnything(JsonParserContext ctx, ClassMeta<T> nt, ParserReader r, BeanPropertyMeta p) throws ParseException {

		if (nt == null)
			nt = (ClassMeta<T>)OBJECT;
		PojoFilter<T,Object> filter = (p == null ? null : p.getFilter());
		if (filter == null)
			filter = (PojoFilter<T,Object>)nt.getPojoFilter();
		ClassMeta<?> ft = (p == null ? nt.getFilteredClassMeta() : p.getFilteredClassMeta());

		int line = r.getLine();
		int column = r.getColumn();
		Object o = null;
		try {
			skipCommentsAndSpace(ctx, r);
			int c = r.peek();
			if (c == -1) {
				// Let o be null.
			} else if ((c == ',' || c == '}' || c == ']')) {
				if (ctx.isStrictMode())
					throw new ParseException(line, column, "Missing value detected.");
				// Handle bug in Cognos 10.2.1 that can product non-existent values.
				// Let o be null;
			} else if (c == 'n') {
				parseKeyword("null", r);
			} else if (ft.isObject()) {
				if (c == '{') {
					ObjectMap m2 = new ObjectMap();
					parseIntoMap2(ctx, r, m2, STRING, OBJECT);
					o = m2.cast();
				} else if (c == '[')
					o = parseIntoCollection2(ctx, r, new ObjectList(), OBJECT);
				else if (c == '\'' || c == '"') {
					o = parseString(ctx, r);
					if (ft.isChar())
						o = o.toString().charAt(0);
				}
				else if (c >= '0' && c <= '9' || c == '-')
					o = parseNumber(r, null);
				else if (c == 't') {
					parseKeyword("true", r);
					o = Boolean.TRUE;
				} else {
					parseKeyword("false", r);
					o = Boolean.FALSE;
				}
			} else if (ft.isBoolean()) {
				if (c == 't') {
					parseKeyword("true", r);
					o = Boolean.TRUE;
				} else {
					parseKeyword("false", r);
					o = Boolean.FALSE;
				}
			} else if (ft.isCharSequence()) {
				o = parseString(ctx, r);
			} else if (ft.isChar()) {
				o = parseString(ctx, r).charAt(0);
			} else if (ft.isNumber()) {
				o = parseNumber(r, (Class<? extends Number>)ft.getInnerClass());
			} else if (ft.isMap()) {
				Map m = (ft.canCreateNewInstance() ? (Map)ft.newInstance() : new ObjectMap());
				o = parseIntoMap2(ctx, r, m, ft.getKeyType(), ft.getValueType());
			} else if (ft.isCollection()) {
				if (c == '{') {
					ObjectMap m = new ObjectMap();
					parseIntoMap2(ctx, r, m, STRING, OBJECT);
					o = m.cast();
				} else {
					Collection l = (ft.canCreateNewInstance() ? (Collection)ft.newInstance() : new ObjectList());
					o = parseIntoCollection2(ctx, r, l, ft.getElementType());
				}
			} else if (ft.isBean() && ft.canCreateNewInstance()) {
				BeanMap m = beanContext.newBeanMap(ft.getInnerClass());
				o = parseIntoBeanMap2(ctx, r, m).getBean();
			} else if (ft.canCreateNewInstanceFromString() && (c == '\'' || c == '"')) {
				o = ft.newInstance(parseString(ctx, r));
			} else if (ft.isArray()) {
				if (c == '{') {
					ObjectMap m = new ObjectMap();
					parseIntoMap2(ctx, r, m, STRING, OBJECT);
					o = m.cast();
				} else {
					ArrayList l = (ArrayList)parseIntoCollection2(ctx, r, new ArrayList(), ft.getElementType());
					o = beanContext.toArray(ft, l);
				}
			} else if (c == '{' ){
				Map m = new ObjectMap();
				parseIntoMap2(ctx, r, m, ft.getKeyType(), ft.getValueType());
				if (m.containsKey("_class"))
					o = ((ObjectMap)m).cast();
				else {
					if (ft.isBean())
						throw new ParseException(line, column, "Class does not have a public no-arg constructor.");
					throw new ParseException(line, column, "Class is not a bean.  Reason: ''{0}''", ft.getNotABeanReason());
				}
			} else {
				throw new ParseException(line, column, "Unrecognized syntax for class type ''{0}'', starting character ''{1}''", ft, (char)c);
			}

			if (filter != null && o != null)
				o = filter.unfilter(o, nt, beanContext);

			return (T)o;

		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			if (p == null)
				throw new ParseException("Error occurred trying to parse into class ''{0}''", ft).setCause(e);
			throw new ParseException("Error occurred trying to parse value for bean property ''{0}'' on class ''{1}''",
				p.getName(), p.getBeanMeta().getClassMeta()
			).setCause(e);
		}
	}

	private <K,V> Map<K,V> parseIntoMap2(JsonParserContext ctx, ParserReader r, Map<K,V> m, ClassMeta<K> keyType, ClassMeta<V> valueType) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		if (keyType == null)
			keyType = (ClassMeta<K>)STRING;

		int S0=0; // Looking for outer {
		int S1=1; // Looking for attrName start.
		int S3=3; // Found attrName end, looking for :.
		int S4=4; // Found :, looking for valStart: { [ " ' LITERAL.
		int S5=5; // Looking for , or }

		int state = S0;
		String currAttr = null;
		int c = 0;
		while (c != -1) {
			c = r.read();
			if (state == S0) {
				if (c == '{')
					state = S1;
			} else if (state == S1) {
				if (c == '}') {
					return m;
				} else if (c == '/') {
					skipCommentsAndSpace(ctx, r.unread());
				} else if (! Character.isWhitespace(c)) {
					currAttr = parseFieldName(ctx, r.unread());
					state = S3;
				}
			} else if (state == S3) {
				if (c == ':')
					state = S4;
			} else if (state == S4) {
				if (c == '/') {
					skipCommentsAndSpace(ctx, r.unread());
				} else if (! Character.isWhitespace(c)) {
					K key = convertAttrToType(currAttr, keyType);
					V value = parseAnything(ctx, valueType, r.unread(), null);
					m.put(key, value);
					state = S5;
				}
			} else if (state == S5) {
				if (c == ',')
					state = S1;
				else if (c == '/')
					skipCommentsAndSpace(ctx, r.unread());
				else if (c == '}') {
					return m;
				}
			}
		}
		if (state == S0)
			throw new ParseException(line, column, "Expected '{' at beginning of JSON object.");
		if (state == S1)
			throw new ParseException(line, column, "Could not find attribute name on JSON object.");
		if (state == S3)
			throw new ParseException(line, column, "Could not find ':' following attribute name on JSON object.");
		if (state == S4)
			throw new ParseException(line, column, "Expected one of the following characters: {,[,',\",LITERAL.");
		if (state == S5)
			throw new ParseException(line, column, "Could not find '}' marking end of JSON object.");

		return null; // Unreachable.
	}

	/*
	 * Parse a JSON attribute from the character array at the specified position, then
	 * set the position marker to the last character in the field name.
	 */
	private String parseFieldName(JsonParserContext ctx, ParserReader r) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();
		int c = r.peek();
		if (c == '\'' || c == '"')
			return parseString(ctx, r);
		if (ctx.isStrictMode())
			throw new ParseException(line, column, "Unquoted attribute detected.");
		r.mark();
		// Look for whitespace.
		while (c != -1) {
			c = r.read();
			if (c == ':' || Character.isWhitespace(c) || c == '/') {
				r.unread();
				String s = r.getFromMarked().intern();
				return s.equals("null") ? null : s;
			}
		}
		throw new ParseException(line, column, "Could not find the end of the field name.");
	}

	private <E> Collection<E> parseIntoCollection2(JsonParserContext ctx, ParserReader r, Collection<E> l, ClassMeta<E> elementType) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		int S0=0; // Looking for outermost [
		int S1=1; // Looking for starting [ or { or " or ' or LITERAL
		int S2=2; // Looking for , or ]

		int state = S0;
		int c = 0;
		while (c != -1) {
			c = r.read();
			if (state == S0) {
				if (c == '[')
					state = S1;
			} else if (state == S1) {
				if (c == ']') {
					return l;
				} else if (c == '/') {
					skipCommentsAndSpace(ctx, r.unread());
				} else if (! Character.isWhitespace(c)) {
					l.add(parseAnything(ctx, elementType, r.unread(), null));
					state = S2;
				}
			} else if (state == S2) {
				if (c == ',') {
					state = S1;
				} else if (c == '/') {
					skipCommentsAndSpace(ctx, r.unread());
				} else if (c == ']') {
					return l;
				}
			}
		}
		if (state == S0)
			throw new ParseException(line, column, "Expected '[' at beginning of JSON array.");
		if (state == S1)
			throw new ParseException(line, column, "Expected one of the following characters: {,[,',\",LITERAL.");
		if (state == S2)
			throw new ParseException(line, column, "Expected ',' or ']'.");

		return null;  // Unreachable.
	}

	private Object[] parseArgs(JsonParserContext ctx, ParserReader r, ClassMeta<?>[] argTypes) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		int S0=0; // Looking for outermost [
		int S1=1; // Looking for starting [ or { or " or ' or LITERAL
		int S2=2; // Looking for , or ]

		Object[] o = new Object[argTypes.length];
		int i = 0;

		int state = S0;
		int c = 0;
		while (c != -1) {
			c = r.read();
			if (state == S0) {
				if (c == '[')
					state = S1;
			} else if (state == S1) {
				if (c == ']') {
					return o;
				} else if (c == '/') {
					skipCommentsAndSpace(ctx, r.unread());
				} else if (! Character.isWhitespace(c)) {
					o[i] = parseAnything(ctx, argTypes[i], r.unread(), null);
					i++;
					state = S2;
				}
			} else if (state == S2) {
				if (c == ',') {
					state = S1;
				} else if (c == '/') {
					skipCommentsAndSpace(ctx, r.unread());
				} else if (c == ']') {
					return o;
				}
			}
		}
		if (state == S0)
			throw new ParseException(line, column, "Expected '[' at beginning of JSON array.");
		if (state == S1)
			throw new ParseException(line, column, "Expected one of the following characters: {,[,',\",LITERAL.");
		if (state == S2)
			throw new ParseException(line, column, "Expected ',' or ']'.");

		return null;  // Unreachable.
	}

	private <T> BeanMap<T> parseIntoBeanMap2(JsonParserContext ctx, ParserReader r, BeanMap<T> m) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();

		int S0=0; // Looking for outer {
		int S1=1; // Looking for attrName start.
		int S3=3; // Found attrName end, looking for :.
		int S4=4; // Found :, looking for valStart: { [ " ' LITERAL.
		int S5=5; // Looking for , or }

		int state = S0;
		String currAttr = "";
		int c = 0;
		int currAttrLine = -1, currAttrCol = -1;
		while (c != -1) {
			c = r.read();
			if (state == S0) {
				if (c == '{')
					state = S1;
			} else if (state == S1) {
				if (c == '}') {
					return m;
				} else if (c == '/') {
					skipCommentsAndSpace(ctx, r.unread());
				} else if (! Character.isWhitespace(c)) {
					r.unread();
					currAttrLine= r.getLine();
					currAttrCol = r.getColumn();
					currAttr = parseFieldName(ctx, r);
					state = S3;
				}
			} else if (state == S3) {
				if (c == ':')
					state = S4;
			} else if (state == S4) {
				if (c == '/') {
					skipCommentsAndSpace(ctx, r.unread());
				} else if (! Character.isWhitespace(c)) {
					if (! currAttr.equals("_class")) {
						BeanPropertyMeta pMeta = m.getPropertyMeta(currAttr);
						if (pMeta == null) {
							onUnknownProperty(currAttr, m, currAttrLine, currAttrCol);
							parseAnything(ctx, OBJECT, r.unread(), null); // Read content anyway to ignore it
						} else {
							Object value = parseAnything(ctx, pMeta.getClassMeta(), r.unread(), pMeta);
							pMeta.set(m, value);
						}
					}
					state = S5;
				}
			} else if (state == S5) {
				if (c == ',')
					state = S1;
				else if (c == '/')
					skipCommentsAndSpace(ctx, r.unread());
				else if (c == '}') {
					return m;
				}
			}
		}
		if (state == S0)
			throw new ParseException(line, column, "Expected '{' at beginning of JSON object.");
		if (state == S1)
			throw new ParseException(line, column, "Could not find attribute name on JSON object.");
		if (state == S3)
			throw new ParseException(line, column, "Could not find ':' following attribute name on JSON object.");
		if (state == S4)
			throw new ParseException(line, column, "Expected one of the following characters: {,[,',\",LITERAL.");
		if (state == S5)
			throw new ParseException(line, column, "Could not find '}' marking end of JSON object.");

		return null; // Unreachable.
	}

	/*
	 * Starting from the specified position in the character array, returns the
	 * position of the character " or '.
	 * If the string consists of a concatenation of strings (e.g. 'AAA' + "BBB"), this method
	 * will automatically concatenate the strings and return the result.
	 */
	private String parseString(JsonParserContext ctx, ParserReader r) throws ParseException, IOException  {
		int line = r.getLine();
		int column = r.getColumn();
		int qc = r.read();		// The quote character being used (" or ')
		if (qc == '\'' && ctx.isStrictMode())
			throw new ParseException(line, column, "Invalid quote character \"'\" being used.");
		r.mark();
		String s = null;
		boolean hasSpecialChars = false;
		boolean isInEscape = false;
		int c = 0;
		while (c != -1) {
			c = r.read();
			if (isInEscape) {
				isInEscape = false;
			} else {
				if (c == '\\') {
					isInEscape = true;
					hasSpecialChars = true;
				} else if (c == qc) {
					r.unread();		// Unread the quote char
					s = r.getFromMarked();
					r.read();
					break;
				}
			}
		}
		if (s == null)
			throw new ParseException(line, column, "Could not find expected end character ''{0}''.", (char)qc);
		if (hasSpecialChars)
			s = replaceSpecialChars(s, line, column);

		// Look for concatenated string (i.e. whitespace followed by +).
		skipCommentsAndSpace(ctx, r);
		if (r.peek() == '+') {
			if (ctx.isStrictMode())
				throw new ParseException(r.getLine(), r.getColumn(), "String concatenation detected.");
			r.read();	// Skip past '+'
			skipCommentsAndSpace(ctx, r);
			s += parseString(ctx, r);
		}
		return s; // End of input reached.
	}

	private ParserReader wrapReader(Reader in) {
		if (in instanceof ParserReader)
			return (ParserReader)in;
		return new ParserReader(in, 1024);
	}

	private static String replaceSpecialChars(String s, int line, int column) throws ParseException {
		StringBuilder sb = new StringBuilder();
		boolean isInEscape = false;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (isInEscape) {
				switch (c) {
					case 'n': sb.append('\n'); break;
					case 'r': sb.append('\r'); break;
					case 't': sb.append('\t'); break;
					case 'f': sb.append('\f'); break;
					case 'b': sb.append('\b'); break;
					case '\\': sb.append('\\'); break;
					case '/': sb.append('/'); break;
					case '\'': sb.append('\''); break;
					case '"': sb.append('"'); break;
					case 'u': {
						int i1 = i+1, i2 = i+5;
						if (i2 > s.length())
							throw new ParseException(line, column, "Invalid unicode sequence in string.");
						sb.append((char)Integer.parseInt(s.substring(i1, i2), 16));
						i+=4;
						break;
					}
					default:
						throw new ParseException(line, column, "Invalid escape sequence in string.");
				}
				isInEscape = false;
			} else {
				if (c == '\\')
					isInEscape = true;
				else
					sb.append(c);
			}
		}
		return sb.toString();
	}

	/*
	 * Looks for the keywords true, false, or null.
	 * Throws an exception if any of these keywords are not found at the specified position.
	 */
	private void parseKeyword(String keyword, ParserReader r) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();
		try {
			String s = r.read(keyword.length());
			if (s.equals(keyword))
				return;
			throw new ParseException(line, column, "Unrecognized syntax.");
		} catch (IndexOutOfBoundsException e) {
			throw new ParseException(line, column, "Unrecognized syntax.");
		}
	}

	/*
	 * Doesn't actually parse anything, but moves the position beyond any whitespace or comments.
	 * If positionOnNext is 'true', then the cursor will be set to the point immediately after
	 * the comments and whitespace.  Otherwise, the cursor will be set to the last position of
	 * the comments and whitespace.
	 */
	private void skipCommentsAndSpace(JsonParserContext ctx, ParserReader r) throws ParseException, IOException {
		int c = 0;
		while ((c = r.read()) != -1) {
			if (! Character.isWhitespace(c)) {
				if (c == '/') {
					if (ctx.isStrictMode())
						throw new ParseException(r.getLine(), r.getColumn(), "Javascript comment detected.");
					skipComments(r);
				} else {
					r.unread();
					return;
				}
			}
		}
	}

	/*
	 * Doesn't actually parse anything, but when positioned at the beginning of comment,
	 * it will move the pointer to the last character in the comment.
	 */
	private void skipComments(ParserReader r) throws ParseException, IOException {
		int line = r.getLine();
		int column = r.getColumn();
		int c = r.read();
		//  "/* */" style comments
		if (c == '*') {
			while (c != -1)
				if (r.read() == '*')
					if (r.read() == '/')
						return;
		//  "//" style comments
		} else if (c == '/') {
			while (c != -1) {
				c = r.read();
				if (c == -1 || c == '\n')
					return;
			}
		}
		throw new ParseException(line, column, "Open ended comment.");
	}

	/*
	 * Call this method after you've finished a parsing a string to make sure that if there's any
	 * remainder in the input, that it consists only of whitespace and comments.
	 */
	private void validateEnd(JsonParserContext ctx, ParserReader r) throws ParseException, IOException {
		skipCommentsAndSpace(ctx, r);
		int c = r.read();
		if (c != -1)
			throw new ParseException(r.getLine(), r.getColumn(), "Remainder after parse: ''{0}''.", (char)c);
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override
	public JsonParserContext createContext(ClassMeta<?> type, ObjectMap properties, String mediaType, String charset) throws ParseException {
		return new JsonParserContext(type, beanContext, jpp, pp, properties, mediaType, charset);
	}

	@Override // Parser
	public <T> T parse(Reader r, ClassMeta<T> type, ParserContext ctx) throws ParseException, IOException {
		if (! (ctx instanceof JsonParserContext))
			throw new ParseException("Context is not an instance of JsonParserContext");
		JsonParserContext ctx2 = (JsonParserContext)ctx;
		type = beanContext.normalizeClassMeta(type);
		ParserReader r2 = wrapReader(r);
		T o = parseAnything(ctx2, type, r2, null);
		validateEnd(ctx2, r2);
		return o;
	}

	@Override // Parser
	public JsonParser setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (jpp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // CoreApi
	public JsonParser setProperties(ObjectMap properties) throws LockedException {
		super.setProperties(properties);
		return this;
	}

	@Override // CoreApi
	public JsonParser addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public JsonParser addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> JsonParser addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}


	@Override // Lockable
	public JsonParser lock() {
		super.lock();
		return this;
	}

	@Override // Lockable
	public JsonParser clone() {
		try {
			return (JsonParser)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
