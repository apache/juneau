package com.ibm.juno.server;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.serializer.SerializerProperties.*;
import static com.ibm.juno.server.RestServletProperties.*;
import static com.ibm.juno.server.RestUtils.*;
import static com.ibm.juno.server.annotation.Inherit.*;
import static java.lang.String.*;
import static javax.servlet.http.HttpServletResponse.*;

import java.io.*;
import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.logging.*;
import java.util.regex.*;

import javax.activation.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.encoders.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.core.utils.*;
import com.ibm.juno.server.RestServletNls.NlsClass;
import com.ibm.juno.server.RestServletNls.NlsClass.NlsMethod;
import com.ibm.juno.server.RestServletNls.NlsClass.NlsResponse;
import com.ibm.juno.server.RestServletNls.NlsVar;
import com.ibm.juno.server.annotation.*;
import com.ibm.juno.server.annotation.Properties;
import com.ibm.juno.server.labels.*;
import com.ibm.juno.server.labels.MethodDescription.Response;
import com.ibm.juno.server.labels.MethodDescription.Var;

/**
 *	Servlet implementation of a REST resource.
 * <p>
 * 	Refer to {@link com.ibm.juno.server} for an overview of the REST server API.
 *
 *
 * <h6 class='topic'>Deploying REST servlets</h6>
 * Since REST servlets are subclasses of <code>HttpServlet</code>, they are deployed in a J2EE
 * 	container like any other servlet, typically a <code>web.xml</code> file.
 * <p>
 * Unlike the <code>JAX-RS</code> specification, there is no <ja>@Path</ja> annotation for identifying
 * 	servlet paths.
 * This feature was specifically not implemented to prevent the need for a separate configuration
 * 	setup step whereby REST resources must be identified programatically or through a
 * 	classloader scan.
 * The {@link RestServlet} class does not depend on any classloader scanning or external setup
 * 	other than registering the servlet with the J2EE container.
 * <p>
 * However, REST servlets can also be deployed by declaring them as children of another REST servlet
 * 	through the use of the {@link RestResource#children()} and {@link RestResource#path()} annotations.
 *
 *
 * <h6 class='topic'>Implementing new servlets</h6>
 *
 * In general, a REST servlet implementation defines the following...
 * <ul>
 * 	<li>An optional {@link RestResource} annotation on the servlet class.
 * 	<li>One or more public methods annotated with {@link RestMethod}.
 * 	<li>Zero or more REST parsers used to convert HTTP request body content to POJOs.
 * 	<li>Zero or more REST serializers used to convert POJOs to the HTTP response body content.
 * </ul>
 * <p>
 *	Implementers will typically subclass directly from this class.
 * However, the following subclass also provided for convenience...
 * <ul>
 * 	<li>{@link RestServletDefault} - Provides a default set of serializers and parsers for a variety of <code>Accept</code> and <code>Content-Type</code> types.
 * </ul>
 *
 *
 * <h6 class='topic'>@RestResource annotation</h6>
 * <p>
 * Implementations can optionally be annotated with {@link RestResource @RestResource}.
 * It provides various convenience annotations for defining servlet-level configuration data on the class.
 * <p>
 * See the {@link RestResource @RestResource} annotation for more information.
 *
 *
 * <h6 class='topic'>Child resources</h6>
 *	<p>
 *	Child resources can be attached to parent resources using the {@link RestResource#children()} annnotation...
 * <p class='bcode'>
 * 	<ja>@RestResource</ja>(
 * 		children={Foo.<jk>class</jk>}
 * 	)
 * 	<jk>public</jk> MyResource <jk>extends</jk> RestServlet {
 * 	}
 *
 * 	<ja>@RestResource</ja>(
 * 		path=<js>"/foo"</js>  // Path relative to parent resource.
 * 	)
 * 	<jk>public</jk> FooResource <jk>extends</jk> RestServlet {
 * 	}
 * <p>
 *
 *
 * <h6 class='topic'>@RestMethod annotation - Implementing REST method handlers</h6>
 *	<p>
 *	Subclasses of this class need only identify RESTful methods using the {@link RestMethod @RestMethod} annotation.
 * <p class='bcode'>
 * 	<ja>@RestMethod</ja>(name=<js>"X"</js>, path=<js>"/*"</js>)
 * 	<jk>public</jk> Object doX(...) {...}
 * </p>
 * <p>
 * See the {@link RestMethod @RestMethod} annotation for information on defining REST methods.
 *
 *
 * <h6 class='topic'>Specifying serializers for serializing response POJOs</h6>
 * <p>
 * REST servlets use the {@link Serializer} API for defining serializers for serializing response POJOs.
 * <p>
 * The servlet will pick which serializer to use by matching the request <code>Accept</code> header with the
 * 	media types defined through the {@link Serializer#getMediaTypes()} method (or {@link Produces} annotation).
 * <p>
 * REST serializers can be associated with REST servlets in the following ways:
 * <ul>
 * 	<li>Through the {@link RestResource#serializers()} annotation on the class.
 * 	<li>Through the {@link RestMethod#serializers()} annotations on individual REST methods of the class.
 * 	<li>By overriding the {@link #createSerializers()} method and setting the serializers programmatically.
 * </ul>
 * <p>
 * The following are equivalent ways of defining serializers used by a servlet...
 * <p class='bcode'>
 * 	<jc>// Example #1 - Serializers defined on servlet through annotation</jc>
 * 	<ja>@RestResource</ja>(
 * 		serializers={JsonSerializer.<jk>class</jk>, XmlSerializer.<jk>class</jk>}
 * 	)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 * 		...
 * 	}
 *
 * 	<jc>// Example #2 - Serializers defined on method through annotation</jc>
 * 	<ja>@RestMethod</ja>(name=<js>"GET"</js>, path=<js>"/*"</js>
 * 		serializers={JsonSerializer.<jk>class</jk>, XmlSerializer.<jk>class</jk>}
 * 	)
 * 	<jk>public</jk> Object doGet() {
 * 		...
 * 	}
 *
 * 	<jc>// Example #3 - Serializers defined on servlet by overriding the getSerializerGroup method</jc>
 * 	<ja>@Override</ja>
 * 	<jk>public</jk> SerializerGroup getSerializerGroup() {
 *
 * 		SerializerGroup g = <jk>new</jk> SerializerGroup()
 * 			.append(JsonSerializer.<jk>class</jk>, XmlSerializer.<jk>class</jk>);
 *
 * 		<jk>return</jk> g;
 * 	}
 * </p>
 *
 *
 * <h6 class='topic'>Specifying parsers for parsing request POJOs</h6>
 * <p>
 * REST servlets use the {@link Parser} API for defining parsers for parsing request body content and converting them into POJOs.
 * <p>
 * The servlet will pick which parser to use by matching the request <code>Content-Type</code> header with the
 * 	media types defined through the {@link Parser#getMediaTypes()} method (or {@link Consumes} annotation).
 * <p>
 * REST parsers can be associated with REST servlets in the following ways:
 * <ul>
 * 	<li>Through the {@link RestResource#parsers()} annotation on the class.
 * 	<li>Through the {@link RestMethod#parsers()} annotations on individual REST methods of the class.
 * 	<li>By overriding the {@link #createParsers()} method and setting the parsers programmatically.
 * </ul>
 * <p>
 * The following are equivalent ways of defining parsers used by a servlet...
 * <p class='bcode'>
 * 	<jc>// Example #1 - Parsers defined on servlet through annotation</jc>
 * 	<ja>@RestResource</ja>(
 * 		parsers={JsonParser.<jk>class</jk>, XmlParser.<jk>class</jk>}
 * 	)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 * 		...
 * 	}
 *
 * 	<jc>// Example #2 - Parsers defined on method through annotation</jc>
 * 	<ja>@RestMethod</ja>(name=<js>"GET"</js>, path=<js>"/*"</js>
 * 		parsers={JsonParser.<jk>class</jk>, XmlParser.<jk>class</jk>}
 * 	)
 * 	<jk>public void</jk> doPut(<ja>@Content</ja> Foo input) {
 * 		...
 * 	}
 *
 * 	<jc>// Example #3 - Parsers defined on servlet by overriding the getParserGroup method</jc>
 * 	<ja>@Override</ja>
 * 	<jk>public</jk> ParserGroup getParserGroup() {
 *
 * 		ParserGroup g = <jk>new</jk> ParserGroup()
 * 			.append(JsonParser.<jk>class</jk>, XmlParser.<jk>class</jk>);
 *
 * 		<jk>return</jk> g;
 * 	}
 * </p>
 *
 * <h6 class='topic'>Built-in URL parameters</h6>
 * <p>
 * The following URL parameters have special meaning and can be passed in through the URL of the request:
 * <ul>
 * 	<li><code>&amp;plainText</code> -
 * 		Useful for debugging.
 * 		Response will always be <code>Content-Type: text/plain</code> and the returned text will be human-readable
 * 			(i.e. {@link SerializerProperties#USE_INDENTATION} and {@link JsonSerializerProperties#USE_WHITESPACE} enabled).
 * 	<li><code>&amp;debug</code> -
 * 		Request body content will be dumped to log file.
 * 	<li><code>&amp;noTrace</code> -
 * 		If an error occurs, don't log the stack trace to the log file.
 * 		Useful for automated JUnit testcases testing error states to prevent the log file from filling up with
 * 			useless stack traces.
 * </ul>
 * <p>
 * If {@link RestServletProperties#ALLOW_HEADER_PARAMS} is enabled, HTTP headers can be passed as URL parameters (case insensitive).
 * <p>
 * If {@link RestServletProperties#ALLOW_METHOD_PARAM} is enabled, the HTTP method name can also be specified as a URL parameter.
 * <p>
 * If {@link RestServletProperties#ALLOW_CONTENT_PARAM} is enabled, the HTTP body content on PUT and POST methods can be passed in as a URL parameter.
 *
 *
 * <h6 class='topic'>OPTIONS pages</h6>
 *	<p>
 *		The {@link ResourceOptions} bean can be used to easily construct OPTIONs pages.
 *	<p>
 *		Typically, options pages can be defined like so:
 * </p>
 * <p class='bcode'>
 * 	<ja>@RestMethod</ja>(name=<js>"OPTIONS"</js>, path=<js>"/*"</js>)
 * 	<jk>public</jk> ResourceOptions doOptions(RestRequest req) {
 * 		<jk>return new</jk> ResourceOptions(<jk>this</jk>, req);
 * 	}
 * </p>
 *
 *
 * <h6 class='topic'>Logging</h6>
 * <p>
 * It's expected that your application handles it's own logging in it's own way.
 * To facilitate that, the following methods are provided for you to override and handle logging yourself:
 * <ul>
 * 	<li>{@link #onError(HttpServletRequest, HttpServletResponse, RestException, boolean)} - Called whenever a non-2xx status occurs during a request.
 * 	<li>{@link #onSuccess(RestRequest, RestResponse, long)} - Called whenever a request completes successfully.
 * </ul>
 *
 *
 * <h6 class='topic'>Request execution flow</h6>
 * <p>
 * 	The request execution flow attempts to make it as easy as possible to modify request settings
 * 		at various stages of execution.
 * <p>
 * 	Communication between the servlet, serializers, and parsers is possible through the modifiable
 * 	<code>properties</code> object, an {@link ObjectMap} that exists for the duration of the request.
 * <p>
 * 	By default, the <code>properties</code> object is loaded with values from {@link RestResource#properties()} (for servlet-level
 * 		properties) and {@link RestMethod#properties()} (for method-level properties).
 * 	This properties object (and request and response headers) can be modified at various steps of execution.
 * <p>
 * 	Here is the order of execution during a single request...
 * <ol>
 * 	<li>{@link RestServlet#service(HttpServletRequest, HttpServletResponse) service(request, response)} called.<br>
 * 		<code>properties</code> object constructed for request.<br>
 * 		<br>
 * 	<li>{@link RestResource#defaultRequestHeaders()} and {@link RestMethod#defaultRequestHeaders} added to {@link RestRequest}.<br>
 * 		<br>
 * 	<li>{@link RestResource#defaultResponseHeaders()} added to {@link RestResponse}.<br>
 * 		<br>
 * 	<li>{@link RestServlet#onPreCall(RestRequest, ObjectMap) onPreCall(request, properties)} called.<br>
 * 		Request headers and properties can be modified.<br>
 * 		<br>
 * 	<li>Parser found based on request <js>"Content-Type"</js> header.<br>
 * 		<br>
 * 	<li><code>ReaderParser.parse(Reader, ClassMeta, ParserContext)</code> called.<br>
 * 		Properties can be modified.<br>
 * 		<br>
 * 	<li>REST Java method invoked.<br>
 * 		Properties can be modified (accessed via {@link Properties} parameter or by calling {@link RestResponse#getProperties()}.<br>
 * 		<br>
 * 	<li>{@link RestServlet#onPostCall(RestRequest, RestResponse, ObjectMap) onPostCall(request, response, properties)} called.<br>
 * 		Request and response headers and properties can be modified.<br>
 * 		<br>
 * 	<li>Serializer found based on request <js>"Accept"</js> header.<br>
 * 		<br>
 * 	<li>{@link Serializer#getResponseHeaders(ObjectMap) Serializer.getResponseHeaders(properties)} called.<br>
 * 		Properties can be modified.<br>
 * 		Results added to response headers.<br>
 * 		<br>
 * 	<li>{@link Serializer#getResponseContentType() Serializer.getResponseContentType()} called.<br>
 * 		If not <jk>null</jk>, set as response <js>"Content-Type"</js> header.<br>
 * 		<br>
 * 	<li>{@link WriterSerializer#serialize(Object, Writer, SerializerContext) Serializer.serialize(object, out, ctx)} called.<br>
 * 		Properties can be modified.<br>
 * 		<br>
 *	</ol>
 *
 * <h6 class='topic'>Other Notes</h6>
 *	<ul>
 *		<li>Subclasses can use either {@link #init(ServletConfig)} or {@link #init()} for initialization
 *			just like any other servlet.
 *		<li>The {@link SerializerProperties#URI_CONTEXT} property is automatically set to the context root (e.g. <js>"/mycontextroot"</js>) of the web application during servlet initialization.
 *			This value can be overridden through the {@link RestResource#properties()} or {@link RestMethod#properties()} annotations, or through {@link RestResponse#setProperty(String, Object)}.
 *		<li>The {@link SerializerProperties#URI_AUTHORITY} property is automatically set to the HTTP authority (e.g. <js>"https://myhost:9443"</js>) during each request.
 *			This value can be overridden through the {@link RestMethod#properties()} annotations, or through {@link RestResponse#setProperty(String, Object)}.
 *		<li>The <code>X-Response-Headers</code> header can be used to pass through header values into the response.
 *			The value should be a URL-encoded map of key-value pairs.
 *			For example, to add a <code>Refresh: 1</code> header to the response to auto-refresh a page, the following parameter
 *				can be specified:  <code>/sample?X-Response-Headers={Refresh=1}</code>
 *	</ul>
 *
 * @author jbognar
 */
@SuppressWarnings({"rawtypes"})
public abstract class RestServlet extends HttpServlet {

	// Map of HTTP method names (e.g. GET/PUT/...) to ResourceMethod implementations for it.  Populated during resource initialization.
	private final Map<String,ResourceMethod> restMethods = new LinkedHashMap<String,ResourceMethod>();

	// The list of all @RestMethod annotated methods in the order they appear in the class.
	private final List<SimpleMethod> javaRestMethods = new LinkedList<SimpleMethod>();

	// Child resources of this resource defined through getX() methods on this class.
	private final Map<String,RestServlet> childResources = new LinkedHashMap<String,RestServlet>();

	private RestServlet parentResource;

	private ServletConfig servletConfig;
	private volatile boolean isInitialized = false;
	private Exception initException;                       // Exception thrown by init() method (cached so it can be thrown on all subsequent requests).
	private Logger logger;
	private RestServletNls msgs;                           // NLS messages.

	private boolean renderResponseStackTraces, useStackTraceHashes;
	private Map<Integer,Integer> stackTraceHashes = new HashMap<Integer,Integer>();
	private String htDocsPrefix, htDocsBetwix;

	boolean allowHeaderParams, allowMethodParam, allowContentParam, trimTrailingRequestUriSlashes, pathInfoBlankForNull;

	private List<RestResource> restResourceAnnotationsChildFirst, restResourceAnnotationsParentFirst;

	@Override
	@SuppressWarnings("hiding")
	public synchronized void init(ServletConfig servletConfig) throws ServletException {
		try {
			if (isInitialized)
				return;
			this.servletConfig = servletConfig;

			// @RestResource annotations from bottom to top.
			restResourceAnnotationsChildFirst = ReflectionUtils.findAnnotations(RestResource.class, getClass());

			// @RestResource annotations from top to bottom.
			restResourceAnnotationsParentFirst = reverse(restResourceAnnotationsChildFirst);

			super.init(servletConfig);

			// Find resource resource bundle location.
			for (RestResource r : restResourceAnnotationsChildFirst)
				if (msgs == null && ! r.messages().isEmpty())
					msgs = new RestServletNls(this.getClass(), r.messages());
			if (msgs == null)
				msgs = new RestServletNls(this.getClass(), "");

			// Discover the @RestMethod methods available on the resource.
			List<String> methodsFound = new LinkedList<String>();   // Temporary to help debug transient duplicate method issue.
			for (java.lang.reflect.Method method : this.getClass().getMethods()) {
				if (method.isAnnotationPresent(RestMethod.class)) {
					RestMethod a = method.getAnnotation(RestMethod.class);
					methodsFound.add(method.getName() + "," + a.name() + "," + a.path());
					try {
						if (! Modifier.isPublic(method.getModifiers()))
							throw new RestServletException("@RestMethod method {0}.{1} must be defined as public.", this.getClass().getName(), method.getName());

						SimpleMethod sm = new SimpleMethod(method);
						javaRestMethods.add(sm);
						ResourceMethod rm = restMethods.get(sm.httpMethod);
						if (rm == null)
							restMethods.put(sm.httpMethod, sm);
						else if (rm instanceof MultiMethod)
							((MultiMethod)rm).addSimpleMethod(sm);
						else
							restMethods.put(sm.httpMethod, new MultiMethod((SimpleMethod)rm, sm));
					} catch (RestServletException e) {
						throw new RestServletException("Problem occurred trying to serialize methods on class {0}, methods={1}", this.getClass().getName(), JsonSerializer.DEFAULT_LAX.serialize(methodsFound)).setCause(e);
					}
				}
			}

			for (ResourceMethod m : restMethods.values())
				m.complete();

			// Discover the child resources.
			childResources.putAll(createChildrenMap());

			for (RestServlet child : childResources.values())
				child.init(servletConfig);

			ObjectMap p = getProperties();
			renderResponseStackTraces = p.getBoolean(RENDER_RESPONSE_STACK_TRACES, false);
			useStackTraceHashes = p.getBoolean(USE_STACK_TRACE_HASHES, true);

			allowHeaderParams = p.getBoolean(ALLOW_HEADER_PARAMS, true);
			allowMethodParam = p.getBoolean(ALLOW_METHOD_PARAM, true);
			allowContentParam = p.getBoolean(ALLOW_CONTENT_PARAM, true);
			trimTrailingRequestUriSlashes = p.getBoolean(TRIM_TRAILING_REQUEST_URI_SLASHES, true);
			pathInfoBlankForNull = p.getBoolean(PATH_INFO_BLANK_FOR_NULL, true);
			String htDocsFolder = trimSlashes(p.getString(HTDOCS_FOLDER, "htdocs"));
			htDocsPrefix = htDocsFolder + '/';
			htDocsBetwix = '/' + htDocsFolder + '/';

			// Make sure all lazy-loaded fields are loaded.
			// This prevents us from needing synchronized blocks in all those methods.
			getBeanContext();
			getSerializers();
			getParsers();
			getConverters();
			getEncoders();
			getFilters();
			getGuards();
			getMimetypesFileTypeMap();
			getUrlEncodingParser();
			getDefaultRequestHeaders();
			getDefaultResponseHeaders();

		} catch (ServletException e) {
			initException = e;
			throw e;
		} catch (Exception e) {
			initException = e;
			throw new ServletException(e);
		} catch (Throwable e) {
			initException = new Exception(e);
			throw new ServletException(e);
		} finally {
			isInitialized = true;
		}
	}

	/**
	 * Creates the child resources of this resource.
	 * <p>
	 * Default implementation calls {@link #createChildren()} and uses the {@link RestResource#path()} annotation
	 * 	on each child to identify the subpath for the resource which become the keys in this map.
	 * It then calls the {@link #setParent(RestServlet)} method on the child resource.
	 * <p>
	 * Subclasses can override this method to programatically create child resources
	 * 	without using the {@link RestResource#children()} annotation approach.
	 * When overridding this method, you are responsible for calling {@link #setParent(RestServlet)} on the
	 * 	child resources.
	 * @return The new mutable list of child resource instances.
	 * @throws Exception If an error occurred during servlet instantiation.
	 */
	protected Map<String,RestServlet> createChildrenMap() throws Exception {
		Map<String,RestServlet> m = new LinkedHashMap<String,RestServlet>();
		for (RestServlet r : createChildren()) {
			r.setParent(this);
			List<RestResource> rrc = ReflectionUtils.findAnnotations(RestResource.class, r.getClass());
			String path = "";
			for (RestResource rc : rrc) {
				path = rc.path();
				if (path.startsWith("/"))
					path = path.substring(1);
				if (! path.isEmpty())
					break;
			}
			if (path.isEmpty())
				throw new RestServletException("Child resource ''{0}'' does not define a ''@RestResource.path'' attribute.", r.getClass().getName());
			m.put(path, r);
		}
		return m;
	}

	/**
	 * Creates instances of child resources for this servlet.
	 * <p>
	 * Default implementation uses the {@link RestResource#children()} annotation to identify and
	 * 	instantiate children.
	 * <p>
	 * Subclasses can override this method to programatically create child resources
	 * 	without using the {@link RestResource#children()} annotation.
	 * @return The new mutable list of child resource instances.
	 * @throws Exception If an error occurred during servlet instantiation.
	 */
	protected List<RestServlet> createChildren() throws Exception {
		List<RestResource> rr = ReflectionUtils.findAnnotations(RestResource.class, getClass());
		if (rr.isEmpty())
			return Collections.emptyList();
		List<RestServlet> l = new LinkedList<RestServlet>();
		for (RestResource r : rr)
			for (Class<?> rsc : r.children())
				if (RestServlet.class.isAssignableFrom(rsc))
					l.add((RestServlet)rsc.newInstance());
		return l;
	}

	/**
	 * Sets the parent of this resource.
	 * @param parent The parent of this resource.
	 */
	protected void setParent(RestServlet parent) {
		this.parentResource = parent;
	}

	/**
	 * Returns the parent of this resource.
	 * @return The parent of this resource, or <jk>null</jk> if resource has no parent.
	 */
	public RestServlet getParent() {
		return this.parentResource;
	}

	private String[] parseHeader(String s) {
		int i = s.indexOf(':');
		if (i == -1)
			return null;
		String name = s.substring(0, i).trim().toLowerCase(Locale.ENGLISH);
		String val = s.substring(i+1).trim();
		return new String[]{name,val};
	}

	/**
	 * Creates a {@link RestRequest} object based on the specified incoming {@link HttpServletRequest} object.
	 * <p>
	 * 	Subclasses may choose to override this method to provide a specialized request object.
	 *
	 * @param req The request object from the {@link #service(HttpServletRequest, HttpServletResponse)} method.
	 * @return The wrapped request object.
	 * @throws ServletException If any errors occur trying to interpret the request.
	 */
	protected RestRequest createRequest(HttpServletRequest req) throws ServletException {
		return new RestRequest(this, req);
	}

	/**
	 * Creates a {@link RestResponse} object based on the specified incoming {@link HttpServletResponse} object
	 * 	 and the request returned by {@link #createRequest(HttpServletRequest)}.
	 * <p>
	 * 	Subclasses may choose to override this method to provide a specialized response object.
	 *
	 * @param req The request object returned by {@link #createRequest(HttpServletRequest)}.
	 * @param res The response object from the {@link #service(HttpServletRequest, HttpServletResponse)} method.
	 * @return The wrapped response object.
	 * @throws ServletException If any erros occur trying to interpret the request or response.
	 */
	protected RestResponse createResponse(RestRequest req, HttpServletResponse res) throws ServletException {
		return new RestResponse(this, req, res);
	}

	/**
	 * Returns whether this resource class can provide an OPTIONS page.
	 * <p>
	 * By default, returns <jk>true</jk>.
	 * <p>
	 * Subclasses can override this method to prevent the <code>options</code> link from showing up in the HTML serialized output.
	 *
	 * @return <jk>true</jk> if this resource has implemented the {@code doOptions()} method.
	 */
	public boolean hasOptionsPage() {
		return true;
	}

	/**
	 * Specify a class-level property.
	 * <p>
	 * Typically, properties in {@link RestServletProperties} can be set in the {@link Servlet#init(ServletConfig)} method.
	 *
	 * @param key The property name.
	 * @param value The property value.
	 * @return This object (for method chaining).
	 */
	public synchronized RestServlet setProperty(String key, Object value) {
		getProperties().put(key, value);
		return this;
	}

	/**
	 * The main service method.
	 * <p>
	 * 	Subclasses can optionally override this method if they want to tailor the behavior of requests.
	 */
	@Override
	public void service(HttpServletRequest r1, HttpServletResponse r2) throws ServletException, IOException {

		long startTime = System.currentTimeMillis();

		try {

			if (initException != null)
				throw new RestException(SC_INTERNAL_SERVER_ERROR, initException);

			if (! isInitialized)
				throw new RestException(SC_INTERNAL_SERVER_ERROR, "Servlet has not been initialized");

			String pathInfo = getUndecodedPathInfo(r1);  // Can't use r1.getPathInfo() because we don't want '%2F' resolved.
			if (pathInfo == null)
				pathInfo = "";
			if (pathInfo.startsWith("/"))
				pathInfo = pathInfo.substring(1);
			if (trimTrailingRequestUriSlashes)
				pathInfo = trimTrailingSlashes(pathInfo);

			// If this resource has child resources, try to recursively call them.
			if (! (childResources.isEmpty() && ! pathInfo.isEmpty())) {
				int i = pathInfo.indexOf('/');
				String pathInfoPart = i == -1 ? pathInfo : pathInfo.substring(0, i);
				RestServlet childResource = childResources.get(pathInfoPart);
				if (childResource != null) {
					final String pathInfoRemainder = decode(i == -1 ? pathInfo : pathInfo.substring(0, i));
					final String servletPath = r1.getServletPath() + "/" + pathInfoPart;
					final HttpServletRequest childRequest = new HttpServletRequestWrapper(r1) {
						@Override
						public String getPathInfo() {
							return pathInfoRemainder;
						}
						@Override
						public String getServletPath() {
							return servletPath;
						}
					};
					childResource.service(childRequest, r2);
					return;
				}
			}

			// See if this is a request for '/htdocs/juno.css' or '/htdocs/javadoc.css'
			// If so, handle it special.
			if (pathInfo.startsWith(htDocsPrefix) || pathInfo.contains(htDocsBetwix)) {
				if (serviceHtDocs(pathInfo, r2))
					return;
			}

			RestServlet resource = this;
			RestRequest req = null;
			RestResponse res = null;

			req = createRequest(r1);
			res = createResponse(req, r2);

			String method = req.getMethod();
			String methodUC = method.toUpperCase();

			// Class-level guards
			for (RestGuard guard : getGuards())
				guard.guard(req, res);

			// If the specified method has been defined in a subclass, invoke it.
			int rc = SC_METHOD_NOT_ALLOWED;
			if (resource.restMethods.containsKey(methodUC)) {
				rc = resource.restMethods.get(methodUC).invoke(method, pathInfo, resource, req, res);
			} else if (resource.restMethods.containsKey("*")) {
				rc = resource.restMethods.get("*").invoke(method, pathInfo, resource, req, res);
			}

			// If not invoked above, see if it's an OPTIONs request
			if (rc != SC_OK) {
				String onPath = pathInfo.isEmpty() ? "" : format(" on path '%s'", pathInfo);
				if (rc == SC_NOT_FOUND)
					throw new RestException(rc, "Method ''{0}'' not found on resource with matching pattern{1}.", methodUC, onPath);
				else if (rc == SC_PRECONDITION_FAILED)
					throw new RestException(rc, "Method ''{0}'' not found on resource{1} with matching matcher.", methodUC, onPath);
				else if (rc == SC_METHOD_NOT_ALLOWED)
					throw new RestException(rc, "Method ''{0}'' not found on resource.", methodUC);
				else
					throw new ServletException("Invalid method response: " + rc);
			}

			if (res.hasOutput()) {
				Object output = res.getOutput();

				// Do any class-level filtering.
				for (RestConverter converter : getConverters())
					output = converter.convert(this, req, output);

				res.setOutput(output);

				// Now serialize the output if there was any.
				// Some subclasses may write to the OutputStream or Writer directly.
				resource.serialize(req, res, output);
			}

			onSuccess(req, res, System.currentTimeMillis() - startTime);

		} catch (RestException e) {
			handleError(r1, r2, e);
		} catch (Throwable e) {
			handleError(r1, r2, new RestException(SC_INTERNAL_SERVER_ERROR, e));
		}
	}

	private synchronized void handleError(HttpServletRequest req, HttpServletResponse res, RestException e) throws IOException {
		Integer c = 1;
		if (useStackTraceHashes) {
			int h = e.hashCode();
			c = stackTraceHashes.get(h);
			if (c == null)
				c = 1;
			else
				c++;
			stackTraceHashes.put(h, c);
			e.setOccurrence(c);
		}
		String q = req.getQueryString();
		boolean noTrace = (q == null ? false : q.toLowerCase().indexOf("notrace") != -1);
		onError(req, res, e, noTrace);
		renderError(req, res, e);
	}

	/**
	 * Method for rendering response errors.
	 * <p>
	 * The default implementation renders a plain text English message, optionally with a stack trace
	 * if {@link RestServletProperties#RENDER_RESPONSE_STACK_TRACES} is enabled.
	 * <p>
	 * Subclasses can override this method to provide their own custom error response handling.
	 *
	 * @param req The servlet request.
	 * @param res The servlet response.
	 * @param e The exception that occurred.
	 * @throws IOException Can be thrown if a problem occurred trying to write to the output stream.
	 */
	protected void renderError(HttpServletRequest req, HttpServletResponse res, RestException e) throws IOException {

		int status = e.getStatus();
		res.setStatus(status);
		res.setContentType("text/plain");
		res.setHeader("Content-Encoding", "identity");
		PrintWriter w = null;
		try {
			w = res.getWriter();
		} catch (IllegalStateException e2) {
			w = new PrintWriter(new OutputStreamWriter(res.getOutputStream(), "UTF-8"));
		}
		String httpMessage = RestUtils.getHttpResponseText(status);
		if (httpMessage != null)
			w.append("HTTP ").append(String.valueOf(status)).append(": ").append(httpMessage).append("\n\n");
		if (renderResponseStackTraces)
			e.printStackTrace(w);
		else
			w.append(e.getFullStackMessage());
		w.flush();
		w.close();
	}

	/**
	 * Callback method for logging errors during HTTP requests.
	 * <p>
	 * Typically, subclasses will override this method and log errors themselves.
	 * <p>
	 * The default implementation simply logs errors to the <code>RestServlet</code> logger.
	 * <p>
	 * Here's a typical implementation showing how stack trace hashing can be used to reduce log file sizes...
	 * <p class='bcode'>
	 * 	<jk>protected void</jk> onError(HttpServletRequest req, HttpServletResponse res, RestException e, <jk>boolean</jk> noTrace) {
	 * 		String qs = req.getQueryString();
	 * 		String msg = <js>"HTTP "</js> + req.getMethod() + <js>" "</js> + e.getStatus() + <js>" "</js> + req.getRequestURI() + (qs == <jk>null</jk> ? <js>""</js> : <js>"?"</js> + qs);
	 * 		<jk>int</jk> c = e.getOccurrence();
	 *
	 * 		<jc>// USE_STACK_TRACE_HASHES is disabled, so we have to log the exception every time.</jc>
	 * 		<jk>if</jk> (c == 0)
	 * 			myLogger.log(Level.<jsf>WARNING</jsf>, <jsm>format</jsm>(<js>"[%s] %s"</js>, e.getStatus(), msg), e);
	 *
	 * 		<jc>// This is the first time we've countered this error, so log a stack trace
	 *			// unless ?noTrace was passed in as a URL parameter.</jc>
	 * 		<jk>else if</jk> (c == 1 && ! noTrace)
	 * 			myLogger.log(Level.<jsf>WARNING</jsf>, <jsm>format</jsm>(<js>"[%h.%s.%s] %s"</js>, e.hashCode(), e.getStatus(), c, msg), e);
	 *
	 * 		<jc>// This error occurred before.
	 *			// Only log the message, not the stack trace.</jc>
	 * 		<jk>else</jk>
	 * 			myLogger.log(Level.<jsf>WARNING</jsf>, <jsm>format</jsm>(<js>"[%h.%s.%s] %s, %s"</js>, e.hashCode(), e.getStatus(), c, msg, e.getLocalizedMessage()));
	 * 	}
	 * </p>
	 *
	 * @param req The servlet request object.
	 * @param res The servlet response object.
	 * @param e Exception indicating what error occurred.
	 * @param noTrace <jk>true</jk> if <code>&noTrace</code> was passed as a URL parameter.
	 * 	This indicates a request that a stack trace not be logged.
	 * 	Useful for JUnit testing when your testing error conditions and you don't want the log file filling up with
	 * 		noisy stack traces.
	 */
	protected void onError(HttpServletRequest req, HttpServletResponse res, RestException e, boolean noTrace) {
		String qs = req.getQueryString();
		String msg = "HTTP " + req.getMethod() + " " + e.getStatus() + " " + req.getRequestURI() + (qs == null ? "" : "?" + qs);
		int c = e.getOccurrence();
		Logger log = getLogger();
		if (c == 0)
			log.log(Level.WARNING, format("[%s] %s", e.getStatus(), msg), e);
		else if (c == 1 && ! noTrace)
			log.log(Level.WARNING, format("[%H.%s.%s] %s", e.hashCode(), e.getStatus(), c, msg), e);
		else
			log.log(Level.WARNING, format("[%H.%s.%s] %s, %s", e.hashCode(), e.getStatus(), c, msg, e.getLocalizedMessage()));
	}

	/**
	 * Callback method for listening for successful completion of requests.
	 * <p>
	 * Subclasses can override this method for gathering performance statistics.
	 * <p>
	 * The default implementation does nothing.
	 *
	 * @param req The HTTP request.
	 * @param res The HTTP response.
	 * @param time The time in milliseconds it took to process the request.
	 */
	protected void onSuccess(RestRequest req, RestResponse res, long time) {}

	/**
	 * Callback method that gets invoked right before the REST Java method is invoked.
	 * <p>
	 * Subclasses can override this method to override request headers or set request-duration properties
	 * 	before the Java method is invoked.
	 *
	 * @param req The HTTP servlet request object.
	 * @param requestProperties The request-duration properties preloaded with values from the following...
	 * 	<ol>
	 * 		<li>{@link RestResource#properties()}
	 * 		<li>{@link RestMethod#properties()}
	 * 	</ol>
	 * @throws RestException If any error occurs.
	 */
	protected void onPreCall(RestRequest req, ObjectMap requestProperties) throws RestException {}

	/**
	 * Callback method that gets invoked right after the REST Java method is invoked, but before
	 * 	the serializer is invoked.
	 * <p>
	 * Subclasses can override this method to override request and response headers, or
	 * 	set/override properties used by the serializer.
	 *
	 * @param req The HTTP servlet request object.
	 * @param res The HTTP servlet response object.
	 * @param requestProperties The request-duration properties.
	 * @throws RestException If any error occurs.
	 */
	protected void onPostCall(RestRequest req, RestResponse res, ObjectMap requestProperties) throws RestException {};

	/**
	 * The main method for serializing POJOs passed in through the {@link RestResponse#setOutput(Object)} method.
	 * <p>
	 * 	Subclasses may override this method if they wish to modify the way the output is rendered, or support
	 * 	other output formats.
	 */
	protected void serialize(RestRequest req, RestResponse res, Object output) throws IOException, RestException {

		if (output instanceof InputStream) {
			res.setHeader("content-type", res.getContentType());
			OutputStream os = res.getOutputStream();
			IOUtils.pipe((InputStream)output, os);
			os.close();

		} else if (output instanceof Reader) {
			Writer w = res.getWriter();
			IOUtils.pipe((Reader)output, w);
			w.close();

		// Otherwise, we're going to convert it using one of the registered serializers.
		} else {

			SerializerGroup g = res.serializerGroup;
			String accept = req.getHeader("accept", "").replace(' ', '+');
			String matchingAccept = g.findMatch(accept);
			if (matchingAccept != null) {
				Serializer r = g.getSerializer(matchingAccept);
				String contentType = r.getResponseContentType();
				if (contentType == null)
					contentType = res.getContentType();
				if (contentType == null)
					contentType = matchingAccept;
				res.setContentType(contentType);
				ObjectMap headers = r.getResponseHeaders(res.getProperties());
				if (headers != null)
					for (String key : headers.keySet())
						res.setHeader(key, headers.getString(key));

				try {
					ObjectMap p = res.getProperties();
					if (req.isPlainText())
						p.put(USE_INDENTATION, true);
					SerializerContext ctx = r.createContext(output, p, matchingAccept, res.getCharacterEncoding());
					if (r instanceof OutputStreamSerializer) {
						OutputStreamSerializer s2 = (OutputStreamSerializer)r;
						OutputStream os = res.getOutputStream();
						s2.serialize(output, os, ctx);
						os.close();
					} else {
						WriterSerializer s2 = (WriterSerializer)r;
						Writer w = res.getWriter();
						s2.serialize(output, w, ctx);
						w.close();
					}
				} catch (SerializeException e) {
					throw new RestException(SC_INTERNAL_SERVER_ERROR, e);
				}
			} else {
				throw new RestException(SC_NOT_ACCEPTABLE,
					"Unsupported media-type in request header ''Accept'': ''{0}''\n\tSupported media-types: {1}",
					req.getHeader("accept", "").replace(' ', '+'), g.getSupportedMediaTypes()
				);
			}
		}
	}

	@Override
	public ServletConfig getServletConfig() {
		return servletConfig;
	}

	// In-memory cache of images and stylesheets in the com.ibm.juno.server.htdocs package.
	private static Map<String,ByteArrayOutputStream> htDocsCache = new HashMap<String,ByteArrayOutputStream>();

	/**
	 * Handle .../htdocs/... requests (i.e. requests for juno.css and images).
	 */
	private boolean serviceHtDocs(String pathInfo, HttpServletResponse res) throws IOException {

		pathInfo = pathInfo.substring(pathInfo.indexOf(htDocsPrefix)+htDocsPrefix.length());

		ByteArrayOutputStream baos = htDocsCache.get(pathInfo);

		if (baos == null) {
			if (pathInfo.indexOf("..") != -1)
				throw new RestException(SC_NOT_FOUND, "File ''{0}'' not found on classpath.", pathInfo);
			InputStream is = getClass().getResourceAsStream(htDocsPrefix + pathInfo);
			if (is != null) {
				ByteArrayOutputStream baos2 = new ByteArrayOutputStream(0);
				IOUtils.pipe(is, baos2);
				htDocsCache.put(pathInfo, baos2);
				baos = baos2;
			} else {
				baos = getDefaultHtDocsDoc(pathInfo);
				htDocsCache.put(pathInfo, baos);
			}
		}

		if (baos.size() == 0)
			throw new RestException(SC_NOT_FOUND, "File ''{0}'' not found on classpath.", pathInfo);

		res.setHeader("Cache-Control", "max-age=86400, public");
		int i = pathInfo.lastIndexOf('/');
		String name = (i == -1 ? pathInfo : pathInfo.substring(0, i));
		String contentType = getMimetypesFileTypeMap().getContentType(name);
		res.setContentType(contentType);
		OutputStream os = res.getOutputStream();
		htDocsCache.get(pathInfo).writeTo(os);
		os.flush();
		return true;
	}


	private static Map<String,ByteArrayOutputStream> defaultHtDocsCache = new HashMap<String,ByteArrayOutputStream>();
	private static ByteArrayOutputStream getDefaultHtDocsDoc(String pathInfo) throws IOException {
		ByteArrayOutputStream baos = defaultHtDocsCache.get(pathInfo);
		if (baos != null)
			return baos;
		baos = new ByteArrayOutputStream();
		InputStream is = RestServlet.class.getResourceAsStream("htdocs/" + pathInfo);
		if (is != null)
			IOUtils.pipe(is, baos);
		defaultHtDocsCache.put(pathInfo, baos);
		return baos;
	}

	/**
	 * Returns a single-line description of this servlet.
	 * <p>
	 * Default implementation pulls the localized string from the <js>"ResourceDescription"</js> key
	 * 	in the <code>ResourceBundle</code> identified by the {@link RestResource#messages()} annotation.
	 * Subclasses can override this method to provide their own description.
	 * @param locale - The message locale.
	 */
	public String getDescription(Locale locale) {
		return getMessage(locale, "ResourceDescription");
	}

	/**
	 * Returns a list of valid {@code Accept} content types for this resource.
	 * <p>
	 * 	Typically used by subclasses during {@code OPTIONS} requests.
	 * <p>
	 * 	Subclasses can override or expand this list as they see fit.
	 *
	 * @return The list of valid {@code Accept} content types for this resource.
	 */
	public Collection<String> getSupportedAcceptTypes() throws RestServletException {
		return getSerializers().getSupportedMediaTypes();
	}

	/**
	 * Returns a list of valid {@code Content-Types} for input for this resource.
	 * <p>
	 * 	Typically used by subclasses during {@code OPTIONS} requests.
	 * <p>
	 * 	Subclasses can override or expand this list as they see fit.
	 *
	 * @return The list of valid {@code Content-Type} header values for this resource.
	 */
	public Collection<String> getSupportedContentTypes() throws RestServletException {
		return getParsers().getSupportedMediaTypes();
	}

	/**
	 * Returns localized descriptions of all REST methods defined on this class that the user of the current
	 * 	request is allowed to access.
	 * <p>
	 * 	Useful for OPTIONS pages.
	 * <p>
	 * 	This method does not cache results, since it's expected to be called infrequently.
	 *
	 * @param req The current request.
	 * @return Localized descriptions of all REST methods defined on this class.
	 */
	public Collection<MethodDescription> getMethodDescriptions(RestRequest req) throws RestServletException {
		List<MethodDescription> l = new LinkedList<MethodDescription>();
		Locale locale = req.getLocale();
		NlsClass cm = msgs.getNlsClass(locale);

		for (SimpleMethod sm : javaRestMethods)
			if (sm.isRequestAllowed(req))
				l.add(sm.getMethodDescription(cm.getMethod(sm.method.getName())));

		return l;
	}

	/**
	 * Returns the localized description of this REST resource.
	 * <p>
	 * 	Pulled from this classes resource bundle identified by the {@link RestResource#messages()} annotation.
	 * <p>
	 * 	Looks for the following keys in the resource bundle:
	 * <ol>
	 * 	<li><code>{ClassName}.ResourceDescription</code>
	 * 	<li><code>ResourceDescription</code>
	 *	</ol>
	 * <p>
	 * 	This method does not cache results, since it's expected to be called infrequently.
	 *
	 * @param locale The client locale.
	 * @return The localized description of this REST resource, or <jk>null</jk> if no resource description was found.
	 */
	public String getResourceDescription(Locale locale) {
		return msgs.getNlsClass(locale).getDescription();
	}

	/**
	 * Gets a localized message from the resource bundle identified by the {@link RestResource#messages()} annotation.
	 * <p>
	 * 	If resource bundle location was not specified, or the resource bundle was not found,
	 * 	returns the string "{!!key}".
	 * <p>
	 * 	If message was not found in the resource bundle, returns the string "{!key}".
	 * @param locale The client locale.
	 * @param key The resource bundle key.
	 * @param args Optional {@link java.text.MessageFormat} variable values to replace.
	 * @return The localized message.
	 */
	public String getMessage(Locale locale, String key, Object...args) {
		return msgs.getMessage(locale, key, args);
	}

	/**
	 * Returns the resource bundle identified by the {@link RestResource#messages()} annotation for the specified locale.
	 * @param locale The resource bundle locale.
	 * @return The resource bundle.  Never <jk>null</jk>.
	 */
	public SafeResourceBundle getResourceBundle(Locale locale) {
		return msgs.getBundle(locale);
	}

	/**
	 * Programmatically adds the specified resource as a child to this resource.
	 * <p>
	 * 	This method can be used in a resources {@link #init()} method to define child resources
	 * 	accessible through a child URL.
	 * <p>
	 * 	Typically, child methods are defined via {@link RestResource#children()}.  However, this
	 * 	method is provided to handle child resources determined at runtime.
	 *
	 * @param name The sub-URL under which this resource is accessible.<br>
	 * 	For example, if the parent resource URL is <js>"/foo"</js>, and this name is <js>"bar"</js>, then
	 * 	the child resource will be accessible via the URL <js>"/foo/bar"</js>.
	 * @param resource The child resource.
	 * @throws ServletException Thrown by the child init() method.
	 */
	public void addChildResource(String name, RestServlet resource) throws ServletException {
		resource.init(getServletConfig());
		childResources.put(name, resource);
	}

	/**
	 * Returns the child resources associated with this servlet.
	 * @return An unmodifiable map of child resources.
	 * 	Keys are the {@link RestResource#path()} annotation defined on the child resource.
	 */
	public Map<String,RestServlet> getChildResources() {
		return Collections.unmodifiableMap(childResources);
	}

	/**
	 * Returns the logger associated with this servlet.
	 * <p>
	 * Subclasses can override this method to provide their own logger.
	 * @return The logger associated with this servlet.
	 */
	public Logger getLogger() {
		if (logger == null)
			logger =  Logger.getLogger(getClass().getName());
		return logger;
	}

	private abstract class ResourceMethod {
		abstract int invoke(String methodName, String pathInfo, RestServlet resource, RestRequest req, RestResponse res) throws RestException;

		void complete() {
			// Do nothing by default.
		}
	}

	@SuppressWarnings("hiding")
	static enum ParamType {
		REQ, RES, ATTR, CONTENT, HEADER, METHOD, PARAM, HASPARAM, REMAINDER, PROPERTIES, MESSAGES
	}

	static class MethodParam {

		ParamType paramType;
		Class<?> classMeta;
		String name = "";

		MethodParam(Class<?> classMeta, Annotation[] annotations) throws ServletException {
			this.classMeta = classMeta;
			if (HttpServletRequest.class.isAssignableFrom(classMeta))
				paramType = ParamType.REQ;
			else if (HttpServletResponse.class.isAssignableFrom(classMeta))
				paramType = ParamType.RES;
			else for (Annotation a : annotations) {
				if (a instanceof Attr) {
					paramType = ParamType.ATTR;
					name = ((Attr)a).value();
				} else if (a instanceof Header) {
					paramType = ParamType.HEADER;
					name = ((Header)a).value();
				} else if (a instanceof Param) {
					paramType = ParamType.PARAM;
					name = ((Param)a).value();
				} else if (a instanceof HasParam) {
					paramType = ParamType.HASPARAM;
					name = ((HasParam)a).value();
				} else if (a instanceof Content) {
					paramType = ParamType.CONTENT;
					name = "CONTENT";
				} else if (a instanceof com.ibm.juno.server.annotation.Method) {
					paramType = ParamType.METHOD;
					if (classMeta != String.class)
						throw new ServletException("@Method parameters must be of type String");
				} else if (a instanceof Remainder) {
					paramType = ParamType.REMAINDER;
					if (classMeta != String.class)
						throw new ServletException("@Remainder parameters must be of type String");
				} else if (a instanceof Properties) {
					paramType = ParamType.PROPERTIES;
					name = "PROPERTIES";
				} else if (a instanceof Messages) {
					paramType = ParamType.MESSAGES;
					name = "MESSAGES";
				}
			}
			if (paramType == null)
				paramType = ParamType.ATTR;
		}

		private Object getValue(RestRequest req, RestResponse res) throws Exception {
			switch(paramType) {
				case REQ:        return req;
				case RES:        return res;
				case ATTR:       return req.getAttribute(classMeta, name);
				case CONTENT:    return req.getInput(classMeta);
				case HEADER:     return req.getHeader(classMeta, name);
				case METHOD:     return req.getMethod();
				case PARAM:      return req.getParameter(classMeta, name);
				case HASPARAM:   return req.getServlet().getBeanContext().convertToType(req.hasParameter(name), classMeta);
				case REMAINDER:  return req.getRemainder();
				case PROPERTIES: return res.getProperties();
				case MESSAGES:   return req.getResourceBundle();
			}
			return null;
		}
	}

	/**
	 * Add default per-request properties.
	 * <p>
	 * Subclasses can override this method to add their own properties programatically.
	 *
	 * @param p The properties to add to.
	 * @param req The HTTP servlet request.
	 */
	public void addDefaultProperties(ObjectMap p, RestRequest req) {
		if (! p.containsKey(URI_AUTHORITY)) {
			int serverPort = req.getServerPort();
			String serverName = req.getServerName();
			p.put(URI_AUTHORITY, req.getScheme() + "://" + serverName + (serverPort == 80 || serverPort == 443 ? "" : ":" + serverPort));
		}
		p.put(URI_SERVLET_PATH, req.getServletPath());
		p.put(URI_PATH_INFO, req.getPathInfo());
		p.put(URI_REQUEST, req.getRequestURI());
		p.put(METHOD, req.getMethod());
	}

	/*
	 * Represents a single Java servlet method annotated with @RestMethod.
	 */
	@SuppressWarnings("hiding")
	private class SimpleMethod extends ResourceMethod implements Comparable<SimpleMethod>  {
		private String httpMethod;
		private java.lang.reflect.Method method;
		private UrlPathPattern pathPattern;
		private MethodParam[] params;
		private RestGuard[] guards;
		private RestMatcher[] matchers;
		private RestConverter[] mConverters;
		private SerializerGroup mSerializers;            // Method-level serializers
		private ParserGroup mParsers;                    // Method-level parsers
		private ObjectMap mProperties;                   // Method-level properties
		private ObjectMap mDefaultRequestHeaders;        // Method-level default request headers

		private SimpleMethod(java.lang.reflect.Method method) throws RestServletException {
			try {
				this.method = method;

				RestMethod m = method.getAnnotation(RestMethod.class);
				if (m == null)
					throw new RestServletException("@RestMethod annotation not found on method ''{0}.{1}''", method.getDeclaringClass().getName(), method.getName());

				this.mSerializers = getSerializers();
				this.mParsers = getParsers();
				this.mProperties = getProperties();

				ArrayList<Inherit> si = new ArrayList<Inherit>(Arrays.asList(m.serializersInherit()));
				ArrayList<Inherit> pi = new ArrayList<Inherit>(Arrays.asList(m.parsersInherit()));

				if (m.serializers().length > 0 || m.parsers().length > 0 || m.properties().length > 0 || m.filters().length > 0) {
					mSerializers = (si.contains(SERIALIZERS) || m.serializers().length == 0 ? mSerializers.clone() : new SerializerGroup());
					mParsers = (pi.contains(PARSERS) || m.parsers().length == 0 ? mParsers.clone() : new ParserGroup());
				}

				httpMethod = m.name().toUpperCase();
				if (httpMethod.equals("") && method.getName().startsWith("do"))
					httpMethod = method.getName().substring(2).toUpperCase();
				if (httpMethod.equals(""))
					throw new RestServletException("@RestMethod name not specified on method ''{0}.{1}''", method.getDeclaringClass().getName(), method.getName());
				if (httpMethod.equals("METHOD"))
					httpMethod = "*";

				String p = m.path();
				mConverters = new RestConverter[m.converters().length];
				for (int i = 0; i < mConverters.length; i++)
					mConverters[i] = m.converters()[i].newInstance();

				guards = new RestGuard[m.guards().length];
				for (int i = 0; i < guards.length; i++)
					guards[i] = m.guards()[i].newInstance();

				matchers = new RestMatcher[m.matchers().length];
				for (int i = 0; i < matchers.length; i++)
					matchers[i] = m.matchers()[i].newInstance();

				if (m.serializers().length > 0) {
					mSerializers.append(m.serializers());
					if (si.contains(FILTERS))
						mSerializers.addFilters(getFilters());
					if (si.contains(PROPERTIES))
						mSerializers.setProperties(getProperties());
				}

				if (m.parsers().length > 0) {
					mParsers.append(m.parsers());
					if (pi.contains(FILTERS))
						mParsers.addFilters(getFilters());
					if (pi.contains(PROPERTIES))
						mParsers.setProperties(getProperties());
				}

				if (m.properties().length > 0) {
					mProperties = new ObjectMap().setInner(getProperties());
					for (Property p1 : m.properties()) {
						String n = p1.name(), v = p1.value();
						mProperties.put(n, v);
						mSerializers.setProperty(n, v);
						mParsers.setProperty(n, v);
					}
				}

				if (m.filters().length > 0) {
					mSerializers.addFilters(m.filters());
					mParsers.addFilters(m.filters());
				}

				mDefaultRequestHeaders = new ObjectMap();
				for (String s : m.defaultRequestHeaders()) {
					String[] h = parseHeader(s);
					if (h == null)
						throw new RestServletException("Invalid default request header specified: ''{0}''.  Must be in the format: ''Header-Name: header-value''", s);
					mDefaultRequestHeaders.append(h[0], h[1]);
				}

				pathPattern = new UrlPathPattern(p);

				int attrIdx = 0;
				Class<?>[] pt = method.getParameterTypes();
				Annotation[][] pa = method.getParameterAnnotations();
				params = new MethodParam[pt.length];
				for (int i = 0; i < params.length; i++) {
					params[i] = new MethodParam(pt[i], pa[i]);
					if (params[i].paramType == ParamType.ATTR && params[i].name.isEmpty()) {
						if (pathPattern.vars.length <= attrIdx)
							throw new RestServletException("Number of attribute parameters in method ''{0}'' exceeds the number of URL pattern variables.", method.getName());
						params[i].name = pathPattern.vars[attrIdx++];
					}
				}

				mSerializers.lock();
				mParsers.lock();

				// Need this to access methods in anonymous inner classes.
				method.setAccessible(true);
			} catch (Exception e) {
				throw new RestServletException("Exception occurred while initializing method ''{0}''", method.getName()).setCause(e);
			}
		}

		private MethodDescription getMethodDescription(NlsMethod nlsMethod) throws RestServletException {
			String javaMethod = method.getName();
			String desc = nlsMethod.getDescription();
			MethodDescription d = new MethodDescription(javaMethod, httpMethod, pathPattern.patternString, desc);

			if (method.getReturnType() != Void.TYPE)
				d.setResponseContent(method.getReturnType().getSimpleName());

			if (method.isAnnotationPresent(RestMethod.class)) {
				RestMethod rm = method.getAnnotation(RestMethod.class);
				d.setConverters(rm.converters());
				d.setGuards(rm.guards());
				d.setMatchers(rm.matchers());
				if (mParsers != getParsers())
					d.setAccept(mParsers.getSupportedMediaTypes());
				if (mSerializers != getSerializers())
					d.setContentType(mSerializers.getSupportedMediaTypes());
				if (mProperties != getProperties())
					d.setProperties(mProperties);

				// URL variable descriptions
				for (MethodParam p : params) {
					switch(p.paramType) {
						case ATTR:
						case HEADER:
						case PARAM:
						case CONTENT:
							String cat = p.paramType.name().toLowerCase();
							NlsVar v = nlsMethod.getRequestVar(cat, p.name);
							Var v2 = d.addRequestVar(cat, p.name);
							v2.classMeta = p.classMeta.getSimpleName();
							if (v != null)
								v2.description = v.description;
							break;
						default:
					}
				}

				for (NlsVar v : nlsMethod.requestVars)
					d.addRequestVar(v.category, v.name).description = v.description;

				for (int rc : rm.rc())
					d.addResponse(rc);

				for (NlsResponse rcm : nlsMethod.getResponses()) {
					Response res = d.addResponse(rcm.httpStatus);
					if (rcm.description != null)
						res.description = rcm.description;
					for (NlsVar v : rcm.responseVars) {
						Var v2 = res.addResponseVar(v.category, v.name);
						v2.description = v.description;
					}
				}
			}

			return d;
		}

		private boolean isRequestAllowed(RestRequest req) {
			for (RestGuard guard : guards)
				if (! guard.isRequestAllowed(req))
					return false;
			return true;
		}

		@Override
		int invoke(String methodName, String pathInfo, RestServlet resource, RestRequest req, RestResponse res) throws RestException {

			String[] patternVals = pathPattern.match(pathInfo);
			if (patternVals == null)
				return SC_NOT_FOUND;

			if (patternVals.length > pathPattern.vars.length) {
				String remainder = patternVals[pathPattern.vars.length];
				if (remainder.startsWith("/"))
					remainder = remainder.substring(1);
				req.setRemainder(decode(remainder));
			}
			for (int i = 0; i < pathPattern.vars.length; i++)
				req.setAttribute(pathPattern.vars[i], patternVals[i]);

			// If the method implements matchers, test them.
			if (matchers.length > 0) {
				boolean matches = false;
				for (RestMatcher m : matchers)
					matches |= m.matches(req);
				if (! matches)
					return SC_PRECONDITION_FAILED;
			}

			req.addDefaultHeaders(mDefaultRequestHeaders);
			ObjectMap requestProperties = createRequestProperties(mProperties, req);
			addDefaultProperties(requestProperties, req);

			req.setProperties(requestProperties);
			res.setProperties(requestProperties);

			req.setParserGroup(mParsers);
			res.setSerializerGroup(mSerializers);

			onPreCall(req, requestProperties);

			Object[] args = new Object[params.length];
			for (int i = 0; i < params.length; i++) {
				try {
					args[i] = params[i].getValue(req, res);
				} catch (RestException e) {
					throw e;
				} catch (Exception e) {
					throw new RestException(SC_BAD_REQUEST,
						"Invalid data conversion.  Could not convert {0} ''{1}'' to type ''{2}'' on method ''{3}.{4}''.",
						params[i].paramType.name().toLowerCase(), params[i].name, params[i].classMeta, method.getDeclaringClass().getName(), method.getName()
					).setCause(e);
				}
			}

			try {

				for (RestGuard guard : guards)
					if (! guard.guard(req, res))
						return SC_OK;

				Object output = method.invoke(resource, args);
				if (! method.getReturnType().equals(Void.TYPE))
					res.setOutput(output);

				onPostCall(req, res, requestProperties);

				if (res.hasOutput()) {
					output = res.getOutput();
					for (RestConverter converter : mConverters)
						output = converter.convert(resource, req, output);
					res.setOutput(output);
				}
			} catch (IllegalArgumentException e) {
				throw new RestException(SC_INTERNAL_SERVER_ERROR,
					"Invalid argument type passed to the following method: ''{0}''.\n\tArgument types: {1}",
					method.toString(), ClassUtils.getReadableClassNames(args)
				);
			} catch (InvocationTargetException e) {
				Throwable e2 = e.getTargetException();		// Get the throwable thrown from the doX() method.
				if (e2 instanceof RestException)
					throw (RestException)e2;
				if (e2 instanceof ParseException)
					throw new RestException(SC_BAD_REQUEST, e2);
				if (e2 instanceof InvalidDataConversionException)
					throw new RestException(SC_BAD_REQUEST, e2);
				throw new RestException(SC_INTERNAL_SERVER_ERROR, e2);
			} catch (RestException e) {
				throw e;
			} catch (Exception e) {
				throw new RestException(SC_INTERNAL_SERVER_ERROR, e);
			}
			return SC_OK;
		}

		@Override
		public String toString() {
			return "SimpleMethod: name=" + httpMethod + ", path=" + pathPattern.patternString + ", matchers=" + matchers.length;
		}

		/*
		 * compareTo() method is used to keep SimpleMethods ordered in the MultiMethod.tempCache list.
		 * It maintains the order in which matches are made during requests.
		 */
		@Override
		public int compareTo(SimpleMethod o) {

			int c = pathPattern.compareTo(o.pathPattern);
			if (c != 0)
				return c;

			c = Integer.valueOf(o.matchers.length).compareTo(matchers.length);
			if (c != 0)
				return c;

			c = Integer.valueOf(o.guards.length).compareTo(guards.length);
			if (c != 0)
				return c;

			return 0;
		}

		@Override
		public boolean equals(Object o) {
			if (! (o instanceof SimpleMethod))
				return false;
			return (compareTo((SimpleMethod)o) == 0);
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}
	}

	/*
	 * Represents a group of SimpleMethods that all belong to the same HTTP method (e.g. "GET").
	 */
	private class MultiMethod extends ResourceMethod {
		SimpleMethod[] childMethods;
		List<SimpleMethod> tempCache = new LinkedList<SimpleMethod>();
		Set<String> collisions = new HashSet<String>();

		private MultiMethod(SimpleMethod... simpleMethods) throws RestServletException {
			for (SimpleMethod m : simpleMethods)
				addSimpleMethod(m);
		}

		private void addSimpleMethod(SimpleMethod m) throws RestServletException {
			if (m.guards.length == 0 && m.matchers.length == 0) {
				String p = m.httpMethod + ":" + m.pathPattern;
				if (collisions.contains(p))
					throw new RestServletException("Duplicate Java methods assigned to the same method/pattern:  method=''{0}'', path=''{1}''", m.httpMethod, m.pathPattern);
				collisions.add(p);
			}
			tempCache.add(m);
		}

		@Override
		void complete() {
			Collections.sort(tempCache);
			collisions = null;
			childMethods = tempCache.toArray(new SimpleMethod[tempCache.size()]);
		}

		@Override
		int invoke(String methodName, String pathInfo, RestServlet resource, RestRequest req, RestResponse res) throws RestException {
			int maxRc = 0;
			for (SimpleMethod m : childMethods) {
				int rc = m.invoke(methodName, pathInfo, resource, req, res);
				if (rc == SC_OK)
					return SC_OK;
				maxRc = Math.max(maxRc, rc);
			}
			return maxRc;
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder("MultiMethod: [\n");
			for (SimpleMethod sm : childMethods)
				sb.append("\t" + sm + "\n");
			sb.append("]");
			return sb.toString();
		}
	}

	private static class UrlPathPattern implements Comparable<UrlPathPattern> {
		private Pattern pattern;
		private String patternString;
		private boolean isDotAll;
		private String[] vars = new String[0];

		private UrlPathPattern(String patternString) {
			this.patternString = patternString;
			if (patternString.startsWith("/"))
				patternString = patternString.substring(1);
			if (patternString.equals("*")) {
				isDotAll = true;
				return;
			}

			// Find all {xxx} variables.
			Pattern p = Pattern.compile("\\{([^\\}]+)\\}");
			List<String> vl = new LinkedList<String>();
			Matcher m = p.matcher(patternString);
			while (m.find())
				vl.add(m.group(1));
			this.vars = vl.toArray(new String[vl.size()]);

			patternString = patternString.replaceAll("\\{[^\\}]+\\}", "([^\\/]+)");
			patternString = patternString.replaceAll("\\/\\*$", "((?:)|(?:\\/.*))");
			pattern = Pattern.compile(patternString);
		}

		private String[] match(String s) {

			if (isDotAll)
				return new String[]{s};

			Matcher m = pattern.matcher(s);
			if (! m.matches())
				return null;

			String[] v = new String[m.groupCount()];

			for (int i = 0; i < m.groupCount(); i++)
				v[i] = decode(m.group(i+1));

			return v;
		}

		@Override
		public int compareTo(UrlPathPattern o) {
			String s1 = patternString.replaceAll("\\{[^\\}]+\\}", ".").replaceAll("\\w+", "X");
			String s2 = o.patternString.replaceAll("\\{[^\\}]+\\}", ".").replaceAll("\\w+", "X");
			if (s1.isEmpty())
				s1 = "+";
			if (s2.isEmpty())
				s2 = "+";
			if (! s1.endsWith("/*"))
				s1 = s1 + "/W";
			if (! s2.endsWith("/*"))
				s2 = s2 + "/W";
			int c = s2.compareTo(s1);
			if (c == 0)
				return o.patternString.compareTo(patternString);
			return c;
		}

		@Override
		public boolean equals(Object o) {
			if (! (o instanceof UrlPathPattern))
				return false;
			return (compareTo((UrlPathPattern)o) == 0);
		}

		@Override
		public int hashCode() {
			return super.hashCode();
		}

		@Override
		public String toString() {
			return patternString;
		}
	}

	/**
	 * Creates a variable resolver for the specified request.
	 * <p>
	 * Variable resolvers are used to replace variables in property values.
	 * For example:
	 * <p class='bcode'>
	 *		<ja>@RestResource</ja>(
	 *			messages=<js>"nls/Messages"</js>,
	 *			properties={
	 *				<ja>@Property</ja>(name=<js>"label"</js>,value=<js>"$L{ResourceDescription}"</js>),  <jc>// Localized variable in Messages.properties</jc>
	 *				<ja>@Property</ja>(name=<js>"javaVendor"</js>,value=<js>"$S{java.vendor}"</js>),  <jc>// System property</jc>
	 *				<ja>@Property</ja>(name=<js>"foo"</js>,value=<js>"bar"</js>),
	 *				<ja>@Property</ja>(name=<js>"bar"</js>,value=<js>"baz"</js>),
	 *				<ja>@Property</ja>(name=<js>"v1"</js>,value=<js>"$R{foo}"</js>),  <jc>// Request variable. value="bar"</jc>
	 *				<ja>@Property</ja>(name=<js>"v2"</js>,value=<js>"$R{$R{foo}}"</js>)  <jc>// Nested request variable. value="baz"</jc>
	 *			}
	 *		)
	 * </p>
	 * <p>
	 * Calls to <code>req.getProperties().getString(<js>"key"</js>)</code> returns strings with variables resolved.
	 * <p>
	 * The following is the set of predefined variables:
	 * <ul>
	 * 	<li><code>$L{...}</code> - Localized messages (pulled from the class resource bundle).
	 * 	<li><code>$S{...}</code> - System properties.
	 * 	<li><code>$R{...}</code> - Other request variable values.
	 * </ul>
	 * <p>
	 * In addition, the <code>$R</code> variable can be used to access the following values:
	 * <ul>
	 * 	<li><code>$R{requestURI}</code> - Value returned by <code>req.getRequestURI();</code>
	 * 	<li><code>$R{requestParentURI}</code> - Value returned by <code>req.getRequestParentURI();</code>
	 * 	<li><code>$R{pathInfo}</code> - Value returned by <code>req.getPathInfo();</code>
	 * 	<li><code>$R{servletPath}</code> - Value returned by <code>req.getServletPath();</code>
	 * 	<li><code>$R{servletURI}</code> - Value returned by <code>req.getServletURI();</code>
	 * 	<li><code>$R{method}</code> - Value returned by <code>req.getMethod();</code>
	 * </ul>
	 * <p>
	 * Subclasses can override this method to provide their own replacement variables.
	 * Typically, subclasses will augment the existing variable resolver through a method such
	 * 	as the following:
	 * <p class='bcode'>
	 * 	<ja>@Override</ja>
	 * 	<jk>protected</jk> StringVarResolver getVarResolver(<jk>final</jk> RestRequest req) {
	 * 		<jk>return</jk> <jk>super</jk>.getVarResolver()
	 * 			.addVar(<js>"X"</js>, <jk>new</jk> StringVar()
	 * 				<ja>@Override</ja>
	 * 				<jk>public</jk> String resolve(String varVal) {
	 * 					<jk>return</jk> resolveMyVar(varVal);
	 * 				}
	 * 			);
	 * 	}
	 * </p>
	 * @param req The servlet request.
	 * @return A new var resolver.  Must not be null;
	 */
	public StringVarResolver createRequestVarResolver(final RestRequest req) {
		StringVarResolver r = new StringVarResolver();

		// System properties.
		r.addVar("S", sVar);

		// Localized string (pulled from resource bundle).
		r.addVar("L", new StringVar() {
			@Override
			public String resolve(String varVal) {
				return req.getMessage(varVal);
			}
		});

		// Request variables.
		r.addVar("R", new StringVar() {
			@Override
			public String resolve(String varVal) {
				if (varVal.length() > 0) {
					if (varVal.equals("requestURI"))
						return req.getRequestURI();
					if (varVal.equals("pathInfo"))
						return req.getPathInfo();
					if (varVal.equals("servletPath"))
						return req.getServletPath();
					if (varVal.equals("servletURI"))
						return req.getServletURI().toString();
					if (varVal.equals("method"))
						return req.getMethod();
					if (varVal.equals("requestParentURI"))
						return req.getRequestParentURI();
					Object o = req.getProperties().get(varVal);
					if (o != null)
						return o.toString();
				}
				return null;
			}
		});

		return r;
	}

	/**
	 * Creates a properties map for the specified request.
	 * This map will automatically resolve any <js>"$X{...}"</js> variables using the {@link StringVarResolver}
	 * 	returned by {@link #createRequestVarResolver(RestRequest)}.
	 *
	 * @param methodProperties The method-level properties.
	 * @param req The HTTP servlet request.
	 * @return The new object map for the request.
	 */
	protected ObjectMap createRequestProperties(final ObjectMap methodProperties, final RestRequest req) {
		final StringVarResolver varResolver = req.getVarResolver();
		ObjectMap m = new ObjectMap() {
			@Override
			public Object get(Object key) {
				Object o = super.get(key);
				if (o instanceof String)
					o = varResolver.resolve(o.toString());
				return o;
			}
		};
		m.setInner(methodProperties);
		return m;
	}

	/*
	 * Reusable system properties variable (e.g. "$S{java.vendor}")
	 */
	private static StringVar sVar = new StringVar() {
		@Override
		public String resolve(String varVal) {
			return System.getProperty(varVal);
		}
	};

	/**
	 * Returns the class-level properties associated with this servlet.
	 * <p>
	 * On first execution, calls {@link #createProperties()} to create the set of properties for this servlet.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * This set of properties can be added to by overridding {@link #getProperties()}
	 * 	and appending to the map returned by <code><jk>super</jk>.getProperties()</code>, or
	 * 	by calling {@link #setProperty(String, Object)}.
	 * <p>
	 * <b>Important note:</b>  The returned {@code Map} is mutable.  Therefore, subclasses are free to override
	 * or set additional initialization parameters in their {@code init()} method.
	 * <p>
	 * This method can be called from {@link HttpServlet#init(ServletConfig)} or {@link HttpServlet#init()}.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Old way of getting a boolean init parameter</jc>
	 * 	String s = getInitParam(<js>"allowMethodParam"</js>);
	 * 	if (s == <jk>null</jk>)
	 * 		s = <js>"false"</js>;
	 * 	<jk>boolean</jk> b = Boolean.parseBoolean(s);
	 *
	 * 	<jc>// New simplified way of getting a boolean init parameter</jc>
	 * 	<jk>boolean</jk> b = getProperties().getBoolean(<js>"allowMethodParam"</js>, <jk>false</jk>);
	 * </p>
	 *
	 * @return The resource properties as an {@link ObjectMap}.
	 */
	public ObjectMap getProperties() {
		if (properties == null)
			properties = createProperties();
		return properties;
	}
	private ObjectMap properties;

	/**
	 * Creates the class-level properties associated with this servlet.
	 * <p>
	 * Subclasses can override this method to provide their own class-level properties for this servlet, typically
	 * 	by calling <code><jk>super</jk>.createProperties()</code> and appending to the map.
	 * However, in most cases, the existing set of properties can be added to by overridding {@link #getProperties()}
	 * 	and appending to the map returned by <code><jk>super</jk>.getProperties()</code>
	 * <p>
	 * By default, the map returned by this method contains the following:
	 * <ul>
	 * 	<li>Servlet-init parameters.
	 * 	<li>{@link RestResource#properties()} annotations in parent-to-child order.
	 * 	<li>{@link SerializerProperties#URI_CONTEXT} from {@link ServletConfig#getServletContext()}.
	 * </ul>
	 *
	 * @return The resource properties as an {@link ObjectMap}.
	 */
	protected ObjectMap createProperties() {
		ObjectMap m = new ObjectMap();

		ServletContext ctx = servletConfig.getServletContext();
		m.put(URI_CONTEXT, ctx.getContextPath());

		// Get the initialization parameters.
		for (Enumeration ep = servletConfig.getInitParameterNames(); ep.hasMoreElements();) {
			String p = (String)ep.nextElement();
			String initParam = servletConfig.getInitParameter(p);
			m.put(p, initParam);
		}

		// Properties are loaded in parent-to-child order to allow overrides.
		for (RestResource r : restResourceAnnotationsParentFirst)
			for (Property p : r.properties())
				m.append(p.name(), p.value());

		return m;
	}

	/**
	 * Returns the class-level guards associated with this servlet.
	 * <p>
	 * On first execution, calls {@link #createGuards()} to create the set of guards.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createGuards()} to implement or append their own set of guards.
	 *
	 * @return The class-level guards associated with this servlet.
	 * @throws RestServletException If {@link #createGuards()} threw an exception.
	 */
	public RestGuard[] getGuards() throws RestServletException {
		if (guards == null)
			guards = createGuards();
		return guards;
	}
	private RestGuard[] guards;

	/**
	 * Creates the class-level guards associated with this servlet.
	 * <p>
	 * Subclasses can override this method to provide their own class-level guards for this servlet.
	 * <p>
	 * By default, returns the guards specified through the {@link RestResource#guards()} annotation in child-to-parent order.
	 * (i.e. guards on children will be called before guards on parents).
	 *
	 * @return The new set of guards associated with this servet.
	 */
	protected RestGuard[] createGuards() throws RestServletException {
		List<RestGuard> l = new LinkedList<RestGuard>();

		// Guards are loaded in child-to-parent order.
		for (RestResource r : restResourceAnnotationsChildFirst)
			for (Class<? extends RestGuard> c : reverse(r.guards()))
				try {
					l.add(c.newInstance());
				} catch (Exception e) {
					throw new RestServletException("Exception occurred while trying to instantiate RestGuard ''{0}''", c.getSimpleName()).setCause(e);
				}

		return l.toArray(new RestGuard[l.size()]);
	}

	/**
	 * Returns the class-level POJO filters associated with this servlet.
	 * <p>
	 * On first execution, calls {@link #createFilters()} to create the set of POJO filters.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createFilters()} to implement or append their own set of filters.
	 *
	 * @return The class-level guards associated with this servlet.
	 */
	public Class<?>[] getFilters() {
		if (filters == null)
			filters = createFilters();
		return filters;
	}
	private Class<?>[] filters;

	/**
	 * Creates the class-level POJO filters associated with this servlet.
	 * <p>
	 * Subclasses can override this method to provide their own class-level POJO filters for this servlet.
	 * <p>
	 * By default, returns the filters specified through the {@link RestResource#filters()} annotation in parent-to-child order.
	 * (i.e. filters will be applied in parent-to-child order with child annotations overriding parent annotations when
	 * 	the same filters are applied).
	 *
	 * @return The new set of filters associated with this servet.
	 */
	protected Class<?>[] createFilters() {
		List<Class<?>> l = new LinkedList<Class<?>>();

		// Filters are loaded in parent-to-child order to allow overrides.
		for (RestResource r : restResourceAnnotationsParentFirst)
			for (Class c : r.filters())
				l.add(c);

		return l.toArray(new Class<?>[l.size()]);
	}

	/**
	 * Returns the class-level converters associated with this servlet.
	 * <p>
	 * On first execution, calls {@link #createConverters()} to create the set of converters.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createConverters()} to implement or append their own set of converters.
	 *
	 * @return The class-level converters associated with this servlet.
	 */
	public RestConverter[] getConverters() throws RestServletException {
		if (converters == null)
			converters = createConverters();
		return converters;
	}
	private RestConverter[] converters;

	/**
	 * Creates the class-level converters associated with this servlet.
	 * <p>
	 * Subclasses can override this method to provide their own class-level converters for this servlet.
	 * <p>
	 * By default, returns the converters specified through the {@link RestResource#converters()} annotation in child-to-parent order.
	 * (e.g. converters on children will be called before converters on parents).
	 *
	 * @return The new set of filters associated with this servet.
	 */
	protected RestConverter[] createConverters() throws RestServletException {
		List<RestConverter> l = new LinkedList<RestConverter>();

		// Converters are loaded in child-to-parent order.
		for (RestResource r : restResourceAnnotationsChildFirst)
			for (Class<? extends RestConverter> c : r.converters())
				try {
					l.add(c.newInstance());
				} catch (Exception e) {
					throw new RestServletException("Exception occurred while trying to instantiate RestConverter ''{0}''", c.getSimpleName()).setCause(e);
				}

		return l.toArray(new RestConverter[l.size()]);
	}

	/**
	 * Returns the class-level default request headers associated with this servlet.
	 * <p>
	 * On first execution, calls {@link #createDefaultRequestHeaders()} to create the set of default request headers.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createDefaultRequestHeaders()} to implement or append their own set of default request headers.
	 *
	 * @return The class-level default request headers associated with this servlet.
	 */
	public ObjectMap getDefaultRequestHeaders() throws RestServletException {
		if (defaultRequestHeaders == null)
			defaultRequestHeaders = createDefaultRequestHeaders();
		return defaultRequestHeaders;
	}
	private ObjectMap defaultRequestHeaders;

	/**
	 * Creates the set of default request headers for this servlet.
	 * <p>
	 * Default request headers are default values for when HTTP requests do not specify a header value.
	 * For example, you can specify a default value for <code>Accept</code> if a request does not specify that header value.
	 * <p>
	 * Subclasses can override this method to provide their own class-level default request headers for this servlet.
	 * <p>
	 * By default, returns the default request headers specified through the {@link RestResource#defaultRequestHeaders()} annotation in parent-to-child order.
	 * (e.g. headers defined on children will override the same headers defined on parents).
	 *
	 * @return The new set of default request headers associated with this servet.
	 */
	protected ObjectMap createDefaultRequestHeaders() throws RestServletException {
		ObjectMap m = new ObjectMap();

		// Headers are loaded in parent-to-child order to allow overrides.
		for (RestResource r : restResourceAnnotationsParentFirst) {
			for (String s : r.defaultRequestHeaders()) {
				String[] h = parseHeader(s);
				if (h == null)
					throw new RestServletException("Invalid default request header specified: ''{0}''.  Must be in the format: ''Header-Name: header-value''", s);
				m.put(h[0], h[1]);
			}
		}

		return m;
	}

	/**
	 * Returns the class-level default response headers associated with this servlet.
	 * <p>
	 * On first execution, calls {@link #createDefaultResponseHeaders()} to create the set of default response headers.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createDefaultResponseHeaders()} to implement or append their own set of default response headers.
	 *
	 * @return The class-level default response headers associated with this servlet.
	 */
	public ObjectMap getDefaultResponseHeaders() throws RestServletException {
		if (defaultResponseHeaders == null)
			defaultResponseHeaders = createDefaultResponseHeaders();
		return defaultResponseHeaders;
	}
	private ObjectMap defaultResponseHeaders;

	/**
	 * Creates the set of default response headers for this servlet.
	 * <p>
	 * Default response headers are headers that will be appended to all responses if those headers have not already been
	 * 	set on the response object.
	 * <p>
	 * Subclasses can override this method to provide their own class-level default response headers for this servlet.
	 * <p>
	 * By default, returns the default response headers specified through the {@link RestResource#defaultResponseHeaders()} annotation in parent-to-child order.
	 * (e.g. headers defined on children will override the same headers defined on parents).
	 *
	 * @return The new set of default response headers associated with this servet.
	 */
	protected ObjectMap createDefaultResponseHeaders() throws RestServletException {
		ObjectMap m = new ObjectMap();

		// Headers are loaded in parent-to-child order to allow overrides.
		for (RestResource r : restResourceAnnotationsParentFirst) {
			for (String s : r.defaultResponseHeaders()) {
				String[] h = parseHeader(s);
				if (h == null)
					throw new RestServletException("Invalid default response header specified: ''{0}''.  Must be in the format: ''Header-Name: header-value''", s);
				m.put(h[0], h[1]);
			}
		}

		return m;
	}

	/**
	 * Returns the class-level encoder group associated with this servlet.
	 * <p>
	 * On first execution, calls {@link #createEncoders()} to create the group.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createEncoders()} to implement or append their own encoder group.
	 *
	 * @return The class-level encoder group associated with this servlet.
	 */
	public EncoderGroup getEncoders() throws RestServletException {
		if (encoders == null)
			encoders = createEncoders();
		return encoders;
	}
	private EncoderGroup encoders;

	/**
	 * Creates the {@link EncoderGroup} for this servlet for handling various encoding schemes.
	 * <p>
	 * Subclasses can override this method to provide their own encoder group, typically by
	 * 	appending to the group returned by <code><jk>super</jk>.createEncoders()</code>.
	 * <p>
	 * By default, returns a group containing {@link IdentityEncoder#INSTANCE} and all encoders
	 * 	specified through {@link RestResource#encoders()} annotations in parent-to-child order.
	 *
	 * @return The new encoder group associated with this servet.
	 */
	protected EncoderGroup createEncoders() throws RestServletException {
			EncoderGroup g = new EncoderGroup().append(IdentityEncoder.INSTANCE);

			// Encoders are loaded in parent-to-child order to allow overrides.
			for (RestResource r : restResourceAnnotationsParentFirst)
				for (Class<? extends Encoder> c : reverse(r.encoders()))
					try {
						g.append(c);
					} catch (Exception e) {
						throw new RestServletException("Exception occurred while trying to instantiate Encoder ''{0}''", c.getSimpleName()).setCause(e);
					}

			return g;
	}

	/**
	 * Returns the serializer group containing serializers used for serializing output POJOs in HTTP responses.
	 * <p>
	 * On first execution, calls {@link #createSerializers()} to create a new serializer group, then
	 * 	associates the class-level filters and properties with the group, then locks the group.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createSerializers()} to implement their own serializers.
	 * However, they can instead override this method if they want to prevent the class-level filters
	 * 	and properties from being applied to the group.
	 *
	 * @return The group of serializers.
	 * @throws RestServletException If {@link #createSerializers()} threw an exception.
	 */
	public SerializerGroup getSerializers() throws RestServletException {
		if (serializers == null)
			try {
				serializers = createSerializers().addFilters(getFilters()).setProperties(getProperties()).lock();
			} catch (Exception e) {
				throw new RestServletException("Exception occurred while trying to create serializers").setCause(e);
			}
		return serializers;
	}
	private SerializerGroup serializers;

	/**
	 * Creates the serializer group containing serializers used for serializing output POJOs in HTTP responses.
	 * <p>
	 * Subclasses can override this method to provide their own set of serializers for this servlet.
	 * They can do this by either creating a new {@link SerializerGroup} from scratch, or appending to the
	 * 	group returned by <code><jk>super</jk>.createSerializers()</code>.
	 * <p>
	 * By default, returns the serializers defined through {@link RestResource#serializers()} on this class
	 * 	and all parent classes.
	 * <p>
	 * The <code>SerializerGroup</code> (and contained <code>Serializers</code>) must be unlocked so that the
	 * 	filters and properties defined on this servlet can be associated with the group in the {@link #getSerializers()} method.
	 *
	 * @return The group of serializers.
	 * @throws Exception If serializer group could not be constructed for any reason.
	 */
	protected SerializerGroup createSerializers() throws Exception {
		SerializerGroup g = new SerializerGroup();

		// Serializers are loaded in parent-to-child order to allow overrides.
		for (RestResource r : restResourceAnnotationsParentFirst)
			for (Class<? extends Serializer<?>> c : reverse(r.serializers()))
				try {
					g.append(c);
				} catch (Exception e) {
					throw new RestServletException("Exception occurred while trying to instantiate Serializer ''{0}''", c.getSimpleName()).setCause(e);
				}

		return g;
	}

	/**
	 * Returns the parser group containing parsers used for parsing input into POJOs from HTTP requests.
	 * <p>
	 * On first execution, calls {@link #createParsers()} to create a new parser group, then
	 * 	associates the class-level filters and properties with the group, then locks the group.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createParsers()} to implement their own parsers.
	 * However, they can instead override this method if they want to prevent the class-level filters
	 * 	and properties from being applied to the group.
	 *
	 * @return The group of parsers.
	 * @throws RestServletException If {@link #createParsers()} threw an exception.
	 */
	public ParserGroup getParsers() throws RestServletException {
		if (parsers == null)
			try {
				parsers = createParsers().addFilters(getFilters()).setProperties(getProperties()).lock();
			} catch (Exception e) {
				throw new RestServletException("Exception occurred while trying to create parsers").setCause(e);
			}
		return parsers;
	}
	private ParserGroup parsers;

	/**
	 * Creates the parser group containing parsers used for parsing input into POJOs from HTTP requests.
	 * <p>
	 * Subclasses can override this method to provide their own set of parsers for this servlet.
	 * They can do this by either creating a new {@link ParserGroup} from scratch, or appending to the
	 * 	group returned by <code><jk>super</jk>.createParsers()</code>.
	 * <p>
	 * By default, returns the parsers defined through {@link RestResource#parsers()} on this class
	 * 	and all parent classes.
	 * <p>
	 * The <code>ParserGroup</code> (and contained <code>Parsers</code>) must be unlocked so that the
	 * 	filters and properties defined on this servlet can be associated with the group in the {@link #getParsers()} method.
	 *
	 * @return The group of parsers.
	 * @throws Exception If parser group could not be constructed for any reason.
	 */
	protected ParserGroup createParsers() throws Exception {
		ParserGroup g = new ParserGroup();

		// Parsers are loaded in parent-to-child order to allow overrides.
		for (RestResource r : restResourceAnnotationsParentFirst)
			for (Class<? extends Parser<?>> c : reverse(r.parsers()))
				try {
					g.append(c);
				} catch (Exception e) {
					throw new RestServletException("Exception occurred while trying to instantiate Parser ''{0}''", c.getSimpleName()).setCause(e);
				}

		return g;
	}

	/**
	 * Returns the URL-encoding parser used for parsing URL query parameters.
	 * <p>
	 * On first execution, calls {@link #createUrlEncodingParser()} to create a new parser, then
	 * 	associates the class-level filters and properties with the parser, then locks the parser.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createUrlEncodingParser()} to implement their own parser.
	 * However, they can instead override this method if they want to prevent the class-level filters
	 * 	and properties from being applied to the parser.
	 *
	 * @return The URL-Encoding parser to use for parsing URL query parameters.
	 * @throws RestServletException If {@link #createUrlEncodingParser()} threw an exception.
	 */
	public UrlEncodingParser getUrlEncodingParser() throws RestServletException {
		if (urlEncodingParser == null)
			try {
				urlEncodingParser = createUrlEncodingParser().addFilters(getFilters()).setProperties(getProperties()).lock();
			} catch (Exception e) {
				throw new RestServletException("Exception occurred while trying to instantiate URL-Encoding parser.").setCause(e);
			}
		return urlEncodingParser;
	}
	private UrlEncodingParser urlEncodingParser;

	/**
	 * Creates the URL-encoding parser used for parsing URL query parameters.
	 * <p>
	 * Subclasses can override this method to provide their own specialized parser.
	 * <p>
	 * By default, returns a default URL-Encoding parser from calling {@link UrlEncodingParser#UrlEncodingParser()}.
	 * <p>
	 * This parser must be unlocked so that the filters and properties defined on this servlet can be associated with it in the {@link #getUrlEncodingParser()} method.
	 *
	 * @return The new URL-Encoding parser.
	 * @throws Exception If the parser could not be constructed for any reason.
	 */
	protected UrlEncodingParser createUrlEncodingParser() throws Exception {
		return new UrlEncodingParser();
	}

	/**
	 * Returns the {@link MimetypesFileTypeMap}  that is used to determine the media types of files served up through <code>/htdocs</code>.
	 * <p>
	 * On first execution, calls {@link #createMimetypesFileTypeMap()} to create a new map.
	 * Subsequent calls returns the same cached copy from the first call.
	 *
	 * @return The reusable MIME-types map.
	 */
	public MimetypesFileTypeMap getMimetypesFileTypeMap() {
		if (mimetypesFileTypeMap == null)
			mimetypesFileTypeMap = createMimetypesFileTypeMap();
		return mimetypesFileTypeMap;
	}
	private MimetypesFileTypeMap mimetypesFileTypeMap;

	/**
	 * Creates an instance of {@link MimetypesFileTypeMap} that is used to determine
	 * 	the media types of files served up through <code>/htdocs</code>.
	 * <p>
	 * 	Subclasses can override this method to provide their own mappings, or augment the existing
	 * 	map by appending to <code><jk>super</jk>.createMimetypesFileTypeMap()</code>
	 *
	 * @return A new reusable MIME-types map.
	 */
	protected MimetypesFileTypeMap createMimetypesFileTypeMap() {
		MimetypesFileTypeMap m = new MimetypesFileTypeMap();
		m.addMimeTypes("text/css css CSS");
		return m;
	}

	/**
	 * Returns the bean context used for parsing path variables and header values.
	 * <p>
	 * On first execution, calls {@link #createBeanContext()} to create a new bean context, then
	 * 	associates the class-level filters and properties with it, then locks it.
	 * Subsequent calls returns the same cached copy from the first call.
	 * <p>
	 * Typically, subclasses override {@link #createBeanContext()} to implement their own specialized bean context.
	 *
	 * @return The bean context used for parsing path variables and header values.
	 * @throws RestException If {@link #createBeanContext()} threw an exception.
	 */
	public BeanContext getBeanContext() {
		if (beanContext == null)
			try {
				beanContext = createBeanContext().addFilters(getFilters()).setProperties(getProperties()).lock();
			} catch (Exception e) {
				throw new RestException(SC_INTERNAL_SERVER_ERROR, "Exception occurred while trying to instantiate Bean context.").setCause(e);
			}
		return beanContext;
	}
	private BeanContext beanContext;

	/**
	 * Creates the bean context used for parsing path variables and header values.
	 * <p>
	 * Subclasses can override this method to provide their own specialized bean context.
	 * They can do this by either creating a new {@link BeanContext} from scratch, or appending to the
	 * 	group returned by <code><jk>super</jk>.createBeanContext()</code>.
	 * <p>
	 * By default, returns a new bean context from calling {@link BeanContext#BeanContext()}.
	 * <p>
	 * The returned bean context must be unlocked so that the
	 * 	filters and properties defined on this servlet can be associated with it in the {@link #getBeanContext()} method.
	 *
	 * @return The new bean context.
	 * @throws Exception If bean context not be constructed for any reason.
	 */
	protected BeanContext createBeanContext() throws Exception {
		return new BeanContext();
	}

	private <T> List<T> reverse(List<T> in) {
		LinkedList<T> l = new LinkedList<T>();
		ListIterator<T> i = in.listIterator(in.size());
		while(i.hasPrevious())
			l.add(i.previous());
		return l;
	}

	private <T> List<T> reverse(T[] in) {
		LinkedList<T> l = new LinkedList<T>();
		for (int i = in.length - 1; i >= 0; i--)
			l.add(in[i]);
		return l;
	}

	private static String getUndecodedPathInfo(HttpServletRequest req) {
		return req.getRequestURI().substring(req.getContextPath().length() + req.getServletPath().length());
	}
}
