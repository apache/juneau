package com.ibm.juno.server.labels;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import com.ibm.juno.core.html.*;
import com.ibm.juno.core.utils.*;

/**
 * Simple bean that implements a hyperlink for the HTML serializer.
 * <p>
 * 	The name and url properties correspond to the following parts of a hyperlink in an HTML document...
 * <p class='bcode'>
 * 	<xt>&lt;a</xt> <xa>href</xa>=<xs>'href'</xs><xt>&gt;</xt>name<xt>&lt;/a&gt;</xt>
 * <p>
 *		When encountered by the {@link HtmlSerializer} class, this object gets converted to a hyperlink.<br>
 *		All other serializers simply convert it to a simple bean.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@HtmlLink(nameProperty = "name", hrefProperty = "href")
public class Link implements Comparable<Link> {
	private String name, href;

	/** No-arg constructor. */
	public Link() {}

	/**
	 * @param name Corresponds to the text inside of the <xt>&lt;A&gt;</xt> element.
	 * @param href Corresponds to the value of the <xa>href</xa> attribute of the <xt>&lt;A&gt;</xt> element.
	 */
	public Link(String name, String href) {
		this.name = name;
		this.href = href;
	}

	/**
	 * Returns the name field of this link that corresponds to the text inside of the <xt>&lt;A&gt;</xt> element.
	 *
	 * @return The name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets a new value for the name field of this label.
	 *
	 * @param name The new name.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns the value of the <xa>href</xa> attribute of the <xt>&lt;A&gt;</xt> element.
	 *
	 * @return The href attribute value.
	 */
	public String getHref() {
		return href;
	}

	/**
	 * Sets a new value for the <xa>href</xa> attribute in the <xt>&lt;A&gt;</xt> element.
	 *
	 * @param href The new href.
	 */
	public void setHref(String href) {
		this.href = href;
	}

	/**
	 * Returns the name so that the {@link PojoQuery} class can search against it.
	 */
	@Override
	public String toString() {
		return name;
	}

	@Override
	public int compareTo(Link o) {
		return name.compareTo(o.name);
	}

	@Override
	public boolean equals(Object o) {
		if (! (o instanceof Link))
			return false;
		return (compareTo((Link)o) == 0);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}
}
