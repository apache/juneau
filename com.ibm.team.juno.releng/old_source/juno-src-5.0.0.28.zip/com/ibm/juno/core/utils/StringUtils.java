package com.ibm.juno.core.utils;

import java.io.*;
import java.math.*;

import com.ibm.juno.core.parser.*;

/**
 * Reusable string utility methods.
 */
public class StringUtils {
	
	/**
	 * Parses a number from the specified reader stream.
	 *
	 * @param r The reader to parse the string from.
	 * @param type The number type to created. <br>
	 * 	Can be any of the following:
	 * 	<ul>
	 * 		<li> Integer
	 * 		<li> Double
	 * 		<li> Float
	 * 		<li> Long
	 * 		<li> Short
	 * 		<li> Byte
	 * 		<li> BigInteger
	 * 		<li> BigDecimal
	 * 	</ul>
	 *		If <jk>null</jk>, uses the best guess.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @return The parsed number.
	 */
	public static Number parseNumber(ParserReader r, Class<? extends Number> type) throws IOException, ParseException {
		boolean isInt=false;
		boolean isHex=false;
		boolean isDouble=false;
		r.mark();
		int c = r.read();
		boolean isNegative = false;
		if (c == '-') {
			isNegative = true;
			c = r.read();
		}
		if (c != '0')
			isInt = true;
		while (c != -1) {
			c = r.read();
			if (c == 'x' || c == 'X') {
				isHex = true;
			} else if (c == '.') {
				isDouble = true;
			} else if ((c >= '0' && c <= '9')
				|| (isHex && ((c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
				|| (isDouble && (c == 'e' || c == 'E'|| c == '+' || c == '-'))) {
				// Do nothing.
			} else if (c != -1) {
				// Reached the end.
				r.unread();
				break;
			}
		}

		String s = r.getFromMarked();

		return getNumber(s, isNegative, isHex, isInt, isDouble, type);
	}

	/**
	 * Parses a number from the specified string.
	 *
	 * @param s The string to parse the number from.
	 * @param type The number type to created. <br>
	 * 	Can be any of the following:
	 * 	<ul>
	 * 		<li> Integer
	 * 		<li> Double
	 * 		<li> Float
	 * 		<li> Long
	 * 		<li> Short
	 * 		<li> Byte
	 * 		<li> BigInteger
	 * 		<li> BigDecimal
	 * 	</ul>
	 *		If <jk>null</jk>, uses the best guess.
	 * @return The parsed number.
	 */
	public static Number parseNumber(String s, Class<? extends Number> type) throws ParseException {
		int i = 0;
		boolean isInt=false;
		boolean isHex=false;
		boolean isDouble=false;
		int c = s.charAt(i);
		boolean isNegative = false;
		if (c == '-') {
			isNegative = true;
			i++;
		}
		if (c != '0')
			isInt = true;
		int length = s.length();
		while (i < length) {
			c = s.charAt(i);
			if (c == 'x' || c == 'X') {
				isHex = true;
			} else if (c == '.') {
				isDouble = true;
			} else if ((c >= '0' && c <= '9')
				|| (isHex && ((c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
				|| (isDouble && (c == 'e' || c == 'E'|| c == '+' || c == '-'))) {
				// Do nothing.
			} else {
				break;
			}
			i++;
		}

		return getNumber(s, isNegative, isHex, isInt, isDouble, type);
	}

	/**
	 * Returns <jk>true</jk> if this string can be parsed by {@link #parseNumber(String, Class)}
	 */
	public static boolean isNumeric(String s) {
		int i = 0;
		boolean isHex=false;
		boolean isDouble=false;
		if (s == null || s.length() == 0)
			return false;
		int c = s.charAt(i);
		if (c == '-')
			i++;
		int length = s.length();
		while (i < length) {
			c = s.charAt(i);
			if (i == 0 && (c == 'x' || c == 'X')) {
				isHex = true;
			} else if (i > 0 && c == '.' && isDouble == false && isHex == false) {
				isDouble = true;
			} else if ((c >= '0' && c <= '9')
				|| (isHex && ((c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
				|| (isDouble && (c == 'e' || c == 'E'|| c == '+' || c == '-'))) {
				// Do nothing.
			} else {
				return false;
			}
			i++;
		}
		if (isHex && s.length() == 1)
			return false;
		return true;
	}

	private static Number getNumber(String s, boolean isNegative, boolean isHex, boolean isInt, boolean isDouble, Class<?> type) throws ParseException {

		try {
			// Determine the data type if it wasn't specified.
			if (type == null) {
				if (isDouble)
					type = Double.class;
				else {
					// It's either an Integer or Long
					int sLen = (isNegative ? s.length() - 1 : s.length());	// Length of number without minus sign.
					if (isHex) {
						sLen -= (isNegative ? 3 : 2);
						type = (sLen > 7 ? Long.class : Integer.class);
					} else if (isInt) {
						type = (sLen > 8 ? Long.class : Integer.class);
					} else /* Is octal */ {
						type = (sLen > 9 ? Long.class : Integer.class);
					}
				}
			}

			if (type == Double.class || type == Double.TYPE)
				return Double.valueOf(s);
			if (type == Float.class || type == Float.TYPE)
				return Float.valueOf(s);
			if (type == BigDecimal.class)
				return new BigDecimal(s);
			int base = 8;
			if (isHex) {
				s = (isNegative ? ('-' + s.substring(3)) : s.substring(2));	// Strip out 0x
				base = 16;
			}
			if (isInt)
				base = 10;
			if (type == Integer.class || type == Integer.TYPE)
				return Integer.valueOf(s, base);
			if (type == Long.class || type == Long.TYPE)
				return Long.valueOf(s, base);
			if (type == Short.class || type == Short.TYPE)
				return Short.valueOf(s, base);
			if (type == Byte.class || type == Byte.TYPE)
				return Byte.valueOf(s, base);
			if (type == BigInteger.class)
				return new BigInteger(s);
			return null;
		} catch (NumberFormatException e) {
			throw new ParseException("Could not convert string '%s' to class '%s'", s, (type == null ? null : type.getName()));
		}
	}
}
