package com.ibm.juno.core.filter;

import java.util.*;

import com.ibm.juno.core.*;

/**
 * Interface for filters that tailor metadata on bean classes.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Bean filters are associated with {@link BeanContext} instances to tailor the properties returned by the {@link BeanMap#entrySet()} method.
 * <p>
 * 	Note that {@link #getExcludeKeys()} and {@link #getIncludeKeys()} are mutually exclusive, so only one method should return a non-<jk>null</jk>.
 * 	If both methods return a non-<jk>null</jk>, the include keys will be ignored.
 *
 *
 * <h6 class='topic'>Additional information</h6>
 * 	See {@link com.ibm.juno.core.filter} for more information.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface IBeanFilter extends IFilter {

	/**
	 * Specifies the list of property names to explicitly include from the bean.
	 * <p>
	 * 	If <jk>null</jk> include all properties.
	 *
	 * @return The list of property names to include.
	 */
	public LinkedHashSet<String> getIncludeKeys();

	/**
	 * Specifies the list of property names to explicitly exclude from the bean.
	 * <p>
	 * 	If <jk>null</jk> don't exclude any properties.
	 *
	 * @return The list of property names to exclude.
	 */
	public LinkedHashSet<String> getExcludeKeys();
}
