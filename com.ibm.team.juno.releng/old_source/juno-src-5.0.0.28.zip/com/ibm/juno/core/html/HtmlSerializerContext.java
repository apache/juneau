package com.ibm.juno.core.html;

import static com.ibm.juno.core.html.HtmlSerializerProperties.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Context object that lives for the duration of a single serialization of {@link HtmlSerializer} and its subclasses.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlSerializerContext extends SerializerContext {

	private final String uriAnchorText;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param hsp Default HTML serializer properties.
	 * @param op Override properties.
	 */
	protected HtmlSerializerContext(BeanContext beanContext, SerializerProperties sp, HtmlSerializerProperties hsp, ObjectMap op, String matchingAccept) {
		super(beanContext, sp, op, matchingAccept, null);
		if (op == null || op.isEmpty()) {
			uriAnchorText = hsp.uriAnchorText;
		} else {
			uriAnchorText = op.getString(URI_ANCHOR_TEXT, hsp.uriAnchorText);
		}
	}

	/**
	 * Returns the {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} setting value in this context.
	 * @return The {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} setting value in this context.
	 */
	public final String getUriAnchorText() {
		return uriAnchorText;
	}
}
