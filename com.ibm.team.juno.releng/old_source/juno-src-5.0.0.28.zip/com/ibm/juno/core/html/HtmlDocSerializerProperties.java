package com.ibm.juno.core.html;

import com.ibm.juno.server.*;
import com.ibm.juno.server.annotation.*;


/**
 * Properties associated with the {@link HtmlDocSerializer} class.
 * <p>
 * 	These are typically specified via {@link RestResource#properties()} and {@link RestMethod#properties()} annotations,
 * 		although they can also be set programmatically via the {@link RestResponse#setProperty(String, Object)} method.
 *
 * <h6 class='topic'>Example</h6>
 * <p class='bcode'>
 * 	<ja>@RestResource</ja>(
 * 		messages=<js>"nls/AddressBookResource"</js>,
 * 		properties={
 * 			<ja>@Property</ja>(name=<jsf>HTML_TITLE</jsf>, value=<js>"title"</js>, type=<jsf>NLS</jsf>),
 * 			<ja>@Property</ja>(name=<jsf>HTML_DESCRIPTION</jsf>, value=<js>"description"</js>, type=<jsf>NLS</jsf>),
 * 			<ja>@Property</ja>(name=<jsf>HTML_LINKS</jsf>, value=<js>"{options:'?method=OPTIONS',doc:'doc'}"</js>)
 * 		}
 * 	)
 * 	<jk>public class</jk> AddressBookResource <jk>extends</jk> RestServletJenaDefault {
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlDocSerializerProperties {

	/**
	 * Adds a title at the top of a page.
	 *
	 * <h6 class='topic'>Example</h6>
	 * <p>
	 * 	The <code>AddressBookResource</code> sample class uses this property...
	 * </p>
	 * <p class='bcode'>
	 * 	<ja>@RestResource</ja>(
	 * 		messages=<js>"nls/AddressBookResource"</js>,
	 * 		properties={
	 * 			<ja>@Property</ja>(name=<jsf>HTML_TITLE</jsf>, value=<js>"title"</js>, type=<jsf>NLS</jsf>)
	 * 		}
	 * 	)
	 * 	<jk>public class</jk> AddressBookResource <jk>extends</jk> RestServletJenaDefault {
	 * </p>
	 * <p>
	 * 	...with this property in <code>AddressBookResource.properties</code>...
	 * </p>
	 * <p class='bcode'>
	 * 	title = <js>AddressBook sample resource</js>
	 * </p>
	 * <p>
	 * 	...to produce this title on the HTML page...
	 * </p>
	 * <img class='bordered' src='doc-files/HTML_TITLE.png'>
	 */
	public static final String HTML_TITLE = "HtmlSerializer.title";

	/**
	 * Adds a description right below the title of a page.
	 *
	 * <h6 class='topic'>Example</h6>
	 * <p>
	 * 	The <code>AddressBookResource</code> sample class uses this property...
	 * </p>
	 * <p class='bcode'>
	 * 	<ja>@RestResource</ja>(
	 * 		messages=<js>"nls/AddressBookResource"</js>,
	 * 		properties={
	 * 			<ja>@Property</ja>(name=<jsf>HTML_DESCRIPTION</jsf>, value=<js>"description"</js>, type=<jsf>NLS</jsf>)
	 * 		}
	 * 	)
	 * 	<jk>public class</jk> AddressBookResource <jk>extends</jk> RestServletJenaDefault {
	 * </p>
	 * <p>
	 * 	...with this property in <code>AddressBookResource.properties</code>...
	 * </p>
	 * <p class='bcode'>
	 * 	description = <js>Simple address book POJO sample resource</js>
	 * </p>
	 * <p>
	 * 	...to produce this description on the HTML page...
	 * </p>
	 * <img class='bordered' src='doc-files/HTML_DESCRIPTION.png'>
	 */
	public static final String HTML_DESCRIPTION = "HtmlSerializer.description";

	/**
	 * Adds a meta refresh tag to the HTML head.  Must be numeric.
	 *
	 * <h6 class='topic'>Example</h6>
	 * <p>
	 * 	The following resource will automatically refresh the page every 5 seconds.
	 * </p>
	 * <p class='bcode'>
	 * 	<ja>@RestResource</ja>(
	 * 		properties={
	 * 			<ja>@Property</ja>(name=<jsf>HTML_REFRESH</jsf>, value=5)
	 * 		}
	 * 	)
	 * 	<jk>public class</jk> MyResource <jk>extends</jk> RestServletDefault {
	 * </p>
	 */
	public static final String HTML_REFRESH = "HtmlSerializer.refresh";

	/**
	 * Adds a list of hyperlinks immediately under the title and description but above the content of the page.
	 * <p>
	 * 	This can be used to provide convenient hyperlinks when viewing the REST interface from a browser.
	 * <p>
	 * 	The value is a JSON object string where the keys are anchor text and the values are URLs.
	 * <p>
	 * 	Relative URLs are considered relative to the servlet path.
	 * 	For example, if the servlet path is <js>"http://localhost/myContext/myServlet"</js>, and the
	 * 		URL is <js>"foo"</js>, the link becomes <js>"http://localhost/myContext/myServlet/foo"</js>.
	 * 	Absolute (<js>"/myOtherContext/foo"</js>) and fully-qualified (<js>"http://localhost2/foo"</js>) URLs
	 * 		can also be used.
	 *
	 * <h6 class='topic'>Example</h6>
	 * <p>
	 * 	The <code>AddressBookResource</code> sample class uses this property...
	 * </p>
	 * <p class='bcode'>
	 * 	<ja>@RestResource</ja>(
	 * 		messages=<js>"nls/AddressBookResource"</js>,
	 * 		properties={
	 * 			<ja>@Property</ja>(name=<jsf>HTML_LINKS</jsf>, value=<js>"{options:'?method=OPTIONS',doc:'doc'}"</js>)
	 * 		}
	 * 	)
	 * 	<jk>public class</jk> AddressBookResource <jk>extends</jk> RestServletJenaDefault {
	 * </p>
	 * <p>
	 * 	...to produce this list of links on the HTML page...
	 * </p>
	 * <img class='bordered' src='doc-files/HTML_LINKS.png'>
	 */
	public static final String HTML_LINKS = "HtmlDocSerializer.links";

	/**
	 * Adds a link to the specified stylesheet URL.
	 * <p>
	 * 	If not specified, defaults to the built-in stylesheet located at <js>"/servletPath/htdocs/juno.css"</js>.
	 */
	public static final String HTML_CSS_URL = "HtmlDocSerializer.cssUrl";
}
