package com.ibm.juno.core.serializer;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;

/**
 * Subclass of {@link Serializer} for character-based serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all character-based serializers since it implements all
 * 	of the following interfaces...
 * <ul>
 * 	<li>{@link ISerializer}
 * 	<li>{@link ICoreApiSerializer}
 * 	<li>{@link IWriterSerializer}
 * </ul>
 * <p>
 * 	...and only has 3 remaining abstract methods to implement...
 * <ul>
 * 	<li>{@link #createContext(Object, ObjectMap, String, String)}
 * 	<li>{@link #createWriter(Writer, SerializerContext)}
 * 	<li>{@link #serialize(Object, Object, SerializerContext)}
 * </ul>
 *
 *
 * <h6 class='topic'>@Produces annotation</h6>
 * <p>
 * 	The media types that this serializer can produce is specified through the {@link Produces @Produces} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()}
 * 		and {@link #getResponseContentType()} methods.
 *
 * @param <W> The writer class type.
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class WriterSerializer<W extends Writer> extends Serializer<W> implements IWriterSerializer<W> {


	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	public abstract void serialize(Object o, W out, SerializerContext ctx) throws IOException, SerializeException;


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override
	public SerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) throws SerializeException {
		return super.createContext(o, properties, mediaType, charset);
	}

	@Override
	@SuppressWarnings("unchecked")
	public W createWriter(Writer w, SerializerContext ctx) {

		// Default implementation simply returns the original writer.
		return (W)w;
	}

	@Override // IWriterSerializer
	public String serialize(Object o, SerializerContext ctx) throws SerializeException {
		try {
			StringWriter w = new StringWriter();
			W writer = createWriter(w, ctx);
			serialize(o, writer, ctx);
			return w.toString();
		} catch (IOException e) { // Shouldn't happen.
			throw new RuntimeException(e);
		}
	}

	@Override // IWriterSerializer
	public String serialize(Object o) throws SerializeException {
		SerializerContext ctx = createContext(o, null, null, null);
		return serialize(o, ctx);
	}

	@Override // IWriterSerializer
	public void serialize(Object o, Writer w) throws SerializeException, IOException {
		SerializerContext ctx = createContext(o, null, null, null);
		W writer = createWriter(w, ctx);
		serialize(o, writer, ctx);
	}
}
