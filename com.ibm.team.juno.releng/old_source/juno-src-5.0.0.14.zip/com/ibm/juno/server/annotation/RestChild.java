package com.ibm.juno.server.annotation;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.*;

import java.lang.annotation.*;

import com.ibm.juno.server.*;

/**
 * Identifies a public getter method on a {@link RestServlet} that returns a REST child resource.
 * <p>
 * A REST child resource is simply another servlet that is initialized as part of the parent
 * 	resource and has a servlet path directly under the parent servlet path.
 * The main advantage to defining servlets as REST children is that you do not need
 * 	to define them in the <code>web.xml</code> file of the web application.
 * This can cut down on the number of entries that show up in the <code>web.xml</code> file
 * 	if you are defining large numbers of servlets.
 * <p>
 * The child resource servlet path is simply the 'name' of the child resource appended
 * 	to the parent's servlet path, as shown below:
 *
 * <h6 class='topic'>Example</h6>
 * <p class='bcode'>
 * 	<jc>// Child resource accessible under /parentServletPath/foo</jc>
 * 	<ja>@RestChild</ja>(name=<js>"foo"</js>)
 * 	<jk>public</jk> RestServlet getFooChildResource() <jk>throws</jk> Exception {
 * 		<jk>return new</jk> FooChildResource();
 * 	}
 * </p>
 * <p>
 *	It should be noted that servlets can be nested arbitrarily deep using this technique (i.e. children can also have children).
 * <p>
 * A child resource will often subclass {@link RestServletChild} so that it shares
 * 	the same resources as the parent resource (e.g. serializers, parsers, properties, etc...).
 * However, this is not a requirement.
 *
 * <h6 class='topic'>Servlet initialization</h6>
 * <p>
 *	A child resource will be initialized immediately after the parent servlet is initialized.  The child resource
 *		receives the same servlet config as the parent resource.  This allows configuration information such as
 *		servlet initialization parameters to filter to child resources.
 * <p>
 *
 * <h6 class='topic'>Runtime behavior</h6>
 * As a rule, methods defined on the <code>HttpServletRequest</code> object will behave as if
 * 	the child servlet were deployed as a top-level resource under the child's servlet path.
 * For example, the <code>getServletPath()</code> and <code>getPathInfo()</code> methods on the
 * 	<code>HttpServletRequest</code> object will behave as if the child resource were deployed
 * 	using the child's servlet path.
 * Therefore, the runtime behavior should be equivalent to deploying the child servlet in
 * 	the <code>web.xml</code> file of the web application.
 *
 * <h6 class='topic'>Child resource getter methods</h6>
 * Java methods in the {@link RestServlet} class identified as REST child methods must have the following attributes:
 * 	<ul>
 * 		<li>Must be public.
 * 		<li>Must have no arguments.
 * 		<li>Must return an instance of {@link RestServlet}.
 * 		<li>Can throw any exception.
 * 	</ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Documented
@Target(METHOD)
@Retention(RUNTIME)
@Inherited
public @interface RestChild {

	/**
	 * REST child name.
	 * <p>
	 * 	Typically <js>"GET"</js>, <js>"PUT"</js>, <js>"POST"</js>, <js>"DELETE"</js>, or <js>"OPTIONS"</js>.
	 * <p>
	 * 	Can also be a non-HTTP-standard name that is passed in through a <code>&amp;method=methodName</code> URL parameter.
	 * <p>
	 * 	If a child name is not specified, then the child name is determined based on the Java method name.<br>
	 * 	For example, if the method is <code>getMyChild(...)</code>, then the child name is automatically detected as <js>"myChild"</js>.

	 */
	String name() default "";
}
