package com.ibm.juno.core.serializer;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Subclass of {@link Serializer} for byte-based serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all byte-based serializers since it implements all
 * 	of the following interfaces...
 * <ul>
 * 	<li>{@link ISerializer}
 * 	<li>{@link ICoreApiSerializer}
 * 	<li>{@link IOutputStreamSerializer}
 * </ul>
 * <p>
 * 	...and only has 2 remaining abstract methods to implement...
 * <ul>
 * 	<li>{@link #getMediaTypes()}
 * 	<li>{@link #serialize(Object, OutputStream, ObjectMap, String)}
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class OutputStreamSerializer extends Serializer<OutputStream> implements IOutputStreamSerializer {

	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	abstract public String[] getMediaTypes();

	@Override
	abstract public void serialize(Object o, OutputStream out, ObjectMap properties, String mediaType) throws IOException, SerializeException;
}
