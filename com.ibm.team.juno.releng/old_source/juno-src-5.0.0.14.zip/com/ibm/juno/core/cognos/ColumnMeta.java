package com.ibm.juno.core.cognos;

/**
 * Represents a column of data in Cognos.
 *
 * <h6 class='topic'>Additional Information</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#CognosSerializer'>1.0 - Cognos serialization support</a>
 * 		for general usage and examples.
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("rawtypes")
public class ColumnMeta {
	final String name;
	final String type;
	final Integer length;
	final ColumnHelper columnHelper;

	ColumnMeta(String name, String type, Integer length, ColumnHelper columnHelper) {
		this.name = name;
		this.type = type;
		this.length = length;
		this.columnHelper = columnHelper;
	}
}