package com.ibm.juno.core.cognos;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJO models to COGNOS-style XML.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>text/xml+cognos</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>text/xml+cognos</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This serializer will only work on tabular data structures such as:
 * 	<ul>
 * 		<li>{@code Collection<Bean>}
 * 		<li>{@code Collection<Map>}
 * 		<li>{@code Bean[]}
 * 		<li>{@code Map[]}
 * 	</ul>
 * <p>
 * 	Before use, the COGNOS metadata must be specified for the serializer by calling
 * 	the {@link #addColumnMeta(String, String, int, ColumnHelper)} method for each column in the results.
 * 	The serialize method will generate rows for each entry in the table based on the metadata
 * 	specified.  The order of the columns in the rows will be the same as the order in which
 * 	the addMeta() method was called.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * <h6>Additional Information:</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#CognosSerializer'>1.0 - Cognos serialization support</a>
 * 		for a general overview of Cognos serialization support.
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({"unchecked","rawtypes"})
public class CognosSerializer extends WriterSerializer {

	private transient List<ColumnMeta> columnMetas = new LinkedList<ColumnMeta>();


	//--------------------------------------------------------------------------------
	// Methods
	//--------------------------------------------------------------------------------

	@Override
	public CognosSerializer setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	/**
	 * Adds an {@code <item name='name' type='type'/>} entry to the {@code <metadata>} section of the output.
	 *
	 * @param name The column name.
	 * @param type The column type.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object so that this method can be chained like the {@link ProcessBuilder} class.
	 */
	public CognosSerializer addColumnMeta(String name, String type) throws LockedException {
		return addColumnMeta(name, type, 0, null);
	}

	/**
	 * Adds an {@code <item name='name' type='type' length='length'/>} entry to the {@code <metadata>} section of the output.
	 *
	 * @param name The column name.
	 * @param type The column type.
	 * @param length The column length, or {@code 0} if the length is irrelevant.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object so that this method can be chained like the {@link ProcessBuilder} class.
	 */
	public CognosSerializer addColumnMeta(String name, String type, int length) throws LockedException {
		return addColumnMeta(name, type, length, null);
	}

	/**
	 * Adds an {@code <item name='name' type='type' length='length'/>} entry to the {@code <metadata>} section of the output,
	 * 	and specifies a helper class for extracting the column value from the serialized object.
	 *
	 * @param name The column name.
	 * @param type The column type.
	 * @param length The column length, or {@code 0} if the length is irrelevant.
	 * @param columnHelper The helper for extracting the column value from the object.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public CognosSerializer addColumnMeta(String name, String type, int length, ColumnHelper<?> columnHelper) throws LockedException {
		columnMetas.add(new ColumnMeta(name, type, length, columnHelper));
		return this;
	}

	/**
	 * Returns the currently specified column metadata associated with this serializer.
	 *
	 * @return The current setting value.
	 */
	public List<ColumnMeta> getColumnMetas() {
		return columnMetas;
	}

	/**
	 * Sets the metadata associated with this serializer needed to convert the input to
	 * 	the correct Cognos format.
	 *
	 * @param columnMetas The new setting value.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public CognosSerializer setColumnMetas(List<ColumnMeta> columnMetas) throws LockedException {
		checkLock();
		this.columnMetas = new LinkedList<ColumnMeta>();
		if (columnMetas != null)
			this.columnMetas.addAll(columnMetas);
		return this;
	}

	/**
	 * Main serialization routine.
	 *
	 * @param o The object being serialized.
	 * @param w The writer to serialize to.
	 * @param ctx The serialization context object.
	 *
	 * @return The same writer passed in.
	 * @throws IOException If a problem occurred trying to send output to the writer.
	 */
	protected SerializerWriter doSerialize(Object o, SerializerWriter w, SerializerContext ctx) throws IOException {
		int d = ctx.getInitialDepth();
		w.append(d, "<dataset xmlns=").q().append("http://developer.cognos.com/schemas/xmldata/1/").q()
			.append(" xmlns:xs=").q().append("http://www.w3.org/2001/XMLSchema-instance").q().append('>').nl();
		w.appendln(d+1, "<metadata>");
		for (ColumnMeta m : columnMetas) {
			w.append(d+2, "<item name=").q().append(m.name).q().append(" type=").q().append(m.type).q();
			if (m.length > 0)
				w.append(" length=").q().append(m.length).q();
			w.append("/>").nl();
		}
		w.appendln(d+1, "</metadata>");
		w.appendln(d+1, "<data>");
		if (o != null) {
			if (o instanceof Collection) {
				Collection c = (Collection)o;
				for (Object o2 : c) {
					w.appendln(d+2, "<row>");

					Map m = null;
					if (o2 instanceof Map)
						m = (Map)o2;
					else
						m = beanContext.forBean(o2);

					for (ColumnMeta column : columnMetas) {
						Object value = (column.columnHelper == null ? m.get(column.name) : column.columnHelper.getString(o2));
						w.appendln(d+3, "<value>"+value+"</value>");
					}
					w.appendln(d+2, "</row>");
				}
			}
		}
		w.appendln(d+1, "</data>");
		w.appendln(d, "</dataset>");
		return w;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	/**
	 * Returns <code>[<js>"text/xml+cognos"</js>]</code>.
	 */
	@Override // ISerializer
	public String[] getMediaTypes() {
		return new String[]{"text/xml+cognos"};
	}

	@Override // ISerializer, IWriterSerializer
	public void serialize(Object o, Writer w, ObjectMap properties, String mediaType) throws IOException, SerializeException {
		SerializerContext ctx = new SerializerContext(beanContext, sp, properties);
		SerializerWriter sw = new SerializerWriter(w, true, true, ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority());
		doSerialize(o, sw, ctx);
	}

	@Override // ICoreApiSerializer, CoreApi
	public CognosSerializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public CognosSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public CognosSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public <T> CognosSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // ISerializer, Lockable
	public CognosSerializer lock() {
		super.lock();
		columnMetas = Collections.unmodifiableList(columnMetas);
		return this;
	}

	@Override // ISerializer, Lockable
	public CognosSerializer clone() {
		try {
			CognosSerializer c = (CognosSerializer)super.clone();
			c.columnMetas = new LinkedList(columnMetas);
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
