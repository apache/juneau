package com.ibm.juno.core.soap;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.soap.SoapXmlSerializerProperties.*;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Serializes POJOs to HTTP responses as XML+SOAP.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>text/xml+soap</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>text/xml+soap</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Essentially the same output as {@link XmlDocSerializer}, except wrapped in a standard SOAP envelope.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link SoapXmlSerializerProperties}
 * 	<li>{@link XmlSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SoapXmlSerializer extends XmlSerializer {

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	/**
	 * Returns <code>[<js>"text/xml+soap"</js>]</code>.
	 */
	@Override // ISerializer, XmlSerializer
	public String[] getMediaTypes() {
		return new String[]{"text/xml+soap"};
	}

	/**
	 * Returns <js>"text/xml"</js>.
	 */
	@Override // ISerializer
	public String getResponseContentType() {
		return "text/xml";
	}

	@Override // ISerializer
	public void serialize(Object output, Writer out, ObjectMap properties, String matchingAccept) throws IOException, SerializeException {
		XmlSerializerContext ctx = new XmlSerializerContext(beanContext, sp, xsp, properties);
		XmlSerializerWriter w = (out instanceof XmlSerializerWriter ? (XmlSerializerWriter)out : new XmlSerializerWriter(out, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority()));
		w.append("<?xml")
			.attr("version", "1.0")
			.attr("encoding", "UTF-8")
			.appendln("?>");
		w.oTag("soap", "Envelope")
			.attr("xmlns", "soap", properties.getString(SOAPACTION, "http://www.w3.org/2003/05/soap-envelope"))
			.appendln(">");
		w.sTag(1, "soap", "Body").nl();
		doSerialize(output, w, ctx);
		w.eTag(1, "soap", "Body").nl();
		w.eTag("soap", "Envelope").nl();
		w.flush();
		w.close();
	}

	@Override // ISerializer
	public ObjectMap getResponseHeaders(ObjectMap properties) {
		return super.getResponseHeaders(properties)
			.append("SOAPAction", properties.getString(SOAPACTION, "http://www.w3.org/2003/05/soap-envelope"));
	}
}
