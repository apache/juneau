package com.ibm.juno.core;

/**
 * Exception that gets thrown when trying to modify settings on a locked {@link Lockable} object.
 * <p>
 * A locked exception indicates a programming error.
 * Certain objects that are meant for reuse, such as serializers and parsers, provide
 * the ability to lock the current settings so that they cannot be later changed.
 * This exception indicates that a setting change was attempted on a previously locked object.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class LockedException extends RuntimeException {
	LockedException() {
		super("Object is locked and object settings cannot be modified.");
	}
}
