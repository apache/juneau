package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Subclass of {@link Parser} for byte-based parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all byte-based parsers since it implements all
 * 	of the following interfaces...
 * <ul>
 * 	<li>{@link IParser}
 * 	<li>{@link ICoreApiParser}
 * 	<li>{@link IInputStreamParser}
 * </ul>
 * <p>
 * 	...and only has 2 remaining abstract methods to implement...
 * <ul>
 * 	<li>{@link #getMediaTypes()}
 * 	<li>{@link #parse(InputStream, ClassType, String)}
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class InputStreamParser extends Parser<InputStream> implements IInputStreamParser {

	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	abstract public String[] getMediaTypes();

	@Override
	abstract public <T> T parse(InputStream in, ClassType<T> type, String mediaType) throws ParseException, IOException;
}
