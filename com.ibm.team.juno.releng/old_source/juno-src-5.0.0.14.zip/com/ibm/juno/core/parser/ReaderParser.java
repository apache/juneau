package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.*;


/**
 * Subclass of {@link Parser} for characters-based parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all character-based parsers since it implements all
 * 	of the following interfaces...
 * <ul>
 * 	<li>{@link IParser}
 * 	<li>{@link ICoreApiParser}
 * 	<li>{@link IReaderParser}
 * </ul>
 * <p>
 * 	...and only has 2 remaining abstract methods to implement...
 * <ul>
 * 	<li>{@link #getMediaTypes()}
 * 	<li>{@link #parse(Reader, ClassType, String)}
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class ReaderParser extends Parser<Reader> implements IReaderParser {

	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	abstract public String[] getMediaTypes();

	@Override
	abstract public <T> T parse(Reader in, ClassType<T> type, String mediaType) throws ParseException, IOException;


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // IReaderParser
	public <T> T parse(CharSequence in, ClassType<T> type, String mediaType) throws ParseException {
		if (in == null)
			return null;
		try {
			return parse(new StringReader(in.toString()), type, mediaType);
		} catch (IOException e) {
			throw new ParseException(e); // Shouldn't happen.
		}
	}

	@Override // IReaderParser
	public <T> T parse(CharSequence in, Class<T> type) throws ParseException {
		return parse(in, beanContext.getClassType(type), null);
	}
}
