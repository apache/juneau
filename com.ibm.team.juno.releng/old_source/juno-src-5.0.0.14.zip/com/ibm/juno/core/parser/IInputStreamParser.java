package com.ibm.juno.core.parser;

import java.io.*;

/**
 * Top-level interface for all byte-based parsers.
 */
public interface IInputStreamParser extends IParser<InputStream> {}
