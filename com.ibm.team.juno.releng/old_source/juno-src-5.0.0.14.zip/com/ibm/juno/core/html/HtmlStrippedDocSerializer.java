package com.ibm.juno.core.html;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJOs to HTTP responses as stripped HTML.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>text/html+stripped</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>text/html</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Produces the same output as {@link HtmlDocSerializer}, but without the header and body tags and page title and description.
 * 	Used primarily for JUnit testing the {@link HtmlDocSerializer} class.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlStrippedDocSerializer extends HtmlSerializer {

	//---------------------------------------------------------------------------
	// Overridden methods
	//---------------------------------------------------------------------------

	/**
	 * Returns <code>[<js>"text/html+stripped"</js>]</code>.
	 */
	@Override // ISerializer
	public String[] getMediaTypes() {
		return new String[]{"text/html+stripped"};
	}

	@Override // ISerializer
	public void serialize(Object o, Writer out, ObjectMap properties, String matchingAccept) throws IOException, SerializeException {
		HtmlSerializerContext ctx = new HtmlSerializerContext(beanContext, sp, hsp, properties);
		HtmlSerializerWriter w = new HtmlSerializerWriter(out, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority());
		doSerialize(o, w, ctx);
	}

	/**
	 * Returns <js>"text/html"</js>.
	 */
	@Override // ISerializer
	public String getResponseContentType() {
		return "text/html";
	}

	@Override // HtmlSerializer
	protected HtmlSerializerWriter doSerialize(Object o, HtmlSerializerWriter w, HtmlSerializerContext ctx) throws SerializeException, IOException {
		if (o == null
			|| (o instanceof Collection && ((Collection<?>)o).size() == 0)
			|| (o.getClass().isArray() && ((Object[])o).length == 0))
			w.sTag(1, "p").append("No Results").eTag("p").nl();
		else
			super.doSerialize(o, w, ctx);
		return w;
	}
}
