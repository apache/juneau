package com.ibm.juno.server;

import java.text.*;
import java.util.*;

/**
 * Wraps a {@link ResourceBundle} to gracefully handle missing bundles and entries.
 * <p>
 * If the bundle isn't found, <code>getString(key)</code> returns <js>"{!!key}"</js>.
 * <p>
 * If the key isn't found, <code>getString(key)</code> returns <js>"{!key}"</js>.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SafeResourceBundle extends ResourceBundle {

	private ResourceBundle rb;

	/**
	 * Constructor.
	 * @param rb The resource bundle to wrap.  Can be <jk>null</jk> to indicate a missing bundle.
	 */
	SafeResourceBundle(ResourceBundle rb) {
		this.rb = rb;
	}

	@Override
	public boolean containsKey(String key) {
		return (rb == null ? false : rb.containsKey(key));
	}

	/**
	 * Similar to {@link ResourceBundle#getString(String)} except allows you to pass in {@link MessageFormat} objects.
	 * @param key The resource bundle key.
	 * @param args Optional variable replacement arguments.
	 * @return The resolved value.  Never <jk>null</jk>.  <js>"{!!key}"</j> if the bundle is missing.  <js>"{!key}"</j> if the key is missing.
	 */
	public String getString(String key, Object...args) {
		if (rb == null)
			return "{!!"+key+"}";
		if (! containsKey(key))
			return "{!"+key+"}";
		String s = rb.getString(key);
		if (args.length > 0)
			return MessageFormat.format(s, args);
		return s;
	}

	@Override
	public Set<String> keySet() {
		if (rb == null)
			return Collections.emptySet();
		return rb.keySet();
	}

	@Override
	public Enumeration<String> getKeys() {
		if (rb == null)
			return new Vector<String>(0).elements();
		return rb.getKeys();
	}

	@Override
	protected Object handleGetObject(String key) {
		if (rb == null)
			return null;
		return rb.getObject(key);
	}

	/**
	 * Returns <jk>true</jk> if the underlying resource bundle exists.
	 * @return <jk>true</jk> if the underlying resource bundle exists.
	 */
	protected boolean exists() {
		return rb != null;
	}
}