package com.ibm.juno.server.labels;

import java.util.*;

import com.ibm.juno.server.*;
import com.ibm.juno.server.annotation.*;


/**
 * Simple bean for describing REST methods.
 * <p>
 * 	Primarily used for constructing tables with name/path/description/... columns on REST OPTIONS requests.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("hiding")
public class MethodDescription {
	private String javaMethod, httpMethod, path, description, responseContent;
	private String[] guards, converters, matchers;
	private List<Var> requestVars = new LinkedList<Var>();
	private Map<Integer,Response> responses = new LinkedHashMap<Integer,Response>();
	private Map<String,Object> properties;
	private Collection<String> accept, contentType;

	/**
	 * A request variable.
	 * <p>
	 * Examples: attr, param
	 */
	public static class Var {

		/** Variable category */
		public String category;

		/** Variable name */
		public String name;

		/** Variable class type */
		public String classType;

		/** Variable description */
		public String description;

		/** Bean constructor */
		public Var() {}

		/**
		 * Constructor.
		 * @param category Variable category (e.g. "ATTR", "PARAM").
		 * @param name Variable name.
		 */
		public Var(String category, String name) {
			this.category = category;
			this.name = name;
		}

		private boolean matches(String category, String name) {
			if (this.category.equals(category))
				if (name == null || name.equals(this.name))
					return true;
			return false;
		}
	}

	/**
	 * A possible response status.
	 */
	public static class Response {

		/** HTTP status code */
		public int status;

		/** Response description */
		public String description;

		/** Response headers set */
		public List<Var> responseVars = new LinkedList<Var>();

		/** Bean constructor */
		public Response() {}

		/**
		 * Constructor.
		 * @param status HTTP status code.
		 */
		public Response(int status) {
			this.status = status;
			this.description = RestUtils.getHttpResponseText(status);
		}

		/**
		 * Add a response variable to this response.
		 * @param category The response variable category (typically only <js>"header"</js>).
		 * @param name The response variable name.
		 * @return The new variable object whose fields can be updated.
		 */
		public Var addResponseVar(String category, String name) {
			for (Var v : responseVars)
				if (v.matches(category, name))
					return v;
			Var v = new Var(category, name);
			responseVars.add(v);
			return v;
		}
	}

	/** No-arg constructor.  Used for JUnit testing of OPTIONS pages. */
	public MethodDescription() {}

	/**
	 * Constructor.
	 * @param javaMethod The java method name.
	 * @param httpMethod The HTTP method name.
	 * @param path The path that this method handles.
	 * @param description The method description.
	 */
	public MethodDescription(String javaMethod, String httpMethod, String path, String description) {
		this.javaMethod = javaMethod;
		this.httpMethod = httpMethod;
		this.setPath(path);
		this.description = description;
	}

	/**
	 * Returns the javaMethod field on this label.
	 * @return The name.
	 */
	public String getJavaMethod() {
		return javaMethod;
	}

	/**
	 * Sets the javaMethod field on this label to a new value.
	 * @param javaMethod The new name.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setJavaMethod(String javaMethod) {
		this.javaMethod = javaMethod;
		return this;
	}

	/**
	 * Returns the httpMethod field on this label.
	 * @return The name.
	 */
	public String getHttpMethod() {
		return httpMethod;
	}

	/**
	 * Sets the httpMethod field on this label to a new value.
	 * @param httpMethod The new name.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
		return this;
	}

	/**
	 * Returns the path field on this label.
	 * @return The path.
	 */
	public String getPath() {
		return path;
	}

	/**
	 * Sets the path field on this label to a new value.
	 * @param path The new path.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setPath(String path) {
		this.path = path;
		return this;
	}

	/**
	 * Returns the description field on this label.
	 * @return The description.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description field on this label to a new value.
	 * @param description The new description.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setDescription(String description) {
		this.description = description;
		return this;
	}

	/**
	 * Returns the vars field on this label.
	 * @return The vars.
	 */
	public Collection<Var> getInput() {
		return requestVars;
	}

	/**
	 * Sets the responseContent field for this method description.
	 * <p>
	 * Typically the class name of the serialized object in the HTTP response body.
	 *
	 * @param responseContent The content field value.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setResponseContent(String responseContent) {
		this.responseContent = responseContent;
		return this;
	}

	/**
	 * Returns the HTTP response body content description.
	 * @return The HTTP response body content description.
	 */
	public String getResponseContent() {
		return responseContent;
	}

	/**
	 * Returns the possible response codes returned by this method.
	 * @return The possible response codes returned by this method.
	 */
	public Collection<Response> getResponses() {
		return responses.values();
	}

	/**
	 * Sets the properties field on this label to a new value.
	 * This identifies properties defined on a method via the {@link RestMethod#properties()} annotation.
	 * @param properties The new list if properties.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setProperties(Map<String,Object> properties) {
		this.properties = properties;
		return this;
	}

	/**
	 * Returns the list of properties set on a method.
	 * @return The list of properties set on a method.
	 */
	public Map<String,Object> getProperties() {
		return properties;
	}

	/**
	 * Sets the list of <code>Accept</code> header values that this method accepts if it's different
	 * 	from the servlet.
	 * @param accept The list of <code>Accept</code> header values.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setAccept(Collection<String> accept) {
		this.accept = accept;
		return this;
	}

	/**
	 * Returns the list of <code>Accept</code> header values that this method accepts if it's different
	 * 	from the servlet.
	 * @return The list of <code>Accept</code> header values.
	 */
	public Collection<String> getAccept() {
		return accept;
	}

	/**
	 * Sets the list of <code>Content-Type</code> header values that this method accepts if it's different
	 * 	from the servlet.
	 * @param contentType The list of <code>Content-Type</code> header values.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setContentType(Collection<String> contentType) {
		this.contentType = contentType;
		return this;
	}

	/**
	 * Returns the list of <code>Content-Type</code> header values that this method accepts if it's different
	 * 	from the servlet.
	 * @return The list of <code>Content-Type</code> header values.
	 */
	public Collection<String> getContentType() {
		return contentType;
	}
	/**
	 * Sets the guards field on this label to a new value.
	 * @param guards The guards associated with this method.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setGuards(Class<?>...guards) {
		this.guards = new String[guards.length];
		for (int i = 0; i < guards.length; i++)
			this.guards[i] = guards[i].getSimpleName();
		return this;
	}

	/**
	 * Returns the guards field on this label.
	 * @return The guards.
	 */
	public String[] getGuards() {
		return guards;
	}

	/**
	 * Sets the matchers field on this label to a new value.
	 * @param matchers The matchers associated with this method.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setMatchers(Class<?>...matchers) {
		this.matchers = new String[matchers.length];
		for (int i = 0; i < matchers.length; i++)
			this.matchers[i] = matchers[i].getSimpleName();
		return this;
	}

	/**
	 * Returns the matchers field on this label.
	 * @return The matchers.
	 */
	public String[] getMatchers() {
		return matchers;
	}

	/**
	 * Sets the converters field on this label to a new value.
	 * @param converters The converters associated with this method.
	 * @return This object (for method chaining).
	 */
	public MethodDescription setConverters(Class<?>...converters) {
		this.converters = new String[converters.length];
		for (int i = 0; i < converters.length; i++)
			this.converters[i] = converters[i].getSimpleName();
		return this;
	}

	/**
	 * Returns the converters field on this label.
	 * @return The converters.
	 */
	public String[] getConverters() {
		return converters;
	}

	/**
	 * Add a request variable to this method description.
	 * @param category The variable category (e.g. <js>"attr"</js>, <js>"attr"</js>, <js>"header"</js>, <js>"content"</js>).
	 * @param name The variable name.
	 * 	Can be <jk>null</jk> in the case of <js>"content"</js> category.
	 * @return The new variable whose fields can be modified.
	 */
	public Var addRequestVar(String category, String name) {
		for (Var v : requestVars)
			if (v.matches(category, name))
				return v;
		Var v = new Var(category, name);
		requestVars.add(v);
		return v;
	}

	/**
	 * Add a possible HTTP response code from this method.
	 * @param httpStatus The HTTP status code.
	 * @return The new response object whose fields can be modified.
	 */
	public Response addResponse(int httpStatus) {
		if (! responses.containsKey(httpStatus))
			responses.put(httpStatus, new Response(httpStatus));
		return responses.get(httpStatus);
	}
}
