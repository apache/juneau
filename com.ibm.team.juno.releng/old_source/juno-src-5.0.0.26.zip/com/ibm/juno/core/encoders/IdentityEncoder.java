package com.ibm.juno.core.encoders;

import java.io.*;

import com.ibm.juno.server.*;

/**
 * Encoder for handling <js>"identity"</js> encoding and decoding (e.g. no encoding at all).
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class IdentityEncoder extends Encoder {

	/** Singleton */
	public static final IdentityEncoder INSTANCE = new IdentityEncoder();

	/** Constructor. */
	protected IdentityEncoder() {}

	@Override
	public InputStream getInputStream(InputStream is) throws RestException {
		return is;
	}

	@Override
	public OutputStream getOutputStream(OutputStream os) throws RestException {
		return os;
	}

	/**
	 * Returns <code>[<js>"identity"</js>]</code>.
	 */
	@Override
	public String[] getCodings() {
		return new String[]{"identity"};
	}
}
