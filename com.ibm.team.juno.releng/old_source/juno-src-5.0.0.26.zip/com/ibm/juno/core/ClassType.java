package com.ibm.juno.core;

import static com.ibm.juno.core.ClassType.ClassCategory.*;
import static com.ibm.juno.core.ClassType.ClassCategory.URI;

import java.io.*;
import java.lang.reflect.*;
import java.lang.reflect.Proxy;
import java.net.*;
import java.net.URI;
import java.util.*;

import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.utils.*;
import com.ibm.juno.core.xml.*;
import com.ibm.juno.core.xml.annotation.*;

/**
 * A wrapper class around the {@link Class} object that provides cached information
 * about that class.
 *
 * <p>
 * 	Instances of this class can be created through the {@link BeanContext#getClassType(Class)} method.
 * <p>
 * 	The {@link BeanContext} class will cache and reuse instances of this class except for the following class types:
 * <ul>
 * 	<li>Arrays
 * 	<li>Maps with non-Object key/values.
 * 	<li>Collections with non-Object key/values.
 * </ul>
 * <p>
 * 	This class is tied to the {@link BeanContext} class because it's that class that makes the determination
 * 	of what is a bean.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <T> The class type of the wrapped class.
 */
public class ClassType<T> implements Type {

	/** Class categories. */
	enum ClassCategory {
		MAP, COLLECTION, NUMBER, DECIMAL, BOOLEAN, CHAR, DATE, ARRAY, ENUM, BEAN, UNKNOWN, OTHER, CHARSEQ, STR, OBJ, URI, BEANMAP, READER, INPUTSTREAM
	}

	final BeanContext beanContext;                    // The bean context that created this object.
	ClassCategory classCategory = UNKNOWN;            // The class category.
	final Class<T> innerClass;                        // The class being wrapped.
	ClassType<?>
		filteredClassType,                            // The filtered class type (in class has filter associated with it.
		elementType = null,                           // If ARRAY or COLLECTION, the element class type.
		keyType = null,                               // If MAP, the key class type.
		valueType = null;                             // If MAP, the value class type.
	Constructor<? extends T> noArgConstructor;        // The no-arg constructor for this class (if it has one).
	InvocationHandler invocationHandler;              // The invocation handler for this class (if it has one).
	volatile BeanMeta<T> beanMeta;                    // The bean meta for this bean class (if it's a bean).
	Method valueOfMethod;                             // The static valueOf(String) or fromString(String) method (if it has one).
	Constructor<T> stringConstructor;                 // The X(String) constructor (if it has one).
	String notABeanReason;                            // If this isn't a bean, the reason why.
	IPojoFilter<T,?> pojoFilter;                      // The object filter associated with this bean (if it has one).
	BeanFilter<? extends T> beanFilter;               // The bean filter associated with this bean (if it has one).
	private Namespace namespace;
	private String elementName, childName;
	private XmlFormat xmlFormat = XmlFormat.NORMAL;
	private boolean isDelegate, isAbstract;
	private Xml xml;

	/** Reusable instance that represents 'anything'. */
	public static final ClassType<Object> OBJECT = new ClassType<Object>(Object.class, null);

	/** Reusable instance that represents 'anything'. */
	public static final ClassType<String> STRING = new ClassType<String>(String.class, null);

	/**
	 * Construct a new {@code ClassType} based on the specified {@link Class}.
	 *
	 * @param innerClass The class being wrapped.
	 * @param beanContext The bean context that created this object.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	ClassType(Class<T> innerClass, BeanContext beanContext) {
		this.innerClass = innerClass;
		this.beanContext = beanContext;

		IFilter filter = getFilter(beanContext);
		if (filter != null) {
			if (filter.isBeanFilter())
				beanFilter = (BeanFilter)filter;
			else
				pojoFilter = (PojoFilter)filter;
			filteredClassType = (pojoFilter == null ? this : beanContext.getClassType(pojoFilter.getFilteredClass()));
		} else {
			filteredClassType = this;
		}

		if (beanContext != null)
			this.noArgConstructor = beanContext.getConstructor(innerClass);

		this.xml = ReflectionUtils.getAnnotation(Xml.class, innerClass);

		Class c = innerClass;

		if (c.isPrimitive()) {
			if (c == Boolean.TYPE)
				classCategory = BOOLEAN;
			else if (c == Byte.TYPE || c == Short.TYPE || c == Integer.TYPE || c == Long.TYPE || c == Float.TYPE || c == Double.TYPE) {
				if (c == Float.TYPE || c == Double.TYPE)
					classCategory = DECIMAL;
				else
					classCategory = NUMBER;
			}
			else if (c == Character.TYPE)
				classCategory = CHAR;
		} else {
			if (Delegate.class.isAssignableFrom(c))
				isDelegate = true;
			if (c == Object.class)
				classCategory = OBJ;
			else if (c.isEnum())
				classCategory = ENUM;
			else if (CharSequence.class.isAssignableFrom(c)) {
				if (c.equals(String.class))
					classCategory = STR;
				else
					classCategory = CHARSEQ;
			}
			else if (Number.class.isAssignableFrom(c)) {
				if (Float.class.isAssignableFrom(c) || Double.class.isAssignableFrom(c))
					classCategory = DECIMAL;
				else
					classCategory = NUMBER;
			}
			else if (Collection.class.isAssignableFrom(c))
				classCategory = COLLECTION;
			else if (Map.class.isAssignableFrom(c)) {
				if (BeanMap.class.isAssignableFrom(c))
					classCategory = BEANMAP;
				else
					classCategory = MAP;
			}
			else if (c == Character.class)
				classCategory = CHAR;
			else if (c == Boolean.class)
				classCategory = BOOLEAN;
			else if (Date.class.isAssignableFrom(c) || Calendar.class.isAssignableFrom(c))
				classCategory = DATE;
			else if (c.isArray())
				classCategory = ARRAY;
			else if (URL.class.isAssignableFrom(c) || URI.class.isAssignableFrom(c) || c.isAnnotationPresent(com.ibm.juno.core.annotation.URI.class))
				classCategory = URI;
			else if (Reader.class.isAssignableFrom(c))
				classCategory = READER;
			else if (InputStream.class.isAssignableFrom(c))
				classCategory = INPUTSTREAM;
		}

		// Find valueOf(String) or fromString(String) methods if present.
		for (Method m : c.getMethods()) {
			int mod = m.getModifiers();
			if (Modifier.isStatic(mod) && Modifier.isPublic(mod)) {
				String mName = m.getName();
				if (mName.equals("valueOf") || mName.equals("fromString")) {
					Class<?>[] args = m.getParameterTypes();
					if (args.length == 1 && args[0] == String.class) {
						this.valueOfMethod = m;
						break;
					}
				}
			}
		}
		// Find constructor(String) method if present.
		for (Constructor cs : c.getConstructors()) {
			int mod = cs.getModifiers();
			if (Modifier.isPublic(mod)) {
				Class<?>[] args = cs.getParameterTypes();
				if (args.length == 1 && args[0] == String.class) {
					this.stringConstructor = cs;
					break;
				}
			}
		}

		if (beanContext != null) {

			// If this is an array, get the element type.
			if (classCategory == ARRAY)
				elementType = beanContext.getClassType(innerClass.getComponentType());

			// If this is a MAP, see if it's parameterized (e.g. AddressBook extends HashMap<String,Person>)
			else if (classCategory == MAP) {
				ClassType[] parameters = beanContext.findParameters(innerClass, innerClass);
				if (parameters != null && parameters.length == 2) {
					keyType = parameters[0];
					valueType = parameters[1];
				} else {
					keyType = OBJECT;
					valueType = OBJECT;
				}
			}

			// If this is a COLLECTION, see if it's parameterized (e.g. AddressBook extends LinkedList<Person>)
			else if (classCategory == COLLECTION) {
				ClassType[] parameters = beanContext.findParameters(innerClass, innerClass);
				if (parameters != null && parameters.length == 1) {
					elementType = parameters[0];
				} else {
					elementType = OBJECT;
				}
			}

			// Find XML-related stuff.
			elementName = (xml == null || xml.name().isEmpty() ? null : xml.name());
			childName = (xml == null || xml.childName().isEmpty() ? null : xml.childName());
			namespace = findNamespace(innerClass);
			xmlFormat = (xml == null ? XmlFormat.NORMAL : xml.format());
		}

		// Note:  Primitive types are normally abstract.
		isAbstract = Modifier.isAbstract(c.getModifiers()) && ! isPrimitive();
	}

	/**
	 * Returns <jk>true</jk> if this class is a superclass of or the same as the specified class.
	 * @param c The comparison class.
	 * @return <jk>true</jk> if this class is a superclass of or the same as the specified class.
	 */
	public boolean isAssignableFrom(Class<?> c) {
		return innerClass.isAssignableFrom(c);
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of or the same as the specified class.
	 * @param c The comparison class.
	 * @return <jk>true</jk> if this class is a subclass of or the same as the specified class.
	 */
	public boolean isInstanceOf(Class<?> c) {
		return c.isAssignableFrom(innerClass);
	}

	private Namespace findNamespace(Class<?> c) {
		if (c == null)
			return null;

		Namespace ns = null;

		// Check for @Xml.prefix and namespace on this class.
		Xml x = (c == innerClass ? this.xml : ReflectionUtils.getDeclaredAnnotation(Xml.class, c));
		if (x != null) {

			// If prefix or namespace is specified.
			if (! (x.prefix().isEmpty() && x.namespace().isEmpty())) {

				// If both prefix and namespace is defined, use that.
				if ((!x.prefix().isEmpty()) && (!x.namespace().isEmpty()))
					return NamespaceFactory.get(x.prefix(), x.namespace());

				// If only prefix is defined, need to find namespace.
				if (! x.prefix().isEmpty()) {
					ns = findNamespaceByName(c, x.prefix(), x.namespace());
					if (ns != null)
						return ns;
					throw new BeanRuntimeException(c, "Found @Xml.ns annotation with no matching URI.");
				}
				throw new BeanRuntimeException(c, "Found @Xml.nsUri annotation with no matching name.");
			}
		}

		if (c.getEnclosingClass() != null)
			return findNamespace(c.getEnclosingClass());

		if (c.getDeclaringClass() != null)
			return findNamespace(c.getDeclaringClass());

		// Is it defined on the package?
		Package p = c.getPackage();
		XmlSchema xs = (p == null ? null : p.getAnnotation(XmlSchema.class));
		if (xs != null)
			ns = findNamespaceByName(p, xs.prefix(), xs.namespace());
		if (ns != null)
			return ns;

		// Check superclass
		ns = findNamespace(c.getSuperclass());
		if (ns != null)
			return ns;

		// Check interfaces
		for (Class<?> c2 : c.getInterfaces()) {
			ns = findNamespace(c2);
			if (ns != null)
				return ns;
		}

		return null;
	}

	Namespace findNamespaceByName(String prefix, String ns) {
		return findNamespaceByName(innerClass, prefix, ns);
	}

	@SuppressWarnings("hiding")
	private Namespace findNamespaceByName(Class<?> c, String prefix, String namespace) {
		if (c == null || (prefix.isEmpty() && namespace.isEmpty()))
			return null;

		// If we've got both, return right away.
		if (! (prefix.isEmpty() || namespace.isEmpty()))
			return NamespaceFactory.get(prefix, namespace);

		// Check this class.
		Xml x = (c == innerClass ? this.xml : ReflectionUtils.getDeclaredAnnotation(Xml.class, c));
		if (x != null)
			if ((! (x.prefix().isEmpty() || x.namespace().isEmpty())) && (x.prefix().equals(prefix) || x.namespace().equals(namespace)))
					return NamespaceFactory.get(x.prefix(), x.namespace());

		// Check this package.
		Namespace ns = findNamespaceByName(c.getPackage(), prefix, namespace);
		if (ns != null)
			return ns;

		// Check superclass
		ns = findNamespaceByName(c.getSuperclass(), prefix, namespace);
		if (ns != null)
			return ns;

		// Check interfaces
		for (Class<?> c2 : c.getInterfaces()) {
			ns = findNamespaceByName(c2, prefix, namespace);
			if (ns != null)
				return ns;
		}

		return null;
	}

	@SuppressWarnings("hiding")
	private Namespace findNamespaceByName(Package p, String prefix, String namespace) {

		if (p == null || prefix.isEmpty() && namespace.isEmpty())
			return null;

		if (! (prefix.isEmpty() || namespace.isEmpty()))
			return NamespaceFactory.get(prefix, namespace);

		XmlSchema x = p.getAnnotation(XmlSchema.class);
		if (x != null) {
			if ((prefix.isEmpty() && (! x.prefix().isEmpty()) && x.namespace().equals(namespace)) || (namespace.isEmpty() && (! x.namespace().isEmpty()) && x.prefix().equals(prefix)))
				return NamespaceFactory.get(x.prefix(), x.namespace());
			for (XmlNs xmlNs : x.xmlNs()) {
				if (xmlNs.prefix().equals(prefix) || xmlNs.namespaceURI().equals(namespace))
					return NamespaceFactory.get(xmlNs.prefix(), xmlNs.namespaceURI());
			}
		}
		return null;
	}

	private IFilter getFilter(BeanContext context) {
		try {
			Bean b = innerClass.getAnnotation(Bean.class);
			if (b != null) {
				Class<? extends IFilter> c = b.filter();
				if (c != IFilter.NULL.class)
					return c.newInstance();
			}
			if (context == null)
				return null;
			return context.getFilter(innerClass);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Set element type on non-cached <code>Collection</code> types.
	 */
	protected ClassType<T> setElementType(ClassType<?> elementType) {
		this.elementType = elementType;
		return this;
	}

	/**
	 * Set key type on non-cached <code>Map</code> types.
	 */
	protected ClassType<T> setKeyType(ClassType<?> keyType) {
		this.keyType = keyType;
		return this;
	}

	/**
	 * Set value type on non-cached <code>Map</code> types.
	 */
	protected ClassType<T> setValueType(ClassType<?> valueType) {
		this.valueType = valueType;
		return this;
	}

	/**
	 * Returns the {@link Class} object that this class type wraps.
	 * @return The wrapped class object.
	 */
	public Class<T> getInnerClass() {
		return innerClass;
	}

	/**
	 * Returns the generalized form of this class if there is an {@link IPojoFilter} associated with it.
	 * @return The filtered class type, or this object if no filter is associated with the class.
	 */
	public ClassType<?> getFilteredClassType() {
		return filteredClassType;
	}

	/**
	 * For array and {@code Collection} types, returns the class type of the components of the array or {@code Collection}.
	 * @return The element class type, or <jk>null</jk> if this class is not an array or Collection.
	 */
	public ClassType<?> getElementType() {
		return elementType;
	}

	/**
	 * For {@code Map} types, returns the class type of the keys of the {@code Map}.
	 * @return The key class type, or <jk>null</jk> if this class is not a Map.
	 */
	public ClassType<?> getKeyType() {
		return keyType;
	}

	/**
	 * For {@code Map} types, returns the class type of the values of the {@code Map}.
	 * @return The value class type, or <jk>null</jk> if this class is not a Map.
	 */
	public ClassType<?> getValueType() {
		return valueType;
	}

	/**
	 * Returns <jk>true</jk> if this class implements {@link Delegate}, meaning
	 * 	it's a representation of some other object.
	 * @return <jk>true</jk> if this class implements {@link Delegate}.
	 */
	public boolean isDelegate() {
		return isDelegate;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link Map}.
	 * @return <jk>true</jk> if this class is a subclass of {@link Map}.
	 */
	public boolean isMap() {
		return classCategory == MAP || classCategory == BEANMAP;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link BeanMap}.
	 * @return <jk>true</jk> if this class is a subclass of {@link BeanMap}.
	 */
	public boolean isBeanMap() {
		return classCategory == BEANMAP;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link Collection}.
	 * @return <jk>true</jk> if this class is a subclass of {@link Collection}.
	 */
	public boolean isCollection() {
		return classCategory == COLLECTION;
	}

	/**
	 * Returns <jk>true</jk> if this class is an {@link Enum}.
	 * @return <jk>true</jk> if this class is an {@link Enum}.
	 */
	public boolean isEnum() {
		return classCategory == ENUM;
	}

	/**
	 * Returns <jk>true</jk> if this class is an array.
	 * @return <jk>true</jk> if this class is an array.
	 */
	public boolean isArray() {
		return classCategory == ARRAY;
	}

	/**
	 * Returns <jk>true</jk> if this class is a bean.
	 * @return <jk>true</jk> if this class is a bean.
	 */
	public boolean isBean() {
		// isBean and beanMeta are lazy loaded.
		if (classCategory == UNKNOWN && beanMeta == null)
			getBeanMeta();
		return classCategory == BEAN;
	}


	/**
	 * Returns <jk>true</jk> if this class is {@link Object}.
	 * @return <jk>true</jk> if this class is {@link Object}.
	 */
	public boolean isObject() {
		return classCategory == OBJ;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link Number}.
	 * @return <jk>true</jk> if this class is a subclass of {@link Number}.
	 */
	public boolean isNumber() {
		return classCategory == NUMBER || classCategory == DECIMAL;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link Float} or {@link Double}.
	 * @return <jk>true</jk> if this class is a subclass of {@link Float} or {@link Double}.
	 */
	public boolean isDecimal() {
		return classCategory == DECIMAL;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link Boolean}.
	 * @return <jk>true</jk> if this class is a {@link Boolean}.
	 */
	public boolean isBoolean() {
		return classCategory == BOOLEAN;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link CharSequence}.
	 * @return <jk>true</jk> if this class is a subclass of {@link CharSequence}.
	 */
	public boolean isCharSequence() {
		return classCategory == STR || classCategory == CHARSEQ;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link String}.
	 * @return <jk>true</jk> if this class is a {@link String}.
	 */
	public boolean isString() {
		return classCategory == STR;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link Character}.
	 * @return <jk>true</jk> if this class is a {@link Character}.
	 */
	public boolean isChar() {
		return classCategory == CHAR;
	}

	/**
	 * Returns <jk>true</jk> if this class is a primitive.
	 * @return <jk>true</jk> if this class is a primitive.
	 */
	public boolean isPrimitive() {
		return innerClass.isPrimitive();
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link Date} or {@link Calendar}.
	 * @return <jk>true</jk> if this class is a {@link Date} or {@link Calendar}.
	 */
	public boolean isDate() {
		return classCategory == DATE;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link URI} or {@link URL}.
	 * @return <jk>true</jk> if this class is a {@link URI} or {@link URL}.
	 */
	public boolean isUri() {
		return classCategory == URI;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link Reader}.
	 * @return <jk>true</jk> if this class is a {@link Reader}.
	 */
	public boolean isReader() {
		return classCategory == READER;
	}

	/**
	 * Returns <jk>true</jk> if this class is an {@link InputStream}.
	 * @return <jk>true</jk> if this class is an {@link InputStream}.
	 */
	public boolean isInputStream() {
		return classCategory == INPUTSTREAM;
	}

	/**
	 * Returns <jk>true</jk> if instance of this object can be <jk>null</jk>.
	 * <p>
	 * 	Objects can be <jk>null</jk>, but primitives cannot, except for chars which can be represented
	 * 	by <code>(<jk>char</jk>)0</code>.
	 * @return <jk>true</jk> if instance of this class can be null.
	 */
	public boolean isNullable() {
		if (innerClass.isPrimitive())
			return classCategory == CHAR;
		return true;
	}

	/**
	 * Returns the {@link IPojoFilter} associated with this class.
	 * @return The {@link IPojoFilter} associated with this class, or <jk>null</jk> if there is no POJO filter
	 * 	associated with this class.
	 */
	public IPojoFilter<T,?> getPojoFilter() {
		return pojoFilter;
	}

	/**
	 * Returns the {@link BeanMeta} associated with this class.
	 * @return The {@link BeanMeta} associated with this class, or <jk>null</jk> if there is no bean meta
	 * 	associated with this class.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public BeanMeta<T> getBeanMeta() {

		if (beanMeta != null)
			return beanMeta;

		// If beanMeta is null and isBean is true, then beanMeta hasn't been initialized yet.
		if (classCategory == UNKNOWN) {

			synchronized (this) {

				// Make sure someone didn't already set it while this thread was blocked.
				if (beanMeta != null)
					return beanMeta;

				// If it has an object filter, then it's not a bean.
				if (pojoFilter != null) {
					classCategory = OTHER;
					notABeanReason = "Has POJO filter";

				} else {
					BeanMeta newMeta = new BeanMeta(this, beanContext, beanFilter);
					notABeanReason = newMeta.init();
					if (notABeanReason != null)
						classCategory = OTHER;
					else {
						this.beanMeta = newMeta;
						this.classCategory = BEAN;
					}
				}
			}
		}

		return beanMeta;
	}

	/**
	 * Returns the no-arg constructor for this class.
	 * @return The no-arg constructor for this class, or <jk>null</jk> if it does not exist.
	 */
	public Constructor<? extends T> getConstructor() {
		return noArgConstructor;
	}

	/**
	 * Returns the XML namespace associated with this class.
	 * <p>
	 * 	Namespace is determined in the following order:
	 * <ol>
	 * 	<li>{@link Xml#prefix()} annotation defined on class.
	 * 	<li>{@link Xml#prefix()} annotation defined on package.
	 * 	<li>{@link Xml#prefix()} annotation defined on superclasses.
	 * 	<li>{@link Xml#prefix()} annotation defined on superclass packages.
	 * 	<li>{@link Xml#prefix()} annotation defined on interfaces.
	 * 	<li>{@link Xml#prefix()} annotation defined on interface packages.
	 * </ol>
	 * @return The namespace associated with this class, or <jk>null</jk> if no namespace is
	 * 	associated with it.
	 */
	public Namespace getNamespace() {
		return namespace;
	}

	/**
	 * Returns the {@link Xml#name()} annotation for this class.
	 * <p>
	 * 	XML element name is found in the following order:
	 * <ol>
	 * 	<li>{@link Xml#name()} annotation defined on class.
	 * 	<li>{@link Xml#name()} annotation defined on superclasses.
	 * 	<li>{@link Xml#name()} annotation defined on interfaces.
	 * </ol>
	 * @return The XML element name to use for this class, or <jk>null</jk> if no element name
	 * 	was specified.
	 */
	public String getElementName() {
		return elementName;
	}

	/**
	 * Returns the {@link Xml#childName()} annotation for this class.
	 * <p>
	 * 	XML element name is found in the following order:
	 * <ol>
	 * 	<li>{@link Xml#childName()} annotation defined on class.
	 * 	<li>{@link Xml#childName()} annotation defined on superclasses.
	 * 	<li>{@link Xml#childName()} annotation defined on interfaces.
	 * </ol>
	 * @return The XML child element name to use for this class, or <jk>null</jk> if no child element name
	 * 	was specified.
	 */
	public String getChildName() {
		return childName;
	}
	/**
	 * Returns the {@link Xml#format()} annotation for this class.
	 * <p>
	 * 	XML format is found in the following order:
	 * <ol>
	 * 	<li>{@link Xml#format()} annotation defined on class.
	 * 	<li>{@link Xml#format()} annotation defined on superclasses.
	 * 	<li>{@link Xml#format()} annotation defined on interfaces.
	 * </ol>
	 * @return The XML for to use for this class, or {@link XmlFormat#NORMAL} if no XML format
	 * 	was specified.
	 */
	public XmlFormat getXmlFormat() {
		return xmlFormat;
	}

	/**
	 * Returns the interface proxy invocation handler for this class.
	 * @return The interface proxy invocation handler, or <jk>null</jk> if it does not exist.
	 */
	public InvocationHandler getProxyInvocationHandler() {
		if (classCategory == UNKNOWN)
			getBeanMeta();
		if (invocationHandler == null
				&& beanContext != null
				&& beanContext.useInterfaceProxies
				&& classCategory == BEAN
				&& innerClass.isInterface()) {
			beanMeta = getBeanMeta();
			if (beanMeta != null)
				invocationHandler = new BeanProxyInvocationHandler<T>(getBeanMeta());
		}
		return invocationHandler;
	}

	/**
	 * Returns <jk>true</jk> if this class has a no-arg constructor or invocation handler.
	 * @return <jk>true</jk> if this class has a no-arg constructor or invocation handler.
	 */
	public boolean canCreateNewInstance() {
		return (getConstructor() != null || getProxyInvocationHandler() != null || (isBean() && getBeanMeta().readOnlyConstructor != null));
	}

	/**
	 * Returns <jk>true</jk> if this class can call the {@link #newInstance(String)} method.
	 * @return <jk>true</jk> if this class has a no-arg constructor or invocation handler.
	 */
	public boolean canCreateNewInstanceFromString() {
		return (valueOfMethod != null || stringConstructor != null);
	}

	/**
	 * Returns the reason why this class is not a bean, or <jk>null</jk> if it is a bean.
	 * @return The reason why this class is not a bean, or <jk>null</jk> if it is a bean.
	 */
	public synchronized String getNotABeanReason() {
		return notABeanReason;
	}

	/**
	 * Returns <jk>true</jk> if this class is abstract.
	 * @return <jk>true</jk> if this class is abstract.
	 */
	public boolean isAbstract() {
		return isAbstract;
	}

	/**
	 * Create a new instance of the main class of this declared type from a <code>String</code> input.
	 * <p>
	 * In order to use this method, the class must have one of the following methods:
	 * <ul>
	 * 	<li><code><jk>public static</jk> T valueOf(String in);</code>
	 * 	<li><code><jk>public static</jk> T fromString(String in);</code>
	 * 	<li><code><jk>public</jk> T(String in);</code>
	 *	</ul>
	 * @param arg The input argument value.
	 *
	 * @return A new instance of the object, or <jk>null</jk> if there is no no-arg constructor on the object.
	 * @throws IllegalAccessException If the <code>Constructor</code> object enforces Java language access control and the underlying constructor is inaccessible.
	 * @throws IllegalArgumentException If the parameter type on the method was invalid.
	 * @throws InstantiationException If the class that declares the underlying constructor represents an abstract class, or
	 * 	does not have one of the methods described above.
	 * @throws InvocationTargetException If the underlying constructor throws an exception.
	 */
	@SuppressWarnings("unchecked")
	public T newInstance(String arg) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException, InstantiationException {
		Method m = valueOfMethod;
		if (m != null)
			return (T)m.invoke(null, arg);
		Constructor<T> c = stringConstructor;
		if (c != null)
			return c.newInstance(arg);
		throw new InstantiationError("No string constructor or valueOf(String) method found for class '"+getInnerClass().getName()+"'");
	}


	/**
	 * Create a new instance of the main class of this declared type.
	 *
	 * @return A new instance of the object, or <jk>null</jk> if there is no no-arg constructor on the object.
	 * @throws IllegalAccessException If the <code>Constructor</code> object enforces Java language access control and the underlying constructor is inaccessible.
	 * @throws IllegalArgumentException If one of the following occurs:
	 * 	<ul>
	 * 		<li>The number of actual and formal parameters differ.
	 * 		<li>An unwrapping conversion for primitive arguments fails.
	 * 		<li>A parameter value cannot be converted to the corresponding formal parameter type by a method invocation conversion.
	 * 		<li>The constructor pertains to an enum type.
	 * 	</ul>
	 * @throws InstantiationException If the class that declares the underlying constructor represents an abstract class.
	 * @throws InvocationTargetException If the underlying constructor throws an exception.
	 */
	@SuppressWarnings("unchecked")
	public T newInstance() throws IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {
		Constructor<? extends T> c = getConstructor();
		if (c != null)
			return c.newInstance((Object[])null);
		InvocationHandler h = getProxyInvocationHandler();
		if (h != null)
			return (T)Proxy.newProxyInstance(this.getClass().getClassLoader(), new Class[] { getInnerClass(), java.io.Serializable.class }, h);
		return null;
	}

	/**
	 * Checks to see if the specified class type is the same as this one.
	 *
	 * @param t The specified class type.
	 * @return <jk>true</jk> if the specified class type is the same as the class for this type.
	 */
	@Override
	public boolean equals(Object t) {
		if (t == null || ! (t instanceof ClassType))
			return false;
		ClassType<?> t2 = (ClassType<?>)t;
		return t2.getInnerClass() == this.getInnerClass();
	}

	@Override
	public String toString() {
		return toString(new StringBuilder()).toString();
	}

	/**
	 * Appends this object as a readable string to the specified string builder.
	 * @param sb The string builder to append this object to.
	 * @return The same string builder passed in (for method chaining).
	 */
	protected StringBuilder toString(StringBuilder sb) {
		switch(classCategory) {
			case ARRAY:
				return elementType.toString(sb).append("[]");
			case MAP:
			case BEANMAP:
				return sb.append(innerClass.getName()).append(keyType.isObject() && valueType.isObject() ? "" : "<"+keyType+","+valueType+">");
			case COLLECTION:
				return sb.append(innerClass.getName()).append(elementType.isObject() ? "" : "<"+elementType+">");
			default:
				return sb.append(innerClass.getName());
		}
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}
}
