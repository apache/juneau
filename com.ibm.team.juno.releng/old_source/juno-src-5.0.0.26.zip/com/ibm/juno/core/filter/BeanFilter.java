package com.ibm.juno.core.filter;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.*;

/**
 * Base implementation for {@link IBeanFilter} interface.
 *
 * <p>
 * 	Note that value returned by the {@link IFilter#forClass()} method is automatically determined through reflection
 * 		when the no-arg constructor is used.
 *
 *
 * <h6 class='topic'>Additional information</h6>
 * 	See {@link com.ibm.juno.core.filter} for more information.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <T> The class type that this filter applies to.
 */
public class BeanFilter<T> extends Filter implements IBeanFilter {

	private LinkedHashSet<String> includeKeys, excludeKeys;

	/**
	 * Constructor that determines the for-class value using reflection.
	 */
	@SuppressWarnings("unchecked")
	public BeanFilter() {
		super(null, true);

		Class<?> c = this.getClass().getSuperclass();
		Type t = this.getClass().getGenericSuperclass();
		while (c != BeanFilter.class) {
			t = c.getGenericSuperclass();
			c = c.getSuperclass();
		}

		// Attempt to determine the T and G classes using reflection.
		if (t instanceof ParameterizedType) {
			ParameterizedType pt = (ParameterizedType)t;
			Type[] pta = pt.getActualTypeArguments();
			if (pta.length == 2) {
				Type nType = pta[0];
				if (nType instanceof Class)
					this.forClass = (Class<T>)nType;

				else
					throw new RuntimeException("Unsupported parameter type: " + nType);
			}
		}
	}


	/**
	 * Create a new filter for the specified class.
	 * <p>
	 * 	Subclasses of this class will be narrowed to the specified class.
	 *
	 * @param c The class to create a new filter for.
	 */
	public BeanFilter(Class<T> c) {
		super(c, true);
	}

	/**
	 * Set the list of properties to exclude from {@link BeanMap#entrySet()}.
	 *
	 * @param keys The list of properties to exclude from the entry set.
	 * @return This object so that this method can be chained like the {@link ProcessBuilder} class.
	 */
	protected BeanFilter<T> setExcludeKeys(String...keys) {
		return setExcludeKeys(new LinkedHashSet<String>(Arrays.asList(keys)));
	}

	/**
	 * Set the list of properties to exclude from {@link BeanMap#entrySet()}.
	 *
	 * @param keys The list of properties to exclude from the entry set.
	 * @return This object (for method chaining).
	 */
	protected BeanFilter<T> setExcludeKeys(LinkedHashSet<String> keys) {
		excludeKeys = keys;
		return this;
	}

	/**
	 * Set the list and order of properties returned by {@link BeanMap#entrySet()}.
	 *
	 * @param keys The set of properties to return in the entry set.
	 * @return This object so that this method can be chained like the {@link ProcessBuilder} class.
	 */
	protected BeanFilter<T> setIncludeKeys(String...keys) {
		return setIncludeKeys(new LinkedHashSet<String>(Arrays.asList(keys)));
	}

	/**
	 * Set the list and order of properties returned by {@link BeanMap#entrySet()}.
	 *
	 * @param keys The set of properties to return in the entry set.
	 * @return This object (for method chaining).
	 */
	protected BeanFilter<T> setIncludeKeys(LinkedHashSet<String> keys) {
		includeKeys = keys;
		return this;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // IBeanFilter
	public LinkedHashSet<String> getIncludeKeys() {
		return includeKeys;
	}

	@Override // IBeanFilter
	public LinkedHashSet<String> getExcludeKeys() {
		return excludeKeys;
	}
}
