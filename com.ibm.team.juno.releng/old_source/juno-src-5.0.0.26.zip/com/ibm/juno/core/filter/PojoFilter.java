package com.ibm.juno.core.filter;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.lang.reflect.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;

/**
 * Base implementation for {@link IPojoFilter} interface.
 *
 *	<p>
 *		For one-way filters, subclasses must extend {@link #filter(Object, BeanContext)}.
 * <p>
 * 	For two-way filters, subclasses must extend {@link #filter(Object, BeanContext)} and {@link #unfilter(Object, ClassType, BeanContext)}.
 *
 * <p>
 * 	Note that value returned by the {@link IFilter#forClass()} method is automatically determined through reflection.
 *
 *
 * <h6 class='topic'>Additional information</h6>
 * 	See {@link com.ibm.juno.core.filter} for more information.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <T> The normal form of the class.
 * @param <F> The filtered form of the class.
 */
public abstract class PojoFilter<T,F> extends Filter implements IPojoFilter<T,F> {

	Class<T> normalClass;
	Class<F> filteredClass;

	/**
	 * Constructor.
	 */
	@SuppressWarnings("unchecked")
	protected PojoFilter() {
		super(null, false);

		Class<?> c = this.getClass().getSuperclass();
		Type t = this.getClass().getGenericSuperclass();
		while (c != PojoFilter.class) {
			t = c.getGenericSuperclass();
			c = c.getSuperclass();
		}

		// Attempt to determine the T and G classes using reflection.
		if (t instanceof ParameterizedType) {
			ParameterizedType pt = (ParameterizedType)t;
			Type[] pta = pt.getActualTypeArguments();
			if (pta.length == 2) {
				Type nType = pta[0];
				if (nType instanceof Class)
					this.normalClass = (Class<T>)nType;

				// <byte[],x> ends up containing a GenericArrayType, so it has to
				// be handled as a special case.
				else if (nType instanceof GenericArrayType) {
					Class<?> cmpntType = (Class<?>)((GenericArrayType)nType).getGenericComponentType();
					this.normalClass = (Class<T>)Array.newInstance(cmpntType, 0).getClass();
				}

				else
					throw new RuntimeException("Unsupported parameter type: " + nType);
				if (pta[1] instanceof Class)
					this.filteredClass = (Class<F>)pta[1];
				else if (pta[1] instanceof ParameterizedType)
					this.filteredClass = (Class<F>)((ParameterizedType)pta[1]).getRawType();
				else
					throw new RuntimeException("Unexpected filtered class type: " + pta[1].getClass().getName());
			}
		}
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // IFilter
	public Class<?> forClass() {
		return normalClass;
	}

	@Override // IPojoFilter
	public F filter(T o, BeanContext beanContext) throws SerializeException {
		throw new SerializeException("Generalize method not implemented on filter '%s'", this.getClass().getName());
	}

	@Override // IPojoFilter
	public T unfilter(F f, ClassType<?> hint, BeanContext beanContext) throws ParseException {
		throw new ParseException("Narrow method not implemented on filter '%s'", this.getClass().getName());
	}

	@Override // IPojoFilter
	public Class<T> getNormalClass() {
		return normalClass;
	}

	@Override // IPojoFilter
	public Class<F> getFilteredClass() {
		return filteredClass;
	}

	@Override // Object
	public String toString() {
		return getNormalClass().getName() + "->" + getFilteredClass().getName();
	}
}
