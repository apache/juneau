package com.ibm.juno.core.serializer;

import java.io.*;

/**
 * Top-level interface for all byte-based serializers.
 */
public interface IOutputStreamSerializer extends ISerializer<OutputStream> {

	@Override
	public void serialize(Object o, OutputStream out, SerializerContext ctx) throws IOException, SerializeException;

}
