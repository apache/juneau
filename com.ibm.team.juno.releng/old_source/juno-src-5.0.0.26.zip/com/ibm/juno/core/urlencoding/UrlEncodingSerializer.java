package com.ibm.juno.core.urlencoding;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.json.JsonSerializerProperties.*;
import static com.ibm.juno.core.serializer.SerializerProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJO models to URL GET parameter notation (e.g. <js>"foo=bar&amp;baz=bing"</js>).
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>application/x-www-form-urlencoded</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>application/x-www-form-urlencoded</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	<i>Note:</i>  This serializer only works on {@link Map Maps} and beans.
 * <p>
 * 	The conversion is as follows...
 * 	<ul>
 * 		<li>Top-level {@link Map Maps} and beans are converted to key/value pairs.
 * 		<li>Values are converted to JSON using the specified JSON serializer.
 * 	</ul>
 * <p>
 * 	This serializer provides several serialization options.  Typically, one of the predefined DEFAULT serializers will be sufficient.
 * 	However, custom serializers can be constructed to fine-tune behavior.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link JsonSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Serialize a Map</jc>
 * 	Map m = <jk>new</jk> ObjectMap(<js>"{a:'b',c:1,d:false,,e:['f',1,false],g:{h:'i'}}"</js>);
 *
 * 	<jc>// Produces "a=b&amp;c=1&amp;d=false&amp;e=['f',1,false]&amp;g={h:'i'}"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT_LAX</jsf>.serialize(s);
 *
 * 	<jc>// Produces "a='b'&amp;c=1&amp;d=false&amp;e=['f',1,false]&amp;g={h:'i'}"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT_LAX</jsf>.serialize(s);
 *
 * 	<jc>// Serialize a bean</jc>
 * 	<jk>public class</jk> Person {
 * 		<jk>public</jk> Person(String s);
 * 		<jk>public</jk> String getName();
 * 		<jk>public int</jk> getAge();
 * 		<jk>public</jk> Address getAddress();
 * 		<jk>public boolean</jk> deceased;
 * 	}
 *
 * 	<jk>public class</jk> Address {
 * 		<jk>public</jk> String getStreet();
 * 		<jk>public</jk> String getCity();
 * 		<jk>public</jk> String getState();
 * 		<jk>public int</jk> getZip();
 * 	}
 *
 * 	Person p = <jk>new</jk> Person(<js>"John Doe, 23, 123 Main St, Anywhere, NY, 12345, false"</js>);
 *
 * 	<jc>// Produces "name=John%20Doe&amp;age=23&amp;address={street:'123%20Main%20St',city:'Anywhere',state:'NY',zip:12345}&amp;deceased=false"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT_LAX</jsf>.serialize(s);
 *
 * 	<jc>// Produces "name='John%20Doe'&amp;age=23&amp;address={street:'123%20Main%20St',city:'Anywhere',state:'NY',zip:12345}&amp;deceased=false"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT</jsf>.serialize(s);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("hiding")
@Produces("application/x-www-form-urlencoded")
public class UrlEncodingSerializer extends JsonSerializer {

	/** Default serializer. */
	public static final UrlEncodingSerializer DEFAULT = new UrlEncodingSerializer().lock();

	/** Default serializer. */
	public UrlEncodingSerializer() {
		setProperty(SIMPLE_MODE, true);
		setProperty(QUOTE_CHAR, '\'');
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private SerializerWriter serializeAnything(UrlEncodingSerializerWriter out, Object o, ClassType<?> eType, UrlEncodingSerializerContext ctx, String attrName) throws SerializeException {
		try {
			if (o == null) {
				out.append("null");
				return out;
			}

			if (eType == null)
				eType = ClassType.OBJECT;

			boolean addClassAttr;		// Add "_class" attribute to element?
			ClassType<?> aType;			// The actual type
			ClassType<?> gType;			// The generic type

			aType = ctx.push(attrName, o, eType);

			// Note:  We don't have to handle recursion because that will be handled by value serializer.

			gType = aType.getFilteredClassType();
			addClassAttr = (ctx.isAddClassAttrs() && ! eType.equals(aType));

			// Filter if necessary
			IPojoFilter filter = aType.getPojoFilter();				// The filter
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == ClassType.OBJECT)
					gType = beanContext.getClassTypeForObject(o);
			}

			if (o == null || (gType.isChar() && ((Character)o).charValue() == 0))
				out.append("null");
			else if (gType.isUri())
				out.encodeUri(o);
			else if (gType.isBean())
				serializeBean(out, o, addClassAttr, ctx);
			else if (gType.isMap())
				serializeMap(out, (Map)o, gType, ctx);
			else {
				StringWriter sw = new StringWriter();
				JsonSerializerWriter jsw = super.createWriter(sw, ctx);
				super.serialize(o, jsw, ctx);
				out.encode(sw.toString());
			}
			ctx.pop();
			return out;
		} catch (SerializeException e) {
			throw e;
		} catch (Throwable e) {
			e.printStackTrace();
			throw new SerializeException("Exception occured trying to process object of type '%s'", (o == null ? null : o.getClass().getName())).setCause(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private SerializerWriter serializeMap(UrlEncodingSerializerWriter out, Map m, ClassType<?> type, UrlEncodingSerializerContext ctx) throws IOException, SerializeException {

		ClassType<?> keyType = type.getKeyType();

		char d = 0;
		for (Map.Entry e : (Set<Map.Entry>)m.entrySet()) {
			Object val = e.getValue();

			Object key = generalize(e.getKey(), keyType);
			StringWriter sw = new StringWriter();
			JsonSerializerWriter jsw = super.createWriter(sw, ctx);
			super.serialize(val, jsw, ctx);
			String sVal = sw.toString();
			out.appendIf(d != 0, d).encode(key).append('=').encode(sVal);
			d = '&';
		}
		return out;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private SerializerWriter serializeBean(UrlEncodingSerializerWriter out, Object o, boolean addClassAttr, UrlEncodingSerializerContext ctx) throws IOException, SerializeException {
		char d = 0;
		if (addClassAttr) {
			out.appendIf(d != 0, d).append("_class=").append(o.getClass().getName());
			d = '&';
		}
		BeanMap m = beanContext.forBean(o);
		for (BeanMapEntry p : (Set<BeanMapEntry>)m.entrySet()) {
			BeanPropertyMeta pMeta = p.getMeta();

			if (canIgnoreProperty(ctx, pMeta))
				continue;

			Object value = p.getFilteredValue();

			if (canIgnoreValue(ctx, pMeta.getClassType(), value))
				continue;

			Object key = p.getKey();
			out.appendIf(d != 0, d).encode(key).append('=');
			if (pMeta.isUri() || pMeta.isBeanUri())
				out.encodeUri(value);
			else {
				StringWriter sw = new StringWriter();
				JsonSerializerWriter jsw = super.createWriter(sw, ctx);
				super.serialize(value, jsw, ctx);
				out.encode(sw.toString());
			}
			d = '&';
		}
		return out;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer
	public void serialize(Object o, JsonSerializerWriter w, SerializerContext ctx) throws IOException, SerializeException {
		if (! (ctx instanceof UrlEncodingSerializerContext))
			throw new SerializeException("Context is not an instance of UrlEncodingSerializerContext");
		if (! (w instanceof UrlEncodingSerializerWriter))
			throw new SerializeException("Writer is not an instance of UrlEncodingSerializerWriter");
		serializeAnything((UrlEncodingSerializerWriter)w, o, null, (UrlEncodingSerializerContext)ctx, "root");
	}

	@Override // ISerializer
	public UrlEncodingSerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) {
		return new UrlEncodingSerializerContext(beanContext, sp, jsp, properties);
	}

	@Override // IWriterSerializer
	public UrlEncodingSerializerWriter createWriter(Writer w, SerializerContext ctx) {
		return new UrlEncodingSerializerWriter(w, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority());
	}


	@Override // ISerializer, CoreApi
	public UrlEncodingSerializer setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public UrlEncodingSerializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public UrlEncodingSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public UrlEncodingSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public <T> UrlEncodingSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // ISerializer, Lockable
	public UrlEncodingSerializer lock() {
		super.lock();
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public UrlEncodingSerializer clone() {
		return (UrlEncodingSerializer)super.clone();
	}
}
