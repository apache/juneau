package com.ibm.juno.core.xml.annotation;

import static java.lang.annotation.RetentionPolicy.*;

import java.lang.annotation.*;

/**
 * Namespace name/URL mapping pair.
 * <p>
 * 	Used to identify a namespace/URI pair on a {@link XmlSchema#xmlNs()} annotation.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Documented
@Target({})
@Retention(RUNTIME)
@Inherited
public @interface XmlNs {

	/**
	 * XML namespace prefix.
	 */
	String prefix();

	/**
	 * XML namespace URL.
	 */
	String namespaceURI();
}
