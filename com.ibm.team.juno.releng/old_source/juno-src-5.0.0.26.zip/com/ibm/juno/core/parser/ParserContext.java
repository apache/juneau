package com.ibm.juno.core.parser;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;
import java.util.logging.*;

import com.ibm.juno.core.*;


/**
 * Context object that lives for the duration of a single parsing of {@link Parser} and its subclasses.
 * <p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserContext {

	private static Logger logger = Logger.getLogger(ParserContext.class.getName());

	private final ClassType<?> type;
	private final String mediaType, charset;
	private final ObjectMap overrideProperties;
	private final BeanContext beanContext;
	private final List<String> warnings = new LinkedList<String>();

	/**
	 * Create a new parser context with the specified options.
	 *
	 * @param type The class type being parsed.
	 * @param beanContext The bean context being used.
	 * @param pp The default parser properties.
	 * @param op The override properties.
	 * @param mediaType The media type being parsed.
	 * @param charset The charset being parsed.
	 */
	public ParserContext(ClassType<?> type, BeanContext beanContext, ParserProperties pp, ObjectMap op, String mediaType, String charset) {
		this.type = type;
		this.beanContext = beanContext;
		this.mediaType = mediaType;
		this.charset = charset;
		this.overrideProperties = op;
	}

	/**
	 * Returns the bean context associated with this context.
	 */
	public final BeanContext getBeanContext() {
		return beanContext;
	}

	/**
	 * Returns the class type being parsed.
	 */
	public final ClassType<?> getClassType() {
		return type;
	}

	/**
	 * Returns the runtime properties associated with this context.
	 */
	public final ObjectMap getProperties() {
		return overrideProperties;
	}

	/**
	 * Returns the media type being consumed.
	 */
	public final String getMediaType() {
		return mediaType;
	}

	/**
	 * Returns the charset being consumed.
	 */
	public final String getCharset() {
		return charset;
	}

	/**
	 * Logs a warning message.
	 *
	 * @param msg The warning message.
	 * @param args Optional printf arguments to replace in the error message.
	 */
	public void addWarning(String msg, Object... args) {
		msg = args.length == 0 ? msg : String.format(msg, args);
		logger.warning(msg);
		warnings.add(msg);
	}
}
