/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core;

import java.beans.*;
import java.io.*;
import java.lang.reflect.*;

import com.ibm.juno.core.annotation.*;

/**
 * Configurable properties on the {@link BeanContextFactory} class.
 * <p>
 * 	Use the {@link BeanContextFactory#setProperty(String, Object)} method to set properties on
 * 	bean contexts.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class BeanContextProperties {

	/**
	 * Require no-arg constructor ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, a Java class must implement a default no-arg constructor to be considered a bean.
	 * <p>
	 * The {@link Bean @Bean} annotation can be used on a class to override this setting when <jk>true</jk>.
	 */
	public static final String BEANS_REQUIRE_DEFAULT_CONSTRUCTOR = "BeanContext.beansRequireDefaultConstructor";

	/**
	 * Require {@link Serializable} interface ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, a Java class must implement the {@link Serializable} interface to be considered a bean.
	 * <p>
	 * The {@link Bean @Bean} annotation can be used on a class to override this setting when <jk>true</jk>.
	 */
	public static final String BEANS_REQUIRE_SERIALIZABLE = "BeanContext.beansRequireSerializable";

	/**
	 * Require setters for getters ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, only getters that have equivalent setters will be considered as properties on a bean.
	 * Otherwise, they will be ignored.
	 */
	public static final String BEANS_REQUIRE_SETTERS_FOR_GETTERS = "BeanContext.beansRequireSettersForGetters";

	/**
	 * Require some properties ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * If <jk>true</jk>, then a Java class must contain at least 1 property to be considered a bean.
	 * <p>
	 * The {@link Bean @Bean} annotation can be used on a class to override this setting when <jk>true</jk>.
	 */
	public static final String BEANS_REQUIRE_SOME_PROPERTIES = "BeanContext.beansRequireSomeProperties";

	/**
	 * Put returns old value ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, then the {@link BeanMap#put(String,Object) BeanMap.put()} method will return old property values.
	 * <p>
	 * Disabled by default because it introduces a slight performance penalty.
	 */
	public static final String BEANMAP_PUT_RETURNS_OLD_VALUE = "BeanContext.beanMapPutReturnsOldValue";

	/**
	 * Look for bean constructors with the specified minimum visibility ({@link Visibility}, default={@link Visibility#PUBLIC}).
	 */
	public static final String BEAN_CONSTRUCTOR_VISIBILITY = "BeanContext.beanConstructorVisibility";

	/**
	 * Look for bean classes with the specified minimum visibility ({@link Visibility}, default={@link Visibility#PUBLIC}).
	 * <p>
	 * Classes are not considered beans unless they meet the minimum visibility requirements.
	 * For example, if the visibility is <code>PUBLIC</code> and the bean class is <jk>protected</jk>, then
	 * 	the class will not be interpreted as a bean class.
	 */
	public static final String BEAN_CLASS_VISIBILITY = "BeanContext.beanClassVisibility";

	/**
	 * Look for bean fields with the specified minimum visibility ({@link Visibility}, default={@link Visibility#PUBLIC}).
	 * <p>
	 * Fields are not considered bean properties unless they meet the minimum visibility requirements.
	 * For example, if the visibility is <code>PUBLIC</code> and the bean field is <jk>protected</jk>, then
	 * 	the field will not be interpreted as a bean property.
	 * <p>
	 * Use {@link Visibility#NONE} to prevent bean fields from being interpreted as bean properties altogether.
	 */
	public static final String BEAN_FIELD_VISIBILITY = "BeanContext.beanFieldVisibility";

	/**
	 * Look for bean methods with the specified minimum visibility ({@link Visibility}, default={@link Visibility#PUBLIC}).
	 * <p>
	 * Methods are not considered bean getters/setters unless they meet the minimum visibility requirements.
	 * For example, if the visibility is <code>PUBLIC</code> and the bean method is <jk>protected</jk>, then
	 * 	the method will not be interpreted as a bean getter or setter.
	 */
	public static final String BEAN_METHOD_VISIBILITY = "BeanContext.methodMethodVisibility";

	/**
	 * Use Java {@link Introspector} for determining bean properties ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * Using the built-in Java bean introspector will not pick up fields or non-standard getters/setters.
	 * Most {@link Bean @Bean} annotations will be ignored.
	 */
	public static final String USE_JAVA_BEAN_INTROSPECTOR = "BeanContext.useJavaBeanIntrospector";

	/**
	 * Use interface proxies ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * If <jk>true</jk>, then interfaces will be instantiated as proxy classes through the use of an {@link InvocationHandler}
	 * if there is no other way of instantiating them.
	 */
	public static final String USE_INTERFACE_PROXIES = "BeanContext.useInterfaceProxies";

	/**
	 * Ignore unknown properties ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, trying to set a value on a non-existent bean property will silently be ignored.
	 * Otherwise, a {@code RuntimeException} is thrown.
	 */
	public static final String IGNORE_UNKNOWN_BEAN_PROPERTIES = "BeanContext.ignoreUnknownBeanProperties";

	/**
	 * Ignore unknown properties with null values ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * If <jk>true</jk>, trying to set a <jk>null</jk> value on a non-existent bean property will silently be ignored.
	 * Otherwise, a {@code RuntimeException} is thrown.
	 */
	public static final String IGNORE_UNKNOWN_NULL_BEAN_PROPERTIES = "BeanContext.ignoreUnknownNullBeanProperties";

	/**
	 * Ignore properties without setters ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * If <jk>true</jk>, trying to set a value on a bean property without a setter will silently be ignored.
	 * Otherwise, a {@code RuntimeException} is thrown.
	 */
	public static final String IGNORE_PROPERTIES_WITHOUT_SETTERS = "BeanContext.ignorePropertiesWithoutSetters";

	/**
	 * Ignore invocation errors on getters ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, errors thrown when calling bean getter methods will silently be ignored.
	 * Otherwise, a {@code BeanRuntimeException} is thrown.
	 */
	public static final String IGNORE_INVOCATION_EXCEPTIONS_ON_GETTERS = "BeanContext.ignoreInvocationExceptionsOnGetters";

	/**
	 * Ignore invocation errors on setters ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, errors thrown when calling bean setter methods will silently be ignored.
	 * Otherwise, a {@code BeanRuntimeException} is thrown.
	 */
	public static final String IGNORE_INVOCATION_EXCEPTIONS_ON_SETTERS = "BeanContext.ignoreInvocationExceptionsOnSetters";

	/**
	 * Add to the list of packages whose classes should not be considered beans ({@link String}, comma-delimited list).
	 * <p>
	 * When specified, the current list of ignore packages are appended to.
	 * The default list of ignore packages are as follows:
	 * <ul>
	 * 	<li><code>java.lang</code>
	 * 	<li><code>java.lang.annotation</code>
	 * 	<li><code>java.lang.ref</code>
	 * 	<li><code>java.lang.reflect</code>
	 * 	<li><code>java.io</code>
	 * 	<li><code>java.net</code>
	 * 	<li><code>java.nio.*</code>
	 * 	<li><code>java.util.*</code>
	 * </ul>
	 * Any classes within these packages will be serialized to strings using {@link Object#toString()}.
	 * <p>
	 * Note that you can specify prefix patterns to include all subpackages.
	 */
	public static final String ADD_NOTBEAN_PACKAGES = "BeanContext.addNotBeanPackages";

	/**
	 * Remove from the list of packages whose classes should not be considered beans ({@link String}, comma-delimited list).
	 * <p>
	 * Essentially the opposite of {@link #ADD_NOTBEAN_PACKAGES}.
	 */
	public static final String REMOVE_NOTBEAN_PACKAGES = "BeanContext.removeNotBeanPackages";
}
