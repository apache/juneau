/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.urlencoding;

import static com.ibm.juno.core.urlencoding.UrlEncodingSerializerProperties.*;

import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJO models to UON notation (a notation for URL-encoded query paramter values).
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>application/x-www-form-urlencoded</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>application/x-www-form-urlencoded</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This serializer provides several serialization options.  Typically, one of the predefined DEFAULT serializers will be sufficient.
 * 	However, custom serializers can be constructed to fine-tune behavior.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link UrlEncodingSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 * <p>
 * 	The following shows a sample object defined in Javascript:
 * </p>
 * <p class='bcode'>
 * 	{
 * 		id: 1,
 * 		name: <js>'John Smith'</js>,
 * 		uri: <js>'http://sample/addressBook/person/1'</js>,
 * 		addressBookUri: <js>'http://sample/addressBook'</js>,
 * 		birthDate: <js>'1946-08-12T00:00:00Z'</js>,
 * 		otherIds: <jk>null</jk>,
 * 		addresses: [
 * 			{
 * 				uri: <js>'http://sample/addressBook/address/1'</js>,
 * 				personUri: <js>'http://sample/addressBook/person/1'</js>,
 * 				id: 1,
 * 				street: <js>'100 Main Street'</js>,
 * 				city: <js>'Anywhereville'</js>,
 * 				state: <js>'NY'</js>,
 * 				zip: 12345,
 * 				isCurrent: <jk>true</jk>,
 * 			}
 * 		]
 * 	}
 * </p>
 * <p>
 * 	Using the "strict" syntax defined in this document, the equivalent
 * 		UON notation would be as follows:
 * </p>
 * <p class='bcode'>
 * 	$o(
 * 		<xa>id</xa>=$n(<xs>1</xs>),
 * 		<xa>name</xa>=<xs>John+Smith</xs>,
 * 		<xa>uri</xa>=<xs>http://sample/addressBook/person/1</xs>,
 * 		<xa>addressBookUri</xa>=<xs>http://sample/addressBook</xs>,
 * 		<xa>birthDate</xa>=<xs>1946-08-12T00:00:00Z</xs>,
 * 		<xa>otherIds</xa>=<xs>%00</xs>,
 * 		<xa>addresses</xa>=$a(
 * 			$o(
 * 				<xa>uri</xa>=<xs>http://sample/addressBook/address/1</xs>,
 * 				<xa>personUri</xa>=<xs>http://sample/addressBook/person/1</xs>,
 * 				<xa>id</xa>=$n(<xs>1</xs>),
 * 				<xa>street</xa>=<xs>100+Main+Street</xs>,
 * 				<xa>city</xa>=<xs>Anywhereville</xs>,
 * 				<xa>state</xa>=<xs>NY</xs>,
 * 				<xa>zip</xa>=$n(<xs>12345</xs>),
 * 				<xa>isCurrent</xa>=$b(<xs>true</xs>)
 * 			)
 * 		)
 * 	)
 * </p>
 * <p>
 * 	A secondary "lax" syntax is available when the data type of the
 * 		values are already known on the receiving end of the transmission:
 * </p>
 * <p class='bcode'>
 * 	(
 * 		<xa>id</xa>=<xs>1</xs>,
 * 		<xa>name</xa>=<xs>John+Smith</xs>,
 * 		<xa>uri</xa>=<xs>http://sample/addressBook/person/1</xs>,
 * 		<xa>addressBookUri</xa>=<xs>http://sample/addressBook</xs>,
 * 		<xa>birthDate</xa>=<xs>1946-08-12T00:00:00Z</xs>,
 * 		<xa>otherIds</xa>=<xs>%00</xs>,
 * 		<xa>addresses</xa>=(
 * 			(
 * 				<xa>uri</xa>=<xs>http://sample/addressBook/address/1</xs>,
 * 				<xa>personUri</xa>=<xs>http://sample/addressBook/person/1</xs>,
 * 				<xa>id</xa>=<xs>1</xs>,
 * 				<xa>street</xa>=<xs>100+Main+Street</xs>,
 * 				<xa>city</xa>=<xs>Anywhereville</xs>,
 * 				<xa>state</xa>=<xs>NY</xs>,
 * 				<xa>zip</xa>=<xs>12345</xs>,
 * 				<xa>isCurrent</xa>=<xs>true</xs>
 * 			)
 * 		)
 * 	)
 * </p>
 * <p>
 * 	Also, a {@link #serializeParams(Object)} method is provided for serializing
 * 		maps and beans to entire URL query strings:
 * </p>
 * <p class='bcode'>
 * 	<xa>id</xa>=$n(<xs>1</xs>)&
 * 	<xa>name</xa>=<xs>John+Smith</xs>&
 * 	<xa>uri</xa>=<xs>http://sample/addressBook/person/1</xs>&
 * 	<xa>addressBookUri</xa>=<xs>http://sample/addressBook</xs>&
 * 	<xa>birthDate</xa>=<xs>1946-08-12T00:00:00Z</xs>&
 * 	<xa>otherIds</xa>=<xs>%00</xs>&
 * 	<xa>addresses</xa>=$a(
 * 		$o(
 * 			<xa>uri</xa>=<xs>http://sample/addressBook/address/1</xs>,
 * 			<xa>personUri</xa>=<xs>http://sample/addressBook/person/1</xs>,
 * 			<xa>id</xa>=$n(<xs>1</xs>),
 * 			<xa>street</xa>=<xs>100+Main+Street</xs>,
 * 			<xa>city</xa>=<xs>Anywhereville</xs>,
 * 			<xa>state</xa>=<xs>NY</xs>,
 * 			<xa>zip</xa>=$n(<xs>12345</xs>),
 * 			<xa>isCurrent</xa>=$b(<xs>true</xs>)
 * 		)
 * 	)
 * </p>
 *
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Serialize a Map</jc>
 * 	Map m = <jk>new</jk> ObjectMap(<js>"{a:'b',c:1,d:false,e:['f',1,false],g:{h:'i'}}"</js>);
 *
 * 	<jc>// Serialize to value equivalent to JSON.</jc>
 * 	<jc>// Produces "$o(a=b,c=$n(1),d=$b(false),e=$a(f,$n(1),$b(false)),g=$o(h=i))"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT</jsf>.serialize(s);
 *
 * 	<jc>// Serialize to simplified value (for when data type is already known by receiver).</jc>
 * 	<jc>// Produces "(a=b,c=1,d=false,e=(f,1,false),g=(h=i))"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT_SIMPLE</jsf>.serialize(s);
 *
 * 	<jc>// Serialize a bean</jc>
 * 	<jk>public class</jk> Person {
 * 		<jk>public</jk> Person(String s);
 * 		<jk>public</jk> String getName();
 * 		<jk>public int</jk> getAge();
 * 		<jk>public</jk> Address getAddress();
 * 		<jk>public boolean</jk> deceased;
 * 	}
 *
 * 	<jk>public class</jk> Address {
 * 		<jk>public</jk> String getStreet();
 * 		<jk>public</jk> String getCity();
 * 		<jk>public</jk> String getState();
 * 		<jk>public int</jk> getZip();
 * 	}
 *
 * 	Person p = <jk>new</jk> Person(<js>"John Doe"</js>, 23, <js>"123 Main St"</js>, <js>"Anywhere"</js>, <js>"NY"</js>, 12345, <jk>false</jk>);
 *
 * 	<jc>// Produces "name=John+Doe&amp;age=23&amp;address=$o(street=123+Main+St,city=Anywhere,state=NY,zip=$n(12345))&amp;deceased=$b(false)"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT</jsf>.serializeParams(s);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Produces("application/x-www-form-urlencoded")
public class UrlEncodingSerializer extends WriterSerializer {

	/** Reusable instance of {@link UrlEncodingSerializer}, all default settings. */
	public static final UrlEncodingSerializer DEFAULT = new UrlEncodingSerializer().lock();

	/** Reusable instance of {@link UrlEncodingSerializer.Simple}. */
	public static final UrlEncodingSerializer DEFAULT_SIMPLE = new Simple().lock();

	/** Reusable instance of {@link UrlEncodingSerializer.Readable}. */
	public static final UrlEncodingSerializer DEFAULT_READABLE = new Readable().lock();

	/** Reusable instance of {@link UrlEncodingSerializer.Unencoded}. */
	public static final UrlEncodingSerializer DEFAULT_UNENCODED = new Unencoded().lock();

	/** Reusable instance of {@link UrlEncodingSerializer.SimpleUnencoded}. */
	public static final UrlEncodingSerializer DEFAULT_SIMPLE_UNENCODED = new SimpleUnencoded().lock();

	/**
	 * Equivalent to <code><jk>new</jk> UrlEncodingSerializer().setProperty(<jsf>SIMPLE_MODE</jsf>,<jk>true</jk>);</code>.
	 */
	@Produces(value={"application/x-www-form-urlencoded-simple"},contentType="application/x-www-form-urlencoded")
	public static class Simple extends UrlEncodingSerializer {
		/** Constructor */
		public Simple() {
			setProperty(SIMPLE_MODE, true);
		}
	}

	/**
	 * Equivalent to <code><jk>new</jk> UrlEncodingSerializer().setProperty(<jsf>USE_WHITESPACE</jsf>,<jk>true</jk>);</code>.
	 */
	public static class Readable extends UrlEncodingSerializer {
		/** Constructor */
		public Readable() {
			setProperty(USE_WHITESPACE, true);
		}
	}

	/**
	 * Equivalent to <code><jk>new</jk> UrlEncodingSerializer().setProperty(<jsf>ENCODE_CHARS</jsf>,<jk>false</jk>);</code>.
	 */
	public static class Unencoded extends UrlEncodingSerializer {
		/** Constructor */
		public Unencoded() {
			setProperty(ENCODE_CHARS, false);
		}
	}

	/**
	 * Equivalent to <code><jk>new</jk> UrlEncodingSerializer().setProperty(<jsf>SIMPLE_MODE</jsf>,<jk>true</jk>).setProperty(<jsf>ENCODE_CHARS</jsf>,<jk>false</jk>);</code>.
	 */
	@Produces(value={"application/x-www-form-urlencoded-simple"},contentType="application/x-www-form-urlencoded")
	public static class SimpleUnencoded extends UrlEncodingSerializer {
		/** Constructor */
		public SimpleUnencoded() {
			setProperty(SIMPLE_MODE, true);
			setProperty(ENCODE_CHARS, false);
		}
	}

	/** URL-encoding serializer properties currently set on this serializer. */
	protected transient UrlEncodingSerializerProperties usp = new UrlEncodingSerializerProperties();


	/**
	 * Workhorse method. Determines the type of object, and then calls the
	 * appropriate type-specific serialization method.
	 * @param quoteEmptyStrings - <jk>true</jk> if this is the first entry in an array.
	 * @param isTopValue - <jk>true</jk> if we're serializing a top-level parameter.
	 * 	Use to determine whether we should be escaping characters on strings.
	 * @param isParams - <jk>true</jk> if we're serializing to &key=value pairs.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private SerializerWriter serializeAnything(UrlEncodingSerializerWriter out, Object o, ClassMeta<?> eType, UrlEncodingSerializerContext ctx,
			String attrName, BeanPropertyMeta pMeta, boolean quoteEmptyStrings, /*boolean isTopValuex,*/ boolean isParams) throws SerializeException {
		try {

			BeanContext bc = ctx.getBeanContext();

			if (o == null) {
				out.appendObject(null, false, false);
				return out;
			}

			if (eType == null)
				eType = object();

			boolean addClassAttr;		// Add "_class" attribute to element?
			ClassMeta<?> aType;			// The actual type
			ClassMeta<?> gType;			// The generic type

			aType = ctx.push(attrName, o, eType);
			boolean isRecursion = aType == null;

			// Handle recursion
			if (aType == null) {
				o = null;
				aType = object();
			}

			gType = aType.getFilteredClassMeta();
			addClassAttr = (ctx.isAddClassAttrs() && ! eType.equals(aType));

			// Filter if necessary
			PojoFilter filter = aType.getPojoFilter();				// The filter
			if (filter != null) {
				o = filter.filter(o);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType.isObject())
					gType = bc.getClassMetaForObject(o);
			}

			// '\0' characters are considered null.
			if (o == null || (gType.isChar() && ((Character)o).charValue() == 0))
				out.appendObject(null, false, isParams);
			else if (gType.isBean())
				serializeBeanMap(out, bc.forBean(o), addClassAttr, ctx, isParams);
			else if (gType.isUri() || (pMeta != null && (pMeta.isUri() || pMeta.isBeanUri())))
				out.appendUri(o);
			else if (gType.isMap()) {
				if (o instanceof BeanMap)
					serializeBeanMap(out, (BeanMap)o, addClassAttr, ctx, isParams);
				else
					serializeMap(out, (Map)o, eType, ctx, isParams);
			}
			else if (gType.isCollection()) {
				if (addClassAttr)
					serializeCollectionMap(out, (Collection)o, gType, ctx, isParams);
				else
					serializeCollection(out, (Collection) o, eType, ctx);
			}
			else if (gType.isArray()) {
				if (addClassAttr)
					serializeCollectionMap(out, toList(gType.getInnerClass(), o), gType, ctx, isParams);
				else
					serializeCollection(out, toList(gType.getInnerClass(), o), eType, ctx);
			}
			else {
				out.appendObject(o, quoteEmptyStrings, isParams);
			}

			if (! isRecursion)
				ctx.pop();
			return out;
		} catch (SerializeException e) {
			throw e;
		} catch (StackOverflowError e) {
			throw e;
		} catch (Throwable e) {
			throw new SerializeException("Exception occured trying to process object of type ''{0}''", (o == null ? null : o.getClass().getName())).initCause(e);
		}
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeMap(UrlEncodingSerializerWriter out, Map m, ClassMeta<?> type, UrlEncodingSerializerContext ctx, boolean isParams) throws IOException, SerializeException {

		char sep = isParams ? '&' : ',';

		ClassMeta<?> keyType = type.getKeyType(), valueType = type.getValueType();

		int depth = ctx.getIndent();
		if (! isParams)
			out.startFlag('o');

		Iterator mapEntries = m.entrySet().iterator();

		while (mapEntries.hasNext()) {
			Map.Entry e = (Map.Entry) mapEntries.next();
			Object value = e.getValue();
			Object key = generalize(ctx, e.getKey(), keyType);
			out.cr(depth).appendObject(key, false, isParams).append('=').s();
			serializeAnything(out, value, valueType, ctx, (key == null ? null : key.toString()), null, false, false);
			if (mapEntries.hasNext())
				out.append(sep).s();
		}

		out.cr(depth-1).appendIf(!isParams, ')');

		return out;
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeCollectionMap(UrlEncodingSerializerWriter out, Collection o, ClassMeta<?> type, UrlEncodingSerializerContext ctx, boolean isParams) throws IOException, SerializeException {
		int i = ctx.getIndent();
		if (! isParams)
			out.startFlag('o').nl();
		out.append(i, "_class=").s().appendObject(type, false, false).append(',').nl();
		out.append(i, "items=").s();
		ctx.indent++;
		serializeCollection(out, o, type, ctx);
		ctx.indent--;
		out.cr(i-1).appendIf(!isParams, ')');
		return out;
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeBeanMap(UrlEncodingSerializerWriter out, BeanMap m, boolean addClassAttr, UrlEncodingSerializerContext ctx, boolean isParams) throws IOException, SerializeException {
		int depth = ctx.getIndent();
		char sep = isParams ? '&' : ',';

		if (! isParams)
			out.startFlag('o');

		Iterator mapEntries = m.entrySet().iterator();

		// Print out "_class" attribute on this bean if required.
		if (addClassAttr) {
			String attr = "_class";
			out.cr(depth).appendObject(attr, false, false).append('=').s().append(m.getClassMeta().getInnerClass().getName());
			if (mapEntries.hasNext())
				out.append(sep).s();
		}

		boolean addComma = false;

		while (mapEntries.hasNext()) {
			BeanMapEntry p = (BeanMapEntry)mapEntries.next();
			BeanPropertyMeta pMeta = p.getMeta();

			if (canIgnoreProperty(ctx, pMeta))
				continue;

			String key = p.getKey();
			Object value = null;
			try {
				value = p.getFilteredValue();
			} catch (StackOverflowError e) {
				throw e;
			} catch (Throwable t) {
				ctx.addBeanGetterWarning(pMeta, t);
			}

			if (canIgnoreValue(ctx, pMeta.getClassMeta(), key, value))
				continue;

			if (addComma)
				out.append(sep).s();

			out.cr(depth).appendObject(key, false, isParams).append('=').s();

			serializeAnything(out, value, pMeta.getClassMeta(), ctx, key, pMeta, false, false);

			addComma = true;
		}
		out.cr(depth-1).appendIf(! isParams, ')');
		return out;
	}

	@SuppressWarnings("rawtypes")
	private SerializerWriter serializeCollection(UrlEncodingSerializerWriter out, Collection c, ClassMeta<?> type, UrlEncodingSerializerContext ctx) throws IOException, SerializeException {

		ClassMeta<?> elementType = type.getElementType();

		out.startFlag('a');

		int depth = ctx.getIndent();
		boolean quoteEmptyString = c.size() == 1;

		for (Iterator i = c.iterator(); i.hasNext();) {
			out.cr(depth);
			serializeAnything(out, i.next(), elementType, ctx, "<iterator>", null, quoteEmptyString, false);
			if (i.hasNext())
				out.append(',').s();
		}
		out.cr(depth-1).append(')');
		return out;
	}

	//--------------------------------------------------------------------------------
	// Methods for constructing individual parameter values.
	//--------------------------------------------------------------------------------

	/**
	 * Similar in concept to {@link #doSerialize(Object, Writer, SerializerContext)} except maps and beans
	 * 	are serialized to <js>"key1=val1&key2=val2"</js> instead of <js>"(key1=val1,key2=val2)"</js>.
	 * <p>
	 * Intended to be used when constructing a full query string from a map or bean.
	 * <p>
	 * Invalid URI characters are always encoded regardless of {@link UrlEncodingSerializerProperties#ENCODE_CHARS} setting.
	 *
	 * @param o The object to serialize.
	 * @param out The writer or output stream to write to.
	 *
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serializeParams(Object o, Writer out) throws IOException, SerializeException {
		UrlEncodingSerializerContext ctx = createContext(null, null);
		try {
			ctx.encodeChars = true;  // Override ENCODE_CHARS setting.  Cannot produce a valid URL paramters string if disabled.
			serializeAnything(ctx.getWriter(out), o, null, ctx, "root", null, false, true);
		} finally {
			ctx.close();
		}
	}

	/**
	 * Same as {@link #serializeParams(Object, Writer)} except writes to a string.
	 *
	 * @param o The object to serialize.
	 *
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 * @return The output serialized to a string.
	 */
	public String serializeParams(Object o) throws SerializeException {
		StringWriter sw = new StringWriter();
		try {
			serializeParams(o, sw);
		} catch (IOException e) {
			throw new RuntimeException(e); // Shouldn't happen.
		}
		return sw.toString();
	}

	/**
	 * Converts the specified object to a string using this serializers {@link BeanContext#convertToType(Object, Class)} method
	 * 	and runs {@link URLEncoder#encode(String,String)} against the results.
	 * Useful for constructing URL parts.
	 */
	public String serializeUrlPart(Object o) {
		String s = getBeanContext().convertToType(o, String.class);
		try {
			return URLEncoder.encode(s, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Serializer
	public UrlEncodingSerializerContext createContext(ObjectMap properties, Method javaMethod) {
		return new UrlEncodingSerializerContext(getBeanContext(), sp, usp, properties, javaMethod);
	}

	@Override // Serializer
	protected void doSerialize(Object o, Writer out, SerializerContext ctx) throws IOException, SerializeException {
		UrlEncodingSerializerContext uctx = (UrlEncodingSerializerContext)ctx;
		serializeAnything(uctx.getWriter(out), o, null, uctx, "root", null, false, false);
	}

	@Override // CoreApi
	public UrlEncodingSerializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (! usp.setProperty(property, value))
			super.setProperty(property, value);
		return this;
	}

	@Override // CoreApi
	public UrlEncodingSerializer setProperties(ObjectMap properties) throws LockedException {
		for (Map.Entry<String,Object> e : properties.entrySet())
			setProperty(e.getKey(), e.getValue());
		return this;
	}

	@Override // CoreApi
	public UrlEncodingSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public UrlEncodingSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> UrlEncodingSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // Lockable
	public UrlEncodingSerializer lock() {
		super.lock();
		return this;
	}

	@Override // Lockable
	public UrlEncodingSerializer clone() {
		try {
			UrlEncodingSerializer c = (UrlEncodingSerializer)super.clone();
			c.usp = usp.clone();
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
