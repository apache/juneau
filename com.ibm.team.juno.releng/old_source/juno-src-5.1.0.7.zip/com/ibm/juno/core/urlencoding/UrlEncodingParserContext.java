/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.urlencoding;

import static com.ibm.juno.core.urlencoding.UrlEncodingParserProperties.*;

import java.io.*;
import java.lang.reflect.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;

/**
 * Context object that lives for the duration of a single parsing of {@link UrlEncodingParser}.
 * <p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingParserContext extends ParserContext {

	private boolean decodeChars;

	/**
	 * Create a new parser context with the specified options.
	 *
	 * @param beanContext The bean context being used.
	 * @param pp The default parser properties.
	 * @param op The override properties.
	 */
	public UrlEncodingParserContext(BeanContext beanContext, ParserProperties pp, UrlEncodingParserProperties upp, ObjectMap op, Method javaMethod) {
		super(beanContext, pp, op, javaMethod);
		if (op == null || op.isEmpty()) {
			decodeChars = upp.decodeChars;
		} else {
			decodeChars = op.getBoolean(DECODE_CHARS, upp.decodeChars);
		}
	}

	/**
	 * Wraps the specified reader in a {@link UrlEncodingParserReader}.
	 */
	protected final UrlEncodingParserReader getUrlEncodingParserReader(Reader r) {
		if (r instanceof UrlEncodingParserReader)
			return (UrlEncodingParserReader)r;
		return new UrlEncodingParserReader(r, 1024, decodeChars);
	}
}
