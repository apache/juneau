/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.urlencoding;

import static com.ibm.juno.core.urlencoding.UrlEncodingSerializerProperties.*;

import java.io.*;
import java.lang.reflect.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Context object that lives for the duration of a single serialization of {@link UrlEncodingSerializer}.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingSerializerContext extends SerializerContext {

	boolean simpleMode, useWhitespace, encodeChars;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param usp Default URL-Encoding serializer properties.
	 * @param op Override properties.
	 * @param javaMethod Java method that invoked this serializer.
	 * 	When using the REST API, this is the Java method invoked by the REST call.
	 * 	Can be used to access annotations defined on the method or class.
	 */
	protected UrlEncodingSerializerContext(BeanContext beanContext, SerializerProperties sp, UrlEncodingSerializerProperties usp, ObjectMap op, Method javaMethod) {
		super(beanContext, sp, op, javaMethod);
		if (op == null || op.isEmpty()) {
			simpleMode = usp.simpleMode;
			useWhitespace = usp.useWhitespace;
			encodeChars = usp.encodeChars;
		} else {
			simpleMode = op.getBoolean(SIMPLE_MODE, usp.simpleMode);
			useWhitespace = op.getBoolean(USE_WHITESPACE, usp.useWhitespace);
			encodeChars = op.getBoolean(ENCODE_CHARS, usp.encodeChars);
		}
	}

	/**
	 * Returns the {@link UrlEncodingSerializerProperties#SIMPLE_MODE} setting value in this context.
	 * @return The {@link UrlEncodingSerializerProperties#SIMPLE_MODE} setting value in this context.
	 */
	public final boolean isSimpleMode() {
		return simpleMode;
	}

	/**
	 * Returns the {@link UrlEncodingSerializerProperties#USE_WHITESPACE} setting value in this context.
	 * @return The {@link UrlEncodingSerializerProperties#USE_WHITESPACE} setting value in this context.
	 */
	public final boolean isUseWhitespace() {
		return useWhitespace;
	}

	/**
	 * Returns the {@link UrlEncodingSerializerProperties#ENCODE_CHARS} setting value in this context.
	 * @return The {@link UrlEncodingSerializerProperties#ENCODE_CHARS} setting value in this context.
	 */
	public final boolean isEncodeChars() {
		return encodeChars;
	}

	/**
	 * Wraps the specified writer in a {@link UrlEncodingSerializerWriter}.
	 */
	protected UrlEncodingSerializerWriter getWriter(Writer out) {
		if (out instanceof UrlEncodingSerializerWriter)
			return (UrlEncodingSerializerWriter)out;
		return new UrlEncodingSerializerWriter(out, isUseIndentation(), isUseWhitespace(), isSimpleMode(), isEncodeChars(), getUriContext(), getUriAuthority());
	}
}
