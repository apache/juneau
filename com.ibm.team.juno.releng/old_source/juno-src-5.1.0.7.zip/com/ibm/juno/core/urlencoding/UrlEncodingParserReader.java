/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.urlencoding;

import java.io.*;

import com.ibm.juno.core.parser.*;

/**
 * Same functionality as {@link ParserReader} except automatically decoded <code>%xx</code> escape sequences.
 * <p>
 * Escape sequences are assumed to be encoded UTF-8.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingParserReader extends ParserReader {

	private final boolean decodeChars;

	/**
	 * Constructor for input from a {@link CharSequence}.
	 *
	 * @param in The character sequence being read from.
	 * @param decodeChars If <jk>true</jk>, decode <code>%xx</code> escape sequences.
	 */
	public UrlEncodingParserReader(CharSequence in, boolean decodeChars) {
		super(in);
		this.decodeChars = decodeChars;
	}

	/**
	 * Constructor for input from a {@link Reader}).
	 * <p>
	 * 	Automatically wraps the reader in a {@link BufferedReader} if it isn't already a buffered reader.
	 *
	 * @param r The Reader being wrapped.
	 * @param buffSize Buffer size.
	 * @param decodeChars If <jk>true</jk>, decode <code>%xx</code> escape sequences.
	 */
	public UrlEncodingParserReader(Reader r, int buffSize, boolean decodeChars) {
		super(r, buffSize);
		this.decodeChars = decodeChars;
	}

	@Override
	public int read() throws IOException {
		if (isUnread) {
			isUnread = false;
			if (isMarking)
				addMark(lastChar);
			return lastChar;
		}
		int c = r.read();
		if (decodeChars) {
			if (c == '+')
				c = ' ';
			else if (c == '%') {
				int b0 = readEncodedByte();

				// 0xxxxxxx
				if (b0 < 128)
					c = b0;

				// 10xxxxxx
				else if (b0 < 192)
					throw new IOException("Invalid hex value for first escape pattern in UTF-8 sequence:  " + b0);

				// 110xxxxx	10xxxxxx
				// 11000000(192) - 11011111(223)
				else if (b0 < 224)
					c = readUTF8(b0-192, 1);

				// 1110xxxx	10xxxxxx	10xxxxxx
				// 11100000(224) - 11101111(239)
				else if (b0 < 240)
					c = readUTF8(b0-224, 2);

				// 11110xxx	10xxxxxx	10xxxxxx	10xxxxxx
				// 11110000(240) - 11110111(247)
				else if (b0 < 248)
					c = readUTF8(b0-240, 3);

				else
					throw new IOException("Invalid hex value for first escape pattern in UTF-8 sequence:  " + b0);
			}
		}

		length++;
		lastChar = c;
		if (lastChar == '\n') {
			line++;
			column = 0;
		} else {
			column++;
		}
		if (isMarking && c != -1)
			addMark(lastChar);
		return c;
	}

	private int readUTF8(int n, final int numBytes) throws IOException {
		for (int i = 0; i < numBytes; i++) {
			n <<= 6;
			n += readHex()-128;
		}
		return n;
	}

	private int readHex() throws IOException {
		int c = r.read();
		if (c != '%')
			throw new IOException("Did not find expected '%' character in UTF-8 sequence.");
		return readEncodedByte();
	}

	private int readEncodedByte() throws IOException {
		int h = r.read();
		int l = r.read();
		if (l == -1)
			throw new IOException("Incomplete trailing escape pattern");
		h = fromHexChar(h);
		l = fromHexChar(l);
		return (h << 4) + l;
	}

	private int fromHexChar(int c) throws IOException {
		if (c >= '0' && c <= '9')
			return c - '0';
		if (c >= 'a' && c <= 'f')
			return 10 + c - 'a';
		if (c >= 'A' && c <= 'F')
			return 10 + c - 'A';
		throw new IOException("Invalid hex character '"+c+"' found in escape pattern.");
	}
}
