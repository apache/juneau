/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.utils.*;

/**
 * Similar to a {@link java.io.PushbackReader} with a pushback buffer of 1 character.
 * <p>
 * 	Code is optimized to work with a 1 character buffer.
 * <p>
 * 	Additionally keeps track of current line and column number, and provides the ability to set
 * 	mark points and capture characters from the previous mark point.
 * <p>
 * 	<b>Warning:</b>  Not thread safe.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserReader extends Reader {

	/** Wrapped reader */
	protected Reader r;

	/** Last character parsed */
	protected int lastChar;

	/** Current line number */
	protected int line = 1;

	/** Current column number */
	protected int column;

	/** Current number of codepoints read */
	protected int length;

	/** Tracks whether {@link #unread() has been called} */
	protected boolean isUnread;

	/** Tracks whether {@link #mark()} has been called */
	protected boolean isMarking;

	private StringBuilder markBuilder;		// Reusable mark builder.

	ParserReader() {
	}

	/**
	 * Constructor for input from a {@link CharSequence}.
	 *
	 * @param in The character sequence being read from.
	 */
	public ParserReader(CharSequence in) {
		this.r = new CharSequenceReader(in);
	}

	/**
	 * Constructor for input from a {@link Reader}).
	 * <p>
	 * 	Automatically wraps the reader in a {@link BufferedReader} if it isn't already a buffered reader.
	 *
	 * @param r The Reader being wrapped.
	 * @param buffSize The buffer size to use for the buffered reader.
	 */
	public ParserReader(Reader r, int buffSize) {
		if (r instanceof ParserReader)
			this.r = ((ParserReader)r).r;
		else
			this.r = IOUtils.getBufferedReader(r, buffSize);
	}

	/**
	 * Returns the current line number position in this reader.
	 *
	 * @return The current line number.
	 */
	public int getLine() {
		return line;
	}

	/**
	 * Returns the current column number position in this reader.
	 *
	 * @return The current column number.
	 */
	public int getColumn() {
		return column;
	}

	/**
	 * Reads a single character.
	 *
	 * @return The character read, or -1 if the end of the stream has been reached.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@Override // Reader
	public int read() throws IOException {
		if (isUnread) {
			isUnread = false;
			if (isMarking)
				addMark(lastChar);
			return lastChar;
		}
		int x = r.read();
		length++;
		lastChar = x;
		if (lastChar == '\n') {
			line++;
			column = 0;
		} else {
			column++;
		}
		if (isMarking && x != -1)
			addMark(lastChar);
		return x;
	}

	/**
	 * Start buffering the calls to read() so that the text can be gathered from the mark
	 * point on calling {@code getFromMarked()}.
	 */
	public void mark() {
		isMarking = true;
		if (markBuilder == null)
			markBuilder = new StringBuilder();
		markBuilder.setLength(0);
	}


	/**
	 * Returns the number of characters that were parsed in this stream.
	 *
	 * @return The character count.
	 */
	public int getLength() {
		return length;
	}

	/**
	 * Peeks the next character in the stream.
	 * <p>
	 * 	This is equivalent to doing a {@code read()} followed by an {@code unread()}.
	 *
	 * @return The peeked character, or (char)-1 if the end of the stream has been reached.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public int peek() throws IOException {
		int c = read();
		unread();
		return c;
	}

	/**
	 * Read the specified number of characters off the stream.
	 *
	 * @param num The number of characters to read.
	 * @return The characters packaged as a String.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public String read(int num) throws IOException {
		StringBuilder sb = new StringBuilder(num);
		for (int i = 0; i < num; i++)
			sb.appendCodePoint(read());
		return sb.toString();
	}

	/**
	 * Pushes the last read character back into the stream.
	 *
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public ParserReader unread() throws IOException {
		if (isUnread)
			throw new IOException("Buffer overflow.  Cannot unread more than one character.");
		if (lastChar != -1) {
			isUnread = true;
			// If we're unreading while marking, we need to trim the buffer back a codepoint.
			// Note that \u10000+ codepoints are two characters.
			if (isMarking)
				markBuilder.setLength(markBuilder.length()-(lastChar >= 0x10000 ? 2 : 1));
		}
		return this;
	}

	/**
	 * Close this reader and the underlying reader.
	 *
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@Override
	public void close() throws IOException {
		r.close();
	}

	/**
	 * Adds a character to the reusable character buffer.
	 *
	 * @param codepoint The character to add to the reusable buffer.
	 */
	protected void addMark(int codepoint) {
		if (markBuilder == null)
			 markBuilder = new StringBuilder();
		markBuilder.appendCodePoint(codepoint);
	}

	/**
	 * Returns the contents of the reusable character buffer as a string, and
	 * resets the buffer for next usage.
	 *
	 * @return The contents of the reusable character buffer as a string.
	 */
	public String getMarked() {
		return getMarked(0, 0);
	}

	/**
	 * Same as {@link #getMarked()} except allows you to specify offsets
	 * 	into the buffer.
	 * <p>
	 * For example, to return the marked string, but trim the first and last characters,
	 * 	call the following:
	 * <p class='bcode'>
	 * 	getFromMarked(1, -1);
	 * </p>
	 *
	 * @param offsetStart The offset of the start position.
	 * @param offsetEnd The offset of the end position.
	 * @return The contents of the reusable character buffer as a string.
	 */
	public String getMarked(int offsetStart, int offsetEnd) {
		if (markBuilder == null)
			return "";
		String s = markBuilder.substring(offsetStart, markBuilder.length()+offsetEnd);
		markBuilder.setLength(0);
		isMarking = false;
		return s;
	}

	/**
	 * Trims off the last character in the marking buffer.
	 * Useful for removing escape characters from sequences.
	 */
	public ParserReader unreadMark() {
		return unreadMark(1);
	}

	/**
	 * Trims off the specified number of last characters in the marking buffer.
	 * Useful for removing escape characters from sequences.
	 */
	public ParserReader unreadMark(int count) {
		markBuilder.setLength(markBuilder.length()-count);
		return this;
	}

	/**
	 * Appends a character to the end of the marking buffer.
	 */
	public ParserReader appendMark(int codepoint) {
		markBuilder.appendCodePoint(codepoint);
		return this;
	}

	/**
	 * Replaces the last character in the marking buffer with the specified character.
	 */
	public ParserReader replaceMark(int codepoint) {
		unreadMark().appendMark(codepoint);
		return this;
	}

	@Override
	public int read(char[] cbuf, int off, int len) throws IOException {
		for (int i = 0; i < len; i++) {
			int c = read();
			if (c == -1) {
				if (i == 0)
					return -1;
				return i;
			}
			cbuf[off+i] = (char)c;
		}
		return len;
	}
}
