/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.html;

import static com.ibm.juno.core.html.HtmlDocSerializerProperties.*;
import static com.ibm.juno.core.html.HtmlSerializerProperties.*;

import java.io.*;
import java.lang.reflect.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Context object that lives for the duration of a single serialization of {@link HtmlSerializer} and its subclasses.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlSerializerContext extends XmlSerializerContext {

	private final String uriAnchorText, title, description, cssUrl;
	private final ObjectMap links;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param hsp Default HTML serializer properties.
	 * @param op Override properties.
	 * @param javaMethod Java method that invoked this serializer.
	 * 	When using the REST API, this is the Java method invoked by the REST call.
	 * 	Can be used to access annotations defined on the method or class.
	 */
	protected HtmlSerializerContext(BeanContext beanContext, SerializerProperties sp, XmlSerializerProperties xsp, HtmlSerializerProperties hsp, ObjectMap op, Method javaMethod) {
		super(beanContext, sp, xsp, op, javaMethod);
		if (op == null || op.isEmpty()) {
			uriAnchorText = hsp.uriAnchorText;
			title = hsp.title;
			description = hsp.description;
			links = hsp.links;
			cssUrl = hsp.cssUrl;
		} else {
			uriAnchorText = op.getString(URI_ANCHOR_TEXT, hsp.uriAnchorText);
			title = op.getString(HTML_TITLE, hsp.title);
			description = op.getString(HTML_DESCRIPTION, hsp.description);
			links = op.getObjectMap(HTML_LINKS, hsp.links);
			cssUrl = op.getString(HTML_CSS_URL, hsp.cssUrl);
		}
	}

	/**
	 * Returns the {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} setting value in this context.
	 * @return The {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} setting value in this context.
	 */
	public final String getUriAnchorText() {
		return uriAnchorText;
	}

	/**
	 * Returns the {@link HtmlDocSerializerProperties#HTML_TITLE} setting value in this context.
	 * @return The {@link HtmlDocSerializerProperties#HTML_TITLE} setting value in this context.
	 */
	public final String getTitle() {
		return title;
	}

	/**
	 * Returns the {@link HtmlDocSerializerProperties#HTML_DESCRIPTION} setting value in this context.
	 * @return The {@link HtmlDocSerializerProperties#HTML_DESCRIPTION} setting value in this context.
	 */
	public final String getDescription() {
		return description;
	}

	/**
	 * Returns the {@link HtmlDocSerializerProperties#HTML_LINKS} setting value in this context.
	 * @return The {@link HtmlDocSerializerProperties#HTML_LINKS} setting value in this context.
	 */
	public final ObjectMap getLinks() {
		return links;
	}

	/**
	 * Returns the {@link HtmlDocSerializerProperties#HTML_CSS_URL} setting value in this context.
	 * @return The {@link HtmlDocSerializerProperties#HTML_CSS_URL} setting value in this context.
	 */
	public final String getCssUrl() {
		return cssUrl;
	}

	/**
	 * Wraps the specified writer in a {@link HtmlSerializerWriter}.
	 */
	@Override
	public HtmlSerializerWriter getWriter(Writer w) {
		if (w instanceof HtmlSerializerWriter)
			return (HtmlSerializerWriter)w;
		return new HtmlSerializerWriter(w, isUseIndentation(), getQuoteChar(), getUriContext(), getUriAuthority());
	}
}
