/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.json;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.annotation.*;

/**
 * JSON utility methods.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonUtils {

	/**
	 * Returns the value of the {@link Json#wrapperAttr()} annotation on the specified class,
	 * 	or <jk>null</jk> if not specified.
	 */
	public static String getWrapperAttr(ClassMeta<?> cm) {
		Json json = cm.getJsonAnnotation();
		return (json == null || json.wrapperAttr().isEmpty() ? null : json.wrapperAttr());
	}
}
