/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.json;

import static com.ibm.juno.core.json.JsonParserProperties.*;

import java.io.*;
import java.lang.reflect.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;

/**
 * Context object that lives for the duration of a single parsing of {@link JsonParser}.
 * <p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonParserContext extends ParserContext {

	private final boolean strictMode;

	/**
	 * Create a new parser context with the specified options.
	 *
	 * @param beanContext The bean context being used.
	 * @param jpp The JSON parser properties.
	 * @param pp The default parser properties.
	 * @param op The override properties.
	 */
	public JsonParserContext(BeanContext beanContext, JsonParserProperties jpp, ParserProperties pp, ObjectMap op, Method javaMethod) {
		super(beanContext, pp, op, javaMethod);
		if (op == null || op.isEmpty()) {
			strictMode = jpp.isStrictMode();
		} else {
			strictMode = op.getBoolean(STRICT_MODE, jpp.isStrictMode());
		}
	}

	/**
	 * Returns the {@link JsonParserProperties#STRICT_MODE} setting in this context.
	 */
	public boolean isStrictMode() {
		return strictMode;
	}

	/**
	 * Returns the reader associated with this context wrapped in a {@link ParserReader}.
	 */
	public ParserReader getReader(Reader in) {
		if (in instanceof ParserReader)
			return (ParserReader)in;
		return new ParserReader(in, 1024);
	}
}
