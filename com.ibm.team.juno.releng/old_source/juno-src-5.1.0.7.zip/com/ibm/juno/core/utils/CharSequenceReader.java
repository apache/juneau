/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.utils;

import java.io.*;

/**
 * Similar to {@link StringReader} except reads from a generic {@link CharSequenceReader}.
 *
 * @author jbognar
 */
public class CharSequenceReader extends BufferedReader {

	private final CharSequence cs;
	private int idx;

	/**
	 * Constructor.
	 * @param cs The char sequence to read from.  Can be <jk>null</jk>.
	 */
	public CharSequenceReader(CharSequence cs) {
		super(new StringReader(""), 1);   // Does not actually use a reader.
		this.cs = cs == null ? "" : cs;
	}

	@Override
	public int read() {
		if (idx >= cs.length())
			return -1;
		return cs.charAt(idx++);
	}

	@Override
	public boolean markSupported() {
		return false;
	}

	@Override
	public int read(final char[] array, final int offset, final int length) {
		if (array == null)
			throw new IllegalArgumentException("Array is null");

		if (idx >= cs.length())
			return -1;

		if (length < 0 || offset < 0 || offset + length > array.length)
			throw new IndexOutOfBoundsException("Array size=" + array.length + ", offset=" + offset + ", length=" + length);

		int count = 0;
		for (int i = 0; i < length; i++) {
			int c = read();
			if (c == -1)
				return count;
			array[offset + i] = (char)c;
			count++;
		}

		return count;
	}

	@Override
	public long skip(long n) {
		if (n < 0)
			throw new IllegalArgumentException("Skip count is less than zero: " + n);

		if (idx >= cs.length())
			return -1;

		int idx2 = Math.min(cs.length(), idx + (int)n);
		int count = idx2 - idx;
		idx = idx2;
		return count;
	}

	@Override
	public void close() {
		idx = 0;
	}

	@Override
	public String toString() {
		return cs.toString();
	}
}