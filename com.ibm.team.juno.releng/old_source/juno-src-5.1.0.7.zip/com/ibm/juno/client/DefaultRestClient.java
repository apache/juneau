/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.client;

import org.apache.http.client.*;
import org.apache.http.impl.client.*;

import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;

/**
 * Implementation of a {@link RestClient} with a default http client.
 * <p>
 * Http client is an instance of {@link DefaultHttpClient} using {@link LaxRedirectStrategy}.
 * <p>
 * Equivalent to the following code:
 * <p class='bcode'>
 * 	AbstractHttpClient httpClient = <jk>new</jk> DefaultHttpClient();
 * 	httpClient.setRedirectStrategy(<jk>new</jk> LaxRedirectStrategy());  <jc>// Allow redirects on PUT/POST/DELETE</jc>
 * 	RestClient restClient = <jk>new</jk> RestClient(httpClient);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class DefaultRestClient extends RestClient {

	/**
	 * Create a new client with no serializer or parser.
	 */
	public DefaultRestClient() {
		super(createHttpClient());
	}

	/**
	 * Create a new client with the specified serializer and parser classes.
	 *
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 * @throws InstantiationException If serializer or parser could not be instantiated.
	 */
	public DefaultRestClient(Class<? extends Serializer<?>> s, Class<? extends Parser<?>> p) throws InstantiationException {
		super(createHttpClient(), s, p);
	}

	/**
	 * Create a new client with the specified serializer and parser instances.
	 *
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 */
	public DefaultRestClient(Serializer<?> s, Parser<?> p) {
		super(createHttpClient(), s, p);
	}

	private static HttpClient createHttpClient() {
		AbstractHttpClient client = new DefaultHttpClient();
		client.setRedirectStrategy(new LaxRedirectStrategy());  // Allow redirects on PUT/POST/DELETE
		return client;
	}
}
