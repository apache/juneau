package com.ibm.juno.core.filters;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.*;

/**
 * Transforms {@link Date Dates} to {@link Long Longs}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class DateLongFilter extends PojoFilter<Date,Long> {

	/**
	 * Converts the specified {@link Date} to a {@link Long}.
	 */
	@Override
	public Long filter(Date o, BeanContext beanContext) {
		return o.getTime();
	}

	/**
	 * Converts the specified {@link Long} to a {@link Date}.
	 */
	@Override
	public Date unfilter(Long o, ClassMeta<?> hint, BeanContext beanContext) throws ParseException {
		Class<?> c = hint.getInnerClass();
		if (c == java.util.Date.class)
			return new java.util.Date(o);
		if (c == java.sql.Date.class)
			return new java.sql.Date(o);
		if (c == java.sql.Time.class)
			return new java.sql.Time(o);
		if (c == java.sql.Timestamp.class)
			return new java.sql.Timestamp(o);
		throw new ParseException("DateLongFilter is unable to narrow object of type '%s'", c);
	}
}
