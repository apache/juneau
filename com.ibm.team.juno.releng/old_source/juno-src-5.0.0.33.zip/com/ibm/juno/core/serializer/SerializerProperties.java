package com.ibm.juno.core.serializer;

import com.ibm.juno.core.*;

/**
 * Configurable properties common to all {@link Serializer} classes.
 * <p>
 * 	Use the {@link Serializer#setProperty(String, Object)} method to set property values.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SerializerProperties implements Cloneable {

	/**
	 * Max depth ({@link Integer}, default=<code>100</code>).
	 * <p>
	 * Abort serialization if specified depth is reached in the POJO tree.
	 * If this depth is exceeded, an exception is thrown.
	 * This prevents stack overflows from occurring when trying to serialize models with recursive references.
	 */
	public static final String MAX_DEPTH = "Serializer.maxDepth";

	/**
	 * Initial depth ({@link Integer}, default=<code>0</code>).
	 * <p>
	 * The initial indentation level at the root.
	 * Useful when constructing document fragments that need to be indented at a certain level.
	 */
	public static final String INITIAL_DEPTH = "Serializer.initialDepth";

	/**
	 * Automatically detect POJO recursions ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * Specifies that recursions should be checked for during serialization.
	 * <p>
	 * Recursions can occur when serializing models that aren't true trees, but rather contain loops.
	 * <p>
	 * When a recursion is detected, the bottom value is set to <jk>null</jk>.
	 * <p>
	 * For example, if a model contains the links A-&gt;B-&gt;C-&gt;A, then the JSON generated will look like...
	 * <code>{A:{B:{C:null}}}</code><br>
	 * <p>
	 * Note:  Checking for recursion can cause a small performance penalty.
	 */
	public static final String DETECT_RECURSIONS = "Serializer.detectRecursions";

	/**
	 * Use indentation in output ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, newlines and indentation is added to the output to improve readability.
	 */
	public static final String USE_INDENTATION = "Serializer.useIndentation";

	/**
	 * Add class attributes to output ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, then <js>"_class"</js> attributes will be added to beans if their type cannot be inferred through reflection.
	 * This is used to recreate the correct objects during parsing if the object types cannot be inferred.
	 * For example, when serializing a {@code Map<String,Object>} field, where the bean class cannot be determined from the value type.
	 */
	public static final String ADD_CLASS_ATTRS = "Serializer.addClassAttrs";

	/**
	 * Quote character ({@link Character}, default=<js>'"'</js>.
	 * <p>
	 * This is the character used for quoting attributes and values.
	 */
	public static final String QUOTE_CHAR = "Serializer.quoteChar";

	/**
	 * Boolean.  Trim null bean property values from output.
	 * <p>
	 * 	If <jk>true</jk>, null bean values will not be serialized to the output.
	 * <p>
	 * 	Note that enabling this setting has the following effects on parsing:
	 * 	<ul>
	 * 		<li>Map entries with <jk>null</jk> values will be lost.
	 * 	</ul>
	 * <p>
	 * 	Default is <jk>true</jk>.
	 */
	public static final String TRIM_NULL_PROPERTIES = "Serializer.trimNullProperties";

	/**
	 * Boolean.  Trim empty lists and arrays from output.
	 * <p>
	 * 	If <jk>true</jk>, empty list values will not be serialized to the output.
	 * <p>
	 * 	Note that enabling this setting has the following effects on parsing:
	 * 	<ul>
	 * 		<li>Map entries with empty list values will be lost.
	 * 		<li>Bean properties with empty list values will not be set.
	 * 	</ul>
	 * <p>
	 *		Default is <jk>false</jk>.
	 */
	public static final String TRIM_EMPTY_LISTS = "Serializer.trimEmptyLists";

	/**
	 * Boolean.  Trim empty maps from output.
	 * <p>
	 * 	If <jk>true</jk>, empty map values will not be serialized to the output.
	 * <p>
	 * 	Note that enabling this setting has the following effects on parsing:
	 * 	<ul>
	 * 		<li>Bean properties with empty map values will not be set.
	 * 	</ul>
	 * <p>
	 *		Default is <jk>false</jk>.
	 */
	public static final String TRIM_EMPTY_MAPS = "Serializer.trimEmptyMaps";

	/**
	 * String.  URI context root for relative URIs.
	 * <p>
	 * 	Prepended to relative URIs during serialization (along with the {@link #URI_AUTHORITY} if specified.
	 * 	(i.e. URIs not containing a schema and not starting with <js>'/'</js>).
	 * 	(e.g. <js>"foo/bar"</js>)
	 * <p>
	 * <h6 class='topic'>Examples</h6>
	 * <table class='styled'>
	 * 	<tr><th>URI</th><th>URI_AUTHORITY</th><th>URI_CONTEXT</th><th>Serialized URI</th></tr>
	 * 	<tr>
	 * 		<td><code>http://foo:9080/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080</code></td>
	 * 		<td><code>/mywebapp</code></td>
	 * 		<td><code>http://foo:9080/bar/baz</code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>/bar/baz</code></td>
	 * 		<td><code>http://myhost:9080</code></td>
	 * 		<td><code>/mywebapp</code></td>
	 * 		<td><code>http://myhost:9080/bar/baz</code></td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td><code>bar/baz</code></td>
	 * 		<td><code>http://myhost:9080</code></td>
	 * 		<td><code>/mywebapp</code></td>
	 * 		<td><code>http://myhost:9080/mywebapp/bar/baz</code></td>
	 * 	</tr>
	 * </table>
	 * <p>
	 * 	Note that you can disable URI prefixing by setting URI_CONTEXT and URI_AUTHORITY to an empty string.
	 * <p>
	 *		Default is <js>""</js>.
	 */
	public static final String URI_CONTEXT = "Serializer.uriContext";

	/**
	 * String.  URI authority for context-relative URIs.
	 * <p>
	 * 	Prepended to context-relative URIs during serialization.
	 * 	(i.e. URIs not containing a schema but starting with <js>'/'</js>).
	 * 	(e.g. <js>"/contextRoot/foo/bar"</js>)
	 * <p>
	 * 	Refer to {@link #URI_CONTEXT} for more information.
	 * <p>
	 *		Default is <js>""</js>.
	 */
	public static final String URI_AUTHORITY = "Serializer.uriAuthority";

	int maxDepth = 100, initialDepth = 0;
	boolean
		detectRecursions = false,
		useIndentation = false,
		addClassAttrs = false,
		trimNulls = true,
		trimEmptyLists = false,
		trimEmptyMaps = false;
	char quoteChar = '"';
	String uriContext="", uriAuthority="";

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		BeanContext bc = BeanContext.DEFAULT;
		if (property.equals(MAX_DEPTH))
			maxDepth = bc.convertToType(value, Integer.class);
		else if (property.equals(DETECT_RECURSIONS))
			detectRecursions = bc.convertToType(value, Boolean.class);
		else if (property.equals(USE_INDENTATION))
			useIndentation = bc.convertToType(value, Boolean.class);
		else if (property.equals(ADD_CLASS_ATTRS))
			addClassAttrs = bc.convertToType(value, Boolean.class);
		else if (property.equals(QUOTE_CHAR))
			quoteChar = bc.convertToType(value, Character.class);
		else if (property.equals(TRIM_NULL_PROPERTIES))
			trimNulls = bc.convertToType(value, Boolean.class);
		else if (property.equals(TRIM_EMPTY_LISTS))
			trimEmptyLists = bc.convertToType(value, Boolean.class);
		else if (property.equals(TRIM_EMPTY_MAPS))
			trimEmptyMaps = bc.convertToType(value, Boolean.class);
		else if (property.equals(URI_CONTEXT)) {
			uriContext = (value == null ? "" : value.toString());
			if (! uriContext.isEmpty()) {
				if (! uriContext.startsWith("/"))
					uriContext = "/" + uriContext;
				if (uriContext.endsWith("/"))
					uriContext = uriContext.substring(0, uriContext.length()-1);
			}
		}
		else if (property.equals(URI_AUTHORITY)) {
			uriAuthority = (value == null ? "" : value.toString());
			if (! uriAuthority.isEmpty()) {
				if (uriAuthority.endsWith("/"))
					uriAuthority = uriAuthority.substring(0, uriAuthority.length()-1);
			}
		}
		else
			return false;
		return true;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Cloneable
	public SerializerProperties clone() {
		try {
			return (SerializerProperties)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Won't happen.
		}
	}
}
