package com.ibm.juno.core.utils;

import java.io.*;

/**
 * Similar to {@link StringWriter}, but uses a {@link StringBuilder} instead to avoid synchronization overhead.
 * <p>
 * Note that this class is NOT thread safe.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class StringBuilderWriter extends Writer {

	private StringBuilder sb;

	/**
	 * Create a new string writer using the default initial string-builder size.
	 */
	public StringBuilderWriter() {
		sb = new StringBuilder();
		lock = null;
	}

	/**
	 * Create a new string writer using the specified initial string-builder size.
	 *
	 * @param initialSize The number of <tt>char</tt> values that will fit into this buffer before it is automatically expanded
	 *
	 * @throws IllegalArgumentException If <tt>initialSize</tt> is negative
	 */
	public StringBuilderWriter(int initialSize) {
		sb = new StringBuilder(initialSize);
		lock = null;
	}

	@Override
	public void write(int c) {
		sb.append((char) c);
	}

	@Override
	public void write(char cbuf[], int off, int len) {
		if ((off < 0) || (off > cbuf.length) || (len < 0) || ((off + len) > cbuf.length) || ((off + len) < 0)) {
			throw new IndexOutOfBoundsException();
		} else if (len == 0) {
			return;
		}
		sb.append(cbuf, off, len);
	}

	@Override
	public void write(String str) {
		sb.append(str);
	}

	@Override
	public void write(String str, int off, int len) {
		sb.append(str.substring(off, off + len));
	}

	@Override
	public StringBuilderWriter append(CharSequence csq) {
		if (csq == null)
			write("null");
		else
			write(csq.toString());
		return this;
	}

	@Override
	public StringBuilderWriter append(CharSequence csq, int start, int end) {
		CharSequence cs = (csq == null ? "null" : csq);
		write(cs.subSequence(start, end).toString());
		return this;
	}

	@Override
	public StringBuilderWriter append(char c) {
		write(c);
		return this;
	}

	@Override
	public String toString() {
		return sb.toString();
	}

	@Override
	public void flush() {
	}

	@Override
	public void close() throws IOException {
	}
}
