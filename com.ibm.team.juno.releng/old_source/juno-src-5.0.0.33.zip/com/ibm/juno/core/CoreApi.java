package com.ibm.juno.core;



/**
 * Common super class for all core-API serializers, parsers, and serializer/parser groups.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Maintains an inner {@link BeanContext} instance that can be used by serializer and parser subclasses
 * 		to work with beans in a consistent way.
 * <p>
 * 	Provides several duplicate convenience methods from the {@link BeanContext} class to set properties on that class from this class.
 * <p>
 * 	Also implements the {@link Lockable} interface to allow for easy locking and cloning.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class CoreApi extends Lockable {

	/** The bean context used by this object. */
	protected transient BeanContext beanContext;

	/**
	 * Default constructor with default unlocked bean context.
	 */
	protected CoreApi() {
		this.beanContext = new BeanContext();
	}

	/**
	 * Returns the current value of the {@code beanContext} setting.
	 * @return The current setting value.
	 */
	public BeanContext getBeanContext() {
		return beanContext;
	}

	/**
	 * Sets a property on this class.
	 * @param property The property name.
	 * @param value The property value.
	 * @return This class (for method chaining).
	 * @throws LockedException If {@link #lock()} has been called on this object.
	 */
	public CoreApi setProperty(String property, Object value) throws LockedException {
		checkLock();
		beanContext.setProperty(property, value);
		return this;
	}

	/**
	 * Sets multiple properties on this class.
	 * @param properties The properties to set on this class.
	 * @return This class (for method chaining).
	 * @throws LockedException If {@link #lock()} has been called on this object.
	 */
	public CoreApi setProperties(ObjectMap properties) throws LockedException {
		checkLock();
		beanContext.setProperties(properties);
		return this;
	}

	/**
	 * Shortcut for calling <code>getBeanContext().addNotBeanClasses(Class...)</code>.
	 * @see BeanContext#addNotBeanClasses(Class...)
	 * @param classes The new setting value for the bean context.
	 * @throws LockedException If {@link BeanContext#lock()} was called on this class or the bean context.
	 * @return This object (for method chaining).
	 */
	public CoreApi addNotBeanClasses(Class<?>...classes) throws LockedException {
		beanContext.addNotBeanClasses(classes);
		return this;
	}

	/**
	 * Shortcut for calling <code>getBeanContext().addFilters(Class...)</code>.
	 * @see BeanContext#addFilters(Class...)
	 * @param classes The new setting value for the bean context.
	 * @throws LockedException If {@link BeanContext#lock()} was called on this class or the bean context.
	 * @return This object (for method chaining).
	 */
	public CoreApi addFilters(Class<?>...classes) throws LockedException {
		beanContext.addFilters(classes);
		return this;
	}

	/**
	 * Shortcut for calling <code>getBeanContext().addImplClass(Class, Class)</code>.
	 * @see BeanContext#addImplClass(Class, Class)
	 * @param interfaceClass The interface class.
	 * @param implClass The implementation class.
	 * @throws LockedException If {@link BeanContext#lock()} was called on this class or the bean context.
	 * @param <T> The class type of the interface.
	 * @return This object (for method chaining).
	 */
	public <T> CoreApi addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		beanContext.addImplClass(interfaceClass, implClass);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Lockable
	public CoreApi lock() {
		super.lock();
		beanContext.lock();
		return this;
	}

	@Override // Lockable
	public CoreApi clone() throws CloneNotSupportedException{
		CoreApi c = (CoreApi)super.clone();
		c.beanContext = beanContext.clone();
		return c;
	}
}
