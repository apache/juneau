package com.ibm.juno.core.jena;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.ClassMetaConst.*;
import static com.ibm.juno.core.jena.Constants.*;
import static com.ibm.juno.core.jena.RdfProperties.*;
import static com.ibm.juno.core.xml.XmlUtils.*;

import java.io.*;
import java.util.*;

import com.hp.hpl.jena.rdf.model.*;
import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Serializes POJOs to RDF.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	Refer to <a class='doclink' href='package-summary.html#SerializerConfigurableProperties'>Configurable Properties</a>
 * 		for the entire list of configurable properties.
 *
 *
 * <h6 class='topic'>Behavior-specific subclasses</h6>
 * <p>
 * 	The following direct subclasses are provided for language-specific serializers:
 * <ul>
 * 	<li>{@link RdfSerializer.Xml} - RDF/XML.
 * 	<li>{@link RdfSerializer.XmlAbbrev} - RDF/XML-ABBREV.
 * 	<li>{@link RdfSerializer.NTriple} - N-TRIPLE.
 * 	<li>{@link RdfSerializer.Turtle} - TURTLE.
 * 	<li>{@link RdfSerializer.N3} - N3.
 * </ul>
 *
 *
 * <h6 class='topic'>Additional Information</h6>
 * <p>
 * 	See <a class='doclink' href='package-summary.html#TOC'>RDF Overview</a> for an overview of RDF support in Juno.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@Produces(value="text/xml+rdf+abbrev", contentType="text/xml+rdf")
public class RdfSerializer extends WriterSerializer {

	/** Default RDF/XML serializer, all default settings.*/
	public static final RdfSerializer DEFAULT_XML = new RdfSerializer.Xml().lock();

	/** Default Abbreviated RDF/XML serializer, all default settings.*/
	public static final RdfSerializer DEFAULT_XMLABBREV = new RdfSerializer.XmlAbbrev().lock();

	/** Default Turtle serializer, all default settings.*/
	public static final RdfSerializer DEFAULT_TURTLE = new RdfSerializer.Turtle().lock();

	/** Default N-Triple serializer, all default settings.*/
	public static final RdfSerializer DEFAULT_NTRIPLE = new RdfSerializer.NTriple().lock();

	/** Default N3 serializer, all default settings.*/
	public static final RdfSerializer DEFAULT_N3 = new RdfSerializer.N3().lock();


	/** Produces RDF/XML output */
	@Produces("text/xml+rdf")
	public static class Xml extends RdfSerializer {
		/** Constructor */
		public Xml() {
			setProperty(RDF_LANGUAGE, LANG_RDF_XML);
		}
	}

	/** Produces Abbreviated RDF/XML output */
	@Produces(value="text/xml+rdf+abbrev", contentType="text/xml+rdf")
	public static class XmlAbbrev extends RdfSerializer {
		/** Constructor */
		public XmlAbbrev() {
			setProperty(RDF_LANGUAGE, LANG_RDF_XML_ABBREV);
		}
	}

	/** Produces N-Triple output */
	@Produces(value="text/n-triple")
	public static class NTriple extends RdfSerializer {
		/** Constructor */
		public NTriple() {
			setProperty(RDF_LANGUAGE, LANG_NTRIPLE);
		}
	}

	/** Produces Turtle output */
	@Produces(value="text/turtle")
	public static class Turtle extends RdfSerializer {
		/** Constructor */
		public Turtle() {
			setProperty(RDF_LANGUAGE, LANG_TURTLE);
		}
	}

	/** Produces N3 output */
	@Produces(value="text/n3")
	public static class N3 extends RdfSerializer {
		/** Constructor */
		public N3() {
			setProperty(RDF_LANGUAGE, LANG_N3);
		}
	}


	/** Jena serializer properties currently set on this serializer. */
	protected transient RdfSerializerProperties rsp = new RdfSerializerProperties();

	/** Xml serializer properties currently set on this serializer. */
	protected transient XmlSerializerProperties xsp = new XmlSerializerProperties();


	@Override // Serializer
	public void serialize(Object o, Writer w, SerializerContext ctx) throws IOException, SerializeException {
		if (! (ctx instanceof RdfSerializerContext))
			throw new SerializeException("Context is not an instance of RdfSerializerContext");
		RdfSerializerContext ctx2 = (RdfSerializerContext)ctx;

		Model model = ctx2.model;
		Resource r = null;

		ClassMeta cm = beanContext.getClassMetaForObject(o);
		if (cm == null)
			cm = OBJECT;
		RDFNode n = serializeAnything(o, false, cm.getNamespace(), OBJECT, ctx2, false);
		if (n.isLiteral()) {
			r = model.createResource();
			r.addProperty(ctx2.pValue, n);
		} else {
			r = n.asResource();
		}

		if (ctx2.addRootProperty)
			r.addProperty(ctx2.pRoot, "true");

		ctx2.writer.write(model, w, "http://unknown/");
	}

	private RDFNode serializeAnything(Object o, boolean isURI, Namespace ns, ClassMeta<?> eType, RdfSerializerContext ctx, boolean isBeanProperty) throws SerializeException {
		Model m = ctx.model;

		ClassMeta<?> aType = null;                      // The actual type
		ClassMeta<?> wType = null;                      // The wrapped type
		ClassMeta<?> gType = OBJECT;                    // The generic type

		aType = ctx.push("", o, eType);

		if (eType == null)
			eType = OBJECT;

		// Handle recursion
		if (aType == null) {
			o = null;
			aType = OBJECT;
		}

		if (o != null) {

			if (aType.isDelegate()) {
				wType = aType;
				aType = ((Delegate)o).getClassMeta();
			}

			gType = aType.getFilteredClassMeta();

			// Filter if necessary
			PojoFilter filter = aType.getPojoFilter();
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == OBJECT)
					gType = beanContext.getClassMetaForObject(o);
			}
		} else {
			gType = eType.getFilteredClassMeta();
		}

		RDFNode n = null;

		if (o == null || gType.isChar() && ((Character)o).charValue() == 0) {
			if (isBeanProperty) {
				if (! ctx.isTrimNulls()) {
					n = m.createResource(NIL);
				}
			} else {
				n = m.createResource(NIL);
			}

		} else if (gType.isUri() || isURI) {
			n = m.createResource(getUri(o, null, ctx));

		} else if (gType.isCharSequence() || gType.isChar()) {
			n = m.createLiteral(encodeTextInvalidChars(o));

		} else if (gType.isNumber() || gType.isBoolean()) {
			if (! ctx.addLiteralTypes)
				n = m.createLiteral(o.toString());
			else
				n = m.createTypedLiteral(o);

		} else if (gType.isMap() || (wType != null && wType.isMap())) {
			if (o instanceof BeanMap) {
				BeanMap bm = (BeanMap)o;
				String uri = getUri(bm.getBeanUri(), null, ctx);
				n = m.createResource(uri);
				serializeBeanMap(bm, (Resource)n, ctx);
			} else {
				Map m2 = (Map)o;
				n = m.createResource();
				serializeMap(m2, (Resource)n, gType, ctx);
			}

		} else if (gType.isBean()) {
			BeanMap bm = beanContext.forBean(o);
			String uri = getUri(bm.getBeanUri(), null, ctx);
			n = m.createResource(uri);
			serializeBeanMap(bm, (Resource)n, ctx);

		} else if (gType.isCollection() || (wType != null && wType.isCollection())) {
			Seq list = m.createSeq();
			n = serializeCollection((Collection)o, gType, list, ctx);

		} else if (gType.isArray()) {
			Seq list = m.createSeq();
			n = serializeCollection(toList(gType.getInnerClass(), o), gType, list, ctx);
		} else {
			n = m.createLiteral(encodeTextInvalidChars(o));
		}

		if (ctx.isAddClassAttrs() && n != null && n.isResource()) {
			if (o != null && ! eType.equals(aType))
				n.asResource().addProperty(ctx.pClass, aType.toString());
			else if (o == null)
				n.asResource().addProperty(ctx.pClass, eType.toString());
		}

		ctx.pop();

		return n;
	}

	private String getUri(Object uri, Object uri2, RdfSerializerContext ctx) {
		String s = null;
		if (uri != null)
			s = uri.toString();
		if ((s == null || s.isEmpty()) && uri2 != null)
			s = uri2.toString();
		if (s == null)
			return null;
		if (s.indexOf(':') == -1) {
			String authority = ctx.getUriAuthority();
			String context = ctx.getUriContext();
			StringBuilder sb = new StringBuilder(s.length() + authority.length() + context.length());
			sb.append(authority);
			if ((! s.startsWith("/")) && ! context.isEmpty())
				sb.append(context).append("/");
			sb.append(s);
			s = sb.toString();
		}
		return s;
	}

	private void serializeMap(Map m, Resource r, ClassMeta<?> type, RdfSerializerContext ctx) throws SerializeException {

		ClassMeta<?> keyType = type.getKeyType(), valueType = type.getValueType();

		ArrayList<Map.Entry<Object,Object>> l = new ArrayList<Map.Entry<Object,Object>>(m.entrySet());
		Collections.reverse(l);
		for (Map.Entry<Object,Object> me : l) {
			Object value = me.getValue();

			Object key = generalize(me.getKey(), keyType);

			Namespace ns = ctx.junoBpNs;
			Model model = ctx.model;
			Property p = model.createProperty(ns.getUri(), encodeElementName(key));
			RDFNode n = serializeAnything(value, false, ns, valueType, ctx, false);
			if (n != null)
				r.addProperty(p, n);
		}
	}

	private void serializeBeanMap(BeanMap m, Resource r, RdfSerializerContext ctx) throws SerializeException {
		ArrayList<BeanMapEntry> l = new ArrayList<BeanMapEntry>(m.entrySet());
		Collections.reverse(l);
		for (BeanMapEntry bme : l) {
			BeanPropertyMeta pMeta = bme.getMeta();

			if (canIgnoreProperty(ctx, pMeta) || pMeta.isBeanUri())
				continue;

			String key = bme.getKey();
			Object value = null;
			try {
				value = bme.getFilteredValue();
			} catch (Throwable x) {
				ctx.addWarning("Could not call getValue() on property '%s', %s", key, x.getLocalizedMessage());
			}

			if (canIgnoreValue(ctx, pMeta.getClassMeta(), value))
				continue;

			Namespace ns = bme.getMeta().getNamespace();
			if (ns == null)
				ns = ctx.junoBpNs;
			else if (ctx.isAutoDetectNamespaces())
				ctx.addModelPrefix(ns);

			Property p = ctx.model.createProperty(ns.getUri(), encodeElementName(key));
			RDFNode n = serializeAnything(value, pMeta.isUri(), ns, pMeta.getClassMeta(), ctx, true);
			if (n != null)
				r.addProperty(p, n);
		}
	}


	private Seq serializeCollection(Collection c, ClassMeta<?> type, Seq list, RdfSerializerContext ctx) throws SerializeException {

		ClassMeta<?> elementType = type.getElementType();

		int i = 1;
		for (Object e : c) {
			RDFNode n = serializeAnything(e, false, null, elementType, ctx, false);
			list = list.add(i++, n);
		}
		return list;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Serializer
	public RdfSerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) {
		return new RdfSerializerContext(beanContext, sp, xsp, rsp, properties, mediaType);
	}

	@Override // CoreApi
	public RdfSerializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (rsp.setProperty(property, value))
			return this;
		if (xsp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // CoreApi
	public RdfSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public RdfSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> RdfSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // Lockable
	public RdfSerializer lock() {
		super.lock();
		return this;
	}

	@Override // Lockable
	public RdfSerializer clone() {
		try {
			RdfSerializer c = (RdfSerializer)super.clone();
			c.rsp = rsp.clone();
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
