package com.ibm.juno.server.labels;

import java.util.*;

import com.ibm.juno.server.*;

/**
 * A POJO structure that describes the list of child resources associated with a resource.
 * <p>
 * Typically used in top-level GET methods of router resources to render a list of
 * 	available child resources.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ChildResourceDescriptions extends LinkedList<ResourceDescription> {

	/**
	 * Constructor.
	 * @param servlet The servlet that this bean describes.
	 * @param req The HTTP servlet request.
	 */
	public ChildResourceDescriptions(RestServlet servlet, RestRequest req) {
		String uri = req.getRequestURI();
		Locale locale = req.getLocale();
		for (Map.Entry<String,RestServlet> e : servlet.getChildResources().entrySet())
			add(new ResourceDescription(uri, e.getKey(), e.getValue().getDescription(locale)));
	}

	/**
	 * Bean constructor.
	 */
	public ChildResourceDescriptions() {
		super();
	}
}
