package com.ibm.juno.server.labels;

import java.util.*;

import com.ibm.juno.client.proto.script.*;
import com.ibm.juno.server.*;
import com.ibm.juno.server.annotation.*;

/**
 * Default POJO bean used for generating OPTIONS page results.
 * <p>
 * This POJO bean is also meant to be used by the {@link RestScript} class for discoverable command-line-invokable
 * 	REST services.
 * <p>
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ResourceOptions {
	private String description;
	private String className;
	private Collection<MethodDescription> methods;
	private ChildResourceDescriptions children;
	private Map<String,Object> properties;
	private Collection<String> accept, contentType;

	/**
	 * Constructor.
	 * @param servlet The servlet that this bean describes.
	 * @param req The HTTP servlet request.
	 */
	public ResourceOptions(RestServlet servlet, RestRequest req) {
		setClassName(servlet.getClass().getName());
		setDescription(servlet.getResourceDescription(req.getLocale()));
		setMethods(servlet.getMethodDescriptions(req));
		setProperties(servlet.getProperties());
		setAccept(servlet.getSupportedAcceptTypes());
		setContentType(servlet.getSupportedContentTypes());
		setChildren(new ChildResourceDescriptions(servlet, req));
	}

	/**
	 * Bean constructor.
	 */
	public ResourceOptions() {}

	/**
	 * Returns the description of the REST resource.
	 * @return The current bean property value.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description of the REST resource.
	 * @param description The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setDescription(String description) {
		this.description = description;
		return this;
	}

	/**
	 * Returns the class name of the REST resource.
	 * @return The current bean property value.
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * Sets the class name of the REST resource.
	 * @param className The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setClassName(String className) {
		this.className = className;
		return this;
	}

	/**
	 * Returns the methods provided on this REST resource.
	 * @return The current bean property value.
	 */
	public Collection<MethodDescription> getMethods() {
		return methods;
	}

	/**
	 * Sets the methods provided on this REST resource.
	 * @param methods The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setMethods(Collection<MethodDescription> methods) {
		this.methods = methods;
		return this;
	}

	/**
	 * Returns the list of properties currently set on a servlet.
	 * @return The current bean property value.
	 */
	public Map<String,Object> getProperties() {
		return properties;
	}

	/**
	 * Sets the properties field on this label to a new value.
	 * This identifies properties defined on a servlet via the {@link RestResource#properties()} annotation.
	 * @param properties The new list if properties.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setProperties(Map<String,Object> properties) {
		this.properties = properties;
		return this;
	}



	/**
	 * Returns the list of allowable <code>Accept</code> header values on requests.
	 * @return The current bean property value.
	 */
	public Collection<String> getAccept() {
		return accept;
	}

	/**
	 * Sets the list of allowable <code>Accept</code> header values on requests.
	 * @param accept The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setAccept(Collection<String> accept) {
		this.accept = accept;
		return this;
	}

	/**
	 * Returns the list of allowable <code>Content-Type</code> header values on requests.
	 * @return The current bean property value.
	 */
	public Collection<String> getContentType() {
		return contentType;
	}

	/**
	 * Sets the list of allowable <code>Content-Type</code> header values on requests.
	 * @param contentType The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setContentType(Collection<String> contentType) {
		this.contentType = contentType;
		return this;
	}

	/**
	 * Returns the description of child resources with this resource (typically through {@link RestResource#children()} annotation).
	 * @return The description of child resources of this resource.
	 */
	public ChildResourceDescriptions getChildren() {
		return children;
	}

	/**
	 * Sets the child resource descriptions associated with this resource.
	 * @param children The child resource descriptions.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setChildren(ChildResourceDescriptions children) {
		this.children = children;
		return this;
	}
}
