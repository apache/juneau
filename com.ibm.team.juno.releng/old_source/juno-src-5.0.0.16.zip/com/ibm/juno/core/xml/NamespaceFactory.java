package com.ibm.juno.core.xml;

import java.util.*;
import java.util.concurrent.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.utils.*;

/**
 * Factory class for getting unique instances of {@link Namespace} objects.
 * <p>
 * 	For performance reasons, {@link Namespace} objects are stored in {@link IdentityList IdentityLists}.
 * 	For this to work property, namespaces with the same name and URI must only be represented by a single
 * 	{@link Namespace} instance.
 * 	This factory class ensures this identity uniqueness.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class NamespaceFactory {

	private static ConcurrentHashMap<String,Namespace> cache = new ConcurrentHashMap<String,Namespace>();

	/**
	 * Get the {@link Namespace} with the specified name and URI, and create a new one
	 * 	if this is the first time it's been encountered.
	 * @param name The namespace name.  See {@link Namespace#getName()}.
	 * @param uri The namespace URI.  See {@link Namespace#getUri()}.
	 * @return The namespace object.
	 */
	public static Namespace get(String name, String uri) {
		String key = name + "+" + uri;
		Namespace n = cache.get(key);
		if (n == null) {
			n = new Namespace(name, uri);
			Namespace n2 = cache.putIfAbsent(key, n);
			return (n2 == null ? n : n2);
		}
		return n;
	}

	/**
	 * Converts a JSON string of the form <js>"{ns1:'http://ns1',ns2:'http://ns2'}"</js>
	 * 	into a list of {@link Namespace} objects.
	 * @param json JSON input of namespace/URI pairs.
	 * @return The list of parsed namespaces.
	 * @throws RuntimeException if the JSON is malformed.
	 */
	@SuppressWarnings("rawtypes")
	public static List<Namespace> fromString(String json) {
		try {
			List<Namespace> l = new LinkedList<Namespace>();
			ObjectMap m = new ObjectMap(json);
			for (Map.Entry e : m.entrySet())
				l.add(get(e.getKey().toString(), e.getValue().toString()));
			return l;
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}
}
