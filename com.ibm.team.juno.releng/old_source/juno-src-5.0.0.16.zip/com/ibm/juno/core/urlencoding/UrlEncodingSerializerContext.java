package com.ibm.juno.core.urlencoding;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.serializer.*;

/**
 * Context object that lives for the duration of a single serialization of {@link UrlEncodingSerializer}.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingSerializerContext extends JsonSerializerContext {

	private ObjectMap overrideProperties;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param jsp Default JSON serializer properties.
	 * @param op Override properties.
	 */
	protected UrlEncodingSerializerContext(BeanContext beanContext, SerializerProperties sp, JsonSerializerProperties jsp, ObjectMap op) {
		super(beanContext, sp, jsp, op);
		this.overrideProperties = op;
	}

	/**
	 * Returns the override properties that were passed in through the serialize method.
	 * @return The override properties that were passed in through the serialize method.
	 */
	public ObjectMap getOverrideProperties() {
		return overrideProperties;
	}
}
