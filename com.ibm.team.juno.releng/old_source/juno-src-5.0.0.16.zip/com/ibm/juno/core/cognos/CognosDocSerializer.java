package com.ibm.juno.core.cognos;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Document wrapper for {@link CognosSerializer}.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>text/xml+cognos</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>text/xml+cognos</code>
 * <p>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * Same as {@link CognosSerializer}, except prepends an XML declaration
 * 	(e.g. <code><xt>&lt;?xml</xt> <xa>version</xa>=<xs>"1.0"</xs> <xa>encoding</xa>=<xs>"UTF-8"</xs><xt>?&gt;</xt></code>) to the output.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class CognosDocSerializer extends CognosSerializer {

	@Override
	public void serialize(Object o, Writer w, ObjectMap properties, String mediaType) throws IOException, SerializeException {
		SerializerContext ctx = new SerializerContext(beanContext, sp, properties);
		XmlSerializerWriter sw = new XmlSerializerWriter(w, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority());
		sw.append("<?xml")
			.attr("version", "1.0")
			.attr("encoding", "UTF-8")
			.appendln("?>");
		doSerialize(o, sw, ctx);
	}
}
