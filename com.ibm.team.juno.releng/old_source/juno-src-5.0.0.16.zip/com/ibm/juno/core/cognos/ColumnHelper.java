package com.ibm.juno.core.cognos;

/**
 * Helper class for converting property values to valid Cognos data types.
 * <p>
 * 	ColumnHelpers are used to extract values from beans or maps when the column name is not a simple
 * 		property of a bean or key of a map, or the value cannot simply be converted to a string using
 * 		the {@code toString()} method.
 *
 * <h6 class='topic'>Additional Information</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#CognosSerializer_SampleCode'>1.0.1 - Sample code</a>
 * 		for sample usage.
 * </ul>
 *
 * @param <T> The type of object being serialized.
 */
public interface ColumnHelper<T> {

	/**
	 * Return a value from the specified object.
	 *
	 * @param o The object being serialized to a row.
	 * @return The extracted value.
	 */
	public String getString(T o);
}