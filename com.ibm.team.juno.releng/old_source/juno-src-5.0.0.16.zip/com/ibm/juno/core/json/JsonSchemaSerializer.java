package com.ibm.juno.core.json;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJO metadata to HTTP responses as JSON.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>application/json+schema, text/json+schema</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>application/json</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 *		Produces the JSON-schema for the JSON produced by the {@link JsonSerializer} class with the same properties.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Produces(value={"application/json+schema","text/json+schema"},contentType="application/json")
public class JsonSchemaSerializer extends JsonSerializer {

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer, JsonSerializer
	public void serialize(Object output, Writer out, ObjectMap properties, String mediaType) throws IOException, SerializeException {
		serializeSchema(output, out, properties, mediaType);
	}

	@Override // ISerializer, Lockable
	public JsonSchemaSerializer lock() {
		super.lock();
		return this;
	}
}
