package com.ibm.juno.core.serializer;

import java.io.*;

/**
 * Top-level interface for all byte-based serializers.
 */
public interface IOutputStreamSerializer extends ISerializer<OutputStream> {}
