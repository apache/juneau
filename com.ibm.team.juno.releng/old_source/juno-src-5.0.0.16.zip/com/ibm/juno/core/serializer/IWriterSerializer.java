package com.ibm.juno.core.serializer;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Top-level interface for all character-based serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	In addition to methods defined in {@link ISerializer}, this method defines two additional
 * 	convenience methods for serializing directly to <code>Strings</code>.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface IWriterSerializer extends ISerializer<Writer> {

	/**
	 * Same as {@link ISerializer#serialize(Object, Object, ObjectMap, String)} except serializes to a <code>String</code>.
	 *
	 * @param o The object to serialize.
	 * @param properties Optional run-time properties.  Can be <jk>null</jk>.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o, ObjectMap properties) throws SerializeException;

	/**
	 * Same as {@link #serialize(Object, ObjectMap)} with <jk>null</jk> runtime properties.
	 *
	 * @param o The object to serialize.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o) throws SerializeException;
}
