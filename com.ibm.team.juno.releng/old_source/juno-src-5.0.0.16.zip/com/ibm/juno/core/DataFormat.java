package com.ibm.juno.core;

import com.ibm.juno.core.html.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.core.xml.*;

/**
 * Enumerates all currently implemented parsers used by the {@link ObjectMap} and {@link ObjectList} classes.
 * <p>
 * 	These parsers implement the {@link IExtendedParser} interface.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public enum DataFormat {

	/** JSON format */
	JSON(JsonParser.DEFAULT),

	/** Juno-generated XML format */
	XML(XmlParser.DEFAULT),

	/** HTML format */
	HTML(HtmlParser.DEFAULT),

	/** URL encoding format */
	URLENCODING(UrlEncodingParser.DEFAULT);

	private IExtendedParser parser;

	private DataFormat(IExtendedParser parser) {
		this.parser = parser;
	}

	/**
	 * Returns the default {@link Parser} associated with this data format.
	 *
	 * @return The default parser.
	 */
	public IExtendedParser getParser() {
		return parser;
	}
}
