package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;

/**
 * Subclass of {@link Parser} for byte-based parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all byte-based parsers since it implements all
 * 	of the following interfaces...
 * <ul>
 * 	<li>{@link IParser}
 * 	<li>{@link ICoreApiParser}
 * 	<li>{@link IInputStreamParser}
 * </ul>
 * <p>
 * 	...and only has 1 remaining abstract method to implement...
 * <ul>
 * 	<li>{@link #parse(InputStream, ClassType, ObjectMap, String)}
 * </ul>
 *
 *
 * <h6 class='topic'>@Consumes annotation</h6>
 * <p>
 * 	The media types that this parser can handle is specified through the {@link Consumes @Consumes} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()} method.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class InputStreamParser extends Parser<InputStream> implements IInputStreamParser {

	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	abstract public <T> T parse(InputStream in, ClassType<T> type, ObjectMap properties, String mediaType) throws ParseException, IOException;
}
