/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.utils;

/**
 * Interface for the resolution of Vars.
 * Vars are strings of the format $X{arg}
 * @author jbognar
 */
public abstract class StringVar {

	/**
	 * The interface that needs to be implemented for Vars.
	 */
	public abstract String resolve(String arg);
}
