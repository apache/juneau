/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.xml;

import static com.ibm.juno.core.xml.NamespaceFactory.*;
import static com.ibm.juno.core.xml.XmlSerializerProperties.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.utils.*;

/**
 * Context object that lives for the duration of a single serialization of the {@link XmlSerializer}.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlSerializerContext extends SerializerContext {

	private final boolean
		addJsonTypeAttrs,
		addJsonStringTypeAttrs,
		autoDetectNamespaces,
		enableNamespaces,
		addNamespaceUrlsToRoot;

	private Namespace
		defaultNamespace,
		xsiNamespace,
		xsNamespace;

	private Namespace[] namespaces = new Namespace[0];

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param xsp Default XML serializer properties.
	 * @param op Override properties.
	 */
	public XmlSerializerContext(BeanContext beanContext, SerializerProperties sp, XmlSerializerProperties xsp, ObjectMap op, String mediaType) {
		super(beanContext, sp, op, mediaType, null);
		if (op == null || op.isEmpty()) {
			addJsonTypeAttrs = xsp.addJsonTypeAttrs;
			addJsonStringTypeAttrs = xsp.addJsonStringTypeAttrs;
			enableNamespaces = xsp.enableNamespaces;
			autoDetectNamespaces = xsp.autoDetectNamespaces;
			addNamespaceUrlsToRoot = xsp.addNamespaceUrlsToRoot;
			addNamespaces(xsp.namespaces);
			setDefaultNamespace(xsp.defaultNamespace);
			xsiNamespace = xsp.xsiNamespace;
			xsNamespace = xsp.xsNamespace;
		} else {
			addJsonTypeAttrs = op.getBoolean(ADD_JSON_TYPE_ATTRS, xsp.addJsonTypeAttrs);
			addJsonStringTypeAttrs = op.getBoolean(ADD_JSON_STRING_TYPE_ATTRS, xsp.addJsonStringTypeAttrs);
			enableNamespaces = op.getBoolean(ENABLE_NAMESPACES, xsp.enableNamespaces);
			autoDetectNamespaces = op.getBoolean(AUTO_DETECT_NAMESPACES, xsp.autoDetectNamespaces);
			addNamespaceUrlsToRoot = op.getBoolean(ADD_NAMESPACE_URIS_TO_ROOT, xsp.addNamespaceUrlsToRoot);
			namespaces = (op.containsKey(NAMESPACES) ? parseNamespaces(op.get(NAMESPACES)) : xsp.namespaces);
			setDefaultNamespace(op.containsKey(DEFAULT_NAMESPACE) ? op.getString(DEFAULT_NAMESPACE) : xsp.defaultNamespace);
			xsiNamespace = (op.containsKey(XSI_NAMESPACE) ? parseNamespace(op.get(XSI_NAMESPACE)) : xsp.xsiNamespace);;
			xsNamespace = (op.containsKey(XS_NAMESPACE) ? parseNamespace(op.get(XS_NAMESPACE)) : xsp.xsNamespace);
		}
	}

	private void setDefaultNamespace(String s) {
		if (s == null)
			return;
		if (s.startsWith("{"))
			defaultNamespace = parseNamespace(s);
		else if (! s.startsWith("http://"))
			defaultNamespace = get(s, "http://unknown");
		else
			defaultNamespace = get(null, s);
	}

	@SuppressWarnings("hiding")
	private void addNamespaces(Namespace...namespaces) {
		for (Namespace ns : namespaces)
			addNamespace(ns);
	}

	void addNamespace(Namespace ns) {
		if (ns == defaultNamespace)
			return;

		for (Namespace n : namespaces)
			if (n == ns)
				return;

		if (defaultNamespace != null && (ns.uri.equals(defaultNamespace.uri) || ns.name.equals(defaultNamespace.name)))
			defaultNamespace = ns;
		else
			namespaces = ArrayUtils.append(namespaces, ns);
	}

	/**
	 * Returns the list of namespaces being used in the current XML serialization.
	 * @return The list of namespaces being used in the current XML serialization.
	 */
	public Namespace[] getNamespaces() {
		return namespaces;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ADD_JSON_TYPE_ATTRS} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ADD_JSON_TYPE_ATTRS} setting value in this context.
	 */
	public final boolean isAddJsonTypeAttrs() {
		return addJsonTypeAttrs;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ADD_JSON_STRING_TYPE_ATTRS} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ADD_JSON_STRING_TYPE_ATTRS} setting value in this context.
	 */
	public final boolean isAddJsonStringTypeAttrs() {
		return addJsonStringTypeAttrs;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#AUTO_DETECT_NAMESPACES} setting value in this context.
	 * @return The {@link XmlSerializerProperties#AUTO_DETECT_NAMESPACES} setting value in this context.
	 */
	public final boolean isAutoDetectNamespaces() {
		return enableNamespaces && autoDetectNamespaces;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ENABLE_NAMESPACES} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ENABLE_NAMESPACES} setting value in this context.
	 */
	public final boolean isEnableNamespaces() {
		return enableNamespaces;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ADD_NAMESPACE_URIS_TO_ROOT} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ADD_NAMESPACE_URIS_TO_ROOT} setting value in this context.
	 */
	public final boolean isAddNamespaceUrlsToRoot() {
		return addNamespaceUrlsToRoot;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#DEFAULT_NAMESPACE} setting value in this context.
	 * @return The {@link XmlSerializerProperties#DEFAULT_NAMESPACE} setting value in this context.
	 */
	public final Namespace getDefaultNamespace() {
		return defaultNamespace;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#XSI_NAMESPACE} setting value in this context.
	 * @return The {@link XmlSerializerProperties#XSI_NAMESPACE} setting value in this context.
	 */
	public final Namespace getXsiNamespace() {
		return xsiNamespace;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#XS_NAMESPACE} setting value in this context.
	 * @return The {@link XmlSerializerProperties#XS_NAMESPACE} setting value in this context.
	 */
	public final Namespace getXsNamespace() {
		return xsNamespace;
	}
}
