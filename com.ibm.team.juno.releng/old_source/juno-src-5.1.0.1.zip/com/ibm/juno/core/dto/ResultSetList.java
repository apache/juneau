/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.dto;

import java.sql.*;
import java.util.*;

import com.ibm.juno.core.utils.*;

/**
 * Transforms an SQL {@link ResultSet ResultSet} into a list of maps.
 * <p>
 * 	Loads the entire result set into an in-memory data structure, and then closes the result set object.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ResultSetList extends LinkedList<Map<String,Object>> {

	/**
	 * Constructor.
	 *
	 * @param rs The result set to load into this DTO.
	 * @param pos The start position (zero-indexed).
	 * @param limit The maximum number of rows to retrieve.
	 * @param includeRowNums Make the first column be the row number.
	 * @throws SQLException Database error.
	 */
	public ResultSetList(ResultSet rs, int pos, int limit, boolean includeRowNums) throws SQLException {
		try {
			int rowNum = pos;

			// Get the column names.
			ResultSetMetaData rsmd = rs.getMetaData();
			int offset = (includeRowNums ? 1 : 0);
			int cc = rsmd.getColumnCount();
			String[] columns = new String[cc + offset];
			if (includeRowNums)
				columns[0] = "ROW";

			for (int i = 0; i < cc; i++)
				columns[i+offset] = rsmd.getColumnName(i+1);

			while (--pos > 0 && rs.next());

			// Get the rows.
			while (limit-- > 0 && rs.next()) {
				Object[] row = new Object[cc + offset];
				if (includeRowNums)
					row[0] = rowNum++;
				for (int i = 0; i < cc; i++) {
					Object o = rs.getObject(i+1);
					if (o instanceof Blob)
						o = handleBlob((Blob)o);
					else if (o instanceof Clob)
						o = handleClob((Clob)o);
					row[i+offset] = o;
				}
				add(new SimpleMap(columns, row));
			}
		} finally {
			try {
				rs.close();
			} catch (Exception e) {}
		}
	}

	/**
	 * Convert blob to serialized form.
	 * <p>
	 * Subclasses can override this method to provide specialized serialization.
	 * Default implementation simply returns the string <js>"blob"</js>.
	 *
	 * @param b The blob to be serialized.
	 * @return Serialized form of blob.
	 */
	public Object handleBlob(Blob b) {
		return "blob";
	}

	/**
	 * Convert clob to serialized form.
	 * <p>
	 * Subclasses can override this method to provide specialized serialization.
	 * Default implementation simply returns the string <js>"clob"</js>.
	 *
	 * @param c The clob to be serialized.
	 * @return Serialized form of clob.
	 */
	public Object handleClob(Clob c) {
		return "blob";
	}
}
