package com.ibm.juno.core.json;

import static com.ibm.juno.core.json.JsonSerializerProperties.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Context object that lives for the duration of a single serialization of {@link JsonSerializer} and its subclasses.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonSerializerContext extends SerializerContext {

	private final boolean laxMode, useWhitespace;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param jsp Default JSON serializer properties.
	 * @param op Override properties.
	 */
	protected JsonSerializerContext(BeanContext beanContext, SerializerProperties sp, JsonSerializerProperties jsp, ObjectMap op) {
		super(beanContext, sp, op);
		if (op == null || op.isEmpty()) {
			laxMode = jsp.laxMode;
			useWhitespace = jsp.useWhitespace;
		} else {
			laxMode = op.getBoolean(LAX_MODE, jsp.laxMode);
			useWhitespace = op.getBoolean(USE_WHITESPACE, jsp.useWhitespace);
		}
	}

	/**
	 * Returns the {@link JsonSerializerProperties#LAX_MODE} setting value in this context.
	 * @return The {@link JsonSerializerProperties#LAX_MODE} setting value in this context.
	 */
	public final boolean isLaxMode() {
		return laxMode;
	}

	/**
	 * Returns the {@link JsonSerializerProperties#USE_WHITESPACE} setting value in this context.
	 * @return The {@link JsonSerializerProperties#USE_WHITESPACE} setting value in this context.
	 */
	public final boolean isUseWhitespace() {
		return useWhitespace;
	}
}
