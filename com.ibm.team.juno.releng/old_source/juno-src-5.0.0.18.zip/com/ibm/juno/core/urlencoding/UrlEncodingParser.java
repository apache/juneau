package com.ibm.juno.core.urlencoding;

import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.utils.*;

/**
 * Parses URL-encoded text into a POJO model.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Content-Type</code> types: <code>application/x-www-form-urlencoded</code>
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link ParserProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "unchecked", "rawtypes", "hiding" })
@Consumes("application/x-www-form-urlencoded")
public class UrlEncodingParser extends JsonParser {

	/** Default parser, all default settings.*/
	public static final UrlEncodingParser DEFAULT = new UrlEncodingParser().lock();

	/**
	 * Wraps the specified reader in a ParserStringReader if it isn't already.
	 *
	 * @param in The reader being wrapped.
	 * @return The wrapped reader
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	protected ParserStringReader wrapReader(Reader in) throws IOException {
		if (in instanceof ParserStringReader)
			return (ParserStringReader)in;
		return new ParserStringReader(IOUtils.read(in));
	}

	private <T> T parse2(ClassType<T> type, CharSequence cs) throws ParseException, IOException {
		if (cs == null || cs.length() == 0)
			return null;

		if (type == null)
			type = (ClassType<T>)ClassType.OBJECT;
		PojoFilter<T,Object> filter = (PojoFilter<T,Object>)type.getPojoFilter();
		ClassType<?> t = type.getFilteredClassType();

		String s = cs.toString();

		// Skip anything up to '?' if there is anything.
		if (s.indexOf('?') != -1)
			s = s.substring(s.indexOf('?') + 1);

		try {
			if (s.indexOf('=') == -1 && s.indexOf('&') == -1) {
				s = URLDecoder.decode(s, "UTF-8");
				return interpretValue(type, s);
			}

			Map<String,String> m = splitTokens(s);
			if (m.containsKey("_class"))
				t = beanContext.getClassTypeFromString(m.remove("_class").toString());

			Object o;

			if (t.isObject())
				o = (T)parseIntoMap(m, new ObjectMap(), null, null);
			else if (t.isMap()) {
				Map m2 = (Map)(t.canCreateNewInstance() ? t.newInstance() : new ObjectMap());
				o = (T)parseIntoMap(m, m2, t.getKeyType(), t.getValueType());
			} else if (t.isBean() && t.canCreateNewInstance()) {
				BeanMap m2 = beanContext.newBeanMap(t.getInnerClass());
				o = parseIntoBean(m, m2).getBean();
			} else {
				throw new ParseException("Unrecognized syntax for class '%s'", type);
			}

			if (filter != null && o != null)
				o = filter.unfilter(m, type, beanContext);

			return (T)o;

		} catch (ParseException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} catch (Exception e) {
			throw new ParseException(e);
		}
	}

	private <K,V> Map<K,V> parseIntoMap(Map<String,String> in, Map<K,V> m, ClassType<K> keyType, ClassType<V> valueType) throws ParseException, IOException {
		for (Map.Entry<String,String> e : in.entrySet())
			m.put(convertAttrToType(e.getKey(), keyType), interpretValue(valueType, e.getValue()));
		return m;
	}

	private <T> BeanMap<T> parseIntoBean(Map<String,String> input, BeanMap<T> m) throws ParseException, IOException {
		for (Map.Entry<String,String> e : input.entrySet()) {
			String p = e.getKey();
			BeanPropertyMeta pMeta = m.getPropertyMeta(p);
			if (pMeta == null) {
				onUnknownProperty(p, m, -1, -1);
			} else {
				ClassType<?> ct = pMeta.getClassType();
				String v = convertToValidJson(e.getValue());
				Object val = super.parse(new ParserStringReader(v), pMeta, ct);
				m.put(p, val);
			}
		}
		return m;
	}

	private String convertToValidJson(String s) {
		if (s == null || s.length() == 0)
			return s;
		char c = s.charAt(0);
		if (c == '"' || c == '\'' || c == '{' || c == '[')
			return s;
		if (c == 't' && s.equals("true") || c == 'f' && s.equals("false") || c == 'n' && s.equals("null"))
			return s;
		if (isNumeric(s))
			return s;
		int length = s.length() + 2;
		for (int i = 0; i < s.length(); i++)
			if (s.charAt(i) == '\'')
				length++;
		StringBuilder sb = new StringBuilder(length);
		sb.append('\'');
		for (int i = 0; i < s.length(); i++) {
			c = s.charAt(i);
			if (c == '\'')
				sb.append('\\');
			sb.append(c);
		}
		sb.append('\'');
		return sb.toString();
	}

	private Map<String,String> splitTokens(CharSequence cs) {
		String s = cs.toString();

		// Skip anything up to '?' if there is anything.
		if (s.indexOf('?') != -1)
			s = s.substring(s.indexOf('?') + 1);

		// Parameter list
		Map<String,String> m = new LinkedHashMap<String,String>();

		try {

			int S1 = 1; // In param name. Looking for = or end.
			int S2 = 2; // Found =. Looking for & or end.

			int i1 = 0;
			int state = S1;
			String paramName = null;
			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (state == S1) {
					if (c == '=') {
						paramName = URLDecoder.decode(s.substring(i1, i), "UTF-8");
						if (paramName.length() == 1 && paramName.charAt(0) == 0)
							paramName = null;
						i1 = i + 1;
						state = S2;
					} else if (c == '&') {
						paramName = URLDecoder.decode(s.substring(i1, i), "UTF-8");
						i1 = i + 1;
						m.put(paramName, null);
						state = S1;
					}
				} else if (state == S2) {
					if (c == '&') {
						String val = URLDecoder.decode(s.substring(i1, i), "UTF-8");
						m.put(paramName, val);
						state = S1;
						i1 = i + 1;
					}
				}
			}

			// If state is S1, then we encountered a parameter without a value at the end of the string: &PARAM<end>
			if (state == S1 && i1 < s.length())
				m.put(URLDecoder.decode(s.substring(i1, s.length()), "UTF-8"), null);

			// If state is S2, then a blank value was at the end of the string: &PARAM=<end>
			else if (state == S2) {
				String val = URLDecoder.decode(s.substring(i1, s.length()), "UTF-8");
				m.put(paramName, val);
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return m;
	}

	private <T> T interpretValue(ClassType<T> type, String s) throws ParseException, IOException {
		if (s == null)
			return null;
		char c2 = (s.length() == 0 ? 0 : s.charAt(0));
		if (type == null || type.isObject()) {
			if (c2 == '{' || c2 == '[' || c2 == '\'' || c2 == '"')
				return super.parse(new ParserStringReader(s), null, type);
			if (s.equals("true") || s.equals("false"))
				return (T)Boolean.valueOf(s);
			if (s.equals("null"))
				return null;
			if (isNumeric(s))
				return (T)super.parseNumber(s, null);
			return (T)s;
		} else if (type.isMap() && c2 != '{') {
			try {
				Map m = (Map)type.newInstance();
				m.put(s, null);
				return (T)m;
			} catch (Exception e) {
				throw new ParseException(e);
			}
		}
		return super.parse(new ParserStringReader(s), type, null, null);
	}

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // IParser
	public <T> T parse(Reader in, ClassType<T> type, ObjectMap properties, String mediaType) throws ParseException, IOException {
		ParserStringReader r2 = wrapReader(in);
		return parse2(type, r2.getInput());
	}

	@Override // IParser, CoreApi
	public UrlEncodingParser setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	@Override // IExtendedParser
	public <K,V> Map<K,V> parseIntoMap(Reader in, Map<K,V> m, Type keyType, Type valueType) throws ParseException, IOException {
		ParserStringReader r2 = wrapReader(in);
		return parseIntoMap(splitTokens(r2.getInput()), m, beanContext.getClassType(keyType), beanContext.getClassType(valueType));
	}

	@Override // IExtendedParser
	public <E> Collection<E> parseIntoCollection(Reader in, Collection<E> c, Type elementType) throws ParseException, IOException {
		ParserStringReader r2 = wrapReader(in);
		CharSequence input = r2.getInput();
		if (input == null)
			return c;
		r2 = new ParserStringReader(URLDecoder.decode(input.toString(), "UTF-8"));
		return super.parseIntoCollection(r2, c, elementType);
	}

	@Override // IExtendedParser
	public Object[] parseArgs(Reader in, ClassType<?>[] argTypes) throws ParseException, IOException {
		return super.parseArgs(in, argTypes);
	}

	@Override // ICoreApiParser, CoreApi
	public UrlEncodingParser addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public UrlEncodingParser addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public UrlEncodingParser addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public <T> UrlEncodingParser addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // IParser, Lockable
	public UrlEncodingParser lock() {
		super.lock();
		return this;
	}

	@Override // IParser, Lockable
	public UrlEncodingParser clone() {
		return (UrlEncodingParser)super.clone();
	}
}
