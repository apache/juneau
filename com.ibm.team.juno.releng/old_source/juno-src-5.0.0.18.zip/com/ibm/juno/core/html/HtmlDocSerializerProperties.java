package com.ibm.juno.core.html;


/**
 * Properties associated with the {@link HtmlDocSerializer} class.
 * <p>
 * <h6 class='topic'>Example</h6>
 * <p class='bcode'>
 * 	<ja>@RestMethod</ja>(name=<js>"GET"</js>, pattern=<js>"/people/{id}/*"</js>)
 * 	<jk>public</jk> Person getPerson(RestRequest req, RestResponse res, <ja>@Attr</ja> <jk>int</jk> id) <jk>throws</jk> Exception {
 *
 * 		<jc>// Add a title to the page</jc>
 * 		res.addProperty(<jsf>TITLE</jsf>, <js>"Person information"</js>);
 *
 * 		<jc>// Refresh page every 10 seconds</jc>
 * 		res.addProperty(<jsf>REFRESH</jsf>, 10);
 *
 * 		<jc>// Override the stylesheet URL</jc>
 * 		res.addProperty(<jsf>STYLE_SHEET_URL</jsf>, <js>"/contextRoot/myStyles.css"</js>);

 * 		<jk>return</jk> findPerson(id);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlDocSerializerProperties {

	/**
	 * Adds a page title to the top of a page.
	 */
	public static final String TITLE = "HtmlSerializer.title";

	/**
	 * Adds a page description right below the title of a page.
	 */
	public static final String DESCRIPTION = "HtmlSerializer.description";

	/**
	 * Adds a meta refresh tag to the HTML head.  Must be numeric.
	 */
	public static final String REFRESH = "HtmlSerializer.refresh";

	/**
	 * Adds an <code>options</code> link to the page pointing to the specified URL.
	 */
	public static final String OPTIONS_URL = "HtmlDocSerializer.optionsUrl";

	/**
	 * Adds a link to the specified stylesheet URL.
	 */
	public static final String STYLE_SHEET_URL = "HtmlDocSerializer.styleSheetUrl";
}
