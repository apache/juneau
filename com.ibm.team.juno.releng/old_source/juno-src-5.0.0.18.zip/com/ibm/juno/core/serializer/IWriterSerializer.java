package com.ibm.juno.core.serializer;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Top-level interface for all character-based serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	In addition to methods defined in {@link ISerializer}, this method defines two additional
 * 	convenience methods for serializing directly to <code>Strings</code>.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface IWriterSerializer extends ISerializer {

	/**
	 * Serializes a POJO to the specified writer.
	 * <p>
	 * 	The <code>properties</code> map contains configuration settings that override any
	 * 		properties that were specified through the {@link #setProperty(String, Object)} method.
	 * 	For example, you may have a whitespace setting that's disabled by default, but can
	 * 		be overridden for the duration of a method call.
	 * 	The reason why a {@link ObjectMap} is used is because it contains various convenience methods
	 * 		for converting objects to different types without casting.
	 * <p>
	 * 	The media type is going to be one of the strings returned by the {@link #getMediaTypes()} method,
	 * 	but can be <jk>null</jk>.
	 * 	This parameter is provided so that subclasses can handle different media types differently.
	 *
	 * @param o The object to serialize.
	 * @param out The writer or output stream to write to.
	 * @param properties Optional run-time properties.  Can be <jk>null</jk>.
	 * @param mediaType The matched media type.  Can be <jk>null</jk>.
	 *
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serialize(Object o, Writer out, ObjectMap properties, String mediaType) throws IOException, SerializeException;

	/**
	 * Same as {@link IWriterSerializer#serialize(Object, Writer, ObjectMap, String)} except serializes to a <code>String</code>.
	 *
	 * @param o The object to serialize.
	 * @param properties Optional run-time properties.  Can be <jk>null</jk>.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o, ObjectMap properties) throws SerializeException;

	/**
	 * Same as {@link #serialize(Object, ObjectMap)} with <jk>null</jk> runtime properties.
	 *
	 * @param o The object to serialize.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o) throws SerializeException;
}
