package com.ibm.juno.core.rdf;

import static com.ibm.juno.core.rdf.RdfSerializerProperties.*;

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Context object that lives for the duration of a single serialization of {@link RdfSerializer}.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfSerializerContext extends SerializerContext {

	final String rdfLanguage;
	final Namespace defaultNamespace;
	final boolean addLiteralTypes;
	final Map<String,Object> jenaSettings;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param jsp Default Jena serializer properties.
	 * @param op Override properties.
	 */
	protected RdfSerializerContext(BeanContext beanContext, SerializerProperties sp, RdfSerializerProperties jsp, ObjectMap op) {
		super(beanContext, sp, op);
		this.jenaSettings = new HashMap<String,Object>();
		jenaSettings.put("tab", isUseIndentation() ? 0 : 2);
		jenaSettings.put("attributeQuoteChar", getQuoteChar());
		jenaSettings.putAll(jsp.jenaSettings);
		if (op == null || op.isEmpty()) {
			this.rdfLanguage = jsp.rdfLanguage;
			this.defaultNamespace = jsp.defaultNamespace;
			this.addLiteralTypes = jsp.addLiteralTypes;
		} else {
			this.rdfLanguage = op.getString(RDF_LANGUAGE, jsp.rdfLanguage);
			this.defaultNamespace = jsp.defaultNamespace;
			this.addLiteralTypes = op.getBoolean(ADD_LITERAL_TYPES, jsp.addLiteralTypes);
			for (Map.Entry<String,Object> e : op.entrySet()) {
				String key = e.getKey();
				if (key.startsWith("RdfSerializer.")) {
					if (! (key.equals(RDF_LANGUAGE) || key.equals(DEFAULT_NAMESPACE) || key.equals(ADD_LITERAL_TYPES)))
						jenaSettings.put(key.substring(14), e.getValue());
 				}
			}
		}
	}
}
