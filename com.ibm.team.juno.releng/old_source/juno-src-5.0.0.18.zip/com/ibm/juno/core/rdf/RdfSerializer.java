package com.ibm.juno.core.rdf;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.rdf.RdfSerializerProperties.*;

import java.io.*;
import java.util.*;

import com.hp.hpl.jena.rdf.model.*;
import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Serializes POJO models to RDF.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link RdfSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * <h6 class='topic'>Behavior-specific subclasses</h6>
 * <p>
 * 	The following direct subclasses are provided for language-specific serializers:
 * <ul>
 * 	<li>{@link RdfSerializer.Xml} - RDF/XML.
 * 	<li>{@link RdfSerializer.XmlAbbrev} - RDF/XML-ABBREV.
 * 	<li>{@link RdfSerializer.NTriple} - N-TRIPLE.
 * 	<li>{@link RdfSerializer.Turtle} - TURTLE.
 * 	<li>{@link RdfSerializer.N3} - N3.
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@Produces(value="text/xml+rdf+abbrev", contentType="text/xml+rdf")
public class RdfSerializer extends WriterSerializer {

	/** Produces RDF/XML output */
	@Produces("text/xml+rdf")
	public static class Xml extends RdfSerializer {
		/** Constructor */
		public Xml() {
			setProperty(RDF_LANGUAGE, "RDF/XML");
		}
	}

	/** Produces RDF/XML-ABBREV output */
	@Produces(value="text/xml+rdf+abbrev", contentType="text/xml+rdf")
	public static class XmlAbbrev extends RdfSerializer {
		/** Constructor */
		public XmlAbbrev() {
			setProperty(RDF_LANGUAGE, "RDF/XML-ABBREV");
		}
	}

	/** Produces N-TRIPLE output */
	@Produces(value="text/n-triple", contentType="text/plain")
	public static class NTriple extends RdfSerializer {
		/** Constructor */
		public NTriple() {
			setProperty(RDF_LANGUAGE, "N-TRIPLE");
		}
	}

	/** Produces TURTLE output */
	@Produces(value="text/turtle")
	public static class Turtle extends RdfSerializer {
		/** Constructor */
		public Turtle() {
			setProperty(RDF_LANGUAGE, "TURTLE");
		}
	}

	/** Produces N3 output */
	@Produces(value="text/n3")
	public static class N3 extends RdfSerializer {
		/** Constructor */
		public N3() {
			setProperty(RDF_LANGUAGE, "N3");
		}
	}


	/** Jena serializer properties currently set on this serializer. */
	protected transient RdfSerializerProperties jsp = new RdfSerializerProperties();


	/**
	 * @param out The output writer.
	 * @param o The object to serialize.
	 * @param properties Override properties.
	 * @param rootUrl The url of the root document (overridden by URI on root bean if present).
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serialize(Writer out, Object o, String rootUrl, ObjectMap properties) throws IOException, SerializeException {
		RdfSerializerContext ctx = new RdfSerializerContext(beanContext, sp, jsp, properties);
		doSerialize(o, out, ctx, rootUrl);
	}

	/**
	 * Main serialization routine.
	 *
	 * @param o The object being serialized.
	 * @param out The writer to serialize to.
	 * @param ctx The serialization context object.
	 *
	 * @return The same writer passed in.
	 * @throws SerializeException If a general error occurred.
	 */
	protected Writer doSerialize(Object o, Writer out, RdfSerializerContext ctx, String rootUrl) throws SerializeException {
		Model model = ModelFactory.createDefaultModel();
		RDFWriter writer = model.getWriter(ctx.rdfLanguage);
		for (Map.Entry<String,Object> e : ctx.jenaSettings.entrySet())
			writer.setProperty(e.getKey(), e.getValue());
		if (o == null) {
			throw new SerializeException("Null passed to serializer.");
		} else if (o instanceof BeanMap || beanContext.isBean(o)) {
			BeanMap bm = (o instanceof BeanMap ? (BeanMap)o : beanContext.forBean(o));
			String uri = getUri(bm.getBeanUri(), rootUrl, ctx);
			Resource r = model.createResource(uri);
			serializeBeanMap(bm, r, model, ctx);
		} else {
			Resource r = model.createResource(rootUrl);
			if (o instanceof Map) {
				serializeMap((Map)o, r, model, ctx);
			} else if (o instanceof Collection || o.getClass().isArray()) {
				Namespace dns = ctx.defaultNamespace;
				model.setNsPrefix(dns.getName(), dns.getUri());
				Property p = model.createProperty(dns.getUri(), "items");
				RDFList list = model.createList();
				Collection c = (o.getClass().isArray() ? Arrays.asList((Object[])o) : (Collection)o);
				list = serializeCollection(c, null, list, model, ctx);
				r.addProperty(p, list);
			} else {
				throw new SerializeException("Invalid object type '%s' passed to serializer.  Serializer can only serialize beans and maps.", o.getClass().getName());
			}
		}
		writer.write(model, out, "http://unknown/");
		return out;
	}

	private String getUri(Object uri, Object uri2, RdfSerializerContext ctx) {
		String s = null;
		if (uri != null)
			s = uri.toString();
		if ((s == null || s.isEmpty()) && uri2 != null)
			s = uri2.toString();
		if (s == null)
			return null;
		if (s.indexOf(':') == -1) {
			String authority = ctx.getUriAuthority();
			String context = ctx.getUriContext();
			StringBuilder sb = new StringBuilder(s.length() + authority.length() + context.length());
			sb.append(authority);
			if ((! s.startsWith("/")) && ! context.isEmpty())
				sb.append(context).append("/");
			sb.append(s);
			s = sb.toString();
		}
		return s;
	}

	private void serializeMap(Map m, Resource r, Model model, RdfSerializerContext ctx) throws SerializeException {
		for (Map.Entry<Object,Object> me : (Set<Map.Entry<Object,Object>>)m.entrySet()) {
			String key = me.getKey().toString();
			Object value = me.getValue();
			Namespace ns = ctx.defaultNamespace;
			model.setNsPrefix(ns.getName(), ns.getUri());

			Property p = model.createProperty(ns.getUri(), key);
			RDFNode n = serializeAnything(value, model, false, ns, beanContext.getClassTypeForObject(value), ctx);
			if (n != null)
				r.addProperty(p, n);
		}
	}

	private void serializeBeanMap(BeanMap m, Resource r, Model model, RdfSerializerContext ctx) throws SerializeException {
		for (BeanMapEntry bme : (Set<BeanMapEntry>)m.entrySet()) {
			BeanPropertyMeta pMeta = bme.getMeta();

			if (canIgnoreProperty(ctx, pMeta) || pMeta.isBeanUri())
				continue;

			String key = bme.getKey();
			Object value = null;
			try {
				value = bme.getFilteredValue();
			} catch (Throwable x) {
				ctx.addWarning("Could not call getValue() on property '%s', %s", key, x.getLocalizedMessage());
			}

			if (canIgnoreValue(ctx, pMeta.getClassType(), value))
				continue;

			Namespace ns = bme.getMeta().getNamespace();
			if (ns == null)
				ns = ctx.defaultNamespace;
			model.setNsPrefix(ns.getName(), ns.getUri());

			Property p = model.createProperty(ns.getUri(), key);
			RDFNode n = serializeAnything(value, model, pMeta.isUri(), ns, pMeta.getClassType(), ctx);
			if (n != null)
				r.addProperty(p, n);
		}
	}

	private RDFNode serializeAnything(Object o, Model m, boolean isURI, Namespace ns, ClassType<?> eType, RdfSerializerContext ctx) throws SerializeException {

		ClassType<?> aType = null;						// The actual type
		ClassType<?> gType = ClassType.OBJECT;		// The generic type

		aType = ctx.push("", o, eType);

		if (eType == null)
			eType = ClassType.OBJECT;

		// Handle recursion
		if (aType == null) {
			o = null;
			aType = ClassType.OBJECT;
		}

		if (o != null) {

			gType = aType.getFilteredClassType();

			// Filter if necessary
			IPojoFilter filter = aType.getPojoFilter();
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == ClassType.OBJECT)
					gType = beanContext.getClassTypeForObject(o);
			}
		}

		if (o == null || gType.isChar() && ((Character)o).charValue() == 0)
			return (ctx.isTrimNulls() ? null : m.createLiteral("_x0000_"));

		if (gType.isUri() || isURI)
			return m.createResource(getUri(o, null, ctx));

		if (! (gType.isMap() || gType.isBean() || gType.isCollection() || gType.isArray())) {
			if (gType.isCharSequence() || ! ctx.addLiteralTypes)
				return m.createLiteral(o.toString());
			return m.createTypedLiteral(o);
		}

		if (gType.isBean()) {
			BeanMap bm = beanContext.forBean(o);
			String uri = getUri(bm.getBeanUri(), null, ctx);
			Resource r2 = m.createResource(uri);
			serializeBeanMap(bm, r2, m, ctx);
			return r2;
		}

		if (gType.isMap()) {
			Map m2 = (Map)o;
			Resource r2 = m.createResource();
			serializeMap(m2, r2, m, ctx);
			return r2;
		}

		if (gType.isCollection() || gType.isArray()) {
			RDFList list = m.createList();
			Collection c = (gType.isArray() ? Arrays.asList((Object[])o) : (Collection)o);
			return serializeCollection(c, gType.getElementType(), list, m, ctx);
		}

		ctx.pop();

		return null;
	}

	private RDFList serializeCollection(Collection c, ClassType<?> eType, RDFList list, Model m, RdfSerializerContext ctx) throws SerializeException {
		for (Object e : c) {
			ClassType ct = beanContext.getClassTypeForObject(e);

			if (canIgnoreValue(ctx, ct, e))
				continue;

			RDFNode n = serializeAnything(e, m, false, null, eType, ctx);
			list = list.with(n);
		}
		return list;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer
	public void serialize(Object o, Writer out, ObjectMap properties, String mediaType) throws IOException, SerializeException {
		serialize(out, o, null, properties);
	}

	@Override // ISerializer, CoreApi
	public RdfSerializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (jsp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfSerializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public <T> RdfSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // ISerializer, Lockable
	public RdfSerializer lock() {
		super.lock();
		return this;
	}

	@Override // ISerializer, Lockable
	public RdfSerializer clone() {
		try {
			RdfSerializer c = (RdfSerializer)super.clone();
			c.jsp = jsp.clone();
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
