package com.ibm.juno.client;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static java.util.logging.Level.*;

import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;
import java.util.logging.*;

import javax.net.ssl.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.encoders.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.core.utils.*;

/**
 * Represents a connection to a remote REST resource.
 * <p>
 * 	Instances of this class are created by the various {@code doX()} methods on the {@link RestClient} class.
 * <p>
 * 	This class uses only Java standard APIs.  Requests can be built up using a fluent interface with method chaining, like so...
 *
 * <p class='bcode'>
 * 	RestClient client = <jk>new</jk> RestClient();
 * 	RestCall c = client.doGet(url).setInput(o).setHeader(x,y);
 * </p>
 * <p>
 * 	The actual connection and request/response transaction occurs when calling one of the <code>getResponseXXX()</code> methods.
 *
 * <h6 class='topic'>Additional Information</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#RestClient'>com.ibm.juno.client &gt; REST client API</a> for more information and code examples.
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestCall {

	private HttpURLConnection c;              // The connection.
	private HttpsURLConnection sc;            // The connection if using SSL.
	private Object input;                     // What's going to be serialized and sent if this is a POST or PUT.  Can also be a Reader or InputStream.
	private int rc;                           // The return code.
	private boolean
		isConnected = false,                   // connect() has been called.
		isDisconnected = false;                // disconnect() has been called.
	private final RestClient client;          // The client that created this call.
	private final String method;              // The HTTP method
	private final URL url;                    // The URL

	private static Logger LOGGER = Logger.getLogger(RestCall.class.getName());

	/**
	 * Constructs a REST call with the specifed method name.
	 *
	 * @param client The client that created this request.
	 * @param method The HTTP method (e.g. <js>"GET"</js> / <js>"PUT"</js> / <js>"POST"</js> / <js>"DELETE"</js>)
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param params Optional URL parameters to append to the URL.
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 */
	protected RestCall(RestClient client, String method, Object url, Map<String,Object> params) throws RestCallException {
		this.client = client;
		this.method = method.toUpperCase();
		this.url = getUrl(url, params);
		createConnection(this.method, this.url);
	}

	/**
	 * Constructs a REST call with the specifed method name.
	 *
	 * @param client The client that created this request.
	 * @param method The HTTP method (e.g. <js>"GET"</js> / <js>"PUT"</js> / <js>"POST"</js> / <js>"DELETE"</js>)
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 */
	protected RestCall(RestClient client, String method, Object url) throws RestCallException {
		this(client, method, url, null);
	}

	@SuppressWarnings("hiding")
	private void createConnection(String method, URL url) throws RestCallException {
		try {
			method = method.toUpperCase();
			c = (HttpURLConnection)url.openConnection(client.proxy);
			c.setInstanceFollowRedirects(false);
			sc = (c instanceof HttpsURLConnection) ? (HttpsURLConnection)c : null;
			setRequestMethod(method);
			setDoInput(true);
			setDoOutput(method.equals("POST") || method.equals("PUT"));
			if (client.accept != null)
				setHeader("Accept", client.accept);
			if (client.contentType != null)
				setHeader("Content-Type", client.contentType);
			if (client.encoder != null) {
				setHeader("Content-Encoding", client.encoder.getCodings()[0]);
				setHeader("Accept-Encoding", client.encoder.getCodings()[0]);
			}
			setHeaders(client.headers);
		} catch (IOException e) {
			throw new RestCallException(e);
		}
	}

	/**
	 * Sets the input for this REST call.
	 *
	 * @param input The input to be sent to the REST resource (only valid for PUT and POST) requests. <br>
	 * 	Can be of the following types:
	 * 	<ul>
	 * 		<li>{@link Reader} - Raw contents of {@code Reader} will be serialized to remote resource.
	 * 		<li>{@link InputStream} - Raw contents of {@code InputStream} will be serialized to remote resource.
	 * 		<li>{@link Object} - POJO to be converted to text using the {@link ISerializer} registered with the {@link RestClient}.
	 * 	</ul>
	 * @return This object (for method chaining).
	 */
	public RestCall setInput(Object input) {
		this.input = input;
		return this;
	}

	/**
	 * Sets multiple HTTP request header fields based on the contents of the map.
	 *
	 * @param headers The map containing the HTTP header entries.
	 * @return This object (for method chaining).
	 */
	public RestCall setHeaders(Map<String,Object> headers) {
		for (Map.Entry<String,? extends Object> e : headers.entrySet()) {
			String key = e.getKey();
			Object value = e.getValue();
			if (value instanceof Collection) {
				for (Object v : (Collection<?>)value)
					addHeader(key, v.toString());
			} else {
				setHeader(key, e.getValue().toString());
			}
		}
		return this;
	}

	/**
	 * Equivalent to calling {@code connect()} followed by {@code disconnect()} followed by {@code getResponseCode()}.
	 * <p>
	 * 	Use this method if you're only interested in the return code from the response.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jk>try</jk> {
	 * 		RestClient client = <jk>new</jk> RestClient();
	 * 		<jk>int</jk> rc = client.doGet(url).execute();
	 * 		<jc>// Succeeded!</jc>
	 * 	} <jk>catch</jk> (RestCallException e) {
	 * 		<jc>// Failed!</jc>
	 * 	}
	 * </p>
	 *
	 * @return This object (for method chaining).
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 */
	public int execute() throws RestCallException {
		connect().disconnect();
		return rc;
	}

	/**
	 * Returns the HTTP request message body output stream.
	 * <p>
	 * 	If an {@link Encoder} has been registered with the {@link RestClient}, then the output stream
	 * 		will be wrapped in the encoded stream (e.g. a <code>GZIPOutputStream</code>).
	 *
	 * @return The HTTP request message body output stream.
	 * @throws IOException If a problem occurred trying to write to the writer.
	 */
	public BufferedOutputStream getOutputStream() throws IOException {
		OutputStream os = c.getOutputStream();
		if (client.encoder != null)
			os = client.encoder.getOutputStream(os);
		return new BufferedOutputStream(os);
	}

	/**
	 * Returns the HTTP request message body reader.
	 * <p>
	 * 	If an {@link Encoder} has been registered with the {@link RestClient}, then the underlying output stream
	 * 		will be wrapped in the encoded stream (e.g. a <code>GZIPOutputStream</code>).
	 * <p>
	 * 	If present, automatically handles the <code>charset</code> value in the <code>Content-Type</code> request header.
	 *
	 * @return The HTTP request message body writer.
	 * @throws IOException If <code>charset</code> was an invalid value.
	 */
	public Writer getWriter() throws IOException {
		String cs = "UTF-8";
		String contentType = getRequestHeader("Content-Type");
		if (contentType != null && contentType.contains("charset="))
			cs = contentType.substring(contentType.indexOf("charset=")+8).trim();
		return new OutputStreamWriter(getOutputStream(), cs);
	}

	/**
	 * Connects to the REST resource.
	 * <p>
	 * 	If this is a <code>PUT</code> or <code>POST</code>, also sends the input to the remote resource.<br>
	 * <p>
	 * 	Typically, you would only call this method if you're not interested in retrieving the body of the HTTP response.
	 * 	Otherwise, you're better off just calling one of the {@link #getReader()}/{@link #getResponse(Class)}/{@link #pipeTo(Writer)}
	 * 	methods directly which automatically call this method already.
	 *
	 * @return This object (for method chaining).
	 * @throws RestCallException If an exception or <code>400+</code> HTTP status code occurred during the connection attempt.
	 */
	public RestCall connect() throws RestCallException {

		if (isConnected)
			return this;

		if (isDisconnected) {
			createConnection(method, url);
			isDisconnected = false;
		}

		final boolean[] connectionMade = {false};
		final boolean[] connectionTimedOut = {false};
		long startTime = System.currentTimeMillis();
		try {

			Timer t = null;
			if (getConnectTimeout() > 0) {
				t = new Timer();
				t.schedule(new TimerTask() {
					@Override
					public void run() {
						if (!connectionMade[0]) {
							c.disconnect();
							connectionTimedOut[0] = true;
						}
					}
				}, new Date(System.currentTimeMillis() + c.getConnectTimeout()));
			}
			connectionMade[0] = false;
			connectionTimedOut[0] = false;
			c.connect();
			if (t != null)
				t.cancel();
			connectionMade[0] = true;
			if (LOGGER.isLoggable(FINE)) {
				LOGGER.fine("Connection made in "+(System.currentTimeMillis()-startTime)+"ms");
				startTime = System.currentTimeMillis();
			}
			String m = c.getRequestMethod();
			if (m.equals("POST") || m.equals("PUT")) {
				if (input instanceof InputStream) {
					OutputStream os = getOutputStream();
					IOUtils.pipe((InputStream)input, os);
					os.close();
				} else if (input instanceof Reader) {
					Writer w = getWriter();
					IOUtils.pipe((Reader)input, w);
					w.close();
				} else {
					ISerializer s = getSerializer();
					try {
						if (s instanceof IOutputStreamSerializer) {
							OutputStream os = getOutputStream();
							IOutputStreamSerializer s2 = (IOutputStreamSerializer)s;
							s2.serialize(input, os, null, null, null);
							os.close();
						} else {
							Writer w = getWriter();
							IWriterSerializer s2 = (IWriterSerializer)s;
							s2.serialize(input, w, null, null);
							w.close();
						}
					} catch (SerializeException e) {
						throw new RestCallException(e);
					}
				}
				if (LOGGER.isLoggable(FINE)) {
					System.err.println("Output sent in "+(System.currentTimeMillis()-startTime)+"ms");
					startTime = System.currentTimeMillis();
				}
			}

			rc = c.getResponseCode();

			if (LOGGER.isLoggable(FINE)) {
				LOGGER.fine("Response received in "+(System.currentTimeMillis()-startTime)+"ms");
				startTime = System.currentTimeMillis();
			}

			// Handle redirection ourselves so that the user/pw gets set on the second request too.
			int redirectCount = 0;
			if (rc >= 200 && rc < 400) {
				String url2 = c.getHeaderField("location");
				if (url2 != null) {
					redirectCount++;
					if (redirectCount > 5)
						throw new RestCallException(rc, "Redirect too many times", m, c.getURL().toString(), "");
					isConnected = false;
					createConnection("GET", new URL(url2));
					connect();
					return this;
				}
			}
			isConnected = true;

			if (rc >= 400) {
				String responseText = "";
				try {
					responseText = getResponseAsString();
				} catch (IOException e) {
					responseText = "[" + e.getLocalizedMessage() + "]";
				}
				throw new RestCallException(rc, c.getResponseMessage(), m, c.getURL().toString(), responseText);
			}

		} catch (IOException e) {
			if (connectionTimedOut[0])
				throw new RestCallException(new IOException("Connection timed out."));
			throw (e instanceof RestCallException ? (RestCallException)e : new RestCallException(e));
		} finally {
			isConnected = true;
			if (! getDoInput()) {
				disconnect();
			}
		}
		return this;
	}

	/**
	 * Connects to the remote resource (if <code>connect()</code> hasn't already been called) and returns the HTTP response message body as a reader.
	 * <p>
	 * 	If an {@link Encoder} has been registered with the {@link RestClient}, then the underlying input stream
	 * 		will be wrapped in the encoded stream (e.g. a <code>GZIPInputStream</code>).
	 * <p>
	 * 	If present, automatically handles the <code>charset</code> value in the <code>Content-Type</code> response header.
	 * <p>
	 * 	<b>IMPORTANT:</b>  It is your responsibility to close this reader once you have finished with it.
	 *
	 * @return The HTTP response message body reader.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public Reader getReader() throws IOException {
		InputStream is = getInputStream();

		// Figure out what the charset of the response is.
		String cs = null;
		String ct = c.getContentType();

		// First look for "charset=" in Content-Type header of response.
		if (ct != null && ct.contains("charset="))
			cs = ct.substring(ct.indexOf("charset=")+8).trim();

		if (cs == null)
			cs = "UTF-8";

		return new BufferedReader(new InputStreamReader(is, cs));
	}

	private IParser getParser() throws RestCallException {
		if (client.parser == null)
			throw new RestCallException(0, "No parser defined on client", method, url.toString(), null);
		return client.parser;
	}

	private ISerializer getSerializer() throws RestCallException {
		if (client.serializer == null)
			throw new RestCallException(0, "No serializer defined on client", method, url.toString(), null);
		return client.serializer;
	}

	/**
	 * Connects to the remote resource (if <code>connect()</code> hasn't already been called) and returns the HTTP response message body as an input stream.
	 * <p>
	 * 	If an {@link Encoder} has been registered with the {@link RestClient}, then the underlying input stream
	 * 		will be wrapped in the encoded stream (e.g. a <code>GZIPInputStream</code>).
	 * <p>
	 * 	<b>IMPORTANT:</b>  It is your responsibility to close this reader once you have finished with it.
	 *
	 * @return The HTTP response message body input stream.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public BufferedInputStream getInputStream() throws IOException {
		if (! isConnected)
			connect();
		if (rc < 400) {
			InputStream is = c.getInputStream();
			String ce = c.getContentEncoding();
			if (ce != null) ce = ce.toLowerCase();
			Encoder e = client.encoder;
			if (e != null && ce != null)
				for (String ee : e.getCodings())
					if (ce.contains(ee.toLowerCase()))
						return new BufferedInputStream(e.getInputStream(is));
			return new BufferedInputStream(is);
		}
		return new BufferedInputStream(c.getErrorStream());
	}

	/**
	 * Connects to the remote resource (if {@code connect()} hasn't already been called) and returns the HTTP response message body as plain text.
	 *
	 * @return The response as a string.
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public String getResponseAsString() throws IOException {
		String s = IOUtils.read(getReader()).toString();
		disconnect();
		return s;
	}

	/**
	 * Converts the output from the connection into an object of the specified class using the registered {@link IParser}.
	 *
	 * @param type The class to convert the input to.
	 * @param <T> The class to convert the input to.
	 * @return The parsed output.
	 * @throws IOException If a connection error occurred.
	 * @throws ParseException If the input contains a syntax error or is malformed for the <code>Content-Type</code> header.
	 */
	public <T> T getResponse(Class<T> type) throws IOException, ParseException {
		return getResponse(BeanContext.DEFAULT.getClassType(type));
	}

	private <T> T getResponse(ClassType<T> type) throws IOException, ParseException {
		long startTime = System.currentTimeMillis();
		IParser p = getParser();
		if (p == null)
			throw new RestCallException(0, "No parser defined on client.", method, null, null);
		T o = null;
		if (p instanceof IInputStreamParser) {
			InputStream is = getInputStream();
			o = ((IInputStreamParser)p).parse(is, type, null, null, null);
			is.close();
		} else {
			Reader r = getReader();
			o = ((IReaderParser)p).parse(r, type, null, null);
			r.close();
		}
		disconnect();
		if (LOGGER.isLoggable(FINE))
			LOGGER.fine("Response parsed in "+(System.currentTimeMillis()-startTime)+"ms");
		return o;
	}

	/**
	 * Connects to the remote resource (if {@code connect()} hasn't already been called) and pipes the output to the specified writer.
	 *
	 * @param w The writer to pipe the output to.
	 * @return This object (for method chaining).
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public RestCall pipeTo(Writer w) throws IOException {
		IOUtils.pipe(getReader(), w);
		disconnect();
		return this;
	}

	/**
	 * Connects to the remote resource (if {@code connect()} hasn't already been called) and pipes the output to the specified stream.
	 *
	 * @param os The output stream to send the response to.
	 * @return This object (for method chaining).
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public RestCall pipeTo(OutputStream os) throws IOException {
		IOUtils.pipe(getInputStream(), os);
		disconnect();
		return this;
	}

	/*
	 * Encodes unicode and space characters in a URL.
	 * <p>
	 * 	Takes a URL containing unicode characters (e.g. <js>"http://raaxpjpn1.rtp.raleigh.ibm.com:8088/explore/file/C:/TCs/G11N1/A\u6FECC/GPN\u6FECP4.pli?method=VIEW"</js>)
	 * 	and encodes the unicode characters (e.g. <js>"http://raaxpjpn1.rtp.raleigh.ibm.com:8088/explore/file/C:/TCs/G11N1/A%E6%BF%ACC/GCN%E6%BF%ACP4.cbl?method=VIEW"</js>)
	 * <p>
	 * 	Also replaces spaces with <js>'+'</js>.
	 * <p>
	 * 	Note that you cannot just use {@code URLEncoder.encode(String)}, since that will encode <js>':'</js>, <js>'/'</js>, <js>'?'</js> etc...
	 *
	 * @return The encoded URL.
	 */
	private static URL getUrl(Object url, Map<String,Object> params) throws RestCallException {
		try {
			if (url instanceof URL && (params == null || params.isEmpty()))
				return (URL)url;

			StringWriter sw = new StringWriter();

			boolean needsEncoding = false;

			String u = url.toString();

			for (int i = 0; i < u.length() && ! needsEncoding; i++)
				if (u.charAt(i) > 127 || u.charAt(i) == ' ')
					needsEncoding = true;

			if (needsEncoding) {
				for (int i = 0; i < u.length(); i++) {
					char x = u.charAt(i);
					if (x == ' ')
						sw.append('+');
					else if (x > 127)
						sw.append(URLEncoder.encode(""+x, "UTF-8"));
					else
						sw.append(x);
				}
			} else {
				sw.append(u);
			}

			if (! (params == null || params.isEmpty())) {

				char d = u.indexOf('?') == -1 ? '?' : '&';

				for (Map.Entry<String,Object> e : params.entrySet()) {
					sw.append(d);
					d = '&';
					UrlEncodingSerializerWriter.encode(sw, e.getKey());
					Object val = e.getValue();
					if (val != null) {
						sw.append("=");
						if (val instanceof Map || val instanceof Collection)
							try {
								UrlEncodingSerializerWriter.encode(sw, JsonSerializer.DEFAULT.serialize(val));
							} catch (SerializeException e1) {
								e1.printStackTrace();
							}
						else
							UrlEncodingSerializerWriter.encode(sw, val);
					}
				}
			}

			return new URL(sw.toString());

		} catch (Exception e) {
			throw new RestCallException(e);
		}
	}


	// --------------------------------------------------------------------------------
	// Pass-through URLConnection methods
	// --------------------------------------------------------------------------------

	/**
	 * Sets a specified timeout value, in milliseconds, to be used when opening a communications link to the resource referenced by this URLConnection.
	 * <p>
	 * 	If the timeout expires before theconnection can be established, a java.net.SocketTimeoutException is raised. A timeout of zero is interpreted as an infinite timeout.
	 * <p>
	 * 	Some non-standard implmentation of this method may ignore the specified timeout. To see the connect timeout set, please call getConnectTimeout().
	 *
	 * @param connectTimeout An <jk>int</jk> that specifies the connect timeout value in milliseconds
	 * @throws IllegalArgumentException If the timeout parameter is negative
	 * @return This object for method chaining.
	 * @see URLConnection#setConnectTimeout(int)
	 */
	public RestCall setConnectTimeout(int connectTimeout) {
		c.setConnectTimeout(connectTimeout);
		return this;
	}

	/**
	 * Returns setting for connect timeout.
	 * <p>
	 * 	{@code 0} return implies that the option is disabled (i.e., timeout of infinity).
	 *
	 * @return An <jk>int</jk> that indicates the connect timeout value in milliseconds.
	 * @see URLConnection#getConnectTimeout()
	 */
	public int getConnectTimeout() {
		return c.getConnectTimeout();
	}

	/**
	 * Sets the read timeout to a specified timeout, in milliseconds.
	 * <p>
	 * 	A non-zero value specifies the timeout when reading from Input stream when a connection is established to a resource.
	 * 	If the timeout expires before there is data available for read, a java.net.SocketTimeoutException is raised.
	 * 	A timeout of zero is interpreted as an infinite timeout.
	 * <p>
	 * 	Some non-standard implementation of this method ignores the specified timeout.
	 * 	To see the read timeout set, please call getReadTimeout().
	 *
	 * @param readTimeout An <jk>int</jk> that specifies the timeout value to be used in milliseconds.
	 * @throws IllegalArgumentException If the timeout parameter is negative.
	 * @return This object (for method chaining).
	 *
	 * @see URLConnection#setReadTimeout(int)
	 */
	public RestCall setReadTimeout(int readTimeout) {
		c.setReadTimeout(readTimeout);
		return this;
	}

	/**
	 * Returns setting for read timeout.
	 * <p>
	 * 	{@code 0} return implies that the option is disabled (i.e., timeout of infinity).
	 *
	 * @return An <jk>int</jk> that indicates the read timeout value in milliseconds.
	 * @see URLConnection#getReadTimeout()
	 */
	public int getReadTimeout() {
		return c.getReadTimeout();
	}

	/**
	 * Returns the value of this <code>URLConnection</code>'s <code>URL</code> field.
	 *
	 * @return The value of this <code>URLConnection</code>'s <code>URL</code> field.
	 * @see URLConnection#getURL()
	 */
	public URL getURL() {
		return c.getURL();
	}

	/**
	 * Returns the value of the <code>content-length</code> header field.
	 *
	 * @return The content length of the resource that this connection's URL references, or <code>-1</code> if the content length is not known.
	 * @see URLConnection#getContentLength()
	 */
	public int getContentLength() {
		return c.getContentLength();
	}

	/**
	 * Returns the value of the <code>content-type</code> header field.
	 *
	 * @return The content type of the resource that the URL references, or <jk>null</jk> if not known.
	 * @see URLConnection#getContentType()
	 */
	public String getContentType() {
		return c.getContentType();
	}

	/**
	 * Returns the value of the <code>content-encoding</code> header field.
	 *
	 * @return The content encoding of the resource that the URL references, or <jk>null</jk> if not known.
	 * @see URLConnection#getContentEncoding()
	 */
	public String getContentEncoding() {
		return c.getContentEncoding();
	}

	/**
	 * Returns the value of the <code>expires</code> header field.
	 *
	 * @return The expiration date of the resource that this URL references, or {@code 0} if not known.
	 * 	The value is the number of milliseconds since January 1, 1970 GMT.
	 * @see URLConnection#getExpiration()
	 */
	public long getExpiration() {
		return c.getExpiration();
	}

	/**
	 * Returns the value of the <code>date</code> header field.
	 *
	 * @return The sending date of the resource that the URL references, or <code>0</code> if not known.
	 * 	The value returned is the number of milliseconds since January 1, 1970 GMT.
	 * @see URLConnection#getDate()
	 */
	public long getDate() {
		return c.getDate();
	}

	/**
	 * Returns the value of the <code>last-modified</code> header field.
	 * <p>
	 * 	The result is the number of milliseconds since January 1, 1970 GMT.
	 *
	 * @return The date the resource referenced by this <code>URLConnection</code> was last modified, or {@code 0} if not known.
	 * @see URLConnection#getLastModified()
	 */
	public long getLastModified() {
		return c.getLastModified();
	}

	/**
	 * Returns the value of the named header field.
	 * <p>
	 * 	If called on a connection that sets the same header multiple times with possibly different values, only the last value is returned.
	 *
	 * @param name The name of a header field.
	 * @return The value of the named header field, or <jk>null</jk> if there is no such field in the header.
	 * @see URLConnection#getHeaderField(String)
	 */
	public String getHeaderField(String name) {
		return c.getHeaderField(name);
	}

	/**
	 * Returns an unmodifiable Map of the header fields.
	 * <p>
	 * 	The Map keys are Strings that represent the response-header field names.
	 * 	Each Map value is an unmodifiable List of Strings that represents the corresponding field values.
	 *
	 * @return A Map of header fields
	 * @see URLConnection#getHeaderFields()
	 */
	public Map<String,List<String>> getHeaderFields() {
		return c.getHeaderFields();
	}

	/**
	 * Returns the value of the named field parsed as a number.
	 * <p>
	 * 	This form of <code>getHeaderField</code> exists because some connection types (e.g., <code>http-ng</code>) have pre-parsed headers.
	 * 	Classes for that connection type can override this method and short-circuit the parsing.
	 *
	 * @param name The name of the header field.
	 * @param def The default value.
	 * @return The value of the named field, parsed as an integer.
	 * 	The <code>def</code> value is returned if the field is missing or malformed.
	 * @see URLConnection#getHeaderFieldInt(String, int)
	 */
	public int getHeaderFieldInt(String name, int def) {
		return c.getHeaderFieldInt(name, def);
	}

	/**
	 * Returns the value of the named field parsed as a date.
	 *
	 * @param name The name of the header field.
	 * @param def The default value.
	 * @return The value of the named field, parsed as a date.
	 * 	The <code>def</code> value is returned if the field is missing or malformed.
	 * @see URLConnection#getHeaderFieldDate(String, long)
	 */
	public long getHeaderFieldDate(String name, long def) {
		return c.getHeaderFieldDate(name, def);
	}

	/**
	 * Returns the key for the <code>n</code><sup>th</sup> header field.
	 * <p>
	 * 	Some implementations may treat the <code>0</code><sup>th</sup> header field as special, i.e. as the status line returned by the HTTP server.
	 * 	In this case, {@link #getHeaderField(int) getHeaderField(0)} returns the status line, but <code>getHeaderFieldKey(0)</code> returns null.
	 *
	 * @param index An index, where n &gt;= 0.
	 * @return The key for the <code>n</code><sup>th</sup> header field, or <jk>null</jk> if the key does not exist.
	 * @see URLConnection#getHeaderFieldKey(int)
	 */
	public String getHeaderFieldKey(int index) {
		return c.getHeaderFieldKey(index);
	}

	/**
	 * Returns the value for the <code>n</code><sup>th</sup> header field.
	 * <p>
	 * 	Some implementations may treat the <code>0</code><sup>th</sup> header field as special, i.e. as the status line returned by the HTTP server.
	 * <p>
	 * 	This method can be used in conjunction with the {@link #getHeaderFieldKey getHeaderFieldKey} method to iterate through all the headers in the message.
	 *
	 * @param index An index, where n &gt;= 0.
	 * @return The value of the <code>n</code><sup>th</sup> header field, or <jk>null</jk> if the value does not exist.
	 * @see URLConnection#getHeaderField(int)
	 */
	public String getHeaderField(int index) {
		return c.getHeaderField(index);
	}

	/**
	 * Returns a permission object representing the permission necessary to make the connection represented by this object.
	 * <p>
	 * 	This method returns null if no permission is required to make the connection.
	 * 	By default, this method returns java.security.AllPermission.
	 * 	Subclasses should override this method and return the permission that best represents the permission required to make a a connection to the URL.
	 * 	For example, a URLConnection representing a file: URL would return a java.io.FilePermission object.
	 * <p>
	 * 	The permission returned may dependent upon the state of the connection.
	 * 	For example, the permission before connecting may be different from that after connecting.
	 * 	For example, an HTTP sever, say foo.com, may redirect the connection to a different host, say bar.com.
	 * 	Before connecting the permission returned by the connection will represent the permission needed to connect to foo.com, while the permission returned after connecting will be to bar.com.
	 * <p>
	 * 	Permissions are generally used for two purposes: to protect caches of objects obtained through URLConnections, and to check the right of a recipient to learn about a particular URL.
	 * 	In the first case, the permission should be obtained after the object has been obtained.
	 * 	For example, in an HTTP connection, this will represent the permission to connect to the host from which the data was ultimately fetched.
	 * 	In the second case, the permission should be obtained and tested before connecting.
	 * <p>
	 * @return The permission object representing the permission necessary to make the connection represented by this URLConnection.
	 * @throws IOException If the computation of the permission requires network or file I/O and an exception occurs while computing it.
 	 */
	public Permission getPermission() throws IOException {
		return c.getPermission();
	}

	/**
	 * Sets the value of the <code>doInput</code> field for this <code>URLConnection</code> to the specified value.
	 * <p>
	 * 	A URL connection can be used for input and/or output.
	 * 	Set the DoInput flag to true if you intend to use the URL connection for input, false if not.
	 * 	The default is true.
	 *
	 * @param doInput The new value.
	 * @throws IllegalStateException If already connected.
	 * @return This object for method chaining.
	 * @see URLConnection#setDoInput(boolean)
	 */
	public RestCall setDoInput(boolean doInput) {
		c.setDoInput(doInput);
		return this;
	}

	/**
	 * Returns the value of this <code>URLConnection</code>'s <code>doInput</code> flag.
	 * <p>
	 * @return The value of this <code>URLConnection</code>'s <code>doInput</code> flag.
	 * @see URLConnection#getDoInput()
	 */
	public boolean getDoInput() {
		return c.getDoInput();
	}

	/**
	 * Sets the value of the <code>doOutput</code> field for this <code>URLConnection</code> to the specified value.
	 * <p>
	 * 	A URL connection can be used for input and/or output.
	 * 	Set the DoOutput flag to true if you intend to use the URL connection for output, false if not.
	 * 	The default is false.
	 *
	 * @param doOutput The new value.
	 * @throws IllegalStateException If already connected
	 * @return This object for method chaining.
	 * @see URLConnection#setDoOutput(boolean)
	 */
	public RestCall setDoOutput(boolean doOutput) {
		c.setDoOutput(doOutput);
		return this;
	}

	/**
	 * Returns the value of this <code>URLConnection</code>'s <code>doOutput</code> flag.
	 *
	 * @return The value of this <code>URLConnection</code>'s <code>doOutput</code> flag.
	 * @see URLConnection#getDoOutput()
	 */
	public boolean getDoOutput() {
		return c.getDoOutput();
	}

	/**
	 * Set the value of the <code>allowUserInteraction</code> field of this <code>URLConnection</code>.
	 *
	 * @param allowUserInteraction The new value.
	 * @throws IllegalStateException If already connected
	 * @return This object for method chaining.
	 * @see URLConnection#setAllowUserInteraction(boolean)
	 */
	public RestCall setAllowUserInteraction(boolean allowUserInteraction) {
		c.setAllowUserInteraction(allowUserInteraction);
		return this;
	}

	/**
	 * Returns the value of the <code>allowUserInteraction</code> field for this object.
	 *
	 * @return The value of the <code>allowUserInteraction</code> field for this object.
	 * @see URLConnection#getAllowUserInteraction()
	 */
	public boolean getAllowUserInteraction() {
		return c.getAllowUserInteraction();
	}

	/**
	 * Sets the default value of the <code>allowUserInteraction</code> field for all future <code>URLConnection</code> objects to the specified value.
	 *
	 * @param defaultAllowUserInteraction The new value.
	 * @see URLConnection#setDefaultAllowUserInteraction(boolean)
	 */
	public static void setDefaultAllowUserInteraction(boolean defaultAllowUserInteraction) {
		URLConnection.setDefaultAllowUserInteraction(defaultAllowUserInteraction);
	}

	/**
	 * Returns the default value of the <code>allowUserInteraction</code> field.
	 * <p>
	 * 	The default is "sticky", being a part of the static state of all URLConnections.
	 * 	This flag applies to the next, and all following URLConnections that are created.
	 *
	 * @return The default value of the <code>allowUserInteraction</code> field.
	 * @see URLConnection#getDefaultAllowUserInteraction()
	 */
	public static boolean getDefaultAllowUserInteraction() {
		return URLConnection.getDefaultAllowUserInteraction();
	}

	/**
	 * Sets the value of the <code>useCaches</code> field of this <code>URLConnection</code> to the specified value.
	 * <p>
	 * 	Some protocols do caching of documents.
	 * 	Occasionally, it is important to be able to "tunnel through" and ignore the caches (e.g., the "reload" button in a browser).
	 * 	If the UseCaches flag on a connection is true, the connection is allowed to use whatever caches it can.
	 * 	If false, caches are to be ignored. The default value comes from DefaultUseCaches, which defaults to true.
	 *
	 * @param useCaches A <code>boolean</code> indicating whether or not to allow caching
	 * @throws IllegalStateException If already connected
	 * @return This object for method chaining.
	 * @see URLConnection#setUseCaches(boolean)
	 */
	public RestCall setUseCaches(boolean useCaches) {
		c.setUseCaches(useCaches);
		return this;
	}

	/**
	 * Returns the value of this <code>URLConnection</code>'s <code>useCaches</code> field.
	 *
	 * @return The value of this <code>URLConnection</code>'s <code>useCaches</code> field.
	 * @see URLConnection#getUseCaches()
	 */
	public boolean getUseCaches() {
		return c.getUseCaches();
	}

	/**
	 * Sets the value of the <code>ifModifiedSince</code> field of this <code>URLConnection</code> to the specified value.
	 *
	 * @param ifModifiedSince The new value.
	 * @throws IllegalStateException If already connected.
	 * @return This object for method chaining.
	 * @see URLConnection#setIfModifiedSince(long)
	 */
	public RestCall setIfModifiedSince(long ifModifiedSince) {
		c.setIfModifiedSince(ifModifiedSince);
		return this;
	}

	/**
	 * Returns the value of this object's <code>ifModifiedSince</code> field.
	 *
	 * @return The value of this object's <code>ifModifiedSince</code> field.
	 * @see URLConnection#getIfModifiedSince()
	 */
	public long getIfModifiedSince() {
		return c.getIfModifiedSince();
	}

	/**
	 * Returns the default value of a <code>URLConnection</code>'s <code>useCaches</code> flag.
	 * <p>
	 * 	The default is "sticky", being a part of the static state of all URLConnections.
	 * 	This flag applies to the next, and all following URLConnections that are created.
	 *
	 * @return The default value of a <code>URLConnection</code>'s <code>useCaches</code> flag.
	 * @see URLConnection#getDefaultUseCaches()
	 */
	public boolean getDefaultUseCaches() {
		return c.getDefaultUseCaches();
	}

	/**
	 * Sets the default value of the <code>useCaches</code> field to the specified value.
	 *
	 * @param defaultusecaches The new value.
	 * @return This object for method chaining.
	 * @see URLConnection#setDefaultUseCaches(boolean)
	 */
	public RestCall setDefaultUseCaches(boolean defaultusecaches) {
		c.setDefaultUseCaches(defaultusecaches);
		return this;
	}

	/**
	 * Sets the general request property.
	 * <p>
	 * 	If a property with the key already exists, overwrite its value with the new value.
	 * <p>
	 * 	NOTE: HTTP requires all request properties which can legally have multiple instances with the
	 * 	same key to use a comma-seperated list syntax which enables multiple properties to be appended into  a single property.
	 *
	 * @param key The keyword by which the request is known (e.g., <js>"accept"</js>).
	 * @param value The value associated with it.
	 * @throws IllegalStateException If already connected.
	 * @throws NullPointerException If key is <jk>null</jk>.
	 * @return This object for method chaining.
	 * @see URLConnection#setRequestProperty(String, String)
	 */
	public RestCall setHeader(String key, String value) {
		c.setRequestProperty(key, value);
		return this;
	}

	/**
	 * Adds a general request property specified by a key-value pair.
	 * <p>
	 * 	This method will not overwrite existing values associated with the same key.
	 *
	 * @param key The keyword by which the request is known (e.g., <js>"accept"</js>).
	 * @param value The value associated with it.
	 * @throws IllegalStateException If already connected.
	 * @throws NullPointerException If key is null.
	 * @return This object for method chaining.
	 * @see URLConnection#addRequestProperty(String, String)
	 */
	public RestCall addHeader(String key, String value) {
		c.addRequestProperty(key, value);
		return this;
	}

	/**
	 * Returns the value of the named general request property for this connection.
	 *
	 * @param key The keyword by which the request is known (e.g., "accept").
	 * @return The value of the named general request property for this connection.
	 * 	If key is null, then null is returned.
	 * @throws IllegalStateException if already connected
	 * @see URLConnection#getRequestProperty(String)
	 */
	public String getRequestHeader(String key) {
		return c.getRequestProperty(key);
	}

	/**
	 * Returns an unmodifiable Map of general request properties for this connection.
	 * <p>
	 * 	The Map keys are Strings that represent the request-header field names.
	 * 	Each Map value is a unmodifiable List of
	 * 	Strings that represents the corresponding field values.
	 *
	 * @return A Map of the general request properties for this connection.
	 * @throws IllegalStateException If already connected
	 * @see URLConnection#getRequestProperties()
	 */
	public Map<String,List<String>> getRequestHeader() {
		return c.getRequestProperties();
	}

	// --------------------------------------------------------------------------------
	// Pass-through HttpURLConnection methods
	// --------------------------------------------------------------------------------

	/**
	 * This method is used to enable streaming of a HTTP request body without internal buffering, when the content length is known in advance.
	 * <p>
	 * 	An exception will be thrown if the application attempts to write more data than the indicated content-length, or if the application closes the OutputStream before writing the indicated amount.
	 * <p>
	 * 	When output streaming is enabled, authentication and redirection cannot be handled automatically.
	 * 	A HttpRetryException will be thrown when reading the response if authentication or redirection are required.
	 * 	This exception can be queried for the details of the error.
	 * <p>
	 * 	This method must be called before the URLConnection is connected.
	 *
	 * @param contentLength The number of bytes which will be written to the OutputStream.
	 * @throws IllegalStateException If URLConnection is already connected or if a different streaming mode is already enabled.
	 * @throws IllegalArgumentException If a content length less than zero is specified.
	 * @return This object for method chaining.
	 * @see HttpURLConnection#setFixedLengthStreamingMode(int)
	 */
	public RestCall setFixedLengthStreamingMode(int contentLength) {
		c.setFixedLengthStreamingMode(contentLength);
		return this;
	}

	/**
	 * This method is used to enable streaming of a HTTP request body without internal buffering, when the content length is <b>not</b> known in advance.
	 * <p>
	 * 	In this mode, chunked transfer encoding is used to send the request body.
	 * 	Note, not all HTTP servers support this mode.
	 * <p>
	 * 	When output streaming is enabled, authentication and redirection cannot be handled automatically.
	 * 	A HttpRetryException will be thrown when reading the response if authentication or redirection are required.
	 * 	This exception can be queried for the details of the error.
	 * <p>
	 * 	This method must be called before the URLConnection is connected.
	 *
	 * @param chunkLength The number of bytes to write in each chunk.
	 * 	If chunklen is less than or equal to zero, a default value will be used.
	 * @throws IllegalStateException If URLConnection is already connected or if a different streaming mode is already enabled.
	 * @return This object for method chaining.
	 * @see HttpURLConnection#setChunkedStreamingMode(int)
	 */
	public RestCall setChunkedStreamingMode(int chunkLength) {
		c.setChunkedStreamingMode(chunkLength);
		return this;
	}

	/**
	 * Sets whether HTTP redirects (requests with response code 3xx) should be automatically followed by this class.
	 * <p>
	 * 	True by default.
	 * 	Applets cannot change this variable.
	 * <p>
	 * 	If there is a security manager, this method first calls the security manager's <code>checkSetFactory</code> method to ensure the operation is allowed.
	 * 	This could result in a SecurityException.
	 *
	 * @param followRedirects A <jk>boolean</jk> indicating whether or not to follow HTTP redirects.
	 * @throws SecurityException If a security manager exists and its <code>checkSetFactory</code> method doesn't allow the operation.
	 * @see HttpURLConnection#setFollowRedirects(boolean)
	 */
	public static void setFollowRedirects(boolean followRedirects) {
		HttpURLConnection.setFollowRedirects(followRedirects);
	}

	/**
	 * Returns a <code>boolean</code> indicating whether or not HTTP redirects (3xx) should be automatically followed.
	 *
	 * @return <jk>true</jk> if HTTP redirects should be automatically followed, <jk>false</jk> if not.
	 * @see HttpURLConnection#getFollowRedirects()
	 */
	public static boolean getFollowRedirects() {
		return HttpURLConnection.getFollowRedirects();
	}

	/**
	 * Sets whether HTTP redirects (requests with response code 3xx) should be automatically followed by this <code>HttpURLConnection</code> instance.
	 * <p>
	 * 	The default value comes from followRedirects, which defaults to <jk>true</jk>.
	 *
	 * @param followRedirects A <jk>boolean</jk> indicating whether or not to follow HTTP redirects.
	 * @return This object for method chaining.
	 * @see HttpURLConnection#setInstanceFollowRedirects(boolean)
	 */
	public RestCall setInstanceFollowRedirects(boolean followRedirects) {
		c.setInstanceFollowRedirects(followRedirects);
		return this;
	}

	/**
	 * Returns the value of this <code>HttpURLConnection</code>'s <code>instanceFollowRedirects</code> field.
	 *
	 * @return The value of this <code>HttpURLConnection</code>'s <code>instanceFollowRedirects</code> field.
	 * @see HttpURLConnection#getInstanceFollowRedirects()
	 */
	public boolean getInstanceFollowRedirects() {
		return c.getInstanceFollowRedirects();
	}

	/**
	 * Set the method for the URL request, one of:
	 * <UL>
	 * 	<LI>GET
	 * 	<LI>POST
	 * 	<LI>HEAD
	 * 	<LI>OPTIONS
	 * 	<LI>PUT
	 * 	<LI>DELETE
	 * 	<LI>TRACE
	 * </UL>
	 * are legal, subject to protocol restrictions. The default method is GET.
	 *
	 * @param method The HTTP method.
	 * @throws ProtocolException If the method cannot be reset or if the requested method isn't valid for HTTP.
	 * @return This object for method chaining.
	 * @see HttpURLConnection#setRequestMethod(String)
	 */
	public RestCall setRequestMethod(String method) throws ProtocolException {
		c.setRequestMethod(method);
		return this;
	}

	/**
	 * Get the request method.
	 *
	 * @return The HTTP request method.
	 * @see HttpURLConnection#getRequestMethod()
	 */
	public String getRequestMethod() {
		return c.getRequestMethod();
	}

	/**
	 * Gets the status code from an HTTP response message. For example, in the case of the following status lines:
	 * <PRE>
	 * HTTP/1.0 200 OK
	 * HTTP/1.0 401 Unauthorized
	 * </PRE>
	 * It will return 200 and 401 respectively.
	 * Returns -1 if no code can be discerned from the response (i.e., the response is not valid HTTP).
	 *
	 * @return the HTTP Status-Code, or -1
	 * @see HttpURLConnection#getResponseCode()
	 */
	public int getResponseCode() {
		return rc;
	}

	/**
	 * Gets the HTTP response message, if any, returned along with the response code from a server. From responses like:
	 * <PRE>
	 * HTTP/1.0 200 OK
	 * HTTP/1.0 404 Not Found
	 * </PRE>
	 * Extracts the Strings <js>"OK"</js> and <js>"Not Found"</js> respectively.
	 * Returns <jk>null<jk> if none could be discerned from the responses (the result was not valid HTTP).
	 *
	 * @throws IOException If an error occurred connecting to the server.
	 * @return the HTTP response message, or <jk>null</jk>
	 * @see HttpURLConnection#getResponseMessage()
	 */
	public String getResponseMessage() throws IOException {
		return c.getResponseMessage();
	}

	/**
	 * Indicates that other requests to the server are unlikely in the near future.
	 * <p>
	 * 	Unlike {@link HttpURLConnection#disconnect()}, instances of this class can be used for other requests.
	 *
	 * @return This object (for method chaining).
	 * @see HttpURLConnection#disconnect()
	 */
	public RestCall disconnect() {
		c.disconnect();
		isConnected = false;
		isDisconnected = true;
		return this;
	}

	/**
	 * Indicates if the connection is going through a proxy.
	 *
	 * @return A boolean indicating if the connection is using a proxy.
	 * @see HttpURLConnection#usingProxy()
	 */
	public boolean usingProxy() {
		return c.usingProxy();
	}

	/**
	 * Returns the error stream if the connection failed but the server sent useful data nonetheless.
	 * <p>
	 * 	The typical example is when an HTTP server responds with a 404, which will cause a FileNotFoundException to be thrown in connect,
	 * 	but the server sent an HTML help page with suggestions as to what to do.
	 * <p>
	 * 	This method will not cause a connection to be initiated.
	 * 	If the connection was not connected, or if the server did not have an error while connecting or if the server had an error but no
	 * 	error data was sent, this method will return <jk>null</jk>.
	 * 	This is the default.
	 *
	 * @return An error stream if any, <jk>null</jk> if there have been no errors, the connection is not connected or the server sent no useful data.
	 * @see HttpURLConnection#getErrorStream()
	 */
	public InputStream getErrorStream() {
		return c.getErrorStream();
	}


	// --------------------------------------------------------------------------------
	// Pass-through HttpsURLConnection methods
	// --------------------------------------------------------------------------------

	private static String NOT_A_SECURE_CONNECTION = "Not a secure connection";

	/**
	 * @return See {@link HttpsURLConnection#getCipherSuite()}.
	 * @see HttpsURLConnection#getCipherSuite()
	 */
	public String getCipherSuite() {
		if (sc == null)
			throw new RuntimeException(NOT_A_SECURE_CONNECTION);
		return sc.getCipherSuite();
	}

	/**
	 * @return See {@link HttpsURLConnection#getDefaultHostnameVerifier()}.
	 * @see HttpsURLConnection#getDefaultHostnameVerifier()
	 */
	public static HostnameVerifier getDefaultHostnameVerifier() {
		return HttpsURLConnection.getDefaultHostnameVerifier();
	}

	/**
	 * @return See {@link HttpsURLConnection#getDefaultSSLSocketFactory()}.
	 * @see HttpsURLConnection#getDefaultSSLSocketFactory()
	 */
	public static SSLSocketFactory getDefaultSSLSocketFactory() {
		return HttpsURLConnection.getDefaultSSLSocketFactory();
	}

	/**
	 * @return See {@link HttpsURLConnection#getHostnameVerifier()}.
	 * @see HttpsURLConnection#getHostnameVerifier()
	 */
	public HostnameVerifier getHostnameVerifier() {
		if (sc == null)
			throw new RuntimeException(NOT_A_SECURE_CONNECTION);
		return sc.getHostnameVerifier();
	}

	/**
	 * @return See {@link HttpsURLConnection#getLocalCertificates()}.
	 * @see HttpsURLConnection#getLocalCertificates()
	 */
	public java.security.cert.Certificate[] getLocalCertificates() {
		if (sc == null)
			throw new RuntimeException(NOT_A_SECURE_CONNECTION);
		return sc.getLocalCertificates();
	}

	/**
	 * @return See {@link HttpsURLConnection#getLocalPrincipal()}.
	 * @see HttpsURLConnection#getLocalPrincipal()
	 */
	public Principal getLocalPrincipal() {
		if (sc == null)
			throw new RuntimeException(NOT_A_SECURE_CONNECTION);
		return sc.getLocalPrincipal();
	}

	/**
	 * @return See {@link HttpsURLConnection#getPeerPrincipal()}.
	 * @throws SSLPeerUnverifiedException See {@link HttpsURLConnection#getPeerPrincipal()}.
	 * @see HttpsURLConnection#getPeerPrincipal()
	 */
	public Principal getPeerPrincipal() throws SSLPeerUnverifiedException {
		if (sc == null)
			throw new RuntimeException(NOT_A_SECURE_CONNECTION);
		return sc.getPeerPrincipal();
	}

	/**
	 * @return See {@link HttpsURLConnection#getServerCertificates()}.
	 * @throws SSLPeerUnverifiedException See {@link HttpsURLConnection#getServerCertificates()}.
	 * @see HttpsURLConnection#getServerCertificates()
	 */
	public java.security.cert.Certificate[] getServerCertificates() throws SSLPeerUnverifiedException {
		if (sc == null)
			throw new RuntimeException(NOT_A_SECURE_CONNECTION);
		return sc.getServerCertificates();
	}

	/**
	 * @return See {@link HttpsURLConnection#getSSLSocketFactory()}.
	 * @see HttpsURLConnection#getSSLSocketFactory()
	 */
	public SSLSocketFactory getSSLSocketFactory() {
		if (sc == null)
			throw new RuntimeException(NOT_A_SECURE_CONNECTION);
		return sc.getSSLSocketFactory();
	}

	/**
	 * @param hostnameVerifier See {@link HttpsURLConnection#setDefaultHostnameVerifier(HostnameVerifier)}.
	 * @see HttpsURLConnection#setDefaultHostnameVerifier(HostnameVerifier)
	 */
	public static void setDefaultHostnameVerifier(HostnameVerifier hostnameVerifier) {
		HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);
	}

	/**
	 * @param socketFactory See {@link HttpsURLConnection#setDefaultSSLSocketFactory(SSLSocketFactory)}.
	 * @see HttpsURLConnection#setDefaultSSLSocketFactory(SSLSocketFactory)
	 */
	public static void setDefaultSSLSocketFactory(SSLSocketFactory socketFactory) {
		HttpsURLConnection.setDefaultSSLSocketFactory(socketFactory);
	}

	/**
	 * @param hostnameVerifier See {@link HttpsURLConnection#setHostnameVerifier(HostnameVerifier)}.
	 * @return This object for method chaining.
	 * @see HttpsURLConnection#setHostnameVerifier(HostnameVerifier)
	 */
	public RestCall setHostnameVerifier(HostnameVerifier hostnameVerifier) {
		if (sc == null)
			throw new RuntimeException(NOT_A_SECURE_CONNECTION);
		sc.setHostnameVerifier(hostnameVerifier);
		return this;
	}

	/**
	 * @param socketFactory See {@link HttpsURLConnection#setSSLSocketFactory(SSLSocketFactory)}.
	 * @return This object for method chaining.
	 * @see HttpsURLConnection#setSSLSocketFactory(SSLSocketFactory)
	 */
	public RestCall setSSLSocketFactory(SSLSocketFactory socketFactory) {
		if (sc == null)
			throw new RuntimeException(NOT_A_SECURE_CONNECTION);
		sc.setSSLSocketFactory(socketFactory);
		return this;
	}
}
