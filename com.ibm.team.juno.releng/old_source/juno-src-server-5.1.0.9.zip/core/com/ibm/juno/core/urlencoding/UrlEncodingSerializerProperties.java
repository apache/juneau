/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.urlencoding;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Configurable properties on the {@link UrlEncodingSerializer} class.
 * <p>
 * 	Use the {@link UrlEncodingSerializer#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link UrlEncodingSerializer}.
 * <ul>
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public final class UrlEncodingSerializerProperties implements Cloneable {

	/**
	 * Use simplified output ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, type flags will not be prepended to values in most cases.
	 * <p>
	 * Use this setting if the data types of the values (e.g. object/array/boolean/number/string)
	 * 	is known on the receiving end.
	 * <p>
	 * It should be noted that the default behavior produces a data structure that can
	 * 	be losslessly converted into JSON, and any JSON can be losslessly represented
	 * 	in a URL-encoded value.  However, this strict equivalency does not exist
	 * 	when simple mode is used.
	 * <p>
	 * <table class='styled'>
	 * 	<tr>
	 * 		<th>Input (in JSON)</th>
	 * 		<th>Normal mode output</th>
	 * 		<th>Simple mode output</th>
	 * 	</tr>
	 * 	<tr>
	 * 		<td class='code'>{foo:'bar',baz:'bing'}</td>
	 * 		<td class='code'>$o(foo=bar,baz=bing)</td>
	 * 		<td class='code'>(foo=bar,baz=bing)</td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td class='code'>{foo:{bar:'baz'}}</td>
	 * 		<td class='code'>$o(foo=$o(bar=baz))</td>
	 * 		<td class='code'>(foo=(bar=baz))</td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td class='code'>['foo','bar']</td>
	 * 		<td class='code'>$a(foo,bar)</td>
	 * 		<td class='code'>(foo,bar)</td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td class='code'>['foo',['bar','baz']]</td>
	 * 		<td class='code'>$a(foo,$a(bar,baz))</td>
	 * 		<td class='code'>(foo,(bar,baz))</td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td class='code'>true</td>
	 * 		<td class='code'>$b(true)</td>
	 * 		<td class='code'>true</td>
	 * 	</tr>
	 * 	<tr>
	 * 		<td class='code'>123</td>
	 * 		<td class='code'>$n(123)</td>
	 * 		<td class='code'>123</td>
	 * 	</tr>
	 * </table>
	 */
	public static final String URLENC_simpleMode = "UrlEncodingSerializer.simpleMode";

	/**
	 * Use whitespace in output ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, whitespace is added to the output to improve readability.
	 */
	public static final String URLENC_useWhitespace = "UrlEncodingSerializer.useWhitespace";

	/**
	 * Encode non-valid URI characters to <js>"%xx"</js> constructs. ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * If <jk>true</jk>, non-valid URI characters will be converted to <js>"%xx"</js> sequences.
	 * Set to <jk>false</jk> if parameter value is being passed to some other code that will already
	 * 	perform URL-encoding of non-valid URI characters.
	 * <p>
	 * This setting is ignored when calling {@link UrlEncodingSerializer#serializeParams(Object)} and related
	 * 	methods since it would produce invalid results when literals contain <code>=</code> and <code>&</code> characters.
	 */
	public static final String URLENC_encodeChars = "UrlEncodingSerializer.encodeChars";

	boolean
		simpleMode = false,
		useWhitespace = false,
		encodeChars = true;

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		BeanContext bc = BeanContext.DEFAULT;
		if (property.equals(URLENC_simpleMode))
			simpleMode = bc.convertToType(value, Boolean.class);
		else if (property.equals(URLENC_useWhitespace))
			useWhitespace = bc.convertToType(value, Boolean.class);
		else if (property.equals(URLENC_encodeChars))
			encodeChars = bc.convertToType(value, Boolean.class);
		else
			return false;
		return true;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Cloneable
	public UrlEncodingSerializerProperties clone() {
		try {
			return (UrlEncodingSerializerProperties)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
