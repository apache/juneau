/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.client;

import org.apache.http.*;
import org.apache.http.impl.client.*;
import org.apache.http.protocol.*;

/**
 * Redirect strategy that allows for redirects on any request type, not just <code>GET</code> or <code>HEAD</code>.
 * <p>
 * Note:  This class is equivalent to <code>org.apache.http.impl.client.LaxRedirectStrategy</code>
 * 	in Apache HttpClient 4.2, but is included for the same capability in HttpClient 4.1.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class LaxRedirectStrategy extends DefaultRedirectStrategy {

	@Override
	public boolean isRedirected(HttpRequest request, HttpResponse response, HttpContext context) throws ProtocolException {
		int rc = response.getStatusLine().getStatusCode();
		switch (rc) {
			case HttpStatus.SC_MOVED_TEMPORARILY:
				return response.getFirstHeader("location") != null;
			case HttpStatus.SC_MOVED_PERMANENTLY:
			case HttpStatus.SC_TEMPORARY_REDIRECT:
			case HttpStatus.SC_SEE_OTHER:
				return true;
		}
		return false;
	}
}
