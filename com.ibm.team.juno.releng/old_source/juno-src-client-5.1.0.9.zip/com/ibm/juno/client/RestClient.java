/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.client;

import java.net.*;
import java.util.*;

import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.methods.*;
import org.apache.http.conn.*;
import org.apache.http.impl.client.*;

import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.urlencoding.*;

/**
 * Utility class for interfacing with remote REST interfaces.
 *
 *
 * <h6 class='topic'>Features</h6>
 * <ul>
 * 	<li>Convert POJOs directly to HTTP request message bodies using {@link Serializer} class.
 * 	<li>Convert HTTP response message bodies directly to POJOs using {@link Parser} class.
 * 	<li>Fluent interface.
 * 	<li>Thread safe.
 * </ul>
 *
 *
 * <h6 class='topic'>Additional Information</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#RestClient'>com.ibm.juno.client &gt; REST client API</a> for more information and code examples.
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestClient {

	Map<String,Object> headers = new TreeMap<String,Object>(String.CASE_INSENSITIVE_ORDER);
	HttpClient httpClient;
	Serializer<?> serializer;
	Parser<?> parser;
	String accept, contentType;

	/**
	 * Create a new client with no serializer, parser, or HTTP client.
	 * <p>
	 * If you do not specify an {@link HttpClient} via the {@link #setHttpClient(HttpClient)}, one
	 * 	will be created using the {@link #createHttpClient()} method.
	 */
	public RestClient() {
	}

	/**
	 * Create a new client with the specified HTTP client.
	 * <p>
	 * Equivalent to calling the following:
	 * <p class='bcode'>
	 * 	RestClient rc = <jk>new</jk> RestClient().setHttpClient(httpClient);
	 * </p>
	 *
	 * @param httpClient The HTTP client to use for communicating with remote server.
	 */
	public RestClient(HttpClient httpClient) {
		setHttpClient(httpClient);
	}

	/**
	 * Create a new client with the specified serializer and parser instances.
	 * <p>
	 * Equivalent to calling the following:
	 * <p class='bcode'>
	 * 	RestClient rc = <jk>new</jk> RestClient().setSerializer(s).setParser(p);
	 * </p>
	 * <p>
	 * If you do not specify an {@link HttpClient} via the {@link #setHttpClient(HttpClient)}, one
	 * 	will be created using the {@link #createHttpClient()} method.
	 *
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 */
	public RestClient(Serializer<?> s, Parser<?> p) {
		setSerializer(s);
		setParser(p);
	}

	/**
	 * Create a new client with the specified serializer and parser instances.
	 * <p>
	 * Equivalent to calling the following:
	 * <p class='bcode'>
	 * 	RestClient rc = <jk>new</jk> RestClient().setHttpClient(httpClient).setSerializer(s).setParser(p);
	 * </p>
	 *
	 * @param httpClient The HTTP client to use for communicating with remote server.
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 */
	public RestClient(HttpClient httpClient, Serializer<?> s, Parser<?> p) {
		setHttpClient(httpClient);
		setSerializer(s);
		setParser(p);
	}

	/**
	 * Create a new client with the specified serializer and parser classes.
	 * <p>
	 * Equivalent to calling the following:
	 * <p class='bcode'>
	 * 	RestClient rc = <jk>new</jk> RestClient().setSerializer(s).setParser(p);
	 * </p>
	 * <p>
	 * If you do not specify an {@link HttpClient} via the {@link #setHttpClient(HttpClient)}, one
	 * 	will be created using the {@link #createHttpClient()} method.
	 *
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 * @throws InstantiationException If serializer or parser could not be instantiated.
	 */
	public RestClient(Class<? extends Serializer<?>> s, Class<? extends Parser<?>> p) throws InstantiationException {
		setSerializer(s);
		setParser(p);
	}

	/**
	 * Create a new client with the specified serializer and parser classes.
	 * <p>
	 * Equivalent to calling the following:
	 * <p class='bcode'>
	 * 	RestClient rc = <jk>new</jk> RestClient().setHttpClient(httpClient).setSerializer(s).setParser(p);
	 * </p>
	 *
	 * @param httpClient The HTTP client to use for communicating with remote server.
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 * @throws InstantiationException If serializer or parser could not be instantiated.
	 */
	public RestClient(HttpClient httpClient, Class<? extends Serializer<?>> s, Class<? extends Parser<?>> p) throws InstantiationException {
		setHttpClient(httpClient);
		setSerializer(s);
		setParser(p);
	}

	/**
	 * Creates an instance of an {@link HttpClient} to be used to handle all HTTP communications with the target server.
	 * <p>
	 * This HTTP client is used when the HTTP client is not specified through one of the constructors or the
	 * 	{@link #setHttpClient(HttpClient)} method.
	 * <p>
	 * Subclasses can override this method to provide specially-configured HTTP clients to handle
	 * 	stuff such as SSL/TLS certificate handling, authentication, etc.
	 * <p>
	 * The default implementation returns a simple instance of {@link DefaultHttpClient} using {@link LaxRedirectStrategy}.
	 */
	protected HttpClient createHttpClient() throws Exception {
		AbstractHttpClient client = new DefaultHttpClient();
		client.setRedirectStrategy(new LaxRedirectStrategy());  // Allow redirects on PUT/POST/DELETE
		return client;
	}

	/**
	 * Calls {@link ClientConnectionManager#shutdown()} on the underlying {@link HttpClient}.
	 * It's good practice to call this method after the client is no longer used.
	 */
	public void shutdown() {
		if (httpClient != null)
			httpClient.getConnectionManager().shutdown();
	}

	/**
	 * Specifies a request header property to add to all requests created by this client.
	 *
	 * @param name The HTTP header name.
	 * @param value The HTTP header value.
	 * @return This object (for method chaining).
	 */
	public RestClient setHeader(String name, Object value) {
		this.headers.put(name, value);
		return this;
	}

	/**
	 * Sets the serializer used for serializing POJOs to the HTTP request message body.
	 *
	 * @param serializer The serializer.
	 * @return This object (for method chaining).
	 */
	public RestClient setSerializer(Serializer<?> serializer) {
		this.serializer = serializer;
		contentType = serializer.getResponseContentType();
		if (contentType == null)
			contentType = serializer.getMediaTypes()[0];
		return this;
	}

	/**
	 * Same as {@link #setSerializer(Serializer)}, except takes in a serializer class that
	 * 	will be instantiated through a no-arg constructor.
	 *
	 * @param c The serializer class.
	 * @return This object (for method chaining).
	 * @throws InstantiationException If serializer could not be instantiated.
	 */
	public RestClient setSerializer(Class<? extends Serializer<?>> c) throws InstantiationException {
		try {
			return setSerializer(c.newInstance());
		} catch (IllegalAccessException e) {
			throw new InstantiationException(e.getLocalizedMessage());
		}
	}

	/**
	 * Sets the parser used for parsing POJOs from the HTTP response message body.
	 *
	 * @param parser The parser.
	 * @return This object (for method chaining).
	 */
	public RestClient setParser(Parser<?> parser) {
		this.parser = parser;
		this.accept = parser.getMediaTypes()[0];
		return this;
	}

	/**
	 * Same as {@link #setParser(Parser)}, except takes in a parser class that
	 * 	will be instantiated through a no-arg constructor.
	 *
	 * @param c The parser class.
	 * @return This object (for method chaining).
	 * @throws InstantiationException If parser could not be instantiated.
	 */
	public RestClient setParser(Class<? extends Parser<?>> c) throws InstantiationException {
		try {
			return setParser(c.newInstance());
		} catch (IllegalAccessException e) {
			throw new InstantiationException(e.getLocalizedMessage());
		}
	}

	/**
	 * Sets the internal {@link HttpClient} to use for handling HTTP communications.
	 *
	 * @param httpClient The HTTP client.
	 * @return This object (for method chaining).
	 */
	public RestClient setHttpClient(HttpClient httpClient) {
		this.httpClient = httpClient;
		return this;
	}

	/**
	 * Returns the serializer currently associated with this client.
	 *
	 * @return The serializer currently associated with this client, or <jk>null</jk> if no serializer is currently associated.
	 */
	public Serializer<?> getSerializer() {
		return serializer;
	}

	/**
	 * Returns the parser currently associated with this client.
	 *
	 * @return The parser currently associated with this client, or <jk>null</jk> if no parser is currently associated.
	 */
	public Parser<?> getParser() {
		return parser;
	}

	/**
	 * Returns the {@link HttpClient} currently associated with this client.
	 *
	 * @return The HTTP client currently associated with this client.
	 */
	public HttpClient getHttpClient() throws Exception {
		if (httpClient == null)
			httpClient = createHttpClient();
		return httpClient;
	}

	/**
	 * Execute the specified request.
	 * Subclasses can override this method to provide specialized handling.
	 */
	protected HttpResponse execute(HttpUriRequest req) throws Exception {
		return getHttpClient().execute(req);
	}

	/**
	 * Sets the value for the <code>Accept</code> request header.
	 * <p>
	 * 	This overrides the media type specified on the parser, but is overridden by calling <code>setHeader(<js>"Accept"</js>, newvalue);</code>
	 *
	 * @param accept The new header value.
	 * @return This object (for method chaining).
	 */
	public RestClient setAccept(String accept) {
		this.accept = accept;
		return this;
	}

	/**
	 * Sets the value for the <code>Content-Type</code> request header.
	 * <p>
	 * 	This overrides the media type specified on the serializer, but is overridden by calling <code>setHeader(<js>"Content-Type"</js>, newvalue);</code>
	 * @param contentType The new header value.
	 *
	 * @return This object (for method chaining).
	 */
	public RestClient setContentType(String contentType) {
		this.contentType = contentType;
		return this;
	}

	/**
	 * Perform a <code>GET</code> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doGet(Object url) throws RestCallException {
		return doCall("GET", url, false);
	}

	/**
	 * Perform a <code>PUT</code> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doPut(Object url, Object o) throws RestCallException {
		return doCall("PUT", url, true).setInput(o);
	}

	/**
	 * Perform a <code>POST</code> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doPost(Object url, Object o) throws RestCallException {
		return doCall("POST", url, true).setInput(o);
	}

	/**
	 * Perform a <code>DELETE</code> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doDelete(Object url) throws RestCallException {
		return doCall("DELETE", url, false);
	}

	/**
	 * Perform an <code>OPTIONS</code> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doOptions(Object url) throws RestCallException {
		return doCall("OPTIONS", url, true);
	}

	/**
	 * Perform a <code>POST</code> request with a content type of <code>application/x-www-form-urlencoded</code> against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request, serialized as a form post
	 * 	using the {@link UrlEncodingSerializer#DEFAULT} serializer.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doFormPost(Object url, Object o) throws RestCallException {
		try {
			return doCall("POST", url, true)
				.setHeader("Content-Type", "application/x-www-form-urlencoded")
				.setInput(UrlEncodingSerializer.DEFAULT.serializeParams(o));
		} catch (SerializeException e) {
			throw new RestCallException(e);
		}
	}

	/**
	 * Perform a generic REST call.
	 *
	 * @param method The method name (e.g. <js>"GET"</js>, <js>"OPTIONS"</js>).
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doCall(String method, Object url, boolean hasContent) throws RestCallException {
		HttpRequestBase req = null;
		RestCall restCall = null;
		final String methodUC = method.toUpperCase(Locale.ENGLISH);
		if (hasContent) {
			req = new HttpEntityEnclosingRequestBase() {
				@Override
				public String getMethod() {
					return methodUC;
				}
			};
			restCall = new RestCall(this, req);
			if (contentType != null)
				restCall.setHeader("Content-Type", contentType);
		} else {
			req = new HttpRequestBase() {
				@Override
				public String getMethod() {
					return methodUC;
				}
			};
			restCall = new RestCall(this, req);
		}
		try {
			req.setURI(toURI(url));
		} catch (URISyntaxException e) {
			throw new RestCallException(e);
		}
		if (accept != null)
			restCall.setHeader("Accept", accept);
		for (Map.Entry<String,? extends Object> e : headers.entrySet())
			restCall.setHeader(e.getKey(), e.getValue());
		return restCall;
	}


	private URI toURI(Object url) throws URISyntaxException {
		if (url == null)
			throw new NullPointerException("No URI specified");
		if (url instanceof URI)
			return (URI)url;
		if (url instanceof URL)
			((URL)url).toURI();
		return new URI(url.toString());
	}
}
