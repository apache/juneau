/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been
 * deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.client.jazz;

import static org.apache.http.HttpStatus.*;

import java.io.*;
import java.net.*;
import java.security.*;

import javax.net.ssl.*;

import org.apache.http.*;
import org.apache.http.auth.*;
import org.apache.http.client.*;
import org.apache.http.client.entity.*;
import org.apache.http.client.methods.*;
import org.apache.http.client.params.*;
import org.apache.http.conn.*;
import org.apache.http.conn.scheme.*;
import org.apache.http.conn.ssl.*;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.*;
import org.apache.http.impl.conn.*;
import org.apache.http.message.*;
import org.apache.http.util.*;

import com.ibm.juno.client.*;
import com.ibm.juno.client.LaxRedirectStrategy;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;

/**
 * Specialized {@link RestClient} for working with Jazz servers.
 * <p>
 * Provides support for BASIC and FORM authentication against Jazz servers and simple SSL certificate validation.
 *
 * <h6 class='topic'>Additional Information</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#RestClient'>com.ibm.juno.client.jazz &gt; Jazz REST client API</a> for more information and code examples.
 * </ul>
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JazzRestClient extends RestClient {

	private String user, pw;
	private URI jazzUri;

	/**
	 * Create a new client with no serializer or parser.
	 *
	 * @param jazzUrl The URL of the Jazz server being connected to (e.g. <js>"https://localhost:9443/jazz"</js>)
	 * @param user The Jazz username.
	 * @param pw The Jazz password.
	 * @throws IOException If a problem occurred trying to authenticate against the Jazz server.
	 */
	public JazzRestClient(String jazzUrl, String user, String pw) throws IOException {
		super();
		this.user = user;
		this.pw = pw;
		if (! jazzUrl.endsWith("/"))
			jazzUrl = jazzUrl + "/";
		jazzUri = URI.create(jazzUrl);
	}

	/**
	 * Create a new client with the specified serializer and parser instances.
	 *
	 * @param jazzUri The URI of the Jazz server being connected to (e.g. <js>"https://localhost:9443/jazz"</js>)
	 * @param user The Jazz username.
	 * @param pw The Jazz password.
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 * @throws IOException If a problem occurred trying to authenticate against the Jazz server.
	 */
	public JazzRestClient(String jazzUri, String user, String pw, Serializer<?> s, Parser<?> p) throws IOException {
		this(jazzUri, user, pw);
		setParser(p);
		setSerializer(s);
	}

	/**
	 * Create a new client with the specified serializer and parser classes.
	 *
	 * @param jazzUri The URI of the Jazz server being connected to (e.g. <js>"https://localhost:9443/jazz"</js>)
	 * @param user The Jazz username.
	 * @param pw The Jazz password.
	 * @param s The serializer for converting POJOs to HTTP request message body text.
	 * @param p The parser for converting HTTP response message body text to POJOs.
	 * @throws IOException If a problem occurred trying to authenticate against the Jazz server.
	 * @throws InstantiationException If serializer or parser could not be instantiated.
	 */
	public JazzRestClient(String jazzUri, String user, String pw, Class<? extends Serializer<?>> s, Class<? extends Parser<?>> p) throws InstantiationException, IOException {
		this(jazzUri, user, pw);
		setParser(p);
		setSerializer(s);
	}

	@Override /* RestClient */
	protected HttpClient createHttpClient() throws Exception {
		try {
			ClientConnectionManager cm = null;

			if (jazzUri.getScheme().equals("https")) {
				SSLContext sslContext = SSLContext.getInstance("SSL");
				TrustManager tm = new ValidatingX509TrustManager(LenientCertificateValidator.INSTANCE);
				sslContext.init(null, new TrustManager[]{tm}, new SecureRandom());
				SSLSocketFactory sf = new SSLSocketFactory(sslContext, new AllowAllHostnameVerifier());
				Scheme httpsScheme = new Scheme("https", jazzUri.getPort(), sf);
				SchemeRegistry schemeRegistry = new SchemeRegistry();
				schemeRegistry.register(httpsScheme);
				cm = new SingleClientConnManager(schemeRegistry);
			}

			AbstractHttpClient client = new DefaultHttpClient(cm);
			client.setRedirectStrategy(new LaxRedirectStrategy());  // Allow redirects on PUT/POST/DELETE

			// Tomcat will respond with SC_BAD_REQUEST (or SC_REQUEST_TIMEOUT?) when the
			// j_security_check URL is visited before an authenticated URL has been visited.
			visitAuthenticatedURL(client);

			// Authenticate against the server.
			String authMethod = determineAuthMethod(client);
			if (authMethod.equals("FORM")) {
				formBasedAuthenticate(client);
				visitAuthenticatedURL(client);
			} else /* BASIC */ {
				AuthScope scope = new AuthScope(jazzUri.getHost(), jazzUri.getPort());
				Credentials up = new UsernamePasswordCredentials(user, pw);
				client.getCredentialsProvider().setCredentials(scope, up);
			}

			return client;
		} catch (KeyStoreException e) {
			throw new RuntimeException(e);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		} catch (Throwable e) {
			System.err.println("Caught " + e.getClass().getName());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Performs form-based authentication against the Jazz server.
	 */
	private void formBasedAuthenticate(HttpClient client) throws IOException {

		URI uri2 = jazzUri.resolve("j_security_check");
		HttpPost request = new HttpPost(uri2);
		request.getParams().setBooleanParameter(ClientPNames.HANDLE_REDIRECTS, false);
		 // Charset must explicitly be set to UTF-8 to handle user/pw with non-ascii characters.
		request.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");

		NameValuePairs params = new NameValuePairs()
			.append(new BasicNameValuePair("j_username", user))
			.append(new BasicNameValuePair("j_password", pw));
		request.setEntity(new UrlEncodedFormEntity(params));

		HttpResponse response = client.execute(request);
		try {
			int rc = response.getStatusLine().getStatusCode();

			Header authMsg = response.getFirstHeader("X-com-ibm-team-repository-web-auth-msg");
			if (authMsg != null)
				throw new IOException(authMsg.getValue());

			// The form auth request should always respond with a 200 ok or 302 redirect code
			if (rc == SC_MOVED_TEMPORARILY) {
				if (response.getFirstHeader("Location").getValue().matches("^.*/auth/authfailed.*$"))
					throw new IOException("Invalid credentials.");
			} else if (rc != SC_OK) {
				throw new IOException("Unexpected HTTP status: " + rc);
			}
		} finally {
			EntityUtils.consume(response.getEntity());
		}
	}

	/*
	 * This is needed for Tomcat because it responds with SC_BAD_REQUEST when the j_security_check URL is visited before an
	 * authenticated URL has been visited. This same URL must also be visited after authenticating with j_security_check
	 * otherwise tomcat will not consider the session authenticated
	 */
	private int visitAuthenticatedURL(HttpClient httpClient) throws IOException {
		HttpGet authenticatedURL = new HttpGet(jazzUri.resolve("authenticated/identity"));
		HttpResponse response = httpClient.execute(authenticatedURL);
		try {
			return response.getStatusLine().getStatusCode();
		} finally {
			EntityUtils.consume(response.getEntity());
		}
	}

	/*
	 * @return Returns "FORM" for form-based authenication, "BASIC" for basic auth.  Never <code>null</code>.
	 */
	private String determineAuthMethod(HttpClient client) throws IOException {

		HttpGet request = new HttpGet(jazzUri.resolve("authenticated/identity"));
		request.getParams().setBooleanParameter(ClientPNames.HANDLE_REDIRECTS, false);

		// if the FORM_AUTH_URI path exists, then we know we are using FORM auth
		HttpResponse response = client.execute(request);
		try {
			int rc = response.getStatusLine().getStatusCode();
			// Tomcat and Jetty return a status code 200 if the server is using FORM auth
			if (rc == SC_OK)
				return "FORM";
			else if (rc == SC_MOVED_TEMPORARILY && response.getFirstHeader("Location").getValue().matches("^.*(/auth/authrequired|/authenticated/identity).*$"))
				return "FORM";
			return "BASIC";

		} finally {
			EntityUtils.consume(response.getEntity());
		}
	}
}
