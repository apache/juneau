/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.client;

import java.io.*;

import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.methods.*;
import org.apache.http.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.encoders.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.parser.ParseException;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.utils.*;

/**
 * Represents a connection to a remote REST resource.
 * <p>
 * 	Instances of this class are created by the various {@code doX()} methods on the {@link RestClient} class.
 * <p>
 * 	This class uses only Java standard APIs.  Requests can be built up using a fluent interface with method chaining, like so...
 *
 * <p class='bcode'>
 * 	RestClient client = <jk>new</jk> RestClient();
 * 	RestCall c = client.doPost(url).setInput(o).setHeader(x,y);
 * 	MyBean b = c.getResponse(MyBean.<jk>class</jk>);
 * </p>
 * <p>
 * 	The actual connection and request/response transaction occurs when calling one of the <code>getResponseXXX()</code> methods.
 *
 * <h6 class='topic'>Additional Information</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#RestClient'>com.ibm.juno.client &gt; REST client API</a> for more information and code examples.
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public final class RestCall {

	private final RestClient client;                       // The client that created this call.
	private final HttpRequestBase request;                 // The request.
	private HttpResponse response;                         // The response.

	private boolean isConnected = false;                   // connect() has been called.
	private boolean isConsumed = false;                    // getInputStream() has been called.

	/**
	 * Constructs a REST call with the specified method name.
	 *
	 * @param client The client that created this request.
	 * @param request The wrapped Apache HTTP client request object.
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 */
	protected RestCall(RestClient client, HttpRequestBase request) throws RestCallException {
		this.client = client;
		this.request = request;
	}

	/**
	 * Sets the input for this REST call.
	 *
	 * @param input The input to be sent to the REST resource (only valid for PUT and POST) requests. <br>
	 * 	Can be of the following types:
	 * 	<ul>
	 * 		<li>{@link Reader} - Raw contents of {@code Reader} will be serialized to remote resource.
	 * 		<li>{@link InputStream} - Raw contents of {@code InputStream} will be serialized to remote resource.
	 * 		<li>{@link Object} - POJO to be converted to text using the {@link Serializer} registered with the {@link RestClient}.
	 * 		<li>{@link HttpEntity} - Bypass Juno serialization and pass HttpEntity directly to HttpClient.
	 * 	</ul>
	 * @return This object (for method chaining).
	 */
	public RestCall setInput(final Object input) throws RestCallException {
		if (! (request instanceof HttpEntityEnclosingRequestBase))
			throw new RestCallException(0, "Method does not support content entity.", request.getMethod(), request.getURI(), null);
		HttpEntity entity = (input instanceof HttpEntity ? (HttpEntity)input : new RestResponseEntity(input, this));
		((HttpEntityEnclosingRequestBase)request).setEntity(entity);
		return this;
	}

	/**
	 * Convenience method for setting a header value on the request.
	 * <p>
	 * Equivalent to calling <code>restCall.getRequest().setHeader(name, value.toString())</code>.
	 */
	public RestCall setHeader(String name, Object value) {
		request.setHeader(name, value.toString());
		return this;
	}

	/**
	 * Method used to execute an HTTP response where you're only interested in the HTTP response code.
	 * <p>
	 * The response entity is discarded.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jk>try</jk> {
	 * 		RestClient client = <jk>new</jk> RestClient();
	 * 		<jk>int</jk> rc = client.doGet(url).execute();
	 * 		<jc>// Succeeded!</jc>
	 * 	} <jk>catch</jk> (RestCallException e) {
	 * 		<jc>// Failed!</jc>
	 * 	}
	 * </p>
	 *
	 * @return This object (for method chaining).
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 */
	public int execute() throws RestCallException {
		connect();
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			EntityUtils.consume(response.getEntity());
			return statusCode;
		} catch (IOException e) {
			throw new RestCallException(e);
		}
	}

	/**
	 * Connects to the REST resource.
	 * <p>
	 * 	If this is a <code>PUT</code> or <code>POST</code>, also sends the input to the remote resource.<br>
	 * <p>
	 * 	Typically, you would only call this method if you're not interested in retrieving the body of the HTTP response.
	 * 	Otherwise, you're better off just calling one of the {@link #getReader()}/{@link #getResponse(Class)}/{@link #pipeTo(Writer)}
	 * 	methods directly which automatically call this method already.
	 *
	 * @return This object (for method chaining).
	 * @throws RestCallException If an exception or <code>400+</code> HTTP status code occurred during the connection attempt.
	 */
	public RestCall connect() throws RestCallException {

		if (isConsumed) {
			// In 4.1.2, there is no way to reset a request.
			// Once we prereq 4.2, we can use request.reset().
			request.abort();
			isConnected = false;
			isConsumed = false;
		}

		if (isConnected)
			return this;
		isConnected = true;

		try {
			response = client.execute(request);
			StatusLine status = response.getStatusLine();
			if (status.getStatusCode() >= 400) {
				throw new RestCallException(status.getStatusCode(), status.getReasonPhrase(), request.getMethod(), request.getURI(), getResponseAsString());
			}

		} catch (RestCallException e) {
			throw e;
		} catch (Exception e) {
			throw new RestCallException(e);
		}

		return this;
	}

	/**
	 * Connects to the remote resource (if <code>connect()</code> hasn't already been called) and returns the HTTP response message body as a reader.
	 * <p>
	 * 	If an {@link Encoder} has been registered with the {@link RestClient}, then the underlying input stream
	 * 		will be wrapped in the encoded stream (e.g. a <code>GZIPInputStream</code>).
	 * <p>
	 * 	If present, automatically handles the <code>charset</code> value in the <code>Content-Type</code> response header.
	 * <p>
	 * 	<b>IMPORTANT:</b>  It is your responsibility to close this reader once you have finished with it.
	 *
	 * @return The HTTP response message body reader.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public Reader getReader() throws IOException {
		InputStream is = getInputStream();

		// Figure out what the charset of the response is.
		String cs = null;
		Header contentType = response.getLastHeader("Content-Type");
		String ct = contentType == null ? null : contentType.getValue();

		// First look for "charset=" in Content-Type header of response.
		if (ct != null && ct.contains("charset="))
			cs = ct.substring(ct.indexOf("charset=")+8).trim();

		if (cs == null)
			cs = "UTF-8";

		return new InputStreamReader(is, cs);
	}

	/**
	 * Returns the parser specified on the client to use for parsing HTTP response bodies.
	 *
	 * @return The parser.
	 * @throws RestCallException If no parser was defined on the client.
	 */
	protected Parser<?> getParser() throws RestCallException {
		if (client.parser == null)
			throw new RestCallException(0, "No parser defined on client", request.getMethod(), request.getURI(), null);
		return client.parser;
	}

	/**
	 * Returns the serializer specified on the client to use for serializing HTTP request bodies.
	 *
	 * @return The serializer.
	 * @throws RestCallException If no serializer was defined on the client.
	 */
	protected Serializer<?> getSerializer() throws RestCallException {
		if (client.serializer == null)
			throw new RestCallException(0, "No serializer defined on client", request.getMethod(), request.getURI(), null);
		return client.serializer;
	}

	/**
	 * @return The value of the <code>Content-Length</code> header, or <code>-1</code> if header is not present.
	 */
	public int getContentLength() throws IOException {
		connect();
		Header h = response.getLastHeader("Content-Length");
		if (h == null)
			return -1;
		long l = Long.parseLong(h.getValue());
		if (l > Integer.MAX_VALUE)
			return Integer.MAX_VALUE;
		return (int)l;
	}

	/**
	 * Connects to the remote resource (if <code>connect()</code> hasn't already been called) and returns the HTTP response message body as an input stream.
	 * <p>
	 * 	If an {@link Encoder} has been registered with the {@link RestClient}, then the underlying input stream
	 * 		will be wrapped in the encoded stream (e.g. a <code>GZIPInputStream</code>).
	 * <p>
	 * 	<b>IMPORTANT:</b>  It is your responsibility to close this reader once you have finished with it.
	 *
	 * @return The HTTP response message body input stream.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public InputStream getInputStream() throws IOException {
		connect();
		InputStream is = response.getEntity().getContent();
		isConsumed = true;
		return is;
	}

	/**
	 * Connects to the remote resource (if {@code connect()} hasn't already been called) and returns the HTTP response message body as plain text.
	 *
	 * @return The response as a string.
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public String getResponseAsString() throws IOException {
		String s = IOUtils.read(getReader()).toString();
		return s;
	}

	/**
	 * Converts the output from the connection into an object of the specified class using the registered {@link Parser}.
	 *
	 * @param type The class to convert the input to.
	 * @param <T> The class to convert the input to.
	 * @return The parsed output.
	 * @throws IOException If a connection error occurred.
	 * @throws ParseException If the input contains a syntax error or is malformed for the <code>Content-Type</code> header.
	 */
	public <T> T getResponse(Class<T> type) throws IOException, ParseException {
		BeanContext bc = getParser().getBeanContext();
		if (bc == null)
			bc = BeanContext.DEFAULT;
		return getResponse(bc.getClassMeta(type));
	}

	private <T> T getResponse(ClassMeta<T> type) throws IOException, ParseException {
		Parser<?> p = getParser();
		T o = null;
		int contentLength = getContentLength();
		if (p instanceof InputStreamParser) {
			InputStream is = getInputStream();
			o = ((InputStreamParser)p).parse(is, contentLength, type);
			is.close();
		} else {
			Reader r = getReader();
			o = ((ReaderParser)p).parse(r, contentLength, type);
			r.close();
		}
		return o;
	}

	/**
	 * Connects to the remote resource (if {@code connect()} hasn't already been called) and pipes the output to the specified writer.
	 *
	 * @param w The writer to pipe the output to.
	 * @return This object (for method chaining).
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public RestCall pipeTo(Writer w) throws IOException {
		IOUtils.pipe(getReader(), w);
		return this;
	}

	/**
	 * Connects to the remote resource (if {@code connect()} hasn't already been called) and pipes the output to the specified stream.
	 *
	 * @param os The output stream to send the response to.
	 * @return This object (for method chaining).
	 * @throws RestCallException If an exception or non-200 response code occurred during the connection attempt.
	 * @throws IOException If an exception occurred while streaming was already occurring.
	 */
	public RestCall pipeTo(OutputStream os) throws IOException {
		IOUtils.pipe(getInputStream(), os);
		return this;
	}

	/**
	 * Returns access to the {@link HttpUriRequest} passed to {@link HttpClient#execute(HttpUriRequest)}.
	 */
	public HttpUriRequest getRequest() {
		return request;
	}

	/**
	 * Returns access to the {@link HttpResponse} returned by {@link HttpClient#execute(HttpUriRequest)}.
	 * Returns <jk>null</jk> if {@link #connect()} has not yet been called.
	 */
	public HttpResponse getResponse() {
		return response;
	}

	/**
	 * Shortcut for calling <code>getRequest().setHeader(header)</code>
	 *
	 * @param header The header to set on the request.
	 * @return This object (for method chaining).
	 */
	public RestCall setHeader(Header header) {
		request.setHeader(header);
		return this;
	}
}
