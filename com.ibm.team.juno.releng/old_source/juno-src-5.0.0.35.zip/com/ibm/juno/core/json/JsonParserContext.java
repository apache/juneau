package com.ibm.juno.core.json;

import static com.ibm.juno.core.json.JsonParserProperties.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;

/**
 * Context object that lives for the duration of a single parsing of {@link JsonParser}.
 * <p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonParserContext extends ParserContext {

	private final boolean strictMode;

	/**
	 * Create a new parser context with the specified options.
	 *
	 * @param type The class type being parsed.
	 * @param beanContext The bean context being used.
	 * @param jpp The JSON parser properties.
	 * @param pp The default parser properties.
	 * @param op The override properties.
	 * @param mediaType The media type being parsed.
	 * @param charset The charset being parsed.
	 */
	public JsonParserContext(ClassMeta<?> type, BeanContext beanContext, JsonParserProperties jpp, ParserProperties pp, ObjectMap op, String mediaType, String charset) {
		super(type, beanContext, pp, op, mediaType, charset);
		if (op == null || op.isEmpty()) {
			strictMode = jpp.isStrictMode();
		} else {
			strictMode = op.getBoolean(STRICT_MODE, jpp.isStrictMode());
		}
	}

	/**
	 * Returns the {@link JsonParserProperties#STRICT_MODE} setting in this context.
	 */
	public boolean isStrictMode() {
		return strictMode;
	}
}
