package com.ibm.juno.core.filters;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.*;

/**
 * Transforms {@link Calendar Calendars} to {@link Long Longs} using {@code Calender.getTime().getTime()}.
 * <p>
 * 	TODO:  This class does not handle timezones correctly when parsing {@code GregorianCalendar} objects.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class CalendarLongFilter extends PojoFilter<Calendar,Long> {

	/**
	 * Converts the specified {@link Calendar} to a {@link Long}.
	 */
	@Override
	public Long filter(Calendar o, BeanContext beanContext) {
		return o.getTime().getTime();
	}

	/**
	 * Converts the specified {@link Long} to a {@link Calendar}.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Calendar unfilter(Long o, ClassMeta<?> hint, BeanContext beanContext) throws ParseException {
		ClassMeta<? extends Calendar> tt;
		try {
			if (! hint.canCreateNewInstance())
				hint = beanContext.getClassMeta(GregorianCalendar.class);
			tt = (ClassMeta<? extends Calendar>)hint;
			Calendar c = tt.newInstance();
			c.setTimeInMillis(o);
			return c;
		} catch (Exception e) {
			throw new ParseException(e);
		}
	}
}
