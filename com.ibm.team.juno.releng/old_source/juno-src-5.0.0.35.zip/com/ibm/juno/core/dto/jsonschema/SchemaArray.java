package com.ibm.juno.core.dto.jsonschema;

import java.util.*;

/**
 * Represents a list of {@link Schema} objects.
 * <p>
 * 	Refer to {@link com.ibm.juno.core.dto.jsonschema} for usage information.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SchemaArray extends LinkedList<Schema> {

	/**
	 * Default constructor.
	 */
	public SchemaArray() {}

	/**
	 * Constructor with predefined types to add to this list.
	 */
	public SchemaArray(Schema...schemas) {
		addAll(schemas);
	}

	/**
	 * Convenience method for adding one or more {@link Schema} objects to
	 * 	this array.
	 * @param schemas The {@link Schema} objects to add to this array.
	 * @return This object (for method chaining).
	 */
	public SchemaArray addAll(Schema...schemas) {
		for (Schema s : schemas)
			add(s);
		return this;
	}
}
