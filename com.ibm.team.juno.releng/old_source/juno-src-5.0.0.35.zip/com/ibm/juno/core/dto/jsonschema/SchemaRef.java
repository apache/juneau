package com.ibm.juno.core.dto.jsonschema;

import java.net.*;

/**
 * Convenience class for representing a schema reference such as <js>"{'$ref':'/url/to/ref'}"</js>.
 * <p>
 * 	An instance of this object is equivalent to calling...
 *
 * <p class='bcode'>
 * 	Schema s = <jk>new</jk> Schema().setRef(uri);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SchemaRef extends Schema {

	/**
	 * Constructor.
	 * @param uri The URI of the target reference.  Can be <jk>null</jk>.
	 */
	public SchemaRef(String uri) {
		this.setRef(uri == null ? null : URI.create(uri));
	}
}
