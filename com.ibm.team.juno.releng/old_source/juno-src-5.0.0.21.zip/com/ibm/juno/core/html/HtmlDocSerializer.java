package com.ibm.juno.core.html;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.html.HtmlDocSerializerProperties.*;
import static com.ibm.juno.core.serializer.SerializerProperties.*;
import static com.ibm.juno.server.RestServletProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.server.labels.*;

/**
 * Serializes POJOs to HTTP responses as HTML documents.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>text/html</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>text/html</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Same as {@link HtmlSerializer}, except wraps the response in <code><xt>&lt;html&gt;</code>, <code><xt>&lt;head&gt;</code>,
 * 	and <code><xt>&lt;body&gt;</code> tags so that it can be rendered in a browser.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link HtmlDocSerializerProperties}
 * 	<li>{@link HtmlSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Produces("text/html")
public class HtmlDocSerializer extends HtmlStrippedDocSerializer {

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer
	public void serialize(Object o, Writer out, ObjectMap properties, String matchingAccept) throws IOException, SerializeException {

		HtmlSerializerContext ctx = new HtmlSerializerContext(beanContext, sp, hsp, properties);
		HtmlSerializerWriter w = new HtmlSerializerWriter(out, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority());

		// Render the header.
		w.sTag("html").nl();
		w.sTag("head").nl();
		int refresh = properties.getInt(HTML_REFRESH, 0);
		if (refresh > 0) {
			w.oTag(1, "meta")
			.attr("http-equiv", "Refresh")
			.attr("content", refresh)
			.appendln(">");
		}

		String cssUrl = properties.getString(HTML_CSS_URL);
		if (cssUrl == null)
			cssUrl = properties.getString(URI_CONTEXT) + properties.getString(URI_SERVLET_PATH) + "/htdocs/juno.css";

		w.oTag(1, "style")
			.attr("type", "text/css")
			.appendln(">")
				.append(2, "@import ").q().append(cssUrl).q().appendln(";")
			.eTag(1, "style").nl();
		w.eTag("head").nl();
		w.sTag("body").nl();
		// Write the title of the page.
		String title = properties.getString(HTML_TITLE);
		if (title == null && properties.getString(METHOD).equals("OPTIONS"))
			title = "Options";
		String description = properties.getString(HTML_DESCRIPTION);
		if (title != null)
			w.sTag(1, "h3").encodeText(title).eTag("h3");
		if (description != null)
			w.sTag(1, "h5").encodeText(description).eTag("h5");

		// Write the action links that render above the results.
		List<Link> actions = new LinkedList<Link>();

		// If this is an OPTIONS request, provide a 'back' link to return to the GET request page.
		if (! properties.getString(METHOD).equals("OPTIONS")) {
			ObjectMap htmlLinks = properties.getObjectMap(HTML_LINKS, null);
			if (htmlLinks != null) {
				for (Map.Entry<String,Object> e : htmlLinks.entrySet()) {
					String uri = e.getValue().toString();
					StringBuilder sb = new StringBuilder();
					if (! uri.startsWith("http"))
						sb.append(properties.getString(URI_AUTHORITY));
					if (! uri.startsWith("/"))
						sb.append(properties.getString(URI_CONTEXT)).append(properties.getString(URI_SERVLET_PATH));
					if (! uri.startsWith("?"))
						sb.append('/');
					sb.append(uri);
					actions.add(new Link(e.getKey(), sb.toString()));
				}
			}
		}

		if (actions.size() > 0) {
			w.oTag(1, "p").attr("class", "links").append('>').nl();
			for (Iterator<Link> i = actions.iterator(); i.hasNext();) {
				Link h = i.next();
				w.oTag(2, "a").attr("href", h.getHref(), true).append('>').append(h.getName()).eTag("a").nl();
				if (i.hasNext())
					w.append(3, " - ").nl();
			}
			w.eTag(1, "p").nl();
		}

		doSerialize(o, w, ctx);

		w.eTag("body").nl().eTag("html").nl();
	}
}
