package com.ibm.juno.core.parser;

import com.ibm.juno.core.*;

/**
 * Defines methods available for parsers that use internal {@link BeanContext} objects.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	The methods defined on this class are simple pass-through methods to the underlying {@link BeanContext}
 * 	object used by the parser.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface ICoreApiParser extends IParser {

	/**
	 * Shortcut for calling <code>getBeanContext().addNotBeanClassPatterns()</code>.
	 * See {@link BeanContext#addNotBeanClassPatterns(String...)}.
	 *
	 * @param patterns The class patterns.
	 * @return This object (for method chaining).
	 * @throws LockedException If parser is locked.
	 */
	public ICoreApiParser addNotBeanClassPatterns(String... patterns) throws LockedException;

	/**
	 * Shortcut for calling <code>getBeanContext().addNotBeanClasses()</code>.
	 * See {@link BeanContext#addNotBeanClasses(Class...)}.
	 *
	 * @param classes The class that are not beans.
	 * @return This object (for method chaining).
	 * @throws LockedException If parser is locked.
	 */
	public ICoreApiParser addNotBeanClasses(Class<?>...classes) throws LockedException;

	/**
	 * Shortcut for calling <code>getBeanContext().addFilters()</code>.
	 * See {@link BeanContext#addFilters(Class...)}.
	 *
	 * @param classes The filter classes or classes to be filtered.
	 * @return This object (for method chaining).
	 * @throws LockedException If parser is locked.
	 */
	public ICoreApiParser addFilters(Class<?>...classes) throws LockedException;

	/**
	 * Shortcut for calling <code>getBeanContext().addImplClass()</code>.
	 * See {@link BeanContext#addImplClass(Class, Class)}.
	 *
	 * @param interfaceClass The interface class.
	 * @param implClass The implementation class.
	 * @param <T> The interface class.
	 * @return This object (for method chaining).
	 * @throws LockedException If parser is locked.
	 */
	public <T> ICoreApiParser addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException;
}
