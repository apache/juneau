package com.ibm.juno.core.parser;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;
import java.util.logging.*;

import com.ibm.juno.core.*;


/**
 * Context object that lives for the duration of a single parsing of {@link Parser} and its subclasses.
 * <p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserContext {

	private static Logger logger = Logger.getLogger(ParserContext.class.getName());

	/** Any warnings encountered. */
	private final List<String> warnings = new LinkedList<String>();

	/**
	 * Create a new parser context with the specified options.
	 *
	 * @param sp The default serializer properties.
	 * @param op The override properties.
	 */
	public ParserContext(ParserProperties sp, ObjectMap op) {
	}

	/**
	 * Logs a warning message.
	 *
	 * @param msg The warning message.
	 * @param args Optional printf arguments to replace in the error message.
	 */
	public void addWarning(String msg, Object... args) {
		msg = args.length == 0 ? msg : String.format(msg, args);
		logger.warning(msg);
		warnings.add(msg);
	}
}
