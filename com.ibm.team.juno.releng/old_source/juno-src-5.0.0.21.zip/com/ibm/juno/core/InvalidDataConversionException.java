package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

/**
 * General invalid conversion exception.
 * <p>
 * 	Exception that gets thrown if you try to perform an invalid conversion, such as when calling {@code ObjectMap.getInt(...)} on a non-numeric <code>String</code>.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class InvalidDataConversionException extends RuntimeException {

	/**
	 * @param fromType Attempting to convert from this class type.
	 * @param toType Attempting to convert to this class type.
	 * @param cause The cause.
	 */
	public InvalidDataConversionException(Class<?> fromType, Class<?> toType, Exception cause) {
		super("Invalid data conversion from type ["+fromType.getName()+"] to type ["+toType.getName()+"].", cause);
	}

}
