package com.ibm.juno.server.labels;

import java.util.*;

import com.ibm.juno.client.proto.script.*;
import com.ibm.juno.server.*;

/**
 * Default POJO bean used for generating OPTIONS page results.
 * <p>
 * This POJO bean is also meant to be used by the {@link RestScript} class for discoverable command-line-invokable
 * 	REST services.
 * <p>
 * See {@link RestServlet#getOptionsBean(RestRequest)} for more information.
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ResourceOptions {
	private String description;
	private String className;
	private Collection<MethodDescription> methods;
	private Collection<String> accept, contentType;

	/**
	 * Returns the description of the REST resource.
	 * @return The current bean property value.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description of the REST resource.
	 * @param description The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setDescription(String description) {
		this.description = description;
		return this;
	}

	/**
	 * Returns the class name of the REST resource.
	 * @return The current bean property value.
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * Sets the class name of the REST resource.
	 * @param className The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setClassName(String className) {
		this.className = className;
		return this;
	}

	/**
	 * Returns the methods provided on this REST resource.
	 * @return The current bean property value.
	 */
	public Collection<MethodDescription> getMethods() {
		return methods;
	}

	/**
	 * Sets the methods provided on this REST resource.
	 * @param methods The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setMethods(Collection<MethodDescription> methods) {
		this.methods = methods;
		return this;
	}

	/**
	 * Returns the list of allowable <code>Accept</code> header values on requests.
	 * @return The current bean property value.
	 */
	public Collection<String> getAccept() {
		return accept;
	}

	/**
	 * Sets the list of allowable <code>Accept</code> header values on requests.
	 * @param accept The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setAccept(Collection<String> accept) {
		this.accept = accept;
		return this;
	}

	/**
	 * Returns the list of allowable <code>Content-Type</code> header values on requests.
	 * @return The current bean property value.
	 */
	public Collection<String> getContentType() {
		return contentType;
	}

	/**
	 * Sets the list of allowable <code>Content-Type</code> header values on requests.
	 * @param contentType The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setContentType(Collection<String> contentType) {
		this.contentType = contentType;
		return this;
	}
}
