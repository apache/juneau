package com.ibm.juno.server.jena;

import com.ibm.juno.core.html.*;
import com.ibm.juno.core.jena.*;
import com.ibm.juno.core.jso.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.soap.*;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.core.xml.*;
import com.ibm.juno.server.*;
import com.ibm.juno.server.annotation.*;

/**
 * Subclass of {@link RestServlet} with default implementations for
 * 	{@link RestServlet#createSerializerGroup()} and {@link RestServlet#createParserGroup()}.
 * <p>
 * 	This class uses the {@link RdfSerializer} class which requires the Jena libraries to be available
 * 		on the classpath.
 * <p>
 *
 * Adds the following serializers to the serializer group:
 * <ul>
 * 	<li>{@link JsonSerializer}
 * 	<li>{@link JsonSchemaSerializer}
 * 	<li>{@link XmlDocSerializer}
 * 	<li>{@link XmlDocSerializer.Simple}
 * 	<li>{@link XmlSchemaDocSerializer}
 * 	<li>{@link HtmlDocSerializer}
 * 	<li>{@link HtmlStrippedDocSerializer}
 * 	<li>{@link UrlEncodingSerializer}
 * 	<li>{@link SoapXmlSerializer}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.Xml}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.XmlAbbrev}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.N3}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.NTriple}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.Turtle}
 * 	<li>{@link JavaSerializedObjectSerializer}
 * </ul>
 * <p>
 * Adds the following parsers to the parser group:
 * <ul>
 * 	<li>{@link JsonParser}
 * 	<li>{@link XmlParser}
 * 	<li>{@link HtmlParser}
 * 	<li>{@link UrlEncodingParser}
 * 	<li>{@link com.ibm.juno.core.jena.RdfParser.Xml}
 * 	<li>{@link com.ibm.juno.core.jena.RdfParser.N3}
 * 	<li>{@link com.ibm.juno.core.jena.RdfParser.NTriple}
 * 	<li>{@link com.ibm.juno.core.jena.RdfParser.Turtle}
 * </ul>
 * <p>
 * Note that the list of serializers and parsers can be appended to using the {@link RestResource#serializers()} and {@link RestResource#parsers()} annotations.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestServletJenaDefault extends RestServlet {

	@Override
	@SuppressWarnings("unchecked")
	public SerializerGroup createSerializerGroup() throws Exception {

		return new SerializerGroup()
			.append(
				JsonSerializer.class,
				JsonSerializer.Simple.class,
				JsonSchemaSerializer.class,
				XmlDocSerializer.class,
				XmlDocSerializer.Simple.class,
				XmlSchemaDocSerializer.class,
				HtmlDocSerializer.class,
				HtmlStrippedDocSerializer.class,
				UrlEncodingSerializer.class,
				SoapXmlSerializer.class,
				RdfSerializer.Xml.class,
				RdfSerializer.XmlAbbrev.class,
				RdfSerializer.N3.class,
				RdfSerializer.NTriple.class,
				RdfSerializer.Turtle.class,
				JavaSerializedObjectSerializer.class
			);
	}

	@Override
	@SuppressWarnings("unchecked")
	public ParserGroup createParserGroup() throws Exception {

		return new ParserGroup()
			.append(
				JsonParser.class,
				XmlParser.class,
				HtmlParser.class,
				UrlEncodingParser.class,
				JavaSerializedObjectParser.class,
				RdfParser.Xml.class,
				RdfParser.N3.class,
				RdfParser.NTriple.class,
				RdfParser.Turtle.class
			);
	}
}