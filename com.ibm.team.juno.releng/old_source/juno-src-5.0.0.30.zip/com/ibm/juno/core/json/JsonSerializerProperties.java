package com.ibm.juno.core.json;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Configurable properties on the {@link JsonSerializer} class.
 * <p>
 * 	Use the {@link JsonSerializer#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link JsonSerializer}.
 * <ul>
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonSerializerProperties implements Cloneable {

	/**
	 * Simple JSON mode ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, JSON attribute names will only be quoted when necessary.
	 * Otherwise, they are always quoted.
	 */
	public static final String SIMPLE_MODE = "JsonSerializer.simpleMode";

	/**
	 * Use whitespace in output ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, whitespace is added to the output to improve readability.
	 */
	public static final String USE_WHITESPACE = "JsonSerializer.useWhitespace";

	boolean
		simpleMode = false,
		useWhitespace = false;

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		BeanContext bc = BeanContext.DEFAULT;
		if (property.equals(SIMPLE_MODE))
			simpleMode = bc.convertToType(value, Boolean.class);
		else if (property.equals(USE_WHITESPACE))
			useWhitespace = bc.convertToType(value, Boolean.class);
		else
			return false;
		return true;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Cloneable
	public JsonSerializerProperties clone() {
		try {
			return (JsonSerializerProperties)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
