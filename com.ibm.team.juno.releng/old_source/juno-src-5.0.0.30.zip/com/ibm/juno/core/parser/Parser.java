package com.ibm.juno.core.parser;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.ClassTypeConst.*;
import static com.ibm.juno.core.utils.StringUtils.*;
import static java.lang.String.*;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.filters.*;
import com.ibm.juno.core.utils.*;

/**
 * Parent class for all Juno parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Base parser class that provides default implementations for the following interfaces:
 * <ul>
 * 	<li>{@link IParser}
 * 	<li>{@link ICoreApiParser}
 * </ul>
 * <p>
 * 	Subclasses should extend directly from {@link InputStreamParser} or {@link ReaderParser}.
 *
 *
 * <h6 class='topic'>@Consumes annotation</h6>
 * <p>
 * 	The media types that this parser can handle is specified through the {@link Consumes @Consumes} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()} method.
 *
 *
 * <a name='ValidDataConversions'></a><h6 class='topic'>Valid data conversions</h6>
 * 	Parsers can parse any parsable POJO types, as specified in the <a class='doclink' href='../package-summary.html#PojoCategories'>POJO Categories</a>.
 * <p>
 * 	Some examples of conversions are shown below...
 * </p>
 * 	<table class='styled'>
 * 		<tr>
 * 			<th>Data type</th>
 * 			<th>Class type</th>
 * 			<th>JSON example</th>
 * 			<th>XML example</th>
 * 			<th>Class examples</th>
 * 		</tr>
 * 		<tr>
 * 			<td>object</td>
 * 			<td>Maps, Java beans</td>
 * 			<td class='code'>{name:<js>'John Smith'</js>,age:21}</td>
 * 			<td class='code'><xt>&lt;object&gt;
 * 	&lt;name</xt> <xa>type</xa>=<xs>'string'</xs><xt>&gt;</xt>John Smith<xt>&lt;/name&gt;
 * 	&lt;age</xt> <xa>type</xa>=<xs>'number'</xs><xt>&gt;</xt>21<xt>&lt;/age&gt;
 * &lt;/object&gt;</xt></td>
 * 			<td class='code'>HashMap, TreeMap&lt;String,Integer&gt;</td>
 * 		</tr>
 * 		<tr>
 * 			<td>array</td>
 * 			<td>Collections, Java arrays</td>
 * 			<td class='code'>[1,2,3]</td>
 * 			<td class='code'><xt>&lt;array&gt;
 * 	&lt;number&gt;</xt>1<xt>&lt;/number&gt;
 * 	&lt;number&gt;</xt>2<xt>&lt;/number&gt;
 * 	&lt;number&gt;</xt>3<xt>&lt;/number&gt;
 * &lt;/array&gt;</xt></td>
 * 			<td class='code'>List&lt;Integer&gt;, <jk>int</jk>[], Float[], Set&lt;Person&gt;</td>
 * 		</tr>
 * 		<tr>
 * 			<td>number</td>
 * 			<td>Numbers</td>
 * 			<td class='code'>123</td>
 * 			<td class='code'><xt>&lt;number&gt;</xt>123<xt>&lt;/number&gt;</xt></td>
 * 			<td class='code'>Integer, Long, Float, <jk>int</jk></td>
 *			</tr>
 * 		<tr>
 * 			<td>boolean</td>
 * 			<td>Booleans</td>
 * 			<td class='code'><jk>true</jk></td>
 * 			<td class='code'><xt>&lt;boolean&gt;</xt>true<xt>&lt;/boolean&gt;</xt></td>
 * 			<td class='code'>Boolean</td>
 * 		</tr>
 * 		<tr>
 * 			<td>string</td>
 * 			<td>CharSequences</td>
 * 			<td class='code'><js>'foobar'</js></td>
 * 			<td class='code'><xt>&lt;string&gt;</xt>foobar<xt>&lt;/string&gt;</xt></td>
 * 			<td class='code'>String, StringBuilder</td>
 * 		</tr>
 * 	</table>
 * <p>
 * 	In addition, any class types with {@link PojoFilter PojoFilters} associated with them on the registered
 * 		{@link #getBeanContext() beanContext} can also be passed in.
 * <p>
 * 	For example, if the {@link CalendarFilter} filter is used to generalize {@code Calendar} objects to {@code String} objects.  When registered
 * 	with this parser, you can construct {@code Calendar} objects from {@code Strings} using the following syntax...
 * <p class='bcode'>
 * 	Calendar c = parser.parse(<js>"'Sun Mar 03 04:05:06 EST 2001'"</js>, GregorianCalendar.<jk>class</jk>);
 * <p>
 * 	If {@link ClassTypeConst#OBJECT} or <code>Object.<jk>class</jk></code> is specified as the target type, then the parser
 * 	automatically determines the data types and generates the following object types...
 * </p>
 * <table class='styled'>
 * 	<tr><th>JSON type</th><th>Class type</th></tr>
 * 	<tr><td>object</td><td>{@link ObjectMap}</td></tr>
 * 	<tr><td>array</td><td>{@link ObjectList}</td></tr>
 * 	<tr><td>number</td><td>{@link Number} <br>(depending on length and format, could be {@link Integer}, {@link Double}, {@link Float}, etc...)</td></tr>
 * 	<tr><td>boolean</td><td>{@link Boolean}</td></tr>
 * 	<tr><td>string</td><td>{@link String}</td></tr>
 * </table>
 *
 *
 * <a name='SupportedTypes'></a><h6 class='topic'>Supported types</h6>
 * <p>
 * 	Several of the methods below take {@link Type} parameters to identify the type of
 * 		object to create.  Any of the following types can be passed in to these methods...
 * </p>
 * <ul>
 * 	<li>{@link ClassType}
 * 	<li>{@link Class}
 * 	<li>{@link ParameterizedType}
 * 	<li>{@link GenericArrayType}
 * </ul>
 * <p>
 * 	However, {@code ParameterizedTypes} and {@code GenericArrayTypes} should not contain
 * 		{@link WildcardType WildcardTypes} or {@link TypeVariable TypeVariables}.
 * <p>
 * 	Passing in <jk>null</jk> or {@link ClassTypeConst#OBJECT} typically signifies that it's up to the parser
 * 	to determine what object type is being parsed parsed based on the rules above.

 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class Parser<R> extends CoreApi implements ICoreApiParser<R> {

	/** General serializer properties currently set on this serializer. */
	protected transient ParserProperties pp = new ParserProperties();
	private transient List<ParserListener> listeners = new LinkedList<ParserListener>();;
	private String[] mediaTypes;

	// Hidden constructor to force subclass from InputStreamParser or ReaderParser.
	Parser() {}

	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------
	@Override
	public abstract <T> T parse(R in, ClassType<T> type, ParserContext ctx) throws ParseException, IOException;


	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	/**
	 * Adds a {@link ParserListener} to this parser to listen for parse events.
	 *
	 * @param listener The listener to associate with this parser.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public Parser<R> addListener(ParserListener listener) throws LockedException {
		checkLock();
		this.listeners.add(listener);
		return this;
	}

	/**
	 * Returns the current parser listeners associated with this parser.
	 *
	 * @return The current list of parser listeners.
	 */
	public List<ParserListener> getListeners() {
		return listeners;
	}

	/**
	 * Converts the specified string to the specified type.
	 *
	 * @param <T> The class type to convert the string to.
	 * @param s The string to convert.
	 * @param type The class type to convert the string to.
	 * @return The string converted as an object of the specified type.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected <T> T convertAttrToType(String s, ClassType<T> type) throws ParseException {
		if (s == null)
			return null;

		if (type == null)
			type = (ClassType<T>)OBJECT;
		PojoFilter filter = type.getPojoFilter();
		ClassType<?> gType = type.getFilteredClassType();

		Object o = s;
		if (gType.isChar())
			o = s.charAt(0);
		else if (gType.isNumber())
			o = parseNumber(s, (Class<? extends Number>)gType.getInnerClass());
		else if (gType.isBoolean())
			o = Boolean.parseBoolean(s);
		else if (gType.isEnum())
			o = Enum.valueOf((Class<Enum>)gType.getInnerClass(), s);
		else if (! (gType.isCharSequence() || gType.isObject()))
			throw new ParseException("Invalid conversion from string to class '%s'", type);

		if (filter != null)
			o = filter.unfilter(o, type, beanContext);


		return (T)o;
	}


	/**
	 * Method that gets called when an unknown bean property name is encountered.
	 *
	 * @param <T> The class type of the bean map that doesn't have the expected property.
	 * @param propertyName The unknown bean property name.
	 * @param beanMap The bean that doesn't have the expected property.
	 * @param line The line number where the property was found.  <code>-1</code> if line numbers are not available.
	 * @param col The column number where the property was found.  <code>-1</code> if column numbers are not available.
	 * @throws ParseException Automatically thrown if {@link BeanContextProperties#IGNORE_UNKNOWN_BEAN_PROPERTIES} setting
	 * 	on this parser is <jk>false</jk>
	 */
	protected <T> void onUnknownProperty(String propertyName, BeanMap<T> beanMap, int line, int col) throws ParseException {
		if (propertyName.equals("uri") || propertyName.equals("type") || propertyName.equals("_class"))
			return;
		if (! beanContext.isIgnoreUnknownBeanProperties())
			throw new ParseException(line, col, "Unknown property '%s' encountered while trying to parse into class '%s'", propertyName, beanMap.getClassType());
		if (listeners.size() > 0)
			for (ParserListener listener : listeners)
				listener.onUnknownProperty(propertyName, beanMap.getClassType().getInnerClass(), beanMap.getBean(), line, col);
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------


	@Override
	public <T> T parse(R in, Class<T> type) throws ParseException, IOException {
		ClassType<T> ct = beanContext.getClassType(type);
		return parse(in, ct, createContext(ct, null, null, null));
	}

	@Override
	public ParserContext createContext(ClassType<?> type, ObjectMap properties, String mediaType, String charset) throws ParseException {
		return new ParserContext(type, beanContext, pp, properties, mediaType, charset);
	}

	/**
	 * Returns the media types handled based on the value of the {@link Consumes} annotation on the parser class.
	 * <p>
	 * This method can be overridden by subclasses to determine the media types programatically.
	 */
	@Override // IParser
	public String[] getMediaTypes() {
		if (mediaTypes == null) {
			Consumes c = ReflectionUtils.getAnnotation(Consumes.class, getClass());
			if (c == null)
				throw new RuntimeException(format("Class '%s' is missing the @Consumes annotation", getClass().getName()));
			mediaTypes = c.value();
		}
		return mediaTypes;
	}

	@Override // ICoreApiParser, CoreApi
	public Parser<R> setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public Parser<R> addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public Parser<R> addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public Parser<R> addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiParser, CoreApi
	public <T> Parser<R> addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // IParser, Lockable
	public Parser<R> lock() {
		super.lock();
		return this;
	}

	@SuppressWarnings("unchecked")
	@Override // IParser, Lockable
	public Parser<R> clone() throws CloneNotSupportedException {
		return (Parser<R>)super.clone();
	}
}
