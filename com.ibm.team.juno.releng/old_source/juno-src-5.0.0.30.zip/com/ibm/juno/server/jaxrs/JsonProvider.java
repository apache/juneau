package com.ibm.juno.server.jaxrs;

import javax.ws.rs.*;
import javax.ws.rs.ext.*;

import com.ibm.juno.core.json.*;


/**
 * JAX-RS provider for JSON support using the Juno JSON serializer and parser.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Provider
@Produces({"application/json","text/json"})
@Consumes({"application/json","text/json"})
@JunoProvider(
	serializers=JsonSerializer.class,
	parsers=JsonParser.class
)
public final class JsonProvider extends BaseProvider {}

