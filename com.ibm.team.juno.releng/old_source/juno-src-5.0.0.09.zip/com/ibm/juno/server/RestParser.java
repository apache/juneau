package com.ibm.juno.server;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.server.annotation.*;

/**
 * Used for parsing HTTP request body content to POJO.
 * <p>
 * 	Subclasses must implement the {@link #getMediaTypes()} and {@link #parse(Reader, ClassType, String)} methods.
 * <p>
 * 	For the most part, it's usually just a wrapper around an existing {@link Parser} object that allows
 * 	you to handle additional language-specific information (such as an HTML body or XML declaration tag).
 * 	However, there is no requirement that instances of this class use a parser.
 * <p>
 * 	<code>RestParsers</code> are registered with {@link RestServlet RestServlets} in one of the following ways:
 * <ul>
 * 	<li>Through the use of a {@link RestResource#parsers()} annotation.
 * 	<li>Through the use of a {@link RestMethod#parsers()} annotation.
 * 	<li>By overriding the {@link RestServlet#getParserGroup()} method and manually constructing the
 * 		{@link RestParserGroup} for the resource.
 *	</ul>
 *
 * <p>
 * 	See {@link RestParserGroup} for more information.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class RestParser {

	/**
	 * Method called by the servlet to invoke this parser.
	 */
	<T> T handle(RestRequest req, ClassType<T> type) throws IOException, ParseException {
		return parse(req, type);
	}

	/**
	 * Normal parsing method.
	 * <p>
	 * Most subclasses can use this method for parsing the HTTP request body.
	 *
	 * @param r The input reader.
	 * @param type The class type to convert the input to.
	 * @param <T> The class type to convert the input to.
	 * @param mediaType The <code>Content-Type</code> value stripped of parameters from the request.
	 * 	For example: <js>"text/json"</js>
	 * @return The parsed POJO.
	 * @throws IOException If a problem occurred trying to read the input stream.
	 * @throws ParseException If a problem occurred trying to parse the input stream.
	 */
	public <T> T parse(Reader r, ClassType<T> type, String mediaType) throws IOException, ParseException {
		throw new UnsupportedOperationException();
	}

	/**
	 * Low-level parsing method.
	 * <p>
	 * Subclasses can chose to override this method for parsing the HTTP body if the normal parsing method
	 * 	is not sufficient (i.e. if parsing a byte input stream instead of a character input stream).
	 *
	 * @param req The HTTP request object.
	 * @param type The class type to convert the input to.
	 * @param <T> The class type to convert the input to.
	 * @return The parsed POJO.
	 * @throws IOException If a problem occurred trying to read the input stream.
	 * @throws ParseException If a problem occurred trying to parse the input stream.
	 */
	public <T> T parse(RestRequest req, ClassType<T> type) throws IOException, ParseException {
		return parse(req.getReader(), type, req.getMediaType());
	}

	/**
	 * The request <code>Content-Type</code> values that this parser should handle.
	 * @return The request <code>Content-Type</code> values that this parser should handle.
	 */
	public abstract String[] getMediaTypes();
}
