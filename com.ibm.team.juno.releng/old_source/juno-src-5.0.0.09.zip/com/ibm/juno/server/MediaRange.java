/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2008, 2013. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights: Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 ******************************************************************************/

package com.ibm.juno.server;

import java.lang.reflect.*;
import java.util.*;
import java.util.Map.Entry;

/**
 * Describes a single type used in content negotiation between an HTTP client and server, as described in
 * Section 14.1 and 14.7 of RFC2616 (the HTTP/1.1 specification).
 */
public class MediaRange extends ContentRange {

	final private HashMap<String,String[]> parameters, extensions;

	/**
	 * Returns the type enclosed by this media range.
	 * <p>
	 * Examples of such a type might be <js>"text/html"</js>, <js>"text/*"</js>, <js>"*\/*"</js>.
	 *
	 * @return The type of this media range.
	 * 	Never <jk>null</jk>.
	 * 	The returned string will be normalized to lowercase from its original input value.
	 */
	@Override
	public String getType() {
		return super.getType();
	}

	/**
	 * Returns the optional set of parameters associated to the type as returned by {@link #getType()}.
	 * <p>
	 * The parameters are those values as described in standardized MIME syntax.
	 * An example of such a parameter in string form might be <js>"level=1"</js>.
	 *
	 * @return The optional list of parameters.
	 * 	Neither the return value or the map values will ever be <jk>null</jk>.
	 * 	Depending upon how this type was constructed, the returned string values may be
	 * 		normalized to lowercase from their original input value.
	 */
	public Map<String,String[]> getParameters() {
		return parameters;
	}

	/**
	 * Returns the optional set of custom extensions defined for this type.
	 *
	 * @return The optional list of extensions.
	 * 	Neither the return value or the map values will ever be <jk>null</jk>.
	 * 	Depending upon how this type was constructed, the returned string values may be
	 *         normalized to lowercase from their original input value.
	 */
	public Map<String,String[]> getExtensions() {
		return extensions;
	}

	/**
	 * Provides a string representation of this media range, suitable for use as an <code>Accept</code> header value.
	 * <p>
	 * Note that the literal text values used to create this range may be normalized to lowercase on
	 * 	construction, and will be represented as such here - the values may not compare equal
	 * 	wrt case-sensitivity with the values used to create this instance.
	 *
	 * @return A media range suitable for use as an Accept header value. Never <code>null</code>.
	 */
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer(type);
		if (! parameters.isEmpty()) {
			for (Entry<String,String[]> entry : parameters.entrySet()) {
				sb.append(';');
				sb.append(String.format("%s=%s", entry.getKey(), entry.getValue()));
			}
		}

		/*
		 * '1' is equivalent to specifying no qValue. If there's no extensions, then we won't include a qValue.
		 */
		if (qValue.floatValue() == 1.0) {
			if (! extensions.isEmpty()) {
				sb.append(String.format(";q=%s", qValue.toString()));
				for (Entry<String,String[]> entry : extensions.entrySet()) {
					sb.append(';');
					sb.append(String.format("%s=%s", entry.getKey(), entry.getValue()));
				}
			}
		} else {
			sb.append(String.format(";q=%s", qValue.toString()));
			for (Entry<String,String[]> entry : extensions.entrySet()) {
				sb.append(';');
				sb.append(String.format("%s=%s", entry.getKey(), entry.getValue()));
			}
		}
		return sb.toString();
	}

	/**
	 * MediaRanges are considered equal if their qValues, types, and extensions compare equal (case-insensitive compare for type).
	 *
	 * @return <jk>true</jk> if the qValues, types, and extensions compare equal, <jk>false</jk> if not.
	 */
	@Override
	public boolean equals(Object o) {
		if (o == null || !(o instanceof MediaRange))
			return false;
		if (this == o)
			return true;

		MediaRange that = (MediaRange) o;
		return qValue.equals(that.qValue)
			&& type.equalsIgnoreCase(that.type)
			&& MediaRange.parmMapsEqual(parameters, that.parameters)
			&& MediaRange.parmMapsEqual(extensions, that.extensions);
	}

	/**
	 * Returns a hash based on this instance's <code>_type</code>.
	 *
	 * @return Returns the hashcode of the instance's type.
	 */
	@Override
	public int hashCode() {
		return type.hashCode();
	}

	/**
	 * Compares two maps for equality.
	 * <p>
	 * The assumption is that the name/values of the parameters have been case-normalized for comparison purposes.
	 *
	 * @param thisMap May be <jk>null</jk>.
	 * @param thatMap May be <jk>null</jk>.
	 * @return <jk>true</jk> if the maps contain the same keys and values, <jk>false</jk> if not.
	 * 	If both maps are <jk>null</jk>, <jk>true</jk> is returned.
	 */
	private static boolean parmMapsEqual(Map<String,String[]> thisMap, Map<String,String[]> thatMap) {

		if (thatMap == null && thisMap == null)
			return true;

		if (thatMap == null || thisMap == null)
			return false;

		for (Entry<String,String[]> entry : thatMap.entrySet()) {
			String thatKey = entry.getKey();
			String[] thatVal = entry.getValue();

			String[] thisVal = thisMap.get(thatKey);
			if (thisVal == null)
				return false;

			if (!MediaRange.arraysEqual(thisVal, thatVal))
				return false;
		}

		for (Entry<String,String[]> entry : thisMap.entrySet()) {
			String thisKey = entry.getKey();
			String[] thisVal = entry.getValue();

			String[] thatVal = thatMap.get(thisKey);
			if (thatVal == null)
				return false;

			if (!MediaRange.arraysEqual(thatVal, thisVal))
				return false;
		}

		return true;
	}

	/**
	 * Compares the referenced string arrays for equality.
	 * <p>
	 * Assumes that the values for the arrays have been case-normalized.
	 *
	 * @param a May be <jk>null</jk>.
	 * @param b May be <jk>null</jk>.
	 * @return <jk>true</jk> if the referenced arrays are equal in length and contain the same elements, <jk>false</jk> if not.
	 * 	If both arrays are <jk>null</jk>, <jk>true</jk> is returned.
	 */
	private static boolean arraysEqual(String[] a, String[] b) {

		if (a == null && b == null)
			return true;
		if (a != null && b == null || a == null && b != null)
			return false;

		Arrays.sort(a);
		Arrays.sort(b);

		return Arrays.equals(a, b);
	}

	/**
	 * Creates a <code>MediaRange</code> object with the referenced values.
	 *
	 * @param type The MIME tpe of this media range.
	 * 	May be <jk>null</jk>.
	 * 	Setting to <jk>null</jk> or the empty string is the equivalent to setting to <js>"*\/*"</js> (all types).
	 * 	The string is normalized to lowercase and all LWS removed.
	 * @param parameters The optional parameters for this range.
	 * 	May be <jk>null</jk>.
	 * @param qValue The quality value of this range.
	 * 	May be <jk>null</jk>.
	 * 	Note that the permissible range of values are 0 to 1.0. Setting to <jk>null</jk> is the equivalent to setting a quality value of <js>"1.0"</js>.
	 *
	 * @param extensions The optional extensions to this quality value. May be <code>null</code>.
	 */
	MediaRange(String type, HashMap<String,String[]> parameters, Float qValue, HashMap<String,String[]> extensions) {
		super(type == null || type.length() == 0 ? "*/*" : type, qValue);

		if (parameters == null)
			this.parameters = new HashMap<String,String[]>();
		else
			this.parameters = parameters;

		if (extensions == null)
			this.extensions = new HashMap<String,String[]>();
		else
			this.extensions = extensions;
	}

	/**
	 * Parses an <code>Accept</code> header value into an array of media ranges.
	 * <p>
	 * The returned media ranges are sorted such that the most acceptable media is available at ordinal position <js>'0'</js>, and the least acceptable at position n-1.
	 * <p>
	 * The syntax expected to be found in the referenced <code>value</code> complies with the syntax described in RFC2616, Section 14.1, as described below:
	 * <p class='bcode'>
	 * Accept         = "Accept" ":"
	 *                   #( media-range [ accept-params ] )
	 *
	 * media-range    = ( "*\/*"
	 *                   | ( type "/" "*" )
	 *                   | ( type "/" subtype )
	 *                   ) *( ";" parameter )
	 * accept-params  = ";" "q" "=" qvalue *( accept-extension )
	 * accept-extension = ";" token [ "=" ( token | quoted-string ) ]
	 * </p>
	 *
	 * @param value The value to parse.
	 * 	May be <jk>null</jk> or empty.
	 * 	If <jk>null</jk> or empty, a single <code>MediaRange</code> is returned that represents all types.
	 * @return The media ranges described by the string.
	 * 	The ranges are sorted such that the most acceptable media is available at ordinal position <js>'0'</js>, and the least acceptable at position n-1.
	 */
	public static MediaRange[] parse(String value) {

		RangeParseCallback cb = new RangeParseCallback() {

			@Override
			public ContentRange rangeParsed(String type, HashMap<String,String[]> parameters, Float qValue, HashMap<String,String[]> extensions) {
				return new MediaRange(type, parameters, qValue, extensions);
			}

			@Override
			public void preSort(ArrayList<ContentRange> rangeList) {/* empty */
			}

			@Override
			public void postSort(ArrayList<ContentRange> range) {/* empty */
			}
		};

		ContentRange[] range = ContentRange.parse(value, cb);
		MediaRange[] newRange = (MediaRange[]) Array.newInstance(MediaRange.class, range.length);
		System.arraycopy(range, 0, newRange, 0, range.length);

		return newRange;
	}

	/**
	 * Compares two MediaRanges for equality.
	 * <p>
	 * The values are first compared according to <code>qValue</code> values.
	 * Should those values be equal, the <code>type</code> is then lexicographically compared (case-insensitive) in ascending order,
	 * 	with the <js>"*"</js> type demoted last in that order.
	 * <code>MediaRanges</code> with the same type but different sub-types are compared - a more specific subtype is
	 * 	promoted over the 'wildcard' subtype.
	 * <code>MediaRanges</code> with the same types but with extensions are promoted over those same types with no extensions.
	 * <p>
	 * Note that parameters nor extensions are considered in the comparison.
	 *
	 * @param that The range to compare to.
	 * 	If <jk>null</jk> or not of type <code>MediaRange</code>, this instance is promoted.
	 */
	@Override
	public int compareTo(ContentRange that) {

		if (that == null || !(that instanceof MediaRange))
			return 1;

		float lhs = qValue.floatValue();
		float rhs = that.qValue.floatValue();

		if (lhs == rhs) {
			String[] thisType = splitAcceptPairAllowingSingleAsterisk(type);
			String[] thatType = splitAcceptPairAllowingSingleAsterisk(that.type);
			if (thisType[0].equalsIgnoreCase(thatType[0])) {
				if (thisType[1].equalsIgnoreCase(thatType[1]))
					return MediaRange.compareParms(this, (MediaRange) that);
				else if (thisType[1].equals("*"))
					return 1;
				else if (thatType[1].equals("*"))
					return -1;
				else
					return thisType[1].compareTo(thatType[1]);
			} else if (thisType[0].equals("*"))
				return 1;
			else if (thatType[0].equals("*"))
				return -1;
			else
				return type.compareTo(that.type);
		} else if (lhs < rhs)
			return 1;
		else
			return -1;
	}

	/**
	 * Compares the parameters/extensions of the referenced media ranges.
	 *	<p>
	 * Section 14.1 of RFC2616 says: "Media ranges can be overridden by more specific media ranges or specific media types. If more than one media range applies to a given type, the most specific
	 * reference has precedence." It does not state that there needs to be any lexicographical ordering of the qualifiers that boost one type to be more specific than another - apparently just the
	 * presence of the qualifiers is sufficient.
	 * <p>
	 * In this function the presence of type parameters or extensions causes one MediaRange to have precedence over another and forces the compare accordingly. The algorithm first checks if any
	 * parameters or extensions are defined for either MediaRange. If not, '0' is returned. If one MediaRange has a parameter defined and the other one doesn't, that MediaRange is preferred and the
	 * function returns '1' or '-1' appropriately. If one MediaRange has an extension defined but the other one doesn't, that MediaRange is preferred and the function returns '1' or '-1' appropriately.
	 * If both MediaRanges have both parameters and extensions defined, then '0' is returned.
	 *
	 * @param a May be <jk>null</jk>.
	 * @param b May be <jk>null</jk>.
	 * @return '0' if both compare equal, '-1' if <code>a</code> is more "specific" (so that it will be arrive first in an ascending sort), '1' if <code>b</code> is more specific.
	 */
	private static int compareParms(MediaRange a, MediaRange b) {
		if ((a.parameters == null || a.parameters.isEmpty()) && (b.parameters == null || b.parameters.isEmpty()) && (a.extensions == null || a.extensions.isEmpty())
			&& (b.extensions == null || b.extensions.isEmpty())) {
			return 0;
		}

		if (a.parameters != null && !a.parameters.isEmpty() && (b.parameters == null || b.parameters.isEmpty())) {
			return -1;
		}

		if (b.parameters != null && !b.parameters.isEmpty() && (a.parameters == null || a.parameters.isEmpty())) {
			return 1;
		}

		if (a.extensions != null && !a.extensions.isEmpty() && (b.extensions == null || b.extensions.isEmpty())) {
			return -1;
		}

		if (b.extensions != null && !b.extensions.isEmpty() && (a.extensions == null || a.extensions.isEmpty())) {
			return 1;
		}

		return 0;
	}

	/**
	 * Returns <jk>true</jk> if the specified <code>ContentRange</code> matches this range.
	 * <p>
	 * This implies the {@link ContentRange#getType() type}s are the same or one encompasses the other (like <js>'application/xml'</js> and <js>'application/*'</js>).
	 * </p>
	 * @param cr another content range
	 * @return whether the content ranges matches
	 */
	public boolean matches(ContentRange cr) {
		if (this == cr || (type == null ? cr.type == null : type.equals(cr.type)) || "*/*".equals(type) || "*/*".equals(cr.type))
			return true;

		if (type.charAt(type.length() - 1) == '*' || cr.type.charAt(cr.type.length() - 1) == '*') {
			String mainType1 = type.substring(0, type.indexOf('/'));
			return cr.type.startsWith(mainType1 + '/');
		}

		return false;
	}
}
