package com.ibm.juno.server.serializers;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.server.*;

/**
 * Serializes POJOs to HTTP responses as JSON.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"application/json"</js><li><js>"text/json"</js></ul></td>
 * 		<td><ul><li><js>"application/json"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonRestSerializer extends RestSerializerSerializer {

	/**
	 * Constructor using {@link JsonSerializer#DEFAULT_STRICT} as the POJO serializer.
	 */
	public JsonRestSerializer() {
		super(JsonSerializer.DEFAULT_STRICT_CONDENSED.clone());
	}

	/**
	 * Construct using the specified {@link JsonSerializer} as the POJO serializer.
	 *
	 * @param serializer The serializer.
	 */
	public JsonRestSerializer(Serializer serializer) {
		super(serializer);
	}

	@Override
	public void serialize(RestRequest req, Object output, Writer out, JsonMap properties, String matchingAccept) throws IOException, SerializeException {
		serializer.serialize(out, output, properties);
	}

	@Override
	public String getResponseContentType() {
		return "application/json";
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"application/json","text/json"};
	}
}
