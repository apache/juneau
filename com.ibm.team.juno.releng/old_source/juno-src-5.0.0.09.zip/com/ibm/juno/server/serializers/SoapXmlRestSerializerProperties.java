package com.ibm.juno.server.serializers;


/**
 * Properties associated with the {@link SoapXmlRestSerializer} class.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SoapXmlRestSerializerProperties {

	/**
	 * The <code>SOAPAction</code> HTTP header value to set on responses.
	 * <p>
	 * Default is <js>"http://www.w3.org/2003/05/soap-envelope"</js>.
	 */
	public static final String SOAPACTION = "SoapXmlRestSerializer.SOAPAction";
}
