package com.ibm.juno.server;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.server.annotation.*;

/**
 * Subclass of {@link RestParser RestParsers} that use an instance of {@link Parser} for parsing.
 * <p>
 * Using this subclass allows servlet annotations ({@link RestResource#filters()}, {@link RestResource#converters()}, {@link RestResource#properties()} to
 * 	be applied to the inner parser during servlet initialization.
 * <p>
 * 	See {@link RestParserGroup} for more information.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class RestParserParser extends RestParser {

	/** The inner parser */
	protected Parser parser;

	/**
	 * Constructor.
	 * @param parser The {@link Parser}
	 */
	public RestParserParser(Parser parser) {
		this.parser = parser;
	}

	@Override
	public <T> T parse(Reader r, ClassType<T> type, String mediaType) throws IOException, ParseException {
		return parser.parse(r, type);
	}

	@Override
	public abstract String[] getMediaTypes();

	/**
	 * Returns the parser being used by this rest parser.
	 * @return The parser used by this rest parser.
	 */
	protected Parser getParser() {
		return parser;
	}

	/**
	 * Sets the parser used by this rest parser.
	 */
	protected void setParser(Parser parser) {
		this.parser = parser;
	}
}
