package com.ibm.juno.server;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************


/**
 * Exception thrown to trigger an error HTTP status.
 * <p>
 * 	REST methods on subclasses of {@link RestServlet} can throw
 * 	this exception to trigger an HTTP status other than the automatically-generated
 * 	<code>404</code>, <code>405</code>, and <code>500</code> statuses.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestException extends RuntimeException {

	private int status;

	/**
	 * @param status The HTTP status code.
	 * @param msg The status message.
	 * @param args Optional string format arguments.
	 */
	public RestException(int status, String msg, Object...args) {
		this(status, null, msg, args);
	}

	/**
	 * @param status The HTTP status code.
	 * @param cause The root exception.
	 * @param msg The status message.
	 * @param args Optional string format arguments.
	 */
	public RestException(int status, Throwable cause, String msg, Object...args) {
		super(args.length == 0 ? msg : String.format(msg, args), cause);
		this.status = status;
	}

	/**
	 * @param status The HTTP status code.
	 * @param cause The root exception.
	 */
	public RestException(int status, Throwable cause) {
		super(cause);
		this.status = status;
	}

	/**
	 * @return The HTTP status code.
	 */
	public int getStatus() {
		return status;
	}
}
