package com.ibm.juno.server.parsers;

import com.ibm.juno.core.*;
import com.ibm.juno.core.html.*;
import com.ibm.juno.server.*;

/**
 * Parsers HTTP request bodies with <code>Content-Type</code> of <js>"text/html"</js> into POJOs.
 * <p>
 * For more information, refer to {@link RestParser}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlRestParser extends RestParserParser {

	/**
	 * Constructor using {@link HtmlParser#DEFAULT} as the POJO parser.
	 */
	public HtmlRestParser() {
		super(HtmlParser.DEFAULT.clone());
	}

	/**
	 * Construct using the specified {@link HtmlParser} as the POJO parser.
	 *
	 * @param parser The parser.
	 */
	public HtmlRestParser(Parser parser) {
		super(parser);
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"text/html"};
	}
}
