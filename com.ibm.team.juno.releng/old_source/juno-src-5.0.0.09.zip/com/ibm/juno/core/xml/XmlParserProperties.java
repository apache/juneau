package com.ibm.juno.core.xml;

import javax.xml.stream.*;
import javax.xml.stream.util.*;

import com.ibm.juno.core.*;

/**
 * Configurable properties on the {@link XmlParser} class.
 * <p>
 * 	Use the {@link XmlParser#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link XmlParser}.
 * <ul>
 * 	<li>{@link ParserProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlParserProperties {

	/**
	 * XMLSchema namespace URI ({@link String}, default=<js>"http://www.w3.org/2001/XMLSchema-instance"</js>).
	 * <p>
	 * The XMLSchema namespace.
	 */
	public static final String XSI_NS = "XmlParser.xsiNs";

	/**
	 * Trim whitespace from text elements ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, whitespace in text elements will be automatically trimmed.
	 */
	public static final String TRIM_WHITESPACE = "XmlParser.trimWhitespace";

	/**
	 * Set validating mode ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, XML document will be validated.
	 * See {@link XMLInputFactory#IS_VALIDATING} for more info.
	 */
	public static final String VALIDATING = "XmlParser.validating";

	/**
	 * Set coalescing mode ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, XML text elements will be coalesced.
	 * See {@link XMLInputFactory#IS_COALESCING} for more info.
	 */
	public static final String COALESCING = "XmlParser.coalescing";

	/**
	 * Replace entity references ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * If <jk>true</jk>, entity references will be replace during parsing.
	 * See {@link XMLInputFactory#IS_REPLACING_ENTITY_REFERENCES} for more info.
	 */
	public static final String REPLACE_ENTITY_REFERENCES = "XmlParser.replaceEntityReferences";

	/**
	 * XML reporter ({@link XMLReporter}, default=<jk>null</jk>).
	 * <p>
	 * Associates an {@link XMLReporter} with this parser.
	 * <p>
	 * Note:  Reporters are not copied to new parsers during a clone.
	 */
	public static final String REPORTER = "XmlParser.reporter";

	/**
	 * XML resolver ({@link XMLResolver}, default=<jk>null</jk>).
	 * <p>
	 * Associates an {@link XMLResolver} with this parser.
	 */
	public static final String RESOLVER = "XmlParser.resolver";

	/**
	 * XML event allocator. ({@link XMLEventAllocator}, default=<jk>false</jk>).
	 * <p>
	 * Associates an {@link XMLEventAllocator} with this parser.
	 */
	public static final String EVENT_ALLOCATOR = "XmlParser.eventAllocator";
}
