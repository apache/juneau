package com.ibm.juno.core.xml.annotation;

import static java.lang.annotation.RetentionPolicy.*;

import java.lang.annotation.*;

/**
 * Namespace name/URL mapping pair.
 * <p>
 * 	Used to identify a namespace/URI pair on a {@link Xml#namespaces()} annotation.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Documented
@Target({})
@Retention(RUNTIME)
@Inherited
public @interface XmlNs {

	/**
	 * XML namespace.
	 */
	String name();

	/**
	 * XML namespace URL.
	 */
	String uri();
}
