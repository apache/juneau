package com.ibm.juno.core.filters;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.html.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.utils.*;
import com.ibm.juno.core.xml.*;

/**
 * Transforms the contents of a {@link Reader} into an {@code Object}.
 * <p>
 * 	The {@code Reader} must contain JSON, Juno-generated XML (output from {@link XmlSerializer}),
 * 		or Juno-generated HTML (output from {@link JsonSerializer}) in order to be parsed correctly.
 * <p>
 * 	Useful for serializing models that contain {@code Readers} created by {@code RestCall} instances.
 * <p>
 * 	This is a one-way filter, since {@code Readers} cannot be reconstituted.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ReaderFilter extends ObjectFilter<Reader,Object> {

	/**
	 * Default reusable filter for reading JSON text.
	 */
	public static final ReaderFilter DEFAULT_JSON = new ReaderFilter(JsonParser.DEFAULT);

	/**
	 * Default reusable filter for reading XML text.
	 */
	public static final ReaderFilter DEFAULT_XML = new ReaderFilter(XmlParser.DEFAULT);

	/**
	 * Default reusable filter for reading HTML text.
	 */
	public static final ReaderFilter DEFAULT_HTML = new ReaderFilter(HtmlParser.DEFAULT);

	/**
	 * Default reusable filter for reading plain text.
	 */
	public static final ReaderFilter DEFAULT_PLAIN_TEXT = new ReaderFilter(null);

	/** The parser to use to parse the contents of the Reader. */
	private Parser parser;

	/**
	 * @param parser The parser to use to convert the contents of the reader to Java objects.
	 */
	public ReaderFilter(Parser parser) {
		this.parser = parser;
	}

	/**
	 * Converts the specified {@link Reader} to an {@link Object} whose type is determined
	 * by the contents of the reader.
	 */
	@Override
	public Object filter(Reader o, BeanContext beanContext) throws SerializeException {
		try {
			if (parser == null)
				return IOUtils.read(o);
			return parser.parse(o);
		} catch (IOException e) {
			return e.getLocalizedMessage();
		} catch (Exception e) {
			throw new SerializeException(e, "ReaderFilter could not filter object of type '%s'", o == null ? null : o.getClass().getName());
		}
	}
}
