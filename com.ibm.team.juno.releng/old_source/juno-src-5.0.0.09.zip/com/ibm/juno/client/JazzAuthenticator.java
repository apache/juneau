package com.ibm.juno.client;

import java.io.*;
import java.net.*;

import javax.net.ssl.*;

import com.ibm.juno.core.utils.*;

/**
 * Authenticator for logging into Jazz Team Servers.
 * <p>
 * *** PROTOTYPE ***
 * <p>
 * Bean property setters provided so that instances can be instantiated through parsers.
 * <p class='bcode'>
 * 	<jc>// Construct authenticator instance from JSON</jc>
 * 	String json = <js>"{_class:'com.ibm.juno.client.JazzAuthenticator',jtsUrl:'https://localhost:9443/jts',user:'ADMIN',password:'ADMIN'}"</js>;
 * 	Authenticator a = JsonParser.<jsf>DEFAULT</jsf>.parse(json, Authenticator.<jk>class</jk>);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JazzAuthenticator implements Authenticator {
	private String jtsUrl, user, pw;
	private volatile String jsessionid = "";

	/** Bean constructor. */
	public JazzAuthenticator() {}

	/**
	 * Constructor.
	 * @param jtsUrl URL of Jazz Team Server (e.g. <js>"https://localhost:9443/jts"</js>).
	 * @param user Jazz username.
	 * @param pw Jazz password.
	 */
	public JazzAuthenticator(String jtsUrl, String user, String pw) {
		this.jtsUrl = jtsUrl;
		this.user = user;
		this.pw = pw;
	}

	/**
	 * Returns the JTS URL property.
	 * @return The JTS URL property.
	 */
	public String getJtsUrl() {
		return jtsUrl;
	}

	/**
	 * Sets the JTS URL property.
	 * @param jtsUrl URI of Jazz Team Server (e.g. <js>"https://localhost:9443/jts"</js>).
	 * @return This object (for method chaining).
	 */
	public JazzAuthenticator setJtsUrl(String jtsUrl) {
		this.jtsUrl = jtsUrl;
		return this;
	}

	/**
	 * Returns the Jazz authentication username.
	 * @return The Jazz authentication username.
	 */
	public String getUser() {
		return user;
	}

	/**
	 * Sets the Jazz authentication username.
	 * @param user Jazz username.
	 * @return This object (for method chaining).
	 */
	public JazzAuthenticator setUser(String user) {
		this.user = user;
		return this;
	}

	/**
	 * Returns the Jazz authentication password.
	 * @return The Jazz authentication password.
	 */
	public String getPassword() {
		return pw;
	}

	/**
	 * Sets the Jazz authentication password.
	 * @param pw Jazz password.
	 * @return This object (for method chaining).
	 */
	public JazzAuthenticator setPassword(String pw) {
		this.pw = pw;
		return this;
	}

	/**
	 * Adds a <js>"Cookie"</js> header to all requests with the value
	 * <js>"net-jazz-ajax-cookie-rememberUserId=; JSESSIONID=xxx; JazzFormAuth=Form"</js>
	 */
	@Override
	public void authenticate(RestClient client) throws RestCallException {
		if (jsessionid.isEmpty()) {
			synchronized(jsessionid) {
				if (jsessionid.isEmpty()) {
					try {
						java.net.Authenticator.setDefault(
							new java.net.Authenticator() {
								@Override
								protected PasswordAuthentication getPasswordAuthentication() {
								    return new PasswordAuthentication (user, pw.toCharArray());
								  }
							}
						);

						SSLUtils.trustAllCerts();

					    URL url = new URL(jtsUrl + "/authenticated/identity");
						HttpsURLConnection c = (HttpsURLConnection)url.openConnection(Proxy.NO_PROXY);
						c.setRequestMethod("GET");
						c.setInstanceFollowRedirects(false);
						c.connect();
						String location = c.getHeaderField("Location");
						jsessionid = location.substring(location.toLowerCase().indexOf("jsessionid=")+11);
						c.disconnect();

					    url = new URL(jtsUrl + "/auth/j_security_check");
						c = (HttpsURLConnection)url.openConnection(Proxy.NO_PROXY);
						c.setRequestMethod("POST");
						c.setDoInput(true);
						c.setDoOutput(true);
						c.setInstanceFollowRedirects(false);
						c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
						c.setRequestProperty("Connection", "keep-alive");
						c.setRequestProperty("Cookie", "net-jazz-ajax-cookie-rememberUserId=; JSESSIONID="+jsessionid+"; JazzFormAuth=Form");
						c.setRequestProperty("Accept", "text/json");
						c.connect();
						OutputStream os = c.getOutputStream();
						os.write(("j_username="+user+"&j_password="+pw).getBytes("UTF-8"));
						os.flush();
						os.close();
						IOUtils.read(c.getInputStream());
						c.disconnect();

					} catch (Exception e) {
						throw new RestCallException(e);
					}
				}
			}
		}

		client.addRequestHeader("Cookie", "net-jazz-ajax-cookie-rememberUserId=; JSESSIONID="+jsessionid+"; JazzFormAuth=Form");
		client.addRequestHeader("X-Jazz-CSRF-Prevent", jsessionid);
	}
}
