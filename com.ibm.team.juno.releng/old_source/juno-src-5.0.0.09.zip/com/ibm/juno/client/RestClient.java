package com.ibm.juno.client;

import java.net.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.urlencoding.*;

/**
 * Utility class for interfacing with remote REST interfaces.
 * <p>
 * 	Designed using a fluent interface with method chaining.<br>
 * <p>
 * 	This class uses only Java standard APIs.<br>
 * <p>
 * 	This class is designed to be reused.  It is also thread-safe (can be used from multiple threads).
 *
 * <h6 class='topic'>Additional Information</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#RestClient'>com.ibm.juno.client &gt; REST client API</a> for more information and code examples.
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestClient {

	private List<Authenticator> authenticators = new LinkedList<Authenticator>();
	Map<String,Object> requestHeaders = new LinkedHashMap<String,Object>();
	String defaultContentType = null, defaultAccept = null;
	private SerializerGroup serializerGroup = new SerializerGroup();
	private ParserGroup parserGroup = new ParserGroup();

	/**
	 * Create a new client.
	 * <p>
	 * 	Sets the following default values:
	 * <ul>
	 * 	<li>Serializer {@link JsonSerializer#DEFAULT} with default <js>"Content-Type"</js> of <js>"text/json"</js>.
	 * 	<li>Parser {@link JsonParser#DEFAULT} with default <js>"Accept"</js> of <js>"text/json"</js>.
	 * </ul>
	 */
	public RestClient() {
		setDefaultSerializer(JsonSerializer.DEFAULT.clone(), "text/json");
		setDefaultParser(JsonParser.DEFAULT.clone(), "text/json");
	}

	/**
	 * Associates an {@link Authenticator} with this client.
	 * <p>
	 * 	The purpose of authenticators is to add authentication headers to all REST requests created by this client.
	 *
	 * @param authenticator The authenticator to associate with this client.
	 * @return This object (for method chaining).
	 */
	public RestClient addAuthenticator(Authenticator authenticator) {
		this.authenticators.add(authenticator);
		return this;
	}

	/**
	 * Specifies a request header property to add to all REST requests created by this client.
	 *
	 * @param name The HTTP header name.
	 * @param value The HTTP header value.
	 * @return This object (for method chaining).
	 */
	public RestClient addRequestHeader(String name, Object value) {
		this.requestHeaders.put(name, value);
		return this;
	}

	/**
	 * Sets the default serializer and content-type for this client.
	 * <p>
	 * 	The default can be overridden by calling the {@link RestCall#setContentType(String)} method
	 * 	on requests created by this client.
	 *
	 * @param s The serializer to use for this content-type.
	 * @param contentType The value to set for the <js>"Content-Type"</js> header.
	 * @return This object (for method chaining).
	 */
	public RestClient setDefaultSerializer(Serializer s, String contentType) {
		if (s.isLocked())
			s = s.clone();
		this.serializerGroup.add(s, contentType);
		this.defaultContentType = contentType;
		return this;
	}

	/**
	 * Adds an additional serializer to this client to handle other kinds of <js>"Content-Type"</js> requests.
	 *
	 * @param s The serializer to use for the specified content-types.
	 * @param contentType The list of content-types that this serializer will handle.
	 * @return This object (for method chaining).
	 */
	public RestClient addSerializer(Serializer s, String...contentType) {
		if (s.isLocked())
			s = s.clone();
		this.serializerGroup.add(s, contentType);
		return this;
	}

	/**
	 * Sets the default parser and accept-type for this client.
	 * <p>
	 * 	The default can be overridden by calling the {@link RestCall#setAccept(String)} method
	 * 	on requests created by this client.
	 *
	 * @param p The parser to use for this accept-type.
	 * @param accept The value to set for the <js>"Accept"</js> header.
	 * @return This object (for method chaining).
	 */
	public RestClient setDefaultParser(Parser p, String accept) {
		if (p.isLocked())
			p = p.clone();
		this.parserGroup.add(p, accept);
		this.defaultAccept = accept;
		return this;
	}

	/**
	 * Adds an additional parser to this client to handle other kinds of <js>"Accept"</js> requests.
	 *
	 * @param p The parser to use for the specified accept-types.
	 * @param accept The list of accept-types that this parser will handle.
	 * @return This object (for method chaining).
	 */
	public RestClient addParser(Parser p, String...accept) {
		if (p.isLocked())
			p = p.clone();
		this.parserGroup.add(p, accept);
		return this;
	}

	/**
	 * Shortcut method for adding filters to the bean contexts of all serializers and
	 * 	parsers registered with this client.
	 * @param filters One or more filters to associate with all serializers and parsers.
	 * @return This object (for method chaining).
	 */
	public RestClient addFilters(Filter...filters) {
		this.serializerGroup.addFilters(filters);
		this.parserGroup.addFilters(filters);
		return this;
	}

	/**
	 * Returns the serializer for the specified <js>"Content-Type"</js> value, or <jk>null</jk> if
	 * no serializer is registered to handle it.
	 */
	protected Serializer getSerializer(String contentType) {
		Serializer s = serializerGroup.getSerializer(contentType);
		if (s == null)
			s = serializerGroup.getSerializer(defaultContentType);
		return s;
	}

	/**
	 * Returns the parser for the specified <js>"Accept"</js> value, or <jk>null</jk> if
	 * no parser is registered to handle it.
	 */
	protected Parser getParser(String accept) {
		Parser p = parserGroup.getParser(accept);
		if (p == null)
			p = parserGroup.getParser(defaultAccept);
		return p;
	}

	/**
	 * Shortcut for calling <code>setRequestProperty("Content-Encoding", defaultContentEncoding)</code>
	 * <p>
	 * 	If set to <js>"gzip"</js>, output stream will automatically be gzip-encoded.
	 * @param defaultContentEncoding The default content encoding value.  Default is <jk>null</jk>.
	 * @return This object (for method chaining).
	 */
	public RestClient setDefaultContentEncoding(String defaultContentEncoding) {
		addRequestHeader("Content-Encoding", defaultContentEncoding);
		return this;
	}

	/**
	 * Shortcut for calling <code>setRequestProperty("Content-Encoding", defaultContentEncoding)</code>
	 * <p>
	 * 	If set to <js>"gzip"</js>, input stream will automatically be unzipped.
	 * @param defaultAcceptEncoding The default accept encoding value.  Default is <jk>null</jk>.
	 * @return This object (for method chaining).
	 */
	public RestClient setDefaultAcceptEncoding(String defaultAcceptEncoding) {
		addRequestHeader("Accept-Encoding", defaultAcceptEncoding);
		return this;
	}

	/**
	 * Perform a <js>"GET"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doGet(Object url) throws RestCallException {
		authenticate();
		return new RestCall(this, "GET", url);
	}

	/**
	 * Perform a <js>"GET"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param params URL parameters to add to the URL.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doGet(Object url, Map<String,Object> params) throws RestCallException {
		authenticate();
		return new RestCall(this, "GET", url, params);
	}

	/**
	 * Perform a <js>"PUT"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doPut(Object url, Object o) throws RestCallException {
		authenticate();
		return new RestCall(this, "PUT", url).setInput(o);
	}

	/**
	 * Perform a <js>"PUT"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request.
	 * @param params URL parameters to add to the URL.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doPut(Object url, Map<String,Object> params, Object o) throws RestCallException {
		authenticate();
		return new RestCall(this, "PUT", url, params).setInput(o);
	}

	/**
	 * Perform a <js>"POST"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doPost(Object url, Object o) throws RestCallException {
		authenticate();
		return new RestCall(this, "POST", url).setInput(o);
	}

	/**
	 * Perform a <js>"POST"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request.
	 * @param params URL parameters to add to the URL.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doPost(Object url, Map<String,Object> params, Object o) throws RestCallException {
		authenticate();
		return new RestCall(this, "POST", url, params).setInput(o);
	}

	/**
	 * Perform a <js>"DELETE"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doDelete(Object url) throws RestCallException {
		authenticate();
		return new RestCall(this, "DELETE", url);
	}

	/**
	 * Perform a <js>"DELETE"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param params URL parameters to add to the URL.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doDelete(Object url, Map<String,Object> params) throws RestCallException {
		authenticate();
		return new RestCall(this, "DELETE", url, params);
	}

	/**
	 * Perform an <js>"OPTIONS"</js> request against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doOptions(Object url) throws RestCallException {
		authenticate();
		return new RestCall(this, "OPTIONS", url);
	}

	/**
	 * Perform a <js>"POST"</js> request with a content type of <js>"application/x-www-form-urlencoded"</js> against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param o The object to serialize and transmit to the URL as the body of the request, serialized as a form post
	 * 	using the {@link UrlEncodingSerializer#DEFAULT} serializer.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doFormPost(Object url, Object o) throws RestCallException {
		authenticate();
		try {
			return new RestCall(this, "POST", url)
				.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
				.setInput(UrlEncodingSerializer.DEFAULT.serialize(o).substring(1));
		} catch (SerializeException e) {
			throw new RestCallException(e);
		}
	}

	/**
	 * Perform a <js>"POST"</js> request with a content type of <js>"application/x-www-form-urlencoded"</js> against the specified URL.
	 *
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param params URL parameters to add to the URL.
	 * @param o The object to serialize and transmit to the URL as the body of the request, serialized as a form post
	 * 	using the {@link UrlEncodingSerializer#DEFAULT} serializer.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doFormPost(Object url, Map<String,Object> params, Object o) throws RestCallException {
		authenticate();
		try {
			return new RestCall(this, "POST", url, params)
				.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
				.setInput(UrlEncodingSerializer.DEFAULT.serialize(o).substring(1));
		} catch (SerializeException e) {
			throw new RestCallException(e);
		}
	}

	/**
	 * Perform a generic REST call.
	 *
	 * @param method The method name (e.g. <js>"GET"</js>, <js>"OPTIONS"</js>).
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doCall(String method, Object url) throws RestCallException {
		authenticate();
		return new RestCall(this, method, url);
	}

	/**
	 * Perform a generic REST call.
	 * <p>
	 * 	REST calls requiring content (e.g. <js>"POST"</js>, <js>"PUT"</js>) can call the
	 *  {@link RestCall#setInput(Object)} method on the returned object.
	 *
	 * @param method The method name (e.g. <js>"GET"</js>, <js>"OPTIONS"</js>).
	 * @param url The URL of the remote REST resource.  Can be any of the following:  {@link String}, {@link URI}, {@link URL}.
	 * @param params URL parameters to add to the URL.
	 * @return A {@link RestCall} object that can be further tailored before executing the request
	 * 	and getting the response as a parsed object.
	 * @throws RestCallException If any authentication errors occurred.
	 */
	public RestCall doCall(String method, Object url, Map<String,Object> params) throws RestCallException {
		authenticate();
		return new RestCall(this, method, url, params);
	}

	private void authenticate() throws RestCallException {
		for (Authenticator authenticator : authenticators) {
			authenticator.authenticate(this);
		}
	}
}
