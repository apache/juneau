package com.ibm.juno.client;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;

/**
 * Utility for making REST calls through a command-line interface.
 * <p>
 * 	Format of the command is:<br>
 * 	<code>
 * 		java com.ibm.juno.core.rest.RestCmdLine GET|PUT|POST|DELETE url [content] [options]
 * 	</code>
 *
 * <h6 class='topic'>Options</h6>
 * <ul>
 * 	<li>{@code -i} = Input file for POST/PUT requests.
 * 	<li>{@code -o} = Output file.  If not specified, output goes to STDOUT.
 * 	<li>{@code -u} = Username.
 * 	<li>{@code -p} = Password.
 * 	<li>{@code -h} = Headers to set in JSON format (e.g. <code>{<js>'Accept'</js>:<js>'text/json;charset=UTF=8'</js>,<js>'Accept-Language'</js>:<js>'ja'</js>}</code>).
 * </ul>
 *
 * <h6 class='topic'>Additional Information</h6>
 * <ul>
 * 	<li><a class='doclink' href='package-summary.html#RestCmdLine'>com.ibm.juno.client &gt; REST command line client</a> for more information and code examples.
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestCmdLine {

	/**
	 * The method for processing REST commands.
	 *
	 * @param args The command line arguments.
	 * @return The return code.
	 * @throws RestCallException Thrown when remote REST interface causes an error.
	 * @throws IOException If a problem occurred trying to connect to the remote REST interface.
	 * @throws ParseException If the input contains a syntax error or is malformed.
	 */
	public static int handleRequest(List<String> args) throws RestCallException, IOException, ParseException {

		if (! (args instanceof LinkedList))
			args = new LinkedList<String>(args);

		if (args.size() < 2)
			return 2;
		String o = null;
		RestClient client = new RestClient();

		String user = null, pw = null;
		Object input = null;
		String requestProperties = null;

		if (args.size() > 0)
			if (! args.get(0).startsWith("-"))
				input = args.remove(0);

		for (Iterator<String> i2 = args.iterator(); i2.hasNext();) {
			if (! i2.hasNext())
				return 2;
			String s1 = i2.next();
			String s2 = i2.next();
			if (! s1.startsWith("-"))
				return 2;
			switch (s1.charAt(1)) {
				case 'i':	input = new FileReader(s2); break;
				case 'o':	o = s2; break;
				case 'a':	user = s2; break;
				case 'p':	pw = s2; break;
				case 'h':	requestProperties = s2; break;
				default: return 2;
			}
		}
		if (user != null && (! user.isEmpty()) && pw != null && (! pw.isEmpty()))
			client.addAuthenticator(new BasicAuthenticator(user, pw));

		RestCall r = client.doCall(args.remove(0), args.remove(0));
		if (input != null)
			r.setInput(input);
		if (requestProperties != null)
			r.setRequestProperties(requestProperties);

		Writer out = (o == null ? new OutputStreamWriter(System.out) : new BufferedWriter(new FileWriter(o)));
		r.pipeTo(out);
		out.close();
		return r.getResponseCode();
	}

	/**
	 * Main entry point.
	 *
	 * @param args The command-line arguments.
	 */
	public static void main(String[] args) {
		try {
			System.exit(handleRequest(Arrays.asList(args)));
		} catch (RestCallException e) {
			e.printStackTrace(System.err);
			System.exit(e.getResponseCode());
		} catch (Exception e) {
			e.printStackTrace(System.err);
			System.exit(1);
		}
	}
}