package com.ibm.juno.client;

import com.ibm.juno.core.annotation.*;

/**
 * Rest client authenticator.
 * <p>
 * 	Authenticators can be associated with {@link RestClient RestClients} through the
 * 	{@link RestClient#addAuthenticator(Auth)} method.
 * <p>
 * 	The {@link Auth#authenticate(RestClient)} method is called before each
 * 	call to one of the {@code RestClient.doX()} methods.  The authenticator should
 * 	attach any necessary headers to responses by calling the {@link RestClient#setHeader(String, Object)}
 * 	method.
 * <p>
 * 	More than one authenticator can be associated with a client.  For example, both the {@link BasicAuth}
 * 	and {@link BasicProxyAuth} can be associated with a client if a reverse proxy server also requires authentication.
 * <p>
 * 	Auth implementations should be written to be thread-safe.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Bean
public interface Auth {

	/**
	 * Method that all authenticators must implement.
	 * <p>
	 * 	Implementers should add response headers using the {@link RestClient#setHeader(String, Object)} object.
	 * @param client The client being used to create REST calls.
	 * @throws RestCallException Should be thrown if any error occurs during authentication (typically
	 * 	a {@code 401 - SC_NOT_AUTHORIZED}).
	 */
	public void authenticate(RestClient client) throws RestCallException;
}
