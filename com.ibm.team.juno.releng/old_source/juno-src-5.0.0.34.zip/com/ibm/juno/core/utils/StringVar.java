package com.ibm.juno.core.utils;


/**
 * Interface for the resolution of Vars.
 * Vars are strings of the format $X{arg}
 * @author jbognar
 */
public abstract class StringVar {

	/**
	 * The interface that needs to be implemented for Vars.
	 */
	public abstract String resolve(String arg);
}
