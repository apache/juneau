package com.ibm.juno.core.urlencoding;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;

/**
 * Context object that lives for the duration of a single parsing of {@link UrlEncodingParser}.
 * <p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingParserContext extends ParserContext {

	/**
	 * Create a new parser context with the specified options.
	 *
	 * @param type The class type being parsed.
	 * @param beanContext The bean context being used.
	 * @param pp The default parser properties.
	 * @param op The override properties.
	 * @param mediaType The media type being parsed.
	 * @param charset The charset being parsed.
	 */
	public UrlEncodingParserContext(ClassMeta<?> type, BeanContext beanContext, ParserProperties pp, ObjectMap op, String mediaType, String charset) {
		super(type, beanContext, pp, op, mediaType, charset);
	}
}
