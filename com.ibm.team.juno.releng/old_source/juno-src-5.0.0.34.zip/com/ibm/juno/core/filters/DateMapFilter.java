package com.ibm.juno.core.filters;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.*;

/**
 * Transforms {@link Date Dates} to {@link Map Maps} of the format <tt>{value:long}</tt>.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("rawtypes")
public class DateMapFilter extends PojoFilter<Date,Map> {

	/**
	 * Converts the specified {@link Date} to a {@link Map}.
	 */
	@Override
	public Map filter(Date o, BeanContext beanContext) {
		ObjectMap m = new ObjectMap();
		m.put("time", o.getTime());
		return m;
	}

	/**
	 * Converts the specified {@link Map} to a {@link Date}.
	 */
	@Override
	public Date unfilter(Map o, ClassMeta<?> hint, BeanContext beanContext) throws ParseException {
		Class<?> c = hint.getInnerClass();
		long l = Long.parseLong(((Map<?,?>)o).get("time").toString());
		if (c == java.util.Date.class)
			return new java.util.Date(l);
		if (c == java.sql.Date.class)
			return new java.sql.Date(l);
		if (c == java.sql.Time.class)
			return new java.sql.Time(l);
		if (c == java.sql.Timestamp.class)
			return new java.sql.Timestamp(l);
		throw new ParseException("DateMapFilter is unable to narrow object of type ''{0}''", c);
	}
}
