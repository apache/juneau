package com.ibm.juno.core.serializer;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.ClassMetaConst.*;

import java.io.*;
import java.lang.reflect.*;
import java.text.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.soap.*;
import com.ibm.juno.core.utils.*;

/**
 * Parent class for all Juno serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Base serializer class that serves as the parent class for all serializers.
 * <p>
 * 	Subclasses should extend directly from {@link OutputStreamSerializer} or {@link WriterSerializer}.
 *
 *
 * <h6 class='topic'>@Produces annotation</h6>
 * <p>
 * 	The media types that this serializer can produce is specified through the {@link Produces @Produces} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()}
 * 		and {@link #getResponseContentType()} methods.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * 	See {@link SerializerProperties} for a list of configurable properties that can be set on this class
 * 	using the {@link #setProperty(String, Object)} method.
 *
 * @param <W> The output stream or writer class type.
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class Serializer<W> extends CoreApi {

	/** General serializer properties currently set on this serializer. */
	protected transient SerializerProperties sp = new SerializerProperties();
	private String[] mediaTypes;
	private String contentType;

	// Hidden constructor to force subclass from OuputStreamSerializer or WriterSerializer.
	Serializer() {}


	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	/**
	 * Serializes a POJO to the specified output stream or writer.
	 *
	 * @param o The object to serialize.
	 * @param out The writer or output stream to write to.
	 * @param ctx The serializer context object return by {@link #createContext(Object, ObjectMap, String, String)}.<br>
	 * 	Can be <jk>null</jk>.
	 *
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public abstract void serialize(Object o, W out, SerializerContext ctx) throws IOException, SerializeException;


	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	/**
	 * Create the context object that will be passed in to the serialize method.
	 * <p>
	 * 	It's up to implementers to decide what the context object looks like, although typically
	 * 	it's going to be a subclass of {@link SerializerContext}.
	 *
	 * @param o The POJO that's going to be serialized.
	 * @param properties Optional additional properties.
	 * @param mediaType The media type being produced.
	 * 	For example, when using the REST servlet API, this value is set to the accept value that was matched against.
	 * @param charset The output charset.
	 * @return The new context.
	 * @throws SerializeException If any errors were encountered.  This causes serialization to abort.
	 */
	public SerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) throws SerializeException {
		return new SerializerContext(beanContext, sp, properties, mediaType, charset);
	}

	/**
	 * Asserts that the specified {@link SerializerContext} object is a subclass of <code>c</code> and
	 * 	narrows it to that class.
	 * @param ctx The {@link SerializerContext} to test.
	 * @param c The expected parent class of the serializer context.
	 * @throws SerializeException If the context object is <jk>null</jk> or not a subclass of <code>c</code>.
	 */
	@SuppressWarnings("unchecked")
	protected <T extends SerializerContext> T narrow(SerializerContext ctx, Class<T> c) throws SerializeException {
		if (ctx == null)
			throw new SerializeException("Null context specified");
		if (! c.isAssignableFrom(ctx.getClass()))
			throw new SerializeException("Invalid serializer context specified.  Expected=''{0}'', Actual=''{1}''", c.getName(), ctx.getClass().getName());
		return (T)ctx;
	}

	/**
	 * Converts the contents of the specified object array to a list.
	 * <p>
	 * 	Works on both object and primitive arrays.
	 * <p>
	 * 	In the case of multi-dimensional arrays, the outgoing list will
	 * 	contain elements of type n-1 dimension.  i.e. if {@code type} is <code><jk>int</jk>[][]</code>
	 * 	then {@code list} will have entries of type <code><jk>int</jk>[]</code>.
	 *
	 * @param type The type of array.
	 * @param array The array being converted.
	 * @return The array as a list.
	 */
	protected final List<Object> toList(Class<?> type, Object array) {
		Class<?> componentType = type.getComponentType();
		if (componentType.isPrimitive()) {
			int l = Array.getLength(array);
			List<Object> list = new ArrayList<Object>(l);
			for (int i = 0; i < l; i++)
				list.add(Array.get(array, i));
			return list;
		}
		return Arrays.asList((Object[])array);
	}

	/**
	 * Generalize the specified object if a filter is associated with it.
	 *
	 * @param o The object to generalize.
	 * @return The generalized object, or null if the object is null.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected final Object generalize(Object o, ClassMeta<?> type) throws SerializeException {
		if (o == null)
			return null;
		PojoFilter f = (type == null || type.isObject() ? beanContext.getPojoFilter(o.getClass()) : type.getPojoFilter());
		if (f == null)
			return o;
		return f.filter(o, beanContext);
	}

	/**
	 * Returns true if the specified property should not be serialized.
	 */
	protected final boolean canIgnoreProperty(SerializerContext ctx, BeanPropertyMeta<?> pMeta) {
		return false;
	}

	/**
	 * Returns true if the specified value should not be serialized.
	 */
	protected final boolean canIgnoreValue(SerializerContext ctx, ClassMeta<?> cm, Object value) {

		if (ctx.isTrimNulls() && value == null)
			return true;

		if (value == null)
			return false;

		if (cm == null)
			cm = OBJECT;

		if (ctx.isTrimEmptyLists()) {
			if (cm.isArray() || (cm.isObject() && value.getClass().isArray())) {
				if (((Object[])value).length == 0)
					return true;
			}
			if (cm.isCollection() || (cm.isObject() && Collection.class.isAssignableFrom(value.getClass()))) {
				if (((Collection<?>)value).isEmpty())
					return true;
			}
		}

		if (ctx.isTrimEmptyMaps()) {
			if (cm.isMap() || (cm.isObject() && Map.class.isAssignableFrom(value.getClass()))) {
				if (((Map<?,?>)value).isEmpty())
					return true;
			}
		}

		if (ctx.isTrimNulls() && ctx.willRecurse(value))
			return true;

		return false;
	}

	/**
	 * Returns the media types handled based on the value of the {@link Produces} annotation on the serializer class.
	 * <p>
	 * This method can be overridden by subclasses to determine the media types programatically.
	 */
	public String[] getMediaTypes() {
		if (mediaTypes == null) {
			Produces p = ReflectionUtils.getAnnotation(Produces.class, getClass());
			if (p == null)
				throw new RuntimeException(MessageFormat.format("Class ''{0}'' is missing the @Produces annotation", getClass().getName()));
			mediaTypes = p.value();
		}
		return mediaTypes;
	}

	/**
	 * Optional method that specifies HTTP request headers for this serializer.
	 * <p>
	 * 	For example, {@link SoapXmlSerializer} needs to set a <code>SOAPAction</code> header.
	 * <p>
	 * 	This method is typically meaningless if the serializer is being used standalone (i.e. outside of a REST server or client).
	 *
	 * @param properties Optional run-time properties (the same that are passed to {@link WriterSerializer#serialize(Object, Writer, SerializerContext)}.
	 * 	Can be <jk>null</jk>.
	 * @return The HTTP headers to set on HTTP requests.
	 * 	Can be <jk>null</jk>.
	 */
	public ObjectMap getResponseHeaders(ObjectMap properties) {
		return new ObjectMap().setBeanContext(beanContext);
	}

	/**
	 * Optional method that returns the response <code>Content-Type</code> for this serializer if it is different from the matched media type.
	 * <p>
	 * 	This method is specified to override the content type for this serializer.
	 * 	For example, the {@link com.ibm.juno.core.json.JsonSerializer.Simple} class returns that it handles media type <js>"text/json+simple"</js>, but returns
	 * 	<js>"text/json"</js> as the actual content type.
	 * 	This allows clients to request specific 'flavors' of content using specialized <code>Accept</code> header values.
	 * <p>
	 * 	This method is typically meaningless if the serializer is being used standalone (i.e. outside of a REST server or client).
	 * @return The response content type.  If <jk>null</jk>, then the matched media type is used.
	 */
	public String getResponseContentType() {
		if (contentType == null) {
			Produces p = getClass().getAnnotation(Produces.class);
			contentType = (p == null ? "" : p.contentType());
		}
		return (contentType.isEmpty() ? null : contentType);
	}

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // CoreApi
	public Serializer<W> setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (sp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // CoreApi
	public Serializer<W> addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public Serializer<W> addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> Serializer<W> addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // CoreApi
	public Serializer<W> lock() {
		super.lock();
		return this;
	}

	@Override // CoreApi
	public Serializer<W> clone() throws CloneNotSupportedException {
		@SuppressWarnings("unchecked")
		Serializer<W> c = (Serializer<W>)super.clone();
		c.sp = sp.clone();
		return c;
	}
}
