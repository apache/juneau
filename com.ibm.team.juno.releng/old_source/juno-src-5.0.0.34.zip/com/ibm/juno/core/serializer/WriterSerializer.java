package com.ibm.juno.core.serializer;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;

/**
 * Subclass of {@link Serializer} for character-based serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all character-based serializers.
 * 	It has 2 abstract methods to implement...
 * <ul>
 * 	<li>{@link #createContext(Object, ObjectMap, String, String)}
 * 	<li>{@link #serialize(Object, Writer, SerializerContext)}
 * </ul>
 *
 *
 * <h6 class='topic'>@Produces annotation</h6>
 * <p>
 * 	The media types that this serializer can produce is specified through the {@link Produces @Produces} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()}
 * 		and {@link #getResponseContentType()} methods.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class WriterSerializer extends Serializer<Writer> {


	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	public abstract void serialize(Object o, Writer out, SerializerContext ctx) throws IOException, SerializeException;


	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	/**
	 * Same as {@link WriterSerializer#serialize(Object, Writer, SerializerContext)} except serializes to a <code>String</code>.
	 *
	 * @param o The object to serialize.
	 * @param ctx The serialize context.  Can be <jk>null</jk>.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o, SerializerContext ctx) throws SerializeException {
		try {
			StringWriter w = new StringWriter();
			serialize(o, w, ctx);
			return w.toString();
		} catch (IOException e) { // Shouldn't happen.
			throw new RuntimeException(e);
		}
	}

	/**
	 * Same as {@link #serialize(Object, SerializerContext)} with <jk>null</jk> context.
	 *
	 * @param o The object to serialize.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o) throws SerializeException {
		SerializerContext ctx = createContext(o, null, null, null);
		return serialize(o, ctx);
	}

	/**
	 * Convenience method for serializing directly to a writer.
	 *
	 * @param o The object to serialize.
	 * @param w The writer to send the output to.
	 * @throws IOException If a problem occurred trying to send output to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serialize(Object o, Writer w) throws SerializeException, IOException {
		SerializerContext ctx = createContext(o, null, null, null);
		serialize(o, w, ctx);
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Serializer
	public SerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) throws SerializeException {
		return super.createContext(o, properties, mediaType, charset);
	}

	@Override // CoreApi
	public WriterSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public WriterSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> WriterSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // Lockable
	public WriterSerializer lock() {
		super.lock();
		return this;
	}

	@Override // CoreApi
	public WriterSerializer clone() throws CloneNotSupportedException {
		WriterSerializer c = (WriterSerializer)super.clone();
		return c;
	}
}
