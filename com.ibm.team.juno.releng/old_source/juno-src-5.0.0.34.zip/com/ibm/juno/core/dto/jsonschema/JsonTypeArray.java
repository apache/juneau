package com.ibm.juno.core.dto.jsonschema;

import java.util.*;

/**
 * Represents a list of {@link JsonType} objects.
 * <p>
 * 	Refer to {@link com.ibm.juno.core.dto.jsonschema} for usage information.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonTypeArray extends LinkedList<JsonType> {

	/**
	 * Default constructor.
	 */
	public JsonTypeArray() {}

	/**
	 * Constructor with predefined types to add to this list.
	 */
	public JsonTypeArray(JsonType...types) {
		addAll(types);
	}

	/**
	 * Convenience method for adding one or more {@link JsonType} objects to
	 * 	this array.
	 * @param types The {@link JsonType} objects to add to this array.
	 * @return This object (for method chaining).
	 */
	public JsonTypeArray addAll(JsonType...types) {
		for (JsonType t : types)
			add(t);
		return this;
	}
}
