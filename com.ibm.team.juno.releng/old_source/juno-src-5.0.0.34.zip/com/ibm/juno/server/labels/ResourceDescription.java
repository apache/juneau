package com.ibm.juno.server.labels;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

/**
 * Shortcut label for child resources.  Typically used in router resources.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Instead of this...</jc>
 * 	<jk>new</jk> NameDescription(<jk>new</jk> Link(<js>"httpTool"</js>, uri + <js>"/httpTool"</js>), <js>"HTTP request test client"</js>);
 *
 * 	<jc>// ...use this simpler equivalent...</jc>
 * 	<jk>new</jk> ResourceLink(uri, <js>"httpTool"</js>, <js>"HTTP request test client"</js>);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ResourceDescription extends NameDescription {

	/**
	 * Constructor.
	 *
	 * @param rootUrl The root URI of the child resource (e.g. the URI of the parent resource).
	 * 		Must not end with <js>'/'</js>.
	 * @param name The name of the child resource.
	 * @param description The description of the child resource.
	 */
	public ResourceDescription(String rootUrl, String name, String description) {
		super(new Link(name, rootUrl + "/" + name), description);
	}

	/**
	 * Constructor.
	 *
	 * @param name The name of the child resource.
	 * @param description The description of the child resource.
	 */
	public ResourceDescription(String name, String description) {
		super(new Link(name, name), description);
	}

	/** No-arg constructor.  Used for JUnit testing of OPTIONS pages. */
	public ResourceDescription() {}

	@Override
	public Link getName() {
		return (Link)super.getName();
	}

	/**
	 * Overridden setter.
	 * @param name The new name.
	 */
	public void setName(Link name) {
		super.setName(name);
	}
}
