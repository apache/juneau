package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Top-level interface for all character-based parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	In addition to methods defined in {@link IParser}, this method defines two additional
 * 	convenience methods for parsing directly from <code>Strings</code>.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface IReaderParser extends IParser {

	/**
	 * Parses the content of the reader and creates an object of the specified type.
	 * <p>
	 * 	The {@link ClassType} class is similar to {@link Class}, except includes generics information
	 * 	so that classes such as <code>HashMap&lt;String,Number&gt;</code> can be represented.
	 * 	<code>ClassType</code> instances are bound to {@link BeanContext} objects, and are instantiated
	 * 	through one of the methods on that class, such as {@link BeanContext#getClassType(Class)}.
	 * <p>
	 * 	The media type is going to be one of the strings returned by the {@link #getMediaTypes()} method,
	 * 	but can be <jk>null</jk>.
	 * 	This parameter is provided so that subclasses can handle different media types differently.
	 *
	 * @param in The input stream or reader containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassType#OBJECT}, object type is based on what's being parsed.
	 * 	For example, when parsing JSON text, it may return a <code>String</code>, <code>Number</code>, <code>ObjectMap</code>, etc...
	 * @param properties Optional run-time properties.  Can be <jk>null</jk>.
	 * @param mediaType The media type being parsed.  Can be <jk>null</jk>.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T parse(Reader in, ClassType<T> type, ObjectMap properties, String mediaType) throws ParseException, IOException;

	/**
	 * Shortcut method for parsing based on {@link Class} instead of {@link ClassType}.
	 * <p>
	 * 	Note that the {@link Parser} class provides a default implementation for this method.
	 *
	 * @param in The reader containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or <code>Object.<jk>class</jk></code>, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T parse(Reader in, Class<T> type) throws ParseException, IOException;

	/**
	 * Same as {@link #parse(CharSequence, ClassType, String)}, except parses from a <code>String</code>.
	 *
	 * @param in The string containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassType#OBJECT}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @param mediaType The media type being parsed.  Can be <jk>null</jk>.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 */
	public <T> T parse(CharSequence in, ClassType<T> type, String mediaType) throws ParseException;


	/**
	 * Same as {@link #parse(CharSequence, Class)}, except parses from a <code>String</code>.
	 *
	 * @param in The string containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassType#OBJECT}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 */
	public <T> T parse(CharSequence in, Class<T> type) throws ParseException;
}
