package com.ibm.juno.core.parser;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.server.*;

/**
 * Represents a group of {@link Parser Parsers} that can be looked up by media type.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Provides the following features:
 * <ul>
 * 	<li>Finds parsers based on HTTP <code>Content-Type</code> header values.
 * 	<li>Sets common properties on all parsers in a single method call.
 * 	<li>Locks all parsers in a single method call.
 * 	<li>Clones existing groups and all parsers within the group in a single method call.
 * </ul>
 * <p>
 * 	In addition, parser groups can have inner parser groups to allow for hierarchies of
 * 		parsers.
 * 	For example, the {@link RestServlet} class allows parsers to be maintained at
 * 		both the class and method levels.  So you can do things like define global
 * 		parsers at the class level, but augment it with specialized parsers at
 * 		the method level.
 *
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Construct a new parser group</jc>
 * 	ParserGroup g = <jk>new</jk> ParserGroup();
 *
 * 	<jc>// Add some parsers to it</jc>
 * 	g.append(JsonParser.<jk>class</jk>, XmlParser.<jk>class</jk>);
 *
 * 	<jc>// Change settings on parsers simultaneously</jc>
 * 	g.setProperty(<jsf>REQUIRE_SERIALIZABLE</jsf>, <jk>true</jk>)
 * 		.addFilters(CalendarFilter.ISO8601DT.<jk>class</jk>)
 * 		.lock();
 *
 * 	<jc>// Find the appropriate parser by Content-Type</jc>
 * 	IParser p = g.getParser(<js>"text/json"</js>);
 *
 * 	<jc>// Parse a bean from JSON</jc>
 * 	String json = <js>"{...}"</js>;
 * 	AddressBook addressBook = p.parse(json, AddressBook.<jk>class</jk>);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserGroup extends Lockable {

	private Map<String,IParser> parserMap = new LinkedHashMap<String,IParser>();
	private List<IParser> parsers = new ArrayList<IParser>();
	private List<ICoreApiParser> coreApiParsers = new ArrayList<ICoreApiParser>();
	List<MediaRange[]> parserMediaRanges = new ArrayList<MediaRange[]>();
	private ParserGroup parentGroup;


	/**
	 * Sets the parent group for this group.
	 * <p>
	 * 	Calling {@link #getParser(String)} will search this group first, then
	 * 	recursively search the parent groups until it finds a match.
	 *
	 * @param parentGroup The parent group.  Can be <jk>null</jk>.
	 * @return This object (for method chaining).
	 */
	public ParserGroup setParent(ParserGroup parentGroup) {
		this.parentGroup = parentGroup;
		return this;
	}

	/**
	 * Searches the group for a parser that can handle the specified media type.
	 *
	 * @param mediaType The accept string.
	 * @return The media type registered by one of the parsers that matches the <code>mediaType</code> string,
	 * 	or <jk>null</jk> if no media types matched.
	 */
	public String findMatch(String mediaType) {
		MediaRange[] mr = MediaRange.parse(mediaType);
		if (mr.length == 0)
			mr = MediaRange.parse("*/*");

		for (MediaRange a : mr)
			for (int i = 0; i < parsers.size(); i++) {
				for (MediaRange a2 : parserMediaRanges.get(i))
					if (a.matches(a2))
						return a2.getMediaType();
			}

		if (parentGroup != null)
			return parentGroup.findMatch(mediaType);

		return null;
	}

	/**
	 * Returns the parser registered to handle the specified media type.
	 * <p>
	 * The media-type string must not contain any parameters such as <js>";charset=X"</js>.
	 *
	 * @param mediaType The media-type string (e.g. <js>"text/json"</js>).
	 * @return The REST parser that handles the specified request content type, or <jk>null</jk> if
	 * 		no parser is registered to handle it.
	 */
	public IParser getParser(String mediaType) {
		IParser p = parserMap.get(mediaType);
		if (p == null && parentGroup != null)
			p = parentGroup.getParser(mediaType);
		return p;
	}

	/**
	 * Registers the specified REST parsers with this parser group.
	 *
	 * @param p The parsers to append to this group.
	 * @return This object (for method chaining).
	 */
	public ParserGroup append(IParser...p) {
		for (IParser pp : p) {
			this.parsers.add(pp);
			if (pp instanceof ICoreApiParser)
				this.coreApiParsers.add((ICoreApiParser)pp);

			String[] mediaTypes = pp.getMediaTypes();
			List<MediaRange> l = new LinkedList<MediaRange>();
			for (int i = 0; i < mediaTypes.length; i++)
				l.addAll(Arrays.asList(MediaRange.parse(mediaTypes[i])));
			this.parserMediaRanges.add(l.toArray(new MediaRange[l.size()]));

			for (String mt : mediaTypes)
				parserMap.put(mt.toLowerCase(Locale.ENGLISH), pp);
		}
		return this;
	}

	/**
	 * Same as {@link #append(IParser[])}, except specify classes instead of class instances
	 * 	 of {@link Parser}.
	 * <p>
	 * Note that this can only be used on {@link Parser Parsers} with no-arg constructors.
	 *
	 * @param p The parsers to append to this group.
	 * @return This object (for method chaining).
	 * @throws Exception Thrown if {@link Parser} could not be constructed.
	 */
	public ParserGroup append(Class<? extends IParser>...p) throws Exception {
		for (Class<? extends IParser> c : p)
			append(c.newInstance());
		return this;
	}

	/**
	 * Returns the media types that all parsers in this group (and parent groups)
	 * 	can handle.
	 * Entries are ordered by the order in which the parsers were added to the group,
	 * 	followed by entries in the parent group.
	 *
	 * @return The list of media types.
	 */
	public Set<String> getSupportedMediaTypes() {
		Set<String> s = new LinkedHashSet<String>();
		s.addAll(parserMap.keySet());
		if (parentGroup != null)
			s.addAll(parentGroup.getSupportedMediaTypes());
		return s;
	}


	//--------------------------------------------------------------------------------
	// Convenience methods for setting properties on all parsers.
	//--------------------------------------------------------------------------------

	/**
	 * Shortcut for calling {@link Parser#setProperty(String, Object)} on all parsers in this group.
	 *
	 * @param property The property name.
	 * @param value The property value.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup setProperty(String property, Object value) throws LockedException {
		checkLock();
		for (IParser p : parsers)
			p.setProperty(property, value);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#setProperties(ObjectMap)} on all parsers in this group.
	 *
	 * @param properties The properties to set.  Ignored if <jk>null</jk>.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup setProperties(ObjectMap properties) {
		if (properties != null) {
			checkLock();
			for (Map.Entry<String,Object> e : properties.entrySet())
				setProperty(e.getKey(), e.getValue());
		}
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#addNotBeanClassPatterns(String[])} on all {@link ICoreApiParser} parsers in this group.
	 *
	 * @param patterns The new class patterns to add to the underlying bean context of all parsers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup addNotBeanClassPatterns(String... patterns) throws LockedException {
		for (ICoreApiParser p : coreApiParsers)
			p.addNotBeanClassPatterns(patterns);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#addNotBeanClasses(Class[])} on all {@link ICoreApiParser} parsers in this group.
	 *
	 * @param classes The classes to specify as not-beans to the underlying bean context of all parsers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup addNotBeanClasses(Class<?>...classes) throws LockedException {
		for (ICoreApiParser p : coreApiParsers)
			p.addNotBeanClasses(classes);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#addFilters(Class[])} on all {@link ICoreApiParser} parsers in this group.
	 * @param classes The classes to add bean filters for to the underlying bean context of all parsers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup addFilters(Class<?>...classes) throws LockedException {
		for (ICoreApiParser p : coreApiParsers)
			p.addFilters(classes);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#addImplClass(Class, Class)} on all {@link ICoreApiParser} parsers in this group.
	 * @param <T> The interface or abstract class type.
	 * @param interfaceClass The interface or abstract class.
	 * @param implClass The implementation class.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public <T> ParserGroup addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		for (ICoreApiParser p : coreApiParsers)
			p.addImplClass(interfaceClass, implClass);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	/**
	 * Locks this group and all parsers in this group.
	 */
	@Override  // Lockable
	public ParserGroup lock() {
		super.lock();
		parserMap = Collections.unmodifiableMap(parserMap);
		parsers = Collections.unmodifiableList(parsers);
		for (IParser p : parsers)
			p.lock();
		return this;
	}

	/**
	 * Clones this group and all parsers in this group.
	 */
	@Override  // Lockable
	public ParserGroup clone() throws CloneNotSupportedException {
		ParserGroup c = (ParserGroup)super.clone();
		List<IParser> l = c.parsers;
		c.parsers.clear();
		c.parserMap.clear();
		for (IParser p : l)
			c.append(p.clone());
		return c;
	}
}
