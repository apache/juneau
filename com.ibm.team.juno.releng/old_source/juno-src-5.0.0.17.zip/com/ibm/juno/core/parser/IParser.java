package com.ibm.juno.core.parser;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Top-level interface for all parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This interface describes the methods that all parsers must implement.  It has the following two direct subclasses:
 * <ul>
 * 	<li>{@link IReaderParser} - Parsers that read from {@link Reader Readers}.
 * 	<li>{@link IInputStreamParser} - Parsers that read from {@link InputStream InputStreams}.
 * </ul>
 * <p>
 * 	Implementer will typically subclass directly from {@link ReaderParser} or {@link InputStreamParser} which
 * 	will already provide implementations for some of these methods.
 * <p>
 * 	Refer to the <a href='package-summary.html'>package javadocs</a> for an overall description of the parser API.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
  */
public interface IParser {

	/**
	 * Returns the list of media types that this parser can handle.
	 * <p>
	 * 	For example, a JSON parser will typically return <code>{<js>"application/json"</js>,<js>"text/json"</js>}</code> indicating
	 * 	it can parse those media types.
	 * <p>
	 * 	This information is used by the {@link ParserGroup#getParser(String)} method to find the appropriate
	 * 	parser by the media types it handles.
	 * <p>
	 * 	This method can also return media ranges (per RFC2616/14.1) such as <js>"text/*"</js> or <js>"*\/*"</js>.
	 * <p>
	 * 	This method must return at least one value.
	 *
	 * @return The list of media types the parser handles.  Never <jk>null</jk> or empty.
	 */
	public String[] getMediaTypes();

	/**
	 * Sets a configuration property on this parser.
	 * <p>
	 * 	It's up to parsers to define what properties are available.
	 *
	 * @param property The property name.
	 * @param value The property value.
	 * @return This object (for method chaining).
	 * @throws LockedException If {@link #lock()} has previously been called on this object.
	 */
	public IParser setProperty(String property, Object value) throws LockedException;

	/**
	 * Locks this parser so that the properties can no longer be changed.
	 * <p>
	 * 	Allows parser instances to be safely reused without the properties being changed.
	 *
	 * @return This object (for method chaining).
	 */
	public IParser lock();

	/**
	 * Clones this parser.
	 * <p>
	 * 	This method should return a new instance of a parser with identical configuration properties.
	 * <p>
	 * 	If cloning is not supported, this method should throw a {@link CloneNotSupportedException}.
	 *
	 * @return The cloned parser.
	 * @throws CloneNotSupportedException If this class does not support cloning.
	 */
	public IParser clone() throws CloneNotSupportedException;
}
