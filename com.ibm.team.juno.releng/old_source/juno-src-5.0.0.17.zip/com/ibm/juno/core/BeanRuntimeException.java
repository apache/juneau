package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static java.lang.String.*;

/**
 * General bean runtime operation exception.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class BeanRuntimeException extends RuntimeException {

	private Throwable cause;

	/**
	 * @param message The error message.
	 */
	protected BeanRuntimeException(String message) {
		super(message);
	}

	/**
	 * Shortcut for calling
	 * <code><jk>new</jk> BeanRuntimeException(String.format(c.getName() + <js>": "</js> + message, args));</code>
	 *
	 * @param c The class name of the bean that caused the exception.
	 * @param message The error message.
	 * @param args Arguments passed in to the {@code String.format()} method.
	 */
	public BeanRuntimeException(Class<?> c, String message, Object... args) {
		this(c.getName() + ": " + format(message, args));
	}

	/**
	 * @param cause The initial cause of the exception.
	 */
	public BeanRuntimeException(Throwable cause) {
		super(cause == null ? null : cause.getLocalizedMessage());
	}

	@Override
	public Throwable getCause() {
		return cause;
	}

	/**
	 * Sets the inner cause for this exception.
	 * @param cause The inner cause.
	 * @return This object (for method chaining).
	 */
	public BeanRuntimeException setCause(Throwable cause) {
		this.cause = cause;
		return this;
	}
}
