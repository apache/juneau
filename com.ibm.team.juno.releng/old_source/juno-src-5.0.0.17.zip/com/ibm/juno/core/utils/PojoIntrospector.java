package com.ibm.juno.core.utils;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.parser.*;

/**
 * Used to invoke public methods on {@code Objects} in a generalized way.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class PojoIntrospector {

	IExtendedParser parser = JsonParser.DEFAULT;

	/**
	 * Constructor.
	 * @param parser Used to convert arguments to the appropriate object type.
	 */
	public PojoIntrospector(IExtendedParser parser) {
		this.parser = parser;
	}

	/**
	 * Returns the list of public methods defined on this class.
	 * @param c The class.
	 * @param includeOnlyCallableMethods If <jk>true</jk>, then only returns methods with parameters
	 * 	that can be constructed using the parser associated with this class.
	 * @return The list of public methods that can be invoked on the specified class.
	 */
	public List<String> getPublicMethods(Class<?> c, boolean includeOnlyCallableMethods) {
		List<String> methods = new LinkedList<String>();
		for (Method m : c.getMethods()) {
			int modifiers = m.getModifiers();
			if (Modifier.isPublic(modifiers)) {
				StringBuilder sb = new StringBuilder(m.getName());
				Class<?>[] pt = m.getParameterTypes();
				if (pt.length > 0) {
					sb.append("(");
					for (int i = 0; i < pt.length; i++) {
						if (i > 0)
							sb.append(",");
						sb.append(pt[i].getName());
					}
					sb.append(")");
				}
				methods.add(sb.toString());
			}
		}
		return methods;
	}

	/**
	 * Invokes the specified method on this bean.
	 * @param target The object on which the method will be invoked.
	 * @param method The method signature.
	 * 	<p>
	 * 	Can be any of the following formats:
	 * 	</p>
	 * 	<ul>
	 * 		<li>Method name only.  e.g. <js>"myMethod"</js>.
	 * 		<li>Method name with class names.  e.g. <js>"myMethod(String,int)"</js>.
	 * 		<li>Method name with fully-qualified class names.  e.g. <js>"myMethod(java.util.String,int)"</js>.
	 * 	</ul>
	 * 	<p>
	 * 		As a rule, use the simplest format needed to uniquely resolve a method.
	 * 	</p>
	 * @param args The arguments to pass as parameters to the method.<br>
	 * 	These will automatically be converted to the appropriate object type if possible.<br>
	 * 	Primitives, {@code Collections}/{@code Maps}, beans, and arrays can be converted.
	 * @return The object returned by the call to the method.
	 * @throws IllegalAccessException If the <code>Constructor</code> object enforces Java language access control and the underlying constructor is inaccessible.
	 * @throws IllegalArgumentException If one of the following occurs:
	 * 	<ul>
	 * 		<li>The number of actual and formal parameters differ.
	 * 		<li>An unwrapping conversion for primitive arguments fails.
	 * 		<li>A parameter value cannot be converted to the corresponding formal parameter type by a method invocation conversion.
	 * 		<li>The constructor pertains to an enum type.
	 * 	</ul>
	 * @throws InvocationTargetException If the underlying constructor throws an exception.
	 * @throws ParseException If the input contains a syntax error or is malformed.
	 */
	public Object invokeMethod(Object target, String method, String args) throws InvocationTargetException, IllegalArgumentException, IllegalAccessException, ParseException {
		if (target == null)
			throw new IllegalArgumentException("target is null.");
		Method m = findPublicMethod(target.getClass(), method);
		if (m != null) {
			Object[] params = null;
			if (args == null || args.isEmpty())
				params = new Object[0];
			else {
				ClassType<?>[] argTypes = getClassTypes(m.getParameterTypes());
				if (argTypes.length == 0)
					params = new Object[0];
				try {
					params = parser.parseArgs(new StringReader(args), argTypes);
				} catch (IOException e) {
					// Won't ever happen with StringReader.
					e.printStackTrace();
				}
			}
			return m.invoke(target, params);
		}
		throw new InvocationTargetException(new Throwable(), "Could not find method ["+method+"] with ["+args+"] parameters on object of type ["+target.getClass().getName()+"]");
	}

	ClassType<?>[] getClassTypes(Class<?>[] args) {
		ClassType<?>[] ct = new ClassType<?>[args.length];
		for (int i = 0; i < args.length; i++)
			ct[i] = BeanContext.DEFAULT.getClassType(args[i]);
		return ct;
	}

	Method findPublicMethod(Class<?> c, String methodName) {

		if (! classMethodCache.containsKey(c))
			classMethodCache.put(c, new HashMap<String,Method>());

		Map<String,Method> methodCache = classMethodCache.get(c);
		if (! methodCache.containsKey(methodName)) {
			List<Method> matchingMethods = new LinkedList<Method>();
			int x = methodName.indexOf('(');
			String[] params = null;
			if (x != -1) {
				params = methodName.substring(x+1, methodName.indexOf(')', x+1)).trim().split("\\s*,\\s*");
				methodName = methodName.substring(0, x).trim();
			} else {
				methodName = methodName.trim();
			}
			for (Method method : c.getMethods()) {
				int mod = method.getModifiers();
				if (method.getName().equalsIgnoreCase(methodName) && Modifier.isPublic(mod)) {
					boolean isValid = true;
					Class<?>[] pTypes = method.getParameterTypes();
					if (params != null) {
						if (params.length != pTypes.length) {
							isValid = false;
						} else {
							for (int i = 0; i < params.length && isValid; i++) {
								String pn1 = params[i];
								String pn2 = (pTypes[i].isArray() ? pTypes[i].getComponentType().getName() + "[]" : pTypes[i].getName());
								if (pn2.indexOf('.') == -1) {
									if (! pn2.equals(pn1))
										isValid = false;
								} else {
									if (! pn2.endsWith(pn1))
										isValid = false;
								}
							}
						}
					}
					if (params == null && pTypes.length == 0) {
						// Found an exact no-arg match.
						matchingMethods.clear();
						matchingMethods.add(method);
						break;
					}
					if (isValid)
						matchingMethods.add(method);
				}
			}
			if (matchingMethods.size() == 0)
				throw new RuntimeException("Method '"+methodName+"' not found on class '"+c.getName()+"'");
			else if (matchingMethods.size() > 1)
				throw new RuntimeException("Multiple methods matches for '"+methodName+"' on class '"+c.getName()+"'.  Must specify form using parameter types. ");
			methodCache.put(methodName, matchingMethods.get(0));
		}
		return methodCache.get(methodName);
	}

	private Map<Class<?>,Map<String,Method>> classMethodCache = new HashMap<Class<?>,Map<String,Method>>();
}
