package com.ibm.juno.core.ini;

/**
 * API for defining a string encoding/decoding mechanism for entries in {@link ConfigFile}.
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface Encoder {

	/**
	 * Encode a string.
	 * @param in The unencoded input string.
	 * @return The encoded output string.
	 */
	public String encode(String in);

	/**
	 * Decode a string.
	 * @param in The encoded input string.
	 * @return The decoded output string.
	 */
	public String decode(String in);
}
