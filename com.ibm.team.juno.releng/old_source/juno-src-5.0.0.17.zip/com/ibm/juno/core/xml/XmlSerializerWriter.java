package com.ibm.juno.core.xml;

import java.io.*;

import com.ibm.juno.core.serializer.*;

/**
 * Specialized writer for serializing XML.
 * <p>
 * 	<b>Note:  This class is not intended for external use.</b>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlSerializerWriter extends SerializerWriter {

	/**
	 * Constructor.
	 * @param out The wrapped writer.
	 * @param useIndentation If <jk>true</jk> XML elements will be indented.
	 * @param quoteChar The quote character to use for attributes.  Should be <js>'\''</js> or <js>'"'</js>.
	 * @param uriContext The web application context path (e.g. "/contextRoot").
	 * @param uriAuthority The web application URI authority (e.g. "http://hostname:9080")
	 */
	public XmlSerializerWriter(Writer out, boolean useIndentation, char quoteChar, String uriContext, String uriAuthority) {
		super(out, useIndentation, true, quoteChar, uriContext, uriAuthority);
	}

	/**
	 * Writes an opening tag to the output:  <code><xt>&lt;ns:name</xt></code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @param needsEncoding If <jk>true</jk>, element name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter oTag(String ns, String name, boolean needsEncoding) throws IOException {
		append('<').appendIf(ns != null, ns).appendIf(ns != null, ':');
		if (needsEncoding)
			encodeElement(name);
		else
			append(name);
		return this;
	}

	/**
	 * Shortcut for <code>oTag(ns, name, <jk>false</jk>);</code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter oTag(String ns, String name) throws IOException {
		return oTag(ns, name, false);
	}

	/**
	 * Shortcut for <code>oTag(<jk>null</jk>, name, <jk>false</jk>);</code>
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter oTag(String name) throws IOException {
		return oTag(null, name, false);
	}

	/**
	 * Shortcut for <code>i(indent).oTag(ns, name, needsEncoding);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @param needsEncoding If <jk>true</jk>, element name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter oTag(int indent, String ns, String name, boolean needsEncoding) throws IOException {
		return i(indent).oTag(ns, name, needsEncoding);
	}

	/**
	 * Shortcut for <code>i(indent).oTag(ns, name, <jk>false</jk>);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter oTag(int indent, String ns, String name) throws IOException {
		return i(indent).oTag(ns, name, false);
	}

	/**
	 * Shortcut for <code>i(indent).oTag(<jk>null</jk>, name, <jk>false</jk>);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter oTag(int indent, String name) throws IOException {
		return i(indent).oTag(null, name, false);
	}

	/**
	 * Writes a closed tag to the output:  <code><xt>&lt;ns:name/&gt;</xt></code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @param needsEncoding If <jk>true</jk>, element name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter tag(String ns, String name, boolean needsEncoding) throws IOException {
		append('<').appendIf(ns != null, ns).appendIf(ns != null, ':');
		if (needsEncoding)
			encodeElement(name);
		else
			append(name);
		return append('/').append('>');
	}

	/**
	 * Shortcut for <code>tag(ns, name, <jk>false</jk>);</code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter tag(String ns, String name) throws IOException {
		return tag(ns, name, false);
	}

	/**
	 * Shortcut for <code>tag(<jk>null</jk>, name, <jk>false</jk>);</code>
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter tag(String name) throws IOException {
		return tag(null, name, false);
	}

	/**
	 * Shortcut for <code>i(indent).tag(<jk>null</jk>, name, <jk>false</jk>);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter tag(int indent, String name) throws IOException {
		return i(indent).tag(name);
	}

	/**
	 * Shortcut for <code>i(indent).tag(ns, name, needsEncoding);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @param needsEncoding If <jk>true</jk>, element name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter tag(int indent, String ns, String name, boolean needsEncoding) throws IOException {
		return i(indent).tag(ns, name, needsEncoding);
	}

	/**
	 * Shortcut for <code>i(indent).tag(ns, name, <jk>false</jk>);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter tag(int indent, String ns, String name) throws IOException {
		return i(indent).tag(ns, name);
	}


	/**
	 * Writes a start tag to the output:  <code><xt>&lt;ns:name&gt;</xt></code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @param needsEncoding If <jk>true</jk>, element name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter sTag(String ns, String name, boolean needsEncoding) throws IOException {
		return oTag(ns, name, needsEncoding).append('>');
	}

	/**
	 * Shortcut for <code>sTag(ns, name, <jk>false</jk>);</code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter sTag(String ns, String name) throws IOException {
		return sTag(ns, name, false);
	}

	/**
	 * Shortcut for <code>sTag(<jk>null</jk>, name, <jk>false</jk>);</code>
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter sTag(String name) throws IOException {
		return sTag(null, name);
	}

	/**
	 * Shortcut for <code>i(indent).sTag(ns, name, needsEncoding);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @param needsEncoding If <jk>true</jk>, element name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter sTag(int indent, String ns, String name, boolean needsEncoding) throws IOException {
		return i(indent).sTag(ns, name, needsEncoding);
	}

	/**
	 * Shortcut for <code>i(indent).sTag(ns, name, <jk>false</jk>);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter sTag(int indent, String ns, String name) throws IOException {
		return i(indent).sTag(ns, name, false);
	}

	/**
	 * Shortcut for <code>i(indent).sTag(<jk>null</jk>, name, <jk>false</jk>);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter sTag(int indent, String name) throws IOException {
		return i(indent).sTag(null, name, false);
	}


	/**
	 * Writes an end tag to the output:  <code><xt>&lt;/ns:name&gt;</xt></code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @param needsEncoding If <jk>true</jk>, element name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter eTag(String ns, String name, boolean needsEncoding) throws IOException {
		append('<').append('/').appendIf(ns != null, ns).appendIf(ns != null, ':');
		if (needsEncoding)
			encodeElement(name);
		else
			append(name);
		return append('>');
	}

	/**
	 * Shortcut for <code>eTag(ns, name, <jk>false</jk>);</code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter eTag(String ns, String name) throws IOException {
		return eTag(ns, name, false);
	}

	/**
	 * Shortcut for <code>eTag(<jk>null</jk>, name, <jk>false</jk>);</code>
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter eTag(String name) throws IOException {
		return eTag(null, name);
	}

	/**
	 * Shortcut for <code>i(indent).eTag(ns, name, needsEncoding);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @param needsEncoding If <jk>true</jk>, element name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter eTag(int indent, String ns, String name, boolean needsEncoding) throws IOException {
		return i(indent).eTag(ns, name, needsEncoding);
	}

	/**
	 * Shortcut for <code>i(indent).eTag(ns, name, <jk>false</jk>);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter eTag(int indent, String ns, String name) throws IOException {
		return i(indent).eTag(ns, name, false);
	}

	/**
	 * Shortcut for <code>i(indent).eTag(<jk>null</jk>, name, <jk>false</jk>);</code>
	 * @param indent The number of prefix tabs to add.
	 * @param name The element name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter eTag(int indent, String name) throws IOException {
		return i(indent).eTag(name);
	}

	/**
	 * Writes an attribute to the output:  <code><xa>ns:name</xa>=<xs>'value'</xs></code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The attribute name.
	 * @param value The attribute value.
	 * @param needsEncoding If <jk>true</jk>, attribute name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter attr(String ns, String name, Object value, boolean needsEncoding) throws IOException {
		oAttr(ns, name).q();
		if (needsEncoding)
			encodeAttr(value);
		else
			append(value);
		return q();
	}

	/**
	 * Shortcut for <code>attr(<jk>null</jk>, name, value, <jk>false</jk>);</code>
	 * @param name The attribute name.
	 * @param value The attribute value.
	 * @param needsEncoding If <jk>true</jk>, attribute name will be encoded.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter attr(String name, Object value, boolean needsEncoding) throws IOException {
		return attr(null, name, value, needsEncoding);
	}

	/**
	 * Shortcut for <code>attr(ns, name, value, <jk>false</jk>);</code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The attribute name.
	 * @param value The attribute value.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter attr(String ns, String name, Object value) throws IOException {
		return oAttr(ns, name).q().append(value).q();
	}

	/**
	 * Same as {@link #attr(String, Object, boolean)}, except pass in a {@link Namespace} object for the namespace.
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The attribute name.
	 * @param value The attribute value.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter attr(Namespace ns, String name, Object value) throws IOException {
		return oAttr(ns == null ? null : ns.name, name).q().append(value).q();
	}

	/**
	 * Shortcut for <code>attr(<jk>null</jk>, name, value, <jk>false</jk>);</code>
	 * @param name The attribute name.
	 * @param value The attribute value.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter attr(String name, Object value) throws IOException {
		return attr((String)null, name, value);
	}


	/**
	 * Writes an open-ended attribute to the output:  <code><xa>ns:name</xa>=</code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The attribute name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter oAttr(String ns, String name) throws IOException {
		return append(' ').appendIf(ns != null, ns).appendIf(ns != null, ':').append(name).append('=');
	}

	/**
	 * Writes an open-ended attribute to the output:  <code><xa>ns:name</xa>=</code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The attribute name.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter oAttr(Namespace ns, String name) throws IOException {
		return oAttr(ns == null ? null : ns.name, name);
	}

	/**
	 * Writes an attribute with a URI value to the output:  <code><xa>ns:name</xa>=<xs>'uri-value'</xs></code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The attribute name.
	 * @param value The attribute value, convertable to a URI via <code>toString()</code>
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter attrUri(Namespace ns, String name, Object value) throws IOException {
		oAttr(ns, name).q().appendUri(value).q();
		return this;
	}

	/**
	 * Writes an attribute with a URI value to the output:  <code><xa>ns:name</xa>=<xs>'uri-value'</xs></code>
	 * @param ns The namespace.  Can be <jk>null</jk>.
	 * @param name The attribute name.
	 * @param value The attribute value, convertable to a URI via <code>toString()</code>
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter attrUri(String ns, String name, Object value) throws IOException {
		oAttr(ns, name).q().appendUri(value).q();
		return this;
	}

	/**
	 * Serializes and encodes the specified object as valid XML text.
	 * @param o The object being serialized.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter encodeText(Object o) throws IOException {

		if (o == null)
			return append("null");

		String s = o.toString();

		if (needsXmlEncoding(o)) {
			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (c == '&')
					out.append("&amp;");
				else if (c == '<')
					out.append("&lt;");
				else if (c == '>')
					out.append("&gt;");
				else if (c == '_' && isEscapeSequence(s,i))
					appendPaddedHexChar(this, c);
				else if (isValidXmlCharacter(c))
					out.append(c);
				else
					appendPaddedHexChar(this, c);
			}
		} else {
			out.append(s);
		}
		return this;

	}

	/**
	 * Serializes and encodes the specified object as valid XML attribute name.
	 * @param o The object being serialized.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter encodeAttr(Object o) throws IOException {

		if (o == null)
			return append("null");

		String s = o.toString();

		if (needsAttributeEncoding(o)) {
			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (c == '&')
					out.append("&amp;");
				else if (c == '<')
					out.append("&lt;");
				else if (c == '>')
					out.append("&gt;");
				else if (c == '\'')
					out.append("&apos;");
				else if (c == '"')
					out.append("&quot;");
				else if (c == '_' && isEscapeSequence(s,i))
					appendPaddedHexChar(this, c);
				else if (isValidXmlCharacter(c))
					out.append(c);
				else
					appendPaddedHexChar(this, c);
			}
		} else {
			out.append(s);
		}

		return this;
	}

	/**
	 * Serializes and encodes the specified object as valid XML element name.
	 * @param o The object being serialized.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred.
	 */
	public XmlSerializerWriter encodeElement(Object o) throws IOException {

		if (o == null)
			return append("null");

		String s = o.toString();

		if (! needsNameEncoding(s)) {
			out.append(s);
			return this;
		}

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if ((c >= 'A' && c <= 'Z')
					|| (c == '_' && ! isEscapeSequence(s,i))
					|| (c >= 'a' && c <= 'z')
					|| (i != 0 && (
							c == '-'
							|| c == '.'
							|| (c >= '0' && c <= '9')
							|| c == '\u00b7'
							|| (c >= '\u0300' && c <= '\u036f')
							|| (c >= '\u203f' && c <= '\u2040')
						))
					|| (c >= '\u00c0' && c <= '\u00d6')
					|| (c >= '\u00d8' && c <= '\u00f6')
					|| (c >= '\u00f8' && c <= '\u02ff')
					|| (c >= '\u0370' && c <= '\u037d')
					|| (c >= '\u037f' && c <= '\u1fff')
					|| (c >= '\u200c' && c <= '\u200d')
					|| (c >= '\u2070' && c <= '\u218f')
					|| (c >= '\u2c00' && c <= '\u2fef')
					|| (c >= '\u3001' && c <= '\ud7ff')
					|| (c >= '\uf900' && c <= '\ufdcf')
					|| (c >= '\ufdf0' && c <= '\ufffd')) {
				out.append(c);
			}  else {
				appendPaddedHexChar(out, c);
			}
		}

		return this;
	}

	private static final boolean isAlphaNum(char c) {
		return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z');
	}

	/**
	 * Utility method for encoding an element name.
	 * @param s The element name.
	 * @return The encoded element name, or <js>"null"</js> if the element name is <jk>null</jk>
	 */
	public static String encodeElementName(String s) {
		if (s == null)
			return "null";

		if (! needsNameEncoding(s))
			return s;

		StringWriter out = new StringWriter(s.length() * 2);

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if ((c >= 'A' && c <= 'Z')
					|| (c == '_' && ! isEscapeSequence(s,i))
					|| (c >= 'a' && c <= 'z')
					|| (i != 0 && (
							c == '-'
							|| c == '.'
							|| (c >= '0' && c <= '9')
							|| c == '\u00b7'
							|| (c >= '\u0300' && c <= '\u036f')
							|| (c >= '\u203f' && c <= '\u2040')
						))
					|| (c >= '\u00c0' && c <= '\u00d6')
					|| (c >= '\u00d8' && c <= '\u00f6')
					|| (c >= '\u00f8' && c <= '\u02ff')
					|| (c >= '\u0370' && c <= '\u037d')
					|| (c >= '\u037f' && c <= '\u1fff')
					|| (c >= '\u200c' && c <= '\u200d')
					|| (c >= '\u2070' && c <= '\u218f')
					|| (c >= '\u2c00' && c <= '\u2fef')
					|| (c >= '\u3001' && c <= '\ud7ff')
					|| (c >= '\uf900' && c <= '\ufdcf')
					|| (c >= '\ufdf0' && c <= '\ufffd')) {
				out.append(c);
			}  else {
				try {
					appendPaddedHexChar(out, c);
				} catch (IOException e) {
					// Will never happend with StringWriter.
					throw new RuntimeException(e);
				}
			}
		}

		return out.toString();
	}

	private static boolean needsNameEncoding(String s) {
		if (s == null)
			return false;

		// Note that this doesn't need to be perfect, just fast.
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (! (c >= '0' && c <= '9' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z'))
				return true;
			if (i == 0 && (c >= '0' && c <= '9'))
				return true;
		}
		return false;
	}

	private static boolean isValidXmlCharacter(char c) {
		return (c >= 0x20 && c <= 0xD7FF) /*|| c == 0xA || c == 0xD*/ || (c >= 0xE000 && c <= 0xFFFD) || (c >= 0x10000 && c <= 0x10FFFF);
	}

	private boolean needsXmlEncoding(Object o) {
		if (o == null)
			return false;

		String s = o.toString();

		// See if we need to convert the string.
		// Conversion is somewhat expensive, so make sure we need to do so before hand.
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '&' || c == '<' || c == '>' || c == '\n' || ! isValidXmlCharacter(c) || (c == '_' && isEscapeSequence(s,i)))
				return true;
		}
		return false;
	}

	static final boolean isEscapeSequence(String s, int i) {
		return s.length() > i+6
			&& s.charAt(i) == '_'
			&& s.charAt(i+1) == 'x'
			&& isAlphaNum(s.charAt(i+2))
			&& isAlphaNum(s.charAt(i+3))
			&& isAlphaNum(s.charAt(i+4))
			&& isAlphaNum(s.charAt(i+5))
			&& s.charAt(i+6) == '_';
	}

	private boolean needsAttributeEncoding(Object o) {
		if (o == null)
			return false;

		String s = o.toString();

		// See if we need to convert the string.
		// Conversion is somewhat expensive, so make sure we need to do so before hand.
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '&' || c == '<' || c == '>' || c == '\n' || c == '\'' || c == '"' || ! isValidXmlCharacter(c))
				return true;
		}
		return false;
	}

	/*
	 * Converts an integer to a hexadecimal string padded to 4 places.
	 */
	private static Writer appendPaddedHexChar(Writer out, int num) throws IOException {
		out.append("_x");
		char[] n = new char[4];
		int a = num%16;
		n[3] = (char)(a > 9 ? 'A'+a-10 : '0'+a);
		int base = 16;
		for (int i = 1; i < 4; i++) {
			a = (num/base)%16;
			base <<= 4;
			n[3-i] = (char)(a > 9 ? 'A'+a-10 : '0'+a);
		}
		for (int i = 0; i < 4; i++)
			out.append(n[i]);
		return out.append('_');
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // SerializerWriter
	public XmlSerializerWriter cr(int depth) throws IOException {
		super.cr(depth);
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter appendln(int indent, String text) throws IOException {
		super.appendln(indent, text);
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter appendln(String text) throws IOException {
		super.appendln(text);
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter append(int indent, String text) throws IOException {
		super.append(indent, text);
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter append(int indent, char c) throws IOException {
		super.append(indent, c);
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter s() throws IOException {
		super.s();
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter q() throws IOException {
		super.q();
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter i(int indent) throws IOException {
		super.i(indent);
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter nl() throws IOException {
		super.nl();
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter append(Object text) throws IOException {
		super.append(text);
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter append(String text) throws IOException {
		super.append(text);
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter appendIf(boolean b, String text) throws IOException {
		super.appendIf(b, text);
		return this;
	}

	@Override // SerializerWriter
	public XmlSerializerWriter appendIf(boolean b, char c) throws IOException {
		super.appendIf(b, c);
		return this;
	}

	@Override // SerializerWriter
	public final XmlSerializerWriter append(char c) throws IOException {
		out.write(c);
		return this;
	}

	@Override // Object
	public String toString() {
		return out.toString();
	}
}
