package com.ibm.juno.core.json;

import com.ibm.juno.core.*;

/**
 * Configurable properties on the {@link JsonSerializer} class.
 * <p>
 * 	Use the {@link JsonSerializer#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link JsonSerializer}.
 * <ul>
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonSerializerProperties {

	/**
	 * Strict JSON mode ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, JSON attribute names will always be quoted.
	 * Otherwise, they'll only be quoted when necessary.
	 */
	public static final String STRICT_MODE = "JsonSerializer.strictMode";

	/**
	 * Use whitespace in output ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, whitespace is added to the output to improve readability.
	 */
	public static final String USE_WHITESPACE = "JsonSerializer.useWhitespace";

	private boolean
		strictMode = false,
		useWhitespace = true,
		addBeanUris = true;

	/** Default constructor.  All default values. */
	public JsonSerializerProperties() {}

	/**
	 * Copy constructor.
	 * @param copyFrom Properties to copy from.
	 */
	public JsonSerializerProperties(JsonSerializerProperties copyFrom) {
		this.strictMode = copyFrom.strictMode;
		this.useWhitespace = copyFrom.useWhitespace;
		this.addBeanUris = copyFrom.addBeanUris;
	}

	/**
	 * Returns the current {@link #STRICT_MODE} value.
	 * @return The current {@link #STRICT_MODE} value.
	 */
	public final boolean isStrictMode() {
		return strictMode;
	}

	/**
	 * Returns the current {@link #USE_WHITESPACE} value.
	 * @return The current {@link #USE_WHITESPACE} value.
	 */
	public final boolean isUseWhitespace() {
		return useWhitespace;
	}

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		BeanContext bc = BeanContext.DEFAULT;
		if (property.equals(STRICT_MODE))
			strictMode = bc.convertToType(value, Boolean.class);
		else if (property.equals(USE_WHITESPACE))
			useWhitespace = bc.convertToType(value, Boolean.class);
		else
			return false;
		return true;
	}
}
