package com.ibm.juno.core;

import com.ibm.juno.core.annotation.*;

/**
 * Represents a no-op object filter.
 * <p>
 * Used as the default value for the {@link BeanProperty#filter()} annotation to
 * 	represent a <jk>null</jk>.
 */
public class NullObjectFilter extends ObjectFilter<Object,Object> {}
