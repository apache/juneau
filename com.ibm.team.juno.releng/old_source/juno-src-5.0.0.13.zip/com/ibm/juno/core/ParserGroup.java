package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;

/**
 * Represents a group of {@link Parser Parsers}.
 * <p>
 * 	This class servers the following purposes:
 * <ul>
 * 	<li>Associate a single {@link BeanContext} with multiple parsers to reduce {@link ClassType} caching and
 * 			make it easier to modify bean context settings with multiple simultaneous parsers.
 * 	<li>Associate parsers with content type strings.
 * </ul>
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Construct a new parser group</jc>
 * 	ParserGroup g = <jk>new</jk> ParserGroup();
 *
 * 	<jc>// Add some parserMappings to it</jc>
 * 	g.add(<jk>new</jk> JsonParser(), "text/json", "application/json")
 * 	 .add(<jk>new</jk> XmlParser(), "text/xml");
 *
 * 	<jc>// Change settings on the parserMappings simultaneously</jc>
 * 	g.getBeanContext()
 * 		.setProperty(<jsf>REQUIRE_SERIALIZABLE</jsf>, <jk>true</jk>)
 * 		.addFilters(CalendarFilter.<jsf>DEFAULT_ISO8601DT</jsf>)
 * 		.lock();
 *
 * 	<jc>// Parse a bean from JSON</jc>
 * 	String json = <js>"{...}"</js>;
 * 	AddressBook addressBook = g.getParser(<js>"text/json"</js>).parse(json, AddressBook.<jk>class</jk>);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserGroup extends Lockable {

	private Map<String,Parser> parserMappings = new LinkedHashMap<String,Parser>();
	private Map<Parser,String[]> parsers = new HashMap<Parser,String[]>();

	/**
	 * Default constructor.
	 * <p>
	 * 	A default unlocked bean context will be created for this group.
	 */
	public ParserGroup() {
		super();
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The group to clone.  Underlying parsers will also be cloned.
	 */
	protected ParserGroup(ParserGroup copyFrom) {
		for (Map.Entry<Parser,String[]> e : copyFrom.parsers.entrySet())
			add(e.getKey().clone(), e.getValue());
	}

	/**
	 * Adds the specified parser to this group.
	 * @param parser The parser being added to this group.
	 * @param contentTypes The content types handled by this parser (e.g. <js>"text/json"</js>).
	 * @return This object (for method chaining).
	 */
	public ParserGroup add(Parser parser, String...contentTypes) {
		for (String ct : contentTypes)
			parserMappings.put(ct, parser);
		parsers.put(parser, contentTypes);
		return this;
	}

	/**
	 * Returns the parser associated with the specified content type.
	 * @param contentType The content types associated to the parser (e.g. <js>"text/json"</js>).
	 * @return The parser, or <jk>null</jk> if no parser is associated with the specified content type.
	 */
	public Parser getParser(String contentType) {
		return parserMappings.get(contentType);
	}

	/**
	 * Returns the content types handled by all parsers in this group.
	 * @return The set of all content types handled by all parsers in this group.
	 */
	public Set<String> getSupportedContentTypes() {
		return parserMappings.keySet();
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on parsers
	//--------------------------------------------------------------------------------

	/**
	 * Shortcut for calling {@link Parser#setProperty(String, Object)} on all parsers in this group.
	 * @param property The property name.
	 * @param value The property value.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup setProperty(String property, Object value) throws LockedException {
		checkLock();
		for (Parser p : parsers.keySet())
			p.setProperty(property, value);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#setProperties(JsonMap)} on all parsers in this group.
	 * @param properties The properties to set.  Ignored if <jk>null</jk>.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup setProperties(JsonMap properties) {
		if (properties != null) {
			checkLock();
			for (Map.Entry<String,Object> e : properties.entrySet())
				setProperty(e.getKey(), e.getValue());
		}
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#setBeanContext(BeanContext)} on all parsers in this group.
	 * @param beanContext The new bean context to associate with all parsers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup setBeanContext(BeanContext beanContext) throws LockedException {
		for (Parser p : parsers.keySet())
			p.setBeanContext(beanContext);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#addNotBeanClassPatterns(String[])} on all parsers in this group.
	 * @param patterns The new class patterns to add to the underlying bean context of all parsers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup addNotBeanClassPatterns(String... patterns) throws LockedException {
		for (Parser p : parsers.keySet())
			p.addNotBeanClassPatterns(patterns);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#addNotBeanClasses(Class[])} on all parsers in this group.
	 * @param classes The classes to specify as not-beans to the underlying bean context of all parsers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup addNotBeanClasses(Class<?>...classes) throws LockedException {
		for (Parser p : parsers.keySet())
			p.addNotBeanClasses(classes);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#addFilters(Filter[])} on all parsers in this group.
	 * @param filters The filters to add to the underlying bean context of all parsers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup addFilters(Filter...filters) throws LockedException {
		for (Parser p : parsers.keySet())
			p.addFilters(filters);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#addFilters(Class[])} on all parsers in this group.
	 * @param classes The classes to add bean filters for to the underlying bean context of all parsers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public ParserGroup addFilters(Class<?>...classes) throws LockedException {
		for (Parser p : parsers.keySet())
			p.addFilters(classes);
		return this;
	}

	/**
	 * Shortcut for calling {@link Parser#addImplClass(Class, Class)} on all parsers in this group.
	 * @param <T> The interface or abstract class type.
	 * @param interfaceClass The interface or abstract class.
	 * @param implClass The implementation class.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public <T> ParserGroup addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		for (Parser p : parsers.keySet())
			p.addImplClass(interfaceClass, implClass);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public ParserGroup lock() {
		super.lock();
		parserMappings = Collections.unmodifiableMap(parserMappings);
		parsers = Collections.unmodifiableMap(parsers);
		for (Parser p : parsers.keySet())
			p.lock();
		return this;
	}

	@Override
	public ParserGroup clone() {
		return new ParserGroup(this);
	}
}
