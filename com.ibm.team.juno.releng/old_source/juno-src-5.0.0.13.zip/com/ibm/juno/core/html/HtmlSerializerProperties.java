package com.ibm.juno.core.html;

import com.ibm.juno.core.*;
import com.ibm.juno.core.xml.*;

/**
 * Configurable properties on the {@link HtmlSerializer} class.
 * <p>
 * 	Use the {@link HtmlSerializer#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link HtmlSerializer}.
 * <ul>
 * 	<li>{@link XmlSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlSerializerProperties {

	/**
	 * Anchor text source ({@link String}, default={@link #TO_STRING}).
	 * <p>
	 * When creating anchor tags (e.g. <code><xt>&lt;a</xt> <xa>href</xa>=<xs>'...'</xs><xt>&gt;</xt>text<xt>&lt;/a&gt;</xt></code>)
	 * 	in HTML, this setting defines what to set the inner text to.
	 * <p>
	 * Possible values:
	 * <ul>
	 * 	<li>{@link #PROPERTY_NAME}/<js>"propertyName"</js> - Set to the bean property name.
	 * 	<li>{@link #TO_STRING}/<js>"toString"</js> - Set to whatever is returned by {@link #toString()} on the object.
	 * 	<li>{@link #URI}/<js>"uri"</js> - Set to the URI value.
	 * 	<li>{@link #LAST_TOKEN}/<js>"lastToken"</js> - Set to the last token of the URI value.
	 * </ul>
	 */
	public static final String URI_ANCHOR_TEXT = "HtmlSerializer.uriAnchorText";

	/** Constant for {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} property. */
	public static final String PROPERTY_NAME = "propertyName";
	/** Constant for {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} property. */
	public static final String TO_STRING = "toString";
	/** Constant for {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} property. */
	public static final String URI = "uri";
	/** Constant for {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} property. */
	public static final String LAST_TOKEN = "lastToken";

	private String uriAnchorText = TO_STRING;

	/** Default constructor.  All default values. */
	public HtmlSerializerProperties() {}

	/**
	 * Copy constructor.
	 * @param copyFrom Properties to copy from.
	 */
	public HtmlSerializerProperties(HtmlSerializerProperties copyFrom) {
		this.uriAnchorText = copyFrom.uriAnchorText;
	}

	/**
	 * Returns the current {@link #URI_ANCHOR_TEXT} value.
	 * @return The current {@link #URI_ANCHOR_TEXT} value.
	 */
	public final String getUriAnchorText() {
		return uriAnchorText;
	}

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		if (property.equals(URI_ANCHOR_TEXT))
			uriAnchorText = (value == null ? null : value.toString());
		else
			return false;
		return true;
	}
}
