package com.ibm.juno.core.html;

import java.util.*;

import com.ibm.juno.core.*;

/**
 * Context object that lives for the duration of a single serialization of {@link HtmlSerializer} and its subclasses.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlSerializerContext extends SerializerContext {

	private HtmlSerializerProperties hsp;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param hsp Default HTML serializer properties.
	 * @param op Override properties.
	 */
	protected HtmlSerializerContext(BeanContext beanContext, SerializerProperties sp, HtmlSerializerProperties hsp, JsonMap[] op) {
		super(beanContext, sp, op);
		this.hsp = new HtmlSerializerProperties(hsp);
		for (JsonMap m : op)
			for (Map.Entry<String,Object> e : m.entrySet())
				this.hsp.setProperty(e.getKey(), e.getValue());
	}

	/**
	 * Returns the {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} setting value in this context.
	 * @return The {@link HtmlSerializerProperties#URI_ANCHOR_TEXT} setting value in this context.
	 */
	public final String getUriAnchorText() {
		return hsp.getUriAnchorText();
	}
}
