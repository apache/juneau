package com.ibm.juno.core.xml;

/**
 * Represents a simple namespace mapping between a simple name and URI.
 * <p>
 * 	In general, the simple name will be used as the XML prefix mapping unless
 * 	there are conflicts or prefix remappings in the serializer.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class Namespace implements Comparable<Namespace> {
	String name, uri;
	private int hashCode;

	/**
	 * Constructor.
	 * <p>
	 * 	Use this constructor when the long name and short name are the same value.
	 *
	 * @param name The long and short name of this schema.
	 * @param uri The URI of this schema.
	 */
	protected Namespace(String name, String uri) {
		this.name = name;
		this.uri = uri;
		this.hashCode = (name == null ? 0 : name.hashCode()) + uri.hashCode();
	}

	/**
	 * Returns the namespace name.
	 * @return The namespace name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the namespace URI.
	 * @return The namespace URI.
	 */
	public String getUri() {
		return uri;
	}

	@Override
	public int compareTo(Namespace o) {
		int i = name.compareTo(o.name);
		if (i == 0)
			i = uri.compareTo(o.uri);
		return i;
	}

	/**
	 * For performance reasons, equality is always based on identity, since
	 * the {@link NamespaceFactory} class ensures no duplicate name+uri pairs.
	 */
	@Override
	public boolean equals(Object o) {
		return this == o;
	}

	@Override
	public int hashCode() {
		return hashCode;
	}

	@Override
	public String toString() {
		return "{name='"+name+"',uri:'"+uri+"'}";
	}
}
