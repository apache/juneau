package com.ibm.juno.core.xml;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.SerializerProperties.*;
import static com.ibm.juno.core.xml.XmlSerializerProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.utils.*;
import com.ibm.juno.core.xml.annotation.*;

/**
 * Serializes POJO models to XML.
 * <p>
 * 	See the {@link JsonSerializer} class for details on how Java models map to JSON.
 * <p>
 * 	For example, the following JSON...
 * <p class='bcode'>
 * 	{
 * 		name:<js>'John Smith'</js>,
 * 		address: {
 * 			streetAddress: <js>'21 2nd Street'</js>,
 * 			city: <js>'New York'</js>,
 * 			state: <js>'NY'</js>,
 * 			postalCode: <js>10021</js>
 * 		},
 * 		phoneNumbers: [
 * 			<js>'212 555-1111'</js>,
 * 			<js>'212 555-2222'</js>
 * 		],
 * 		additionalInfo: <jk>null</jk>,
 * 		remote: <jk>false</jk>,
 * 		height: <js>62.4</js>,
 * 		<js>'fico score'</js>:  <js>' &gt; 640'</js>
 * 	}
 * <p>
 * 	...maps to the following XML...
 * <p class='bcode'>
 * 	<xt>&lt;object&gt;</xt>
 * 		<xt>&lt;name</xt> <xa>type</xa>=<xs>'string'</xs><xt>&gt;</xt>John Smith<xt>&lt;/name&gt;</xt>
 * 		<xt>&lt;address</xt> <xa>type</xa>=<xs>'object'</xs><xt>&gt;</xt>
 * 			<xt>&lt;streetAddress</xt> <xa>type</xa>=<xs>'string'</xs><xt>&gt;</xt>21 2nd Street<xt>&lt;/streetAddress&gt;</xt>
 * 			<xt>&lt;city</xt> <xa>type</xa>=<xs>'string'</xs><xt>&gt;</xt>New York<xt>&lt;/city&gt;</xt>
 * 			<xt>&lt;state</xt> <xa>type</xa>=<xs>'string'</xs><xt>&gt;</xt>NY<xt>&lt;/state&gt;</xt>
 * 			<xt>&lt;postalCode</xt> <xa>type</xa>=<xs>'number'</xs><xt>&gt;</xt>10021<xt>&lt;/postalCode&gt;</xt>
 * 		<xt>&lt;/address&gt;</xt>
 * 		<xt>&lt;phoneNumbers</xt> <xa>type</xa>=<xs>'array'</xs><xt>&gt;</xt>
 * 			<xt>&lt;string&gt;</xt>212 555-1111<xt>&lt;/string&gt;</xt>
 * 			<xt>&lt;string&gt;</xt>212 555-2222<xt>&lt;/string&gt;</xt>
 * 		<xt>&lt;/phoneNumbers&gt;</xt>
 * 		<xt>&lt;additionalInfo</xt> <xa>type</xa>=<xs>'null'</xs><xt>&gt;&lt;/additionalInfo&gt;</xt>
 * 		<xt>&lt;remote</xt> <xa>type</xa>=<xs>'boolean'</xs><xt>&gt;</xt>false<xt>&lt;/remote&gt;</xt>
 * 		<xt>&lt;height</xt> <xa>type</xa>=<xs>'number'</xs><xt>&gt;</xt>62.4<xt>&lt;/height&gt;</xt>
 * 		<xt>&lt;fico_x0020_score</xt> <xa>type</xa>=<xs>'string'</xs><xt>&gt;</xt> &amp;gt; 640<xt>&lt;/fico_x0020_score&gt;</xt>
 * 	<xt>&lt;/object&gt;</xt>
 * <p>
 * 	This serializer provides several serialization options.  Typically, one of the predefined <jsf>DEFAULT</jsf> serializers will be sufficient.
 * 	However, custom serializers can be constructed to fine-tune behavior.
 * <p>
 * 	If an attribute name contains any non-valid XML element characters, they will be escaped using standard {@code _x####_} notation.
 *
 * <h6 class='topic'>Configurable settings</h6>
 * 	This class has configurable properties that can be set through the {@link #setProperty(String, Object)} method.
 * <p>
 * 	See {@link XmlSerializerProperties} for settings applicable to this class.
 * <p>
 * 	See {@link SerializerProperties} for settings applicable to all {@link Serializer Serializers}.
 * <p>
 * 	See {@link BeanContextProperties} for settings applicable to the {@link BeanContext} associated with this class.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class XmlSerializer extends Serializer {

	/** Default serializer, all default settings.*/
	public static final XmlSerializer DEFAULT =
		new XmlSerializer().lock();

	/** Default serializer, no whitespace added.*/
	public static final XmlSerializer DEFAULT_CONDENSED =
		new XmlSerializer()
			.setProperty(USE_INDENTATION, false)
			.lock();

	/** Default serializer, single quotes.*/
	public static final XmlSerializer DEFAULT_SQ =
		new XmlSerializer()
			.setProperty(QUOTE_CHAR, '\'')
			.lock();

	/** Default serializer, no whitespace added, single quotes.*/
	public static final XmlSerializer DEFAULT_SQC =
		new XmlSerializer()
			.setProperty(USE_INDENTATION, false)
			.setProperty(QUOTE_CHAR, '\'')
			.lock();

	/** Default serializer with JSON attribute tags, all default settings.*/
	public static final XmlSerializer DEFAULT_XMLJSON =
		new XmlSerializer()
			.setProperty(ADD_JSON_TYPE_ATTRS, true)
			.lock();

	/** Default serializer with JSON attribute tags, no whitespace added.*/
	public static final XmlSerializer DEFAULT_XMLJSON_CONDENSED =
		new XmlSerializer()
			.setProperty(ADD_JSON_TYPE_ATTRS, true)
			.setProperty(USE_INDENTATION, false)
			.lock();

	/** Default serializer with JSON attribute tags, single quotes.*/
	public static final XmlSerializer DEFAULT_XMLJSON_SQ =
		new XmlSerializer()
			.setProperty(ADD_JSON_TYPE_ATTRS, true)
			.setProperty(QUOTE_CHAR, '\'')
			.lock();

	/** Default serializer with JSON attribute tags, no whitespace added, single quotes.*/
	public static final XmlSerializer DEFAULT_XMLJSON_SQC =
		new XmlSerializer()
			.setProperty(ADD_JSON_TYPE_ATTRS, true)
			.setProperty(USE_INDENTATION, false)
			.setProperty(QUOTE_CHAR, '\'')
			.lock();

	/** XML serializer properties currently set on this serializer. */
	protected XmlSerializerProperties xsp = new XmlSerializerProperties();

	/**
	 * Default constructor.
	 * <p>
	 * 	A default unlocked bean context will be created for this serializer.
	 */
	public XmlSerializer() {
	}

	/**
	 * Constructor.
	 * @param beanContext The bean context to associate with this serializer.
	 */
	public XmlSerializer(BeanContext beanContext) {
		super(beanContext);
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The serializer to clone.  Underlying bean context will also be cloned.
	 */
	public XmlSerializer(XmlSerializer copyFrom) {
		super(copyFrom);
		this.xsp = new XmlSerializerProperties(copyFrom.xsp);
	}

	//--------------------------------------------------------------------------------
	// Serializer settings
	//--------------------------------------------------------------------------------

	@Override
	public XmlSerializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (xsp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	@Override
	public Writer serialize(Writer out, Object o, JsonMap...properties) throws IOException, SerializeException {
		XmlSerializerContext ctx = new XmlSerializerContext(beanContext, sp, xsp, properties);
		XmlSerializerWriter w = (out instanceof XmlSerializerWriter ? (XmlSerializerWriter)out : new XmlSerializerWriter(out, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority()));
		if (ctx.isEnableNamespaces()) {
			List<Namespace> l = ctx.getNamespaces();
			if (ctx.isAutoDetectNamespaces())
				findNsfMappings(o, ctx);
			else
				l.addAll(ctx.getDefaultNamespaces());
			if (ctx.getDefaultNamespace() != null)
				l.add(ctx.getDefaultNamespace());
			if ((!ctx.isTrimNulls()) && ctx.getXsiNamespace() != null)
				l.add(ctx.getXsiNamespace());
		}
		serializeAnything(w, o, null, ctx, null, null, ctx.isEnableNamespaces() && ctx.isAddNamespaceUrlsToRoot(), XmlFormat.NORMAL, null);
		return out;
	}

	/**
	 * Recursively searches for the XML namespaces on the specified POJO and adds them to the serializer context object.
	 */
	protected void findNsfMappings(Object o, XmlSerializerContext ctx) throws SerializeException {
		ClassType<?> aType = null;						// The actual type
		aType = ctx.push(null, o, null);

		if (aType != null) {
			Namespace ns = aType.getNamespace();
			if (ns != null) {
				if (ns.uri != null)
					ctx.getNamespaces().add(ns);
				else
					ns = null;
			}
		}

		// Handle recursion
		if (aType != null && ! aType.isPrimitive()) {

			BeanMap bm = null;
			if (aType.isBeanMap()) {
				bm = (BeanMap)o;
			} else if (aType.isBean()) {
				bm = beanContext.forBean(o);
			} else if (aType.isDelegate()) {
				ClassType innerType = ((Delegate)o).getClassType();
				Namespace ns = innerType.getNamespace();
				if (ns != null) {
					if (ns.uri != null)
						ctx.getNamespaces().add(ns);
					else
						ns = null;
				}

				if (innerType.isBean()) {
					for (BeanPropertyMeta bpm : (Collection<BeanPropertyMeta>)innerType.getBeanMeta().getMetaProperties()) {
						ns = bpm.getNamespace();
						if (ns != null && ns.uri != null)
							ctx.getNamespaces().add(ns);
					}

				} else if (innerType.isMap()) {
					for (Object o2 : ((Map)o).values())
						findNsfMappings(o2, ctx);
				} else if (innerType.isCollection()) {
					for (Object o2 : ((Collection)o))
						findNsfMappings(o2, ctx);
				}

			} else if (aType.isMap()) {
				for (Object o2 : ((Map)o).values())
					findNsfMappings(o2, ctx);
			} else if (aType.isCollection()) {
				for (Object o2 : ((Collection)o))
					findNsfMappings(o2, ctx);
			} else if (aType.isArray()) {
				for (Object o2 : ((Object[])o))
					findNsfMappings(o2, ctx);
			}
			if (bm != null) {
				for (BeanMapEntry p : (Set<BeanMapEntry>)bm.entrySet()) {

					Namespace ns = p.getMeta().getNamespace();
					if (ns != null && ns.uri != null)
						ctx.getNamespaces().add(ns);

					ns = p.getMeta().getValAttrNamespace();
					if (ns != null && ns.uri != null)
						ctx.getNamespaces().add(ns);

					try {
						findNsfMappings(p.getFilteredValue(), ctx);
					} catch (Throwable x) {
						// Ignore
					}
				}
			}
		}

		ctx.pop();
	}


	/**
	 * Workhorse method.
	 *
	 * @param out The writer to send the output to.
	 * @param o The object to serialize.
	 * @param ctx The serializer context.
	 * @param elementName The root element name.
	 * @param namespaceUrl If
	 * @return The same writer passed in so that calls to the writer can be chained.
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	@SuppressWarnings("null")
	private XmlSerializerWriter serializeAnything(XmlSerializerWriter out, Object o, ClassType eType,
			XmlSerializerContext ctx, String elementName, Namespace namespace, boolean addNamespaceUris,
			XmlFormat format, BeanPropertyMeta<?> pMeta) throws IOException, SerializeException {

		String ts = null;									// The type string (e.g. <type> or <x x='type'>
		int indent = ctx.indent;						// Current indentation
		ClassType<?> aType = null;						// The actual type
		ClassType<?> wType = null;						// The wrapped type
		ClassType<?> gType = ClassType.OBJECT;		// The generic type

		aType = ctx.push(elementName, o, eType);

		if (eType == null)
			eType = ClassType.OBJECT;

		// Handle recursion
		if (aType == null) {
			o = null;
			aType = ClassType.OBJECT;
		}

		if (o != null) {

			if (aType.isDelegate()) {
				wType = aType;
				aType = ((Delegate)o).getClassType();
			}

			gType = aType.getFilteredClassType();

			// Filter if necessary
			ObjectFilter filter = aType.getObjectFilter();
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == ClassType.OBJECT)
					gType = beanContext.getClassTypeForObject(o);
			}
		} else {
			gType = eType.getFilteredClassType();
		}

		String classAttr = null;
		if (ctx.isAddClassAttrs()) {
			if (o != null && ! eType.equals(aType))
				classAttr = aType.toString();
			else if (o == null)
				classAttr = eType.toString();
		}

		// char '\0' is interpreted as null.
		if (o != null && gType.isChar() && ((Character)o).charValue() == 0)
			o = null;

		boolean isCollapsed = false;		// If 'true', this is a collection and we're not rendering the outer element.
		boolean isValAttr = pMeta != null && pMeta.getValAttr() != null;	// Is property of form <xxx valAttr='val'/> instead of <xxx>val</xxx>

		// Get the JSON type string.
		if (gType.isCharSequence() || gType.isChar())
			ts = "string";
		else if (gType.isNumber())
			ts = "number";
		else if (gType.isBoolean())
			ts = "boolean";
		else if (gType.isMap() || gType.isBean())
			ts = "object";
		else if (gType.isCollection() || gType.isArray()) {
			isCollapsed = (format == XmlFormat.COLLAPSED && ! addNamespaceUris);
			ts = "array";
		}
		else
			ts = "string";


		// Is there a name associated with this bean?
		if (elementName == null)
			elementName = gType.getElementName();
		if (elementName == null)
			elementName = aType.getElementName();

		// If the value is null then it's either going to be <null/> or <XmlSerializer nil='true'/>
		// depending on whether the element has a name.
		boolean isNullTag = (elementName == null && o == null);

		if (isNullTag)
			ts = "null";

		if (ctx.isEnableNamespaces()) {
			if (namespace == null)
				namespace = gType.getNamespace();
			if (namespace == null)
				namespace = aType.getNamespace();
			if (namespace != null && namespace.uri == null)
				namespace = null;
			if (namespace == null)
				namespace = ctx.getDefaultNamespace();
		} else {
			namespace = null;
		}

		// Do we need a carriage return after the start tag?
		boolean cr = o != null && (! isValAttr) && (gType.isMap() || gType.isCollection() || gType.isArray() || gType.isBean());

		String en = (elementName == null ? ts : elementName);
		boolean encodeEn = elementName != null;
		String ns = (namespace == null ? null : namespace.name);
		String xsi = null, dns = null, elementNs = null, valAttrNs = null;
		if (ctx.isEnableNamespaces()) {
			xsi = ctx.getXsiNamespace().name;
			dns = elementName == null && ctx.getDefaultNamespace() != null ? ctx.getDefaultNamespace().name : null;
			elementNs = elementName == null ? dns : ns;
			if (isValAttr) {
				Namespace vns = pMeta.getValAttrNamespace();
				valAttrNs = vns == null || vns.name == null ? dns : vns.name;
			}
		}

		// Render the start tag.
		if (! isCollapsed) {
			out.oTag(indent, elementNs, en, encodeEn);
			if (addNamespaceUris) {
				List<Namespace> namespaces = ctx.getNamespaces();
				for (Namespace n : namespaces) {
					if (n.getName() == null)
						out.attr((String)null, "xmlns", n.getUri());
					else
						out.attr("xmlns", n.getName(), n.getUri());
				}
			}
			if (elementName != null && ctx.isAddJsonTypeAttrs() && (ctx.isAddJsonStringTypeAttrs() || ! ts.equals("string")))
				out.attr(dns, "type", ts);
			if (classAttr != null)
				out.attr(dns, "_class", classAttr);
			if (o == null) {
				if (! isNullTag)
					out.attr(xsi, "nil", "true");
				if ((gType.isBoolean() || gType.isNumber()) && ! gType.isNullable())
					o = BeanContext.getPrimitiveDefault(gType.getInnerClass());
			}

			if (o != null && !(gType.isMap() || gType.isBean() || isValAttr))
				out.append('>');

			if (cr && !(gType.isMap() || gType.isBean()))
				out.nl();
		}

		boolean hasChildren = true;

		// Render the tag contents.
		if (o != null) {
			if (isValAttr)
				out.attr(valAttrNs, pMeta.getValAttr(), o);
			else if (gType.isUri() || (pMeta != null && pMeta.isUri()))
				out.appendUri(o);
			else if (gType.isCharSequence() || gType.isChar())
				out.encodeText(o);
			else if (gType.isNumber() || gType.isBoolean())
				out.append(o);
			else if ((wType != null && wType.isMap()) || gType.isMap()) {
				if (o instanceof BeanMap)
					hasChildren = serializeBeanMap(out, (BeanMap)o, ctx);
				else
					hasChildren = serializeMap(out, (Map)o, gType.getKeyType(), gType.getValueType(), ctx);
			}
			else if (gType.isBean())
				hasChildren = serializeBeanMap(out, beanContext.forBean(o), ctx);
			else if ((wType != null && wType.isCollection()) || gType.isCollection()) {
				if (isCollapsed)
					ctx.indent--;
				serializeCollection(out, (Collection)o, gType.getElementType(), ctx, pMeta);
				if (isCollapsed)
					ctx.indent++;
			}
			else if (gType.isArray()) {
				if (isCollapsed)
					ctx.indent--;
				serializeCollection(out, toList(gType.getInnerClass(), o), gType.getElementType(), ctx, pMeta);
				if (isCollapsed)
					ctx.indent++;
			}
			else
				out.encodeText(o);
		}

		ctx.pop();

		// Render the end tag.
		if (! isCollapsed) {
			if (isValAttr || o == null || ! hasChildren)
				out.append('/').append('>').nl();
			else
				out.i(cr ? indent : 0).eTag(elementNs, en, encodeEn).nl();
		}

		return out;
	}

	private boolean serializeMap(XmlSerializerWriter out, Map m, ClassType<?> keyType, ClassType<?> valueType, XmlSerializerContext ctx) throws IOException, SerializeException {
		boolean hasChildren = false;
		for (Iterator i = m.entrySet().iterator(); i.hasNext();) {
			Map.Entry e = (Map.Entry)i.next();

			Object k = e.getKey();
			if (k == null) {
				k = "\u0000";
			} else {
				k = generalize(k);
			}

			Object value = e.getValue();

			if (canIgnoreValue(ctx, valueType, value))
				continue;

			if (! hasChildren) {
				hasChildren = true;
				out.append('>').nl();
			}
			serializeAnything(out, value, valueType, ctx, k.toString(), null, false, XmlFormat.NORMAL, null);
		}
		return hasChildren;
	}

	private boolean serializeBeanMap(XmlSerializerWriter out, BeanMap m, XmlSerializerContext ctx) throws IOException, SerializeException {
		boolean hasChildren = false;

		Map<String,BeanPropertyMeta> xmlAttrs = m.getMeta().getXmlAttrProperties();
		for (BeanPropertyMeta p : xmlAttrs.values()) {

			if (canIgnoreProperty(ctx, p))
				continue;

			String key = p.getName();
			Object value = null;
			try {
				value = m.getFiltered(key);
			} catch (Throwable x) {
				ctx.addWarning("Could not call getValue() on property '%s', %s", key, x.getLocalizedMessage());
			}

			if (canIgnoreValue(ctx, p.getClassType(), value))
				continue;

			if (p.isBeanUri() || p.isUri())
				out.attrUri(ctx.isEnableNamespaces() ? p.getNamespace() : null, key, value);
			else
				out.attr(ctx.isEnableNamespaces() ? p.getNamespace() : null, key, value);
		}

		for (BeanMapEntry p : (Set<BeanMapEntry>)m.entrySet()) {
			BeanPropertyMeta pMeta = p.getMeta();

			if (canIgnoreProperty(ctx, pMeta) || pMeta.getXmlFormat() == XmlFormat.ATTR)
				continue;

			String key = p.getKey();
			Object value = null;
			try {
				value = p.getFilteredValue();
			} catch (Throwable x) {
				ctx.addWarning("Could not call getValue() on property '%s', %s", key, x.getLocalizedMessage());
			}

			if (canIgnoreValue(ctx, pMeta.getClassType(), value))
				continue;

			if (! hasChildren) {
				hasChildren = true;
				out.append('>').nl();
			}
			serializeAnything(out, value, pMeta.getFilteredClassType(), ctx, key, pMeta.getNamespace(), false, pMeta.getXmlFormat(), pMeta);
		}
		return hasChildren;
	}

	private XmlSerializerWriter serializeCollection(XmlSerializerWriter out, Collection c, ClassType<?> elementType, XmlSerializerContext ctx, BeanPropertyMeta<?> ppMeta) throws IOException, SerializeException {

		String eName = null;
		Namespace eNs = null;

		if (ppMeta != null) {
			eName = ppMeta.getChildElementName();
			eNs = ppMeta.getNamespace();
		}

		if (eName == null && elementType != ClassType.OBJECT) {
			eName = elementType.getElementName();
			eNs = elementType.getNamespace();
		}

		for (Iterator i = c.iterator(); i.hasNext();) {
			Object value = i.next();

			if (canIgnoreValue(ctx, elementType, value))
				continue;

			serializeAnything(out, value, elementType, ctx, eName, eNs, false, XmlFormat.NORMAL, null);
		}
		return out;
	}

	@Override
	public Writer serializeSchema(Writer out, Object o, JsonMap...properties) throws IOException, SerializeException {
		XmlSerializerContext ctx = new XmlSerializerContext(beanContext, sp, xsp, properties);
		XmlSerializerWriter w = new XmlSerializerWriter(out, sp.isUseIndentation(), sp.getQuoteChar(), sp.getUriContext(), sp.getUriAuthority());
		String xs = ctx.getXsNamespace().name, xsi = ctx.getXsiNamespace().name;
		String xsUri = ctx.getXsNamespace().uri, xsiUri = ctx.getXsiNamespace().uri;
		boolean eXs = xs != null;
		boolean eXsi = xsi != null;
		w.oTag(ctx.getIndent(), xs, "schema");
		if (eXs)
			w.attr("xmlns", xs, xsUri);
		if (eXsi)
			w.attr("xmlns", xsi, xsiUri);
		ClassType ct = beanContext.getClassTypeForObject(o);
		if (ct != null && ct.getNamespace() != null && ct.getElementName() != null && ctx.isEnableNamespaces())
			w.attr("targetNamespace", ct.getNamespace().getUri());
		w.append('>').nl();
		serializeSchema(w, ct, ctx, null, null, false, true);
		w.eTag(ctx.getIndent(), xs, "schema").nl();
		return out;
	}

	@SuppressWarnings("null")
	private SerializerWriter serializeSchema(XmlSerializerWriter out, ClassType<?> eType, XmlSerializerContext ctx, String attrName, BeanPropertyMeta ppMeta, boolean unbounded, boolean topLevel) throws SerializeException {
		try {

			ClassType<?> aType;			// The actual type (will be null if recursion occurs)
			ClassType<?> gType;			// The generic type

			if (eType == null)
				eType = ClassType.OBJECT;

			aType = ctx.push(attrName, eType, null);
			gType = eType.getFilteredClassType();
			String xs = ctx.getXsNamespace().name;

			if (attrName == null)
				attrName = gType.getElementName();

			if (attrName != null)
				attrName = XmlSerializerWriter.encodeElementName(attrName);

			// We always add a _class attribute if this is the top level.
			// We sometimes add a _class attribute if it's a bean (depending on whether or not aType==eType during serialization).
			boolean addClassAttr = ctx.isAddClassAttrs() && (topLevel || ! (eType.isNumber() || eType.isBoolean() || eType.isChar() || eType.isEnum() || eType.isCharSequence()));

			boolean isValAttr = (ppMeta != null && ppMeta.getValAttr() != null);

			int i = ctx.getIndent();

			String xmlType = null;
			String jsonType = null;
			if (gType.isBoolean())
				xmlType = jsonType = "boolean";
			else if (gType.isNumber()) {
				jsonType = "number";
				if (gType.isDecimal())
					xmlType = "decimal";
				else
					xmlType = "integer";
			}
			else if (gType.isDate()) {
				jsonType = "string";
				xmlType = "date";
			}
			else if (gType.isCharSequence() || gType.isEnum() || gType.isChar() || gType.isUri() || isValAttr)
				xmlType = jsonType = "string";

			if (xmlType != null) {

				boolean isComplexType = (ctx.isAddJsonTypeAttrs() && attrName != null) || addClassAttr || isValAttr;

				if (! isComplexType) {
					// 	<xs:element name='{attrName|jsonType}' type='xs:{dataType} xsi:nil='true'/>
					out.oTag(i, xs, "element")
						.attr(null, "name", (attrName != null ? attrName : jsonType), attrName != null)
						.append(" type=").q().append(xs).append(":").append(xmlType).q();

					if (unbounded)
						out.attr("maxOccurs", "unbounded");
					if (gType.isNullable())
						out.attr("nillable", "true");
					if (! topLevel)
						out.attr("minOccurs", 0);

					out.append("/>").nl();

				} else {
					//  	<xs:element name="{attrName|jsonType}">
					// 		<xs:complexType>
					// 			<xs:simpleContent>
					// 				<xs:extension base="xs:{dataType}">
					// 					<xs:attribute name="type" type="xs:string" fixed="{jsonType}"/>  -- If elementName == attrName
					// 					<xs:attribute name="null" type="xs:boolean" default="false"/>	  -- If not primitive
					// 				</xs:extension>
					// 			</xs:simpleContent>
					// 		</xs:complexType>
					// 	</xs:element>
					out.oTag(i, xs, "element")
						.attr(null, "name", (attrName != null ? attrName : jsonType), attrName != null);
					if (unbounded)
						out.attr("maxOccurs", "unbounded");
					if (gType.isNullable())
						out.attr("nillable", "true");
					out.append('>').nl();
					out.sTag(i+1, xs, "complexType").nl();
					if (isValAttr) {
						if (ppMeta.getValAttrNamespace() == null) {
							out.oTag(i+2, xs, "attribute")
								.attr("name", ppMeta.getValAttr())
								.append(" type=").q().append(xs).append(':').append("string").q()
								.attr("default", "")
								.append("/>").nl();
						} else {
							out.oTag(i+2, xs, "anyAttribute")
								.attr("processContents", "skip")
								.append("/>").nl();
						}
					} else {
						out.sTag(i+2, xs, "simpleContent").nl();
						out.oTag(i+3, xs, "extension")
							.append(" base=").q().append(xs).append(':').append(xmlType).q()
							.append('>').nl();
						if (ctx.isAddJsonTypeAttrs() && attrName != null) {
							out.oTag(i+4, xs, "attribute")
								.attr("name", "type")
								.append(" type=").q().append(xs).append(':').append("string").q()
								.attr("fixed", jsonType)
								.append("/>").nl();
						}
						if (addClassAttr) {
							out.oTag(i+4, xs, "attribute")
								.attr("name", "_class")
								.append(" type=").q().append(xs).append(':').append("string").q()
								.attr("default", "")
								.append("/>").nl();
						}
						out.eTag(i+3, xs, "extension").nl();
						out.eTag(i+2, xs, "simpleContent").nl();
					}
					out.eTag(i+1, xs, "complexType").nl();
					out.eTag(i, xs, "element").nl();
				}
				ctx.pop();
				return out;
			}

			if (gType.isCollection() || gType.isArray())
				jsonType = "array";
			else
				jsonType = "object";

			out.oTag(i, xs, "element")
				.attr(null, "name", (attrName != null ? attrName : jsonType), attrName != null);
			if (unbounded)
				out.attr("maxOccurs", "unbounded");
			if (gType.isNullable())
				out.attr("nillable", "true");
			out.append('>').nl();

			out.sTag(i+1, xs, "complexType").nl();
			out.oTag(i+2, xs, "sequence").attr("minOccurs", 0).attr("maxOccurs", "unbounded").append(">").nl();
			ctx.indent += 2;
			if (aType != null) {
				if (gType.isBean()) {
					BeanMeta<?> bm = gType.getBeanMeta();
					if (ppMeta != null && ppMeta.getProperties() != null)
						bm = new BeanMetaFiltered(bm, ppMeta.getProperties());
					for (BeanPropertyMeta<?> m : bm.getMetaProperties()) {
						if ((! m.isHidden()) && m.getNamespace() != null) {
							out.oTag(i+3, xs, "any")
								.attr("namespace", "##any")
								.attr("minOccurs", "0")
								.attr("maxOccurs", "unbounded")
								.attr("processContents", "skip")
								.append("/>").nl();
							break;
						}
					}

			   //   <xsd:any namespace="##any" minOccurs="0" maxOccurs="unbounded" processContents="skip"/>
					for (BeanPropertyMeta<?> m : bm.getMetaProperties()) {
						if ((! m.isHidden() || m.getNamespace() == null) && m.getXmlFormat() == XmlFormat.COLLAPSED) {
							out.oTag(i+3, xs, "element")
								.attr("name", m.getChildElementName())
								.attr("type", "xs:string")
								.attr("minOccurs", 0)
								.append("/>").nl();
						}
					}
					for (BeanPropertyMeta<?> m : bm.getMetaProperties()) {
						if (! (m.isHidden() || m.getXmlFormat() == XmlFormat.ATTR || m.getXmlFormat() == XmlFormat.COLLAPSED || m.getNamespace() != null))
							serializeSchema(out, m.getClassType(), ctx, m.getName(), m, false, false);
					}
				}
				else if (gType.isCollection() || gType.isArray()) {
					ClassType<?> elementType = gType.getElementType();
					if (elementType == ClassType.OBJECT) {
						out.oTag(i+3, xs, "any")
						.attr("processContents", "skip")
						.attr("maxOccurs", "unbounded")
						.attr("minOccurs", "0")
						.append("/>").nl();
					} else {
						out.oTag(i+3, xs, "choice")
						.attr("minOccurs", 0)
						.attr("maxOccurs", "unbounded")
						.append('>').nl();
					ctx.indent += 1;
					serializeSchema(out, elementType, ctx, null, ppMeta, false, false);
					ctx.indent -= 1;
					out.oTag(i+4, xs, "element")
						.attr("name", "null")
						.append("/>").nl();
					out.eTag(i+3, xs, "choice").nl();
					}
				}
				else {
					out.oTag(i+3, xs, "any")
						.attr("processContents", "skip")
						.attr("maxOccurs", "unbounded")
						.attr("minOccurs", "0")
						.append("/>").nl();
				}
			}
			ctx.indent -= 2;
			out.eTag(i+2, xs, "sequence").nl();
			if (attrName != null && ctx.isAddJsonTypeAttrs()) {
				out.oTag(i+2, xs, "attribute")
					.attr("name", "type")
					.append(" type=").q().append(xs).append(":string").q()
					.append("/>").nl();
			}
			if (addClassAttr) {
				out.oTag(i+2, xs, "attribute")
					.attr("name", "_class")
					.append(" type=").q().append(xs).append(':').append("string").q()
					.append("/>").nl();
			}
			if (gType.isBean()) {
				ConcurrentIdentityList<Namespace> n = new ConcurrentIdentityList<Namespace>();
				BeanMeta<?> bm = gType.getBeanMeta();
				if (ppMeta != null && ppMeta.getProperties() != null)
					bm = new BeanMetaFiltered(bm, ppMeta.getProperties());
				for (BeanPropertyMeta<?> pMeta : bm.getXmlAttrProperties().values()) {
					if (pMeta.getNamespace() == null) {
						out.oTag(i+2, xs, "attribute")
						.attr("name", pMeta.getName())
						.append(" type=").q().append(xs).append(':').append("string").q()
						.attr("default", "")
						.append("/>").nl();
					} else {
						n.add(pMeta.getNamespace());
					}
				}
				if (n.size() > 0) {
					out.oTag(i+2, xs, "anyAttribute")
						.attr("namespace", nsUrisToString(n))
						.attr("processContents", "skip")
						.append("/>").nl();
				}
			}

			out.eTag(i+1, xs, "complexType").nl();
			out.eTag(i, xs, "element").nl();
			if (topLevel) {
				out.oTag(i, xs, "element")
					.attr("name", "null")
					.append("/>").nl();
			}
			ctx.pop();
			return out;
		} catch (Throwable e) {
			throw new SerializeException("Exception occured trying to process object of type '%s'", eType).setCause(e);
		}
	}

	private String nsUrisToString(Collection<Namespace> c) {
		StringBuilder sb = new StringBuilder();
		for (Iterator<Namespace> i = c.iterator(); i.hasNext();) {
			sb.append(i.next().uri);
			if (i.hasNext())
				sb.append(' ');
		}
		return sb.toString();
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on CoreAPI
	//--------------------------------------------------------------------------------

	@Override
	public XmlSerializer setBeanContext(BeanContext beanContext) throws LockedException {
		super.setBeanContext(beanContext);
		return this;
	}

	@Override
	public XmlSerializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override
	public XmlSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override
	public XmlSerializer addFilters(Filter...s) throws LockedException {
		super.addFilters(s);
		return this;
	}

	@Override
	public XmlSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override
	public <T> XmlSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public XmlSerializer lock() {
		super.lock();
//		nsMappings = Collections.unmodifiableMap(nsMappings);
		return this;
	}

	@Override
	public XmlSerializer clone() {
		return new XmlSerializer(this);
	}
}
