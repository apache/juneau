package com.ibm.juno.core.urlencoding;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.SerializerProperties.*;
import static com.ibm.juno.core.json.JsonSerializerProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.*;

/**
 * Serializes POJO models to URL GET parameter notation (e.g. <js>"foo=bar&amp;baz=bing"</js>).
 * <p>
 * 	Note:  This serializer only works on {@link Map Maps} and beans.
 * <p>
 * 	The conversion is as follows...
 * 	<ul>
 * 		<li>Top-level {@link Map Maps} and beans are converted to key/value pairs.
 * 		<li>Values are converted to JSON using the specified JSON serializer.
 * 	</ul>
 * <p>
 * 	This serializer provides several serialization options.  Typically, one of the predefined DEFAULT serializers will be sufficient.
 * 	However, custom serializers can be constructed to fine-tune behavior.
 *
 * <h6 class='topic'>Configurable settings</h6>
 * 	This class has configurable properties that can be set through the {@link #setProperty(String, Object)} method.
 * <p>
 * 	See {@link JsonSerializerProperties} for settings applicable to the parent {@link JsonSerializer} class.
 * <p>
 * 	See {@link SerializerProperties} for settings applicable to all {@link Serializer Serializers}.
 * <p>
 * 	See {@link BeanContextProperties} for settings applicable to the {@link BeanContext} associated with this class.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Serialize a Map</jc>
 * 	Map m = <jk>new</jk> JsonMap(<js>"{a:'b',c:1,d:false,,e:['f',1,false],g:{h:'i'}}"</js>);
 *
 * 	<jc>// Produces "a=b&amp;c=1&amp;d=false&amp;e=['f',1,false]&amp;g={h:'i'}"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT_LAX</jsf>.serialize(s);
 *
 * 	<jc>// Produces "a='b'&amp;c=1&amp;d=false&amp;e=['f',1,false]&amp;g={h:'i'}"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT_LAX</jsf>.serialize(s);
 *
 * 	<jc>// Serialize a bean</jc>
 * 	<jk>public class</jk> Person {
 * 		<jk>public</jk> Person(String s);
 * 		<jk>public</jk> String getName();
 * 		<jk>public int</jk> getAge();
 * 		<jk>public</jk> Address getAddress();
 * 		<jk>public boolean</jk> deceased;
 * 	}
 *
 * 	<jk>public class</jk> Address {
 * 		<jk>public</jk> String getStreet();
 * 		<jk>public</jk> String getCity();
 * 		<jk>public</jk> String getState();
 * 		<jk>public int</jk> getZip();
 * 	}
 *
 * 	Person p = <jk>new</jk> Person(<js>"John Doe, 23, 123 Main St, Anywhere, NY, 12345, false"</js>);
 *
 * 	<jc>// Produces "name=John%20Doe&amp;age=23&amp;address={street:'123%20Main%20St',city:'Anywhere',state:'NY',zip:12345}&amp;deceased=false"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT_LAX</jsf>.serialize(s);
 *
 * 	<jc>// Produces "name='John%20Doe'&amp;age=23&amp;address={street:'123%20Main%20St',city:'Anywhere',state:'NY',zip:12345}&amp;deceased=false"</jc>
 * 	String s = UrlEncodingSerializer.<jsf>DEFAULT</jsf>.serialize(s);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("hiding")
public class UrlEncodingSerializer extends JsonSerializer {

	/** Default serializer. */
	public static final UrlEncodingSerializer DEFAULT =
		new UrlEncodingSerializer()
			.setProperty(USE_WHITESPACE, false)
			.setProperty(USE_INDENTATION, false)
			.setProperty(QUOTE_CHAR, '\'')
			.lock();

	/**
	 * Default serializer, non-strict mode.
	 * <p>
	 * 	Non-strict mode causes top-level string values to not be quoted.  Note that this can cause String parameter
	 * 	values that are numeric/boolean/null to be interpreted as a Number/Boolean/null instead of String when
	 * 	parsing the resulting string using the {@link UrlEncodingParser} class.
	 */
	public static final UrlEncodingSerializer DEFAULT_LAX = DEFAULT;

	/**
	 * Default constructor.
	 * <p>
	 * 	A default unlocked bean context will be created for this serializer.
	 */
	public UrlEncodingSerializer() {
	}

	/**
	 * Constructor.
	 * @param beanContext The bean context to associate with this serializer.
	 */
	public UrlEncodingSerializer(BeanContext beanContext) {
		super(beanContext);
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The serializer to clone.  Underlying bean context will also be cloned.
	 */
	public UrlEncodingSerializer(UrlEncodingSerializer copyFrom) {
		super(copyFrom);
	}

	//--------------------------------------------------------------------------------
	// Properties
	//--------------------------------------------------------------------------------

	@Override
	public UrlEncodingSerializer setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	@Override
	public Writer serialize(Writer out, Object o, JsonMap...properties) throws IOException, SerializeException {
		UrlEncodingSerializerContext ctx = new UrlEncodingSerializerContext(beanContext, sp, jsp, properties);
		UrlEncodingSerializerWriter w = new UrlEncodingSerializerWriter(out, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority());
		serializeAnything(w, o, null, ctx, "root");
		return out;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private SerializerWriter serializeAnything(UrlEncodingSerializerWriter out, Object o, ClassType<?> eType, UrlEncodingSerializerContext ctx, String attrName) throws SerializeException {
		try {
			if (o == null) {
				out.append("null");
				return out;
			}

			if (eType == null)
				eType = ClassType.OBJECT;

			boolean addClassAttr;		// Add "_class" attribute to element?
			ClassType<?> aType;			// The actual type
			ClassType<?> gType;			// The generic type

			aType = ctx.push(attrName, o, eType);

			// Note:  We don't have to handle recursion because that will be handled by value serializer.

			gType = aType.getFilteredClassType();
			addClassAttr = (ctx.isAddClassAttrs() && ! eType.equals(aType));

			// Filter if necessary
			ObjectFilter filter = aType.getObjectFilter();				// The filter
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == ClassType.OBJECT)
					gType = beanContext.getClassTypeForObject(o);
			}

			if (o == null || (gType.isChar() && ((Character)o).charValue() == 0))
				out.append("null");
			else if (gType.isUri())
				out.encodeUri(o);
			else if (gType.isBean())
				serializeBean(out, o, addClassAttr, ctx);
			else if (gType.isMap())
				serializeMap(out, (Map)o, gType.getKeyType(), gType.getValueType(), ctx);
			else
				out.encode(super.serialize(new StringWriter(), o, ctx.getOverrideProperties()).toString());
			ctx.pop();
			return out;
		} catch (SerializeException e) {
			throw e;
		} catch (Throwable e) {
			e.printStackTrace();
			throw new SerializeException("Exception occured trying to process object of type '%s'", (o == null ? null : o.getClass().getName())).setCause(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private SerializerWriter serializeMap(UrlEncodingSerializerWriter out, Map m, ClassType<?> keyType, ClassType<?> valueType, UrlEncodingSerializerContext ctx) throws IOException, SerializeException {
		char d = 0;
		for (Map.Entry e : (Set<Map.Entry>)m.entrySet()) {
			Object val = e.getValue();

			if (canIgnoreValue(ctx, valueType, val))
				continue;

			Object key = generalize(e.getKey());
			String sVal = super.serialize(new StringWriter(), val, ctx.getOverrideProperties()).toString();
			out.appendIf(d != 0, d).encode(key).append('=').encode(sVal);
			d = '&';
		}
		return out;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private SerializerWriter serializeBean(UrlEncodingSerializerWriter out, Object o, boolean addClassAttr, UrlEncodingSerializerContext ctx) throws IOException, SerializeException {
		char d = 0;
		if (addClassAttr) {
			out.appendIf(d != 0, d).append("_class=").append(o.getClass().getName());
			d = '&';
		}
		BeanMap m = beanContext.forBean(o);
		for (BeanMapEntry p : (Set<BeanMapEntry>)m.entrySet()) {
			BeanPropertyMeta pMeta = p.getMeta();

			if (canIgnoreProperty(ctx, pMeta))
				continue;

			Object value = p.getFilteredValue();

			if (canIgnoreValue(ctx, pMeta.getClassType(), value))
				continue;

			Object key = generalize(p.getKey());
			out.appendIf(d != 0, d).encode(key).append('=');
			if (pMeta.isUri() || pMeta.isBeanUri())
				out.encodeUri(value);
			else
				out.encode(super.serialize(new StringWriter(), value, ctx.getOverrideProperties()).toString());
			d = '&';
		}
		return out;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods on CoreAPI
	//--------------------------------------------------------------------------------

	@Override
	public UrlEncodingSerializer setBeanContext(BeanContext beanContext) throws LockedException {
		super.setBeanContext(beanContext);
		return this;
	}

	@Override
	public UrlEncodingSerializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override
	public UrlEncodingSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override
	public UrlEncodingSerializer addFilters(Filter...s) throws LockedException {
		super.addFilters(s);
		return this;
	}

	@Override
	public UrlEncodingSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override
	public <T> UrlEncodingSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public UrlEncodingSerializer lock() {
		super.lock();
		return this;
	}

	@Override
	public UrlEncodingSerializer clone() {
		return new UrlEncodingSerializer(this);
	}
}
