package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filters.*;
import com.ibm.juno.core.xml.annotation.*;

/**
 * Java bean wrapper class.
 * <p>
 * 	A wrapper that wraps Java bean instances inside of a {@link Map} interface that allows
 * 	properties on the wrapped object can be accessed using the {@link Map#get(Object) get()} and {@link Map#put(Object,Object) put()} methods.
 * <p>
 * 	Use the {@link BeanContext} class to create instances of this class.
 * <p>
 * 	The order of the properties returned by the {@link Map#keySet() keySet()} and {@link Map#entrySet() entrySet()} methods are as follows:
 * 	<ul>
 * 		<li>If {@link Bean @Bean} annotation is specified on class, then the order is the same as the list of properties in the annotation.
 * 		<li>If {@link Bean @Bean} annotation is not specified on the class, then the order is the same as that returned
 * 			by the {@link java.beans.BeanInfo} class (i.e. ordered by definition in the class).
 * 	</ul>
 * 	<br>
 * 	The order can also be overridden through the use of a {@link BeanFilter}.
 * <p>
 * 	If {@link ObjectFilter ObjectFilters} are defined on the class types of the properties of this bean, the
 * 	{@link #getFiltered(String)} and {@link #putFiltered(String, Object)} methods can be used to automatically
 * 	transform the property value to and from the serialized form.
 *
 * @author Barry M. Caceres
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <T> Specifies the type of object that this map encapsulates.
 */
public class BeanMap<T> extends AbstractMap<String,Object> implements Delegate<T> {

	/** The wrapped object. */
	protected T bean;

	/** Temporary holding cache for read-only beans.  Normally null. */
	protected Map<String,Object> readOnlyPropertyCache;

	/** The BeanMeta associated with the class of the object. */
	private final BeanMeta<T> meta;

	/**
	 * Instance of this class are instantiated through the BeanContext class.
	 */
	protected BeanMap(T bean, BeanMeta<T> meta) {
		this.bean = bean;
		this.meta = meta;
		if (meta.readOnlyConstructor != null)
			readOnlyPropertyCache = new TreeMap<String,Object>();
	}

	/**
	 * Returns the metadata associated with this bean map.
	 * @return The metadata associated with this bean map.
	 */
	public BeanMeta<T> getMeta() {
		return meta;
	}

	/**
	 * Returns the wrapped bean object.
	 *
	 * @return The inner bean object.
	 */
	public T getBean() {
		/** If this is a read-only bean, then we need to create it. */
		if (bean == null) {
			String[] props = meta.readOnlyConstructorProperties;
			Constructor<T> c = meta.readOnlyConstructor;
			Object[] args = new Object[props.length];
			for (int i = 0; i < props.length; i++)
				args[i] = readOnlyPropertyCache.remove(props[i]);
			try {
				bean = c.newInstance(args);
				for (Map.Entry<String,Object> e : readOnlyPropertyCache.entrySet())
					put(e.getKey(), e.getValue());
				readOnlyPropertyCache = null;
			} catch (Exception e) {
				throw new BeanRuntimeException(e);
			}
		}
		return bean;
	}

	/**
	 * Returns <jk>true</jk> if one of the properties on this bean is annotated with {@link BeanProperty#beanUri()} as <jk>true</jk>
	 * @return <jk>true</jk> if there is a URI property associated with this bean.
	 */
	public boolean hasBeanUri() {
		return meta.beanUriProperty != null;
	}

	/**
	 * Returns the filtered value of the property identified as the URI property (annotated with {@link BeanProperty#beanUri()} as <jk>true</jk>).
	 * @return The URI value, or <jk>null</jk> if no URI property exists on this bean.
	 */
	public Object getBeanUri() {
		if (meta.beanUriProperty == null)
			return null;
		return meta.beanUriProperty.getFiltered(this);
	}

	/**
	 * Sets a property on the bean.
	 *
	 * @param property The name of the property to set.
	 * @param value The value to set the property to.
	 * @return If the bean context setting {@code beanMapPutReturnsOldValue} is <jk>true</jk>, then the old value of the property is returned.
	 * 		Otherwise, this method always returns <jk>null</jk>.
	 * @throws RuntimeException if any of the following occur.
	 * 	<ul>
	 * 		<li>BeanMapEntry does not exist on the underlying object.
	 * 		<li>Security settings prevent access to the underlying object setter method.
	 * 		<li>An exception occurred inside the setter method.
	 * 	</ul>
	 */
	@Override
	public Object put(String property, Object value) {
		BeanPropertyMeta<T> p = meta.properties.get(property);
		if (p == null) {
			if (meta.beanContext.ignoreUnknownBeanProperties)
				return null;
			throw new BeanRuntimeException(meta.c, "Bean property '%s' not found.", property);
		}
		return p.set(this, value);
	}

	/**
	 * Add a value to a collection or array property.
	 * <p>
	 * 	As a general rule, adding to arrays is not recommended since the array must be recreate each time
	 * 	this method is called.
	 * @param property Property name or child-element name (if {@link Xml#childElementName()} is specified).
	 * @param value The value to add to the collection or array.
	 */
	public void add(String property, Object value) {
		BeanPropertyMeta<T> p = meta.properties.get(property);
		if (p == null)
			p = meta.childElementProperties.get(property);
		if (p == null) {
			if (meta.beanContext.ignoreUnknownBeanProperties)
				return;
			throw new BeanRuntimeException(meta.c, "Bean property '%s' not found.", property);
		}
		p.add(this, value);
	}
	/**
	 * Sets a property value with a filtered value.
	 * <p>
	 * 	Same behavior as {@link #put(Object, Object)}, except that if there is an {@link ObjectFilter}
	 * 	associated with this bean property's class, then the value passed in will be
	 * 	converted using the {@link ObjectFilter#unfilter(Object, ClassType, BeanContext)} method
	 * 	before insertion.
	 * <p>
	 * 	For example, if the {@link DateFilter#DEFAULT_ISO8601DT} filter is associated with this
	 * 	bean context, then you can set {@code Date} properties with ISO8601 date-time strings.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='code'>
	 * 	<jc>// Construct a bean with a 'birthDate' Date field</jc>
	 * 	Person p = <jk>new</jk> Person();
	 *
	 * 	<jc>// Create a bean context and add the ISO8601 date-time filter</jc>
	 * 	BeanContext beanContext = <jk>new</jk> BeanContext().addFilter(DateFilter.<jsf>DEFAULT_ISO8601DT</jsf>);
	 *
	 * 	<jc>// Wrap our bean in a bean map</jc>
	 * 	BeanMap&lt;Person&gt; b = beanContext.forBean(p);
	 *
	 * 	<jc>// Set the field</jc>
	 * 	myBeanMap.putFiltered(<js>"birthDate"</js>, <js>"'1901-03-03T04:05:06-5000'"</js>);
	 * </p>
	 *
	 * @param property The name of the property to set.
	 * @param value The generalized value to set the property to.
	 * @return If the bean context setting {@code beanMapPutReturnsOldValue} is <jk>true</jk>, then the
	 * 	old value of the property is returned.
	 * 	Otherwise, this method always returns <jk>null</jk>.
	 */
	public Object putFiltered(String property, Object value) {
		BeanPropertyMeta<T> p = meta.properties.get(property);
		if (p == null) {
			if (meta.beanContext.ignoreUnknownBeanProperties)
				return null;
			throw new BeanRuntimeException(meta.c, "Bean property '%s' not found.", property);
		}
		return p.setFiltered(this, value);
	}

	/**
	 * Gets a property on the bean.
	 *
	 * @param property The name of the property to get.
	 * @throws RuntimeException if any of the following occur.
	 * 	<ol>
	 * 		<li>BeanMapEntry does not exist on the underlying object.
	 * 		<li>Security settings prevent access to the underlying object getter method.
	 * 		<li>An exception occurred inside the getter method.
	 * 	</ol>
	 */
	@Override
	public Object get(Object property) {
		BeanPropertyMeta<T> p = meta.properties.get(property);
		if (p == null)
			return null;
		return p.get(this);
	}

	/**
	 * Gets a filtered property value.
	 * <p>
	 * 	Same behavior as {@link #get(Object)}, except that if there is an {@link ObjectFilter}
	 * 	associated with this bean property's class, then the value passed in will be
	 * 	converted using the {@link ObjectFilter#filter(Object, BeanContext)} method
	 * 	before returning.
	 * <p>
	 * 	For example, if the {@link DateFilter#DEFAULT_ISO8601DT} filter is associated with this
	 * 	bean context, then you can retrieve {@code Date} properties as ISO8601 date-time strings.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Construct a bean with a 'birthDate' Date field</jc>
	 * 	Person p = <jk>new</jk> Person();
	 * 	p.setBirthDate(<jk>new</jk> Date(1, 2, 3, 4, 5, 6));
	 *
	 * 	<jc>// Create a bean context and add the ISO8601 date-time filter</jc>
	 * 	BeanContext beanContext = <jk>new</jk> BeanContext().addFilter(DateFilter.<jsf>DEFAULT_ISO8601DT</jsf>);
	 *
	 * 	<jc>// Wrap our bean in a bean map</jc>
	 * 	BeanMap&lt;Person&gt; b = beanContext.forBean(p);
	 *
	 * 	<jc>// Get the field as a string (i.e. "'1901-03-03T04:05:06-5000'")</jc>
	 * 	String s = myBeanMap.getFiltered(<js>"birthDate"</js>);
	 * </p>
	 *
	 * @param property The name of the property to retrieve.
	 * @return The generalized value of the property.
	 */
	public Object getFiltered(String property) {
		BeanPropertyMeta<T> p = meta.properties.get(property);
		if (p == null)
			return null;
		return p.getFiltered(this);
	}

	/**
	 * Convenience method for setting multiple property values by passing in JSON text.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	aPersonBean.putAll(<js>"{name:'John Smith',age:21}"</js>)
	 * </p>
	 *
	 * @param json The JSON text that will get parsed into a map and then added to this map.
	 * @throws ParseException If the input contains a syntax error or is malformed.
	 */
	public void putAll(String json) throws ParseException {
		putAll(new JsonMap(json));
	}

	/**
	 * Returns the names of all properties associated with the bean.
	 * <p>
	 * 	The returned set is unmodifiable.
	 */
	@Override
	public Set<String> keySet() {
		return meta.properties.keySet();
	}

	/**
	 * Returns the specified property on this bean map.
	 * <p>
	 * 	Allows you to get and set an individual property on a bean without having a
	 * 	handle to the bean itself by using the {@link BeanMapEntry#getValue()}
	 * 	and {@link BeanMapEntry#setValue(Object)} methods.
	 * <p>
	 * 	This method can also be used to get metadata on a property by
	 * 	calling the {@link BeanMapEntry#getMeta()} method.
	 *
	 * @param propertyName The name of the property to look up.
	 * @return The bean property, or null if the bean has no such property.
	 */
	public BeanMapEntry<T> getProperty(String propertyName) {
		BeanPropertyMeta<T> p = meta.properties.get(propertyName);
		if (p == null)
			p = meta.childElementProperties == null ? null : meta.childElementProperties.get(propertyName);
		if (p == null)
			return null;
		return new BeanMapEntry<T>(this, p);
	}

	/**
	 * Returns the metadata on the specified property.
	 *
	 * @return Metadata on the specified property, or <jk>null</jk> if that property does not exist.
	 * @param propertyName The name of the bean property.
	 */
	public BeanPropertyMeta<T> getPropertyMeta(String propertyName) {
		return meta.properties.get(propertyName);
	}

	/**
	 * Returns the class type of the wrapped bean.
	 *
	 * @return The class type of the wrapped bean.
	 */
	@Override
	public ClassType<T> getClassType() {
		return this.meta.getClassType();
	}

	/**
	 * Returns all the properties associated with the bean.
	 */
	@Override
	public Set<Entry<String,Object>> entrySet() {

		// Construct our own anonymous set to implement this function.
		Set<Entry<String,Object>> s = new AbstractSet<Entry<String,Object>>() {

			// Get the list of properties from the meta object.
			// Note that the HashMap.values() method caches results, so this collection
			// will really only be constructed once per bean type since the underlying
			// map never changes.
			final Collection<BeanPropertyMeta<T>> pSet = meta.properties.values();

			@Override
			public Iterator<java.util.Map.Entry<String, Object>> iterator() {

				// Construct our own anonymous iterator that uses iterators against the meta.properties
				// map to maintain position.  This prevents us from having to construct any of our own
				// collection objects.
				return new Iterator<Entry<String,Object>>() {

					final Iterator<BeanPropertyMeta<T>> pIterator = pSet.iterator();

					@Override
					public boolean hasNext() {
						return pIterator.hasNext();
					}

					@Override
					public Map.Entry<String, Object> next() {
						return new BeanMapEntry<T>(BeanMap.this, pIterator.next());
					}

					@Override
					public void remove() {
						throw new UnsupportedOperationException("Cannot remove item from iterator.");
					}
				};
			}

			@Override
			public int size() {
				return pSet.size();
			}
		};

		return s;
	}
}