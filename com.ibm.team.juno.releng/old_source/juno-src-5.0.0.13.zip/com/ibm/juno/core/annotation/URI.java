package com.ibm.juno.core.annotation;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.*;

import java.lang.annotation.*;
import java.net.*;

/**
 * Used to identify a class or bean property as a URI.
 * <p>
 * By default, instances of {@link URL} and {@link URI} are considered URIs.
 * This annotation allows you to identify other classes that return URIs via <code>toString()</code> as URI objects.
 * <p>
 * 	This annotation can be applied to classes, interfaces, or bean property methods for fields.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Documented
@Target({TYPE,FIELD,METHOD})
@Retention(RUNTIME)
@Inherited
public @interface URI {}