package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

/**
 * Parent class for all serializers.
 * <p>
 * 	<ul class='normal'>
 * 		<li>{@link com.ibm.juno.core.json.JsonSerializer}
 * 		<li>{@link com.ibm.juno.core.xml.XmlSerializer}
 * 		<li>{@link com.ibm.juno.core.html.HtmlSerializer}
 * 		<li>{@link com.ibm.juno.core.rdfxml.RdfXmlSerializer}
 * 		<li>{@link com.ibm.juno.core.cognos.CognosSerializer}
 * 		<li>{@link com.ibm.juno.core.urlencoding.UrlEncodingSerializer}
 * 	</ul>
 *
 * <h6 class='topic'>Configurable properties</h6>
 * 	See {@link SerializerProperties} for a list of configurable properties that can be set on this class
 * 	using the {@link #setProperty(String, Object)} method.
 *
 * <h6 class='topic'>Creating Instances of Serializers</h6>
 * <p>
 * 	The serializer subclasses provide reusable static instances of serializers with commonly-used settings.
 * 	For example, the {@link com.ibm.juno.core.json.JsonSerializer#DEFAULT_STRICT} serializer can be used to produce strict JSON.
 * <p>
 * 	In addition, serializers can be constructed from scratch or cloned from existing serializers.
 * </p>
 * <p class='bcode'>
 * 	Serializer s;
 *
 * 	<jc>// Option 1: Use one of the default serializers with default settings.</jc>
 * 	s = JsonSerializer.<jsf>DEFAULT</jsf>;
 *
 * 	<jc>// Option 2: Create a serializer from scratch.</jc>
 * 	s = <jk>new</jk> JsonSerializer()
 * 		.setProperty(<jsf>USE_WHITESPACE</jsf>, <jk>true</jk>);
 *
 * 	<jc>// Option 3: Clone an existing serializer.</jc>
 * 	s = JsonSerializer.<jsf>DEFAULT</jsf>.clone()
 * 		.setProperty(<jsf>USE_WHITESPACE</jsf>, <jk>true</jk>);
 * </p>
 * <p>
 * 	The {@link com.ibm.juno.core.Serializer#lock()} method is provided to prevent serializer settings from being modified.
 * 	For example, the various <jsf>DEFAULT*</jsf> serializers are already locked so that they cannot be modified.
 * 	Cloned serializers are not initially locked even if the serializer cloned is locked.
 * 	Attempting to change a setting on a locked serializer will throw a {@link java.lang.RuntimeException}.
 * <p class='bcode'>
 * 	<jc>// Create a new serializer and lock it so that the settings cannot be modified.</jc>
 * 	Serializer s = <jk>new</jk> JsonSerializer()
 * 		.setProperty(<jsf>USE_WHITESPACE</jsf>, <jk>true</jk>)
 * 		.lock();
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class Serializer extends CoreAPI {

	/** General serializer properties currently set on this serializer. */
	protected SerializerProperties sp = new SerializerProperties();

	/**
	 * Default constructor.
	 * <p>
	 * 	A default unlocked bean context will be created for this serializer.
	 */
	protected Serializer() {
		super();
	}

	/**
	 * Constructor.
	 * @param beanContext The bean context to associate with this serializer.
	 */
	protected Serializer(BeanContext beanContext) {
		super(beanContext);
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The serializer to clone.  Underlying bean context will also be cloned.
	 */
	protected Serializer(Serializer copyFrom) {
		super(copyFrom);
		this.sp = new SerializerProperties(copyFrom.sp);
	}

	//--------------------------------------------------------------------------------
	// Properties
	//--------------------------------------------------------------------------------

	@Override
	public Serializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (sp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	/**
	 * Returns the current {@link SerializerProperties#USE_INDENTATION} setting on this serializer.
	 * @return The current {@link SerializerProperties#USE_INDENTATION} setting on this serializer.
	 */
	public boolean isUseIndentation() {
		return sp.isUseIndentation();
	}

	/**
	 * Returns the current {@link SerializerProperties#QUOTE_CHAR} setting on this serializer.
	 * @return The current {@link SerializerProperties#QUOTE_CHAR} setting on this serializer.
	 */
	public char getQuoteChar() {
		return sp.getQuoteChar();
	}

	/**
	 * Returns the current {@link SerializerProperties#URI_CONTEXT} setting on this serializer.
	 * @return The current {@link SerializerProperties#URI_CONTEXT} setting on this serializer.
	 */
	public String getUriContext() {
		return sp.getUriContext();
	}

	/**
	 * Returns the current {@link SerializerProperties#URI_AUTHORITY} setting on this serializer.
	 * @return The current {@link SerializerProperties#URI_AUTHORITY} setting on this serializer.
	 */
	public String getUriAuthority() {
		return sp.getUriAuthority();
	}

	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	/**
	 * Converts the contents of the specified object array to a list.
	 * <p>
	 * 	Works on both object and primitive arrays.
	 * <p>
	 * 	In the case of multi-dimensional arrays, the outgoing list will
	 * 	contain elements of type n-1 dimension.  i.e. if {@code type} is <code><jk>int</jk>[][]</code>
	 * 	then {@code list} will have entries of type <code><jk>int</jk>[]</code>.
	 *
	 * @param type The type of array.
	 * @param array The array being converted.
	 * @return The array as a list.
	 */
	protected List<Object> toList(Class<?> type, Object array) {
		Class<?> componentType = type.getComponentType();
		if (componentType.isPrimitive()) {
			int l = Array.getLength(array);
			List<Object> list = new ArrayList<Object>(l);
			for (int i = 0; i < l; i++)
				list.add(Array.get(array, i));
			return list;
		}
		return Arrays.asList((Object[])array);
	}

	/**
	 * Serialize the specified object to the specified writer.
	 *
	 * @param out The writer to write to.
	 * @param o The object to serialize.
	 * @param properties Optional override properties to use in this method call.
	 * @return The same writer pass in through parameter w.  Useful if you want to chain serialization commands.
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public abstract Writer serialize(Writer out, Object o, JsonMap...properties) throws IOException, SerializeException;


	/**
	 * Serialize the specified object to a string.
	 *
	 * @param o The object to serialize.
	 * @param properties Optional override properties to use in this method call.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o, JsonMap...properties) throws SerializeException {
		try {
			return serialize(new StringWriter(), o, properties).toString();
		} catch (IOException e) { // Shouldn't happen.
			throw new RuntimeException(e);
		}
	}

	/**
	 * Serialize the specified object to a string.
	 *
	 * @param o The object to serialize.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o) throws SerializeException {
		return serialize(o, new JsonMap[0]);
	}

	/**
	 * Serialize the specified object schema to a string.
	 *
	 * @param o The object to serialize.
	 * @param properties Optional override properties to use in this method call.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serializeSchema(Object o, JsonMap...properties) throws SerializeException {
		try {
			return serializeSchema(new StringWriter(), o, properties).toString();
		} catch (IOException e) { // Shouldn't happen.
			throw new RuntimeException(e);
		}
	}


	/**
	 * Serializes the schema of the specified object to the specified writer.
	 *
	 * @param out The writer to write to.
	 * @param o The object whose class type schema will be serialized.
	 * @param properties Optional override properties to use in this method call.
	 * @return The same writer pass in through parameter w.  Useful if you want to chain serialization commands.
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public Writer serializeSchema(Writer out, Object o, JsonMap...properties) throws IOException, SerializeException {
		throw new UnsupportedOperationException("serializeSchema not implemented on this serializer");
	}

	/**
	 * Generalize the specified object if a filter is associated with it.
	 *
	 * @param o The object to generalize.
	 * @return The generalized object, or null if the object is null.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected Object generalize(Object o) throws SerializeException {
		if (o == null)
			return null;
		ObjectFilter filter = beanContext.getObjectFilter(o.getClass());
		if (filter == null)
			return o;
		return filter.filter(o, beanContext);
	}

	/**
	 * Returns true if the specified property should not be serialized.
	 */
	protected boolean canIgnoreProperty(SerializerContext ctx, BeanPropertyMeta<?> pMeta) {
		if (pMeta.isHidden())
			return true;
		return false;
	}

	/**
	 * Returns true if the specified value should not be serialized.
	 */
	protected boolean canIgnoreValue(SerializerContext ctx, ClassType<?> ct, Object value) {

		if (ctx.isTrimNulls() && value == null)
			return true;

		if (value == null)
			return false;

		if (ct == null)
			ct = ClassType.OBJECT;

		if (ctx.isTrimEmptyLists()) {
			if (ct.isArray() || (ct.isObject() && value.getClass().isArray())) {
				for (Object o : (Object[])value)
					if (! canIgnoreValue(ctx, ct.getElementType(), o))
						return false;
				return true;
			}
			if (ct.isCollection() || (ct.isObject() && Collection.class.isAssignableFrom(value.getClass()))) {
				for (Object o : (Collection<?>)value)
					if (! canIgnoreValue(ctx, ct.getElementType(), o))
						return false;
				return true;
			}
		}

		if (ctx.isTrimEmptyMaps()) {
			if (ct.isMap() || (ct.isObject() && Map.class.isAssignableFrom(value.getClass()))) {
				for (Object o : ((Map<?,?>)value).values())
					if (! canIgnoreValue(ctx, ct.getValueType(), o))
						return false;
				return true;
			}
		}

		return false;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on CoreAPI
	//--------------------------------------------------------------------------------

	@Override
	public Serializer setBeanContext(BeanContext beanContext) throws LockedException {
		super.setBeanContext(beanContext);
		return this;
	}

	@Override
	public Serializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override
	public Serializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override
	public Serializer addFilters(Filter...s) throws LockedException {
		super.addFilters(s);
		return this;
	}

	@Override
	public Serializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override
	public <T> Serializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override
	public Serializer addImplClasses(Map<Class<?>,Class<?>> implClasses) throws LockedException {
		super.addImplClasses(implClasses);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public Serializer lock() {
		super.lock();
		return this;
	}

	@Override
	public Serializer clone() {
		throw new RuntimeException(new CloneNotSupportedException());
	}
}
