package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

/**
 * An implementation of a {@link ParserReader} optimized to work with {@link CharSequence} strings.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserStringReader extends ParserReader {
	private CharSequence in;
	private int pos;
	private int markPos;

	/**
	 * Constructor.
	 *
	 * @param in The String being read.
	 */
	public ParserStringReader(CharSequence in) {
		this.in = in;
		this.length = in.length();
	}

	@Override
	public int read() {
		if (isUnread) {
			isUnread = false;
			pos++;
			return lastChar;
		}
		if (pos == length)
			return -1;
		lastChar = in.charAt(pos++);
		if (lastChar == '\n') {
			line++;
			column = 0;
		} else {
			column++;
		}
		return lastChar;
	}

	@Override
	public String read(int num) throws IOException {
		if (isUnread)
			isUnread = false;
		return in.subSequence(pos, pos += num).toString();
	}

	@Override
	public int peek() throws IOException {
		return pos >= length ? -1 : in.charAt(pos);
	}

	@Override
	public void mark() {
		markPos = pos;
	}

	@Override
	public ParserReader unread() throws IOException {
		super.unread();
		pos--;
		return this;
	}

	@Override
	public String getFromMarked() {
		isMarking = false;
		return in.subSequence(markPos, pos).toString();
	}

	@Override
	public void close() throws IOException {
		// No-op
	}

	/**
	 * Returns the original input for this reader that was passed in through the constructor.
	 *
	 * @return The input for this reader.
	 */
	public CharSequence getInput() {
		return in;
	}

	@Override
	public String toString() {
		return in.toString();
	}
}
