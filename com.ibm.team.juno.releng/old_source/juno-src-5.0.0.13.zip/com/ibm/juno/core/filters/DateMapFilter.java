package com.ibm.juno.core.filters;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;

import com.ibm.juno.core.*;

/**
 * Transforms {@link Date Dates} to {@link Map Maps} of the format <tt>{value:long}</tt>.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("rawtypes")
public class DateMapFilter extends ObjectFilter<Date,Map> {

	/** Default reusable filter for serializing dates to maps of the format <tt>{time:long}</tt>. */
	public static final DateMapFilter DEFAULT = new DateMapFilter();

	/**
	 * Converts the specified {@link Date} to a {@link Map}.
	 */
	@Override
	public Map filter(Date o, BeanContext beanContext) {
		JsonMap m = new JsonMap();
		m.put("time", o.getTime());
		return m;
	}

	/**
	 * Converts the specified {@link Map} to a {@link Date}.
	 */
	@Override
	public Date unfilter(Map o, ClassType<?> hint, BeanContext beanContext) throws ParseException {
		Class<?> c = hint.getInnerClass();
		long l = Long.parseLong(((Map<?,?>)o).get("time").toString());
		if (c == java.util.Date.class)
			return new java.util.Date(l);
		if (c == java.sql.Date.class)
			return new java.sql.Date(l);
		if (c == java.sql.Time.class)
			return new java.sql.Time(l);
		if (c == java.sql.Timestamp.class)
			return new java.sql.Timestamp(l);
		throw new ParseException("DateMapFilter is unable to narrow object of type '%s'", c);
	}
}
