package com.ibm.juno.core;

import static com.ibm.juno.core.ClassType.ClassCategory.*;
import static com.ibm.juno.core.ClassType.ClassCategory.URI;

import java.io.*;
import java.lang.reflect.*;
import java.lang.reflect.Proxy;
import java.net.*;
import java.net.URI;
import java.util.*;

import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.xml.*;
import com.ibm.juno.core.xml.annotation.*;

/**
 * A wrapper class around the {@link Class} object that provides cached information
 * about that class.
 * <p>
 * 	Instances of this class can be created through the {@link BeanContext#getClassType(Class)} (and similar) method.
 * <p>
 * 	The {@link BeanContext} class will cache and reuse instances of this class except for the following class types:
 * <ul>
 * 	<li>Arrays
 * 	<li>Maps with non-Object key/values.
 * 	<li>Collections with non-Object key/values.
 * </ul>
 * <p>
 * 	This class is tied to the {@link BeanContext} class because it's that class that makes the determination
 * 	of what is a bean.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <T> The class type of the wrapped class.
 */
public class ClassType<T> implements Type {

	/** Reusable instance that represents 'anything'. */
	public static ClassType<Object> OBJECT = new ClassType<Object>(Object.class, null);

	/** Reusable instance that represents 'anything'. */
	public static ClassType<String> STRING = new ClassType<String>(String.class, null);

	/** Class categories. */
	enum ClassCategory {
		MAP, COLLECTION, NUMBER, DECIMAL, BOOLEAN, CHAR, DATE, ARRAY, ENUM, BEAN, UNKNOWN, OTHER, CHARSEQ, STR, OBJ, URI, BEANMAP, READER, INPUTSTREAM
	}

	BeanContext beanContext;                          // The bean context that created this object.
	ClassCategory classCategory = UNKNOWN;            // The class category.
	Class<T> innerClass;                              // The class being wrapped.
	ClassType<?>
		filteredClassType = this,                     // The filtered class type (in class has filter associated with it.
		elementType = null,                           // If ARRAY or COLLECTION, the element class type.
		keyType = null,                               // If MAP, the key class type.
		valueType = null;                             // If MAP, the value class type.
	Constructor<? extends T> noArgConstructor;        // The no-arg constructor for this class (if it has one).
	InvocationHandler invocationHandler;              // The invocation handler for this class (if it has one).
	volatile BeanMeta<T> beanMeta;                    // The bean meta for this bean class (if it's a bean).
	Method valueOfMethod;                             // The static valueOf(String) or fromString(String) method (if it has one).
	Constructor<T> stringConstructor;                 // The X(String) constructor (if it has one).
	String notABeanReason;                            // If this isn't a bean, the reason why.
	ObjectFilter<T,?> objectFilter;                   // The object filter associated with this bean (if it has one).
	BeanFilter<? extends T> beanFilter;               // The bean filter associated with this bean (if it has one).
	private Namespace namespace = null;
	private String elementName = null;
	private XmlFormat xmlFormat = XmlFormat.NORMAL;
	private boolean isDelegate;

	/**
	 * Construct a new {@code ClassType} based on the specified {@link Class}.
	 *
	 * @param innerClass The class being wrapped.
	 * @param beanContext The bean context that created this object.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	ClassType(Class<T> innerClass, BeanContext beanContext) {
		this.innerClass = innerClass;
		this.beanContext = beanContext;

		Filter filter = getFilter(beanContext);
		if (filter != null) {
			if (filter.isBeanFilter())
				beanFilter = (BeanFilter)filter;
			else
				objectFilter = (ObjectFilter)filter;
			filteredClassType = (objectFilter == null ? this : beanContext.getClassType(objectFilter.getFilteredClass()));
		} else {
			filteredClassType = this;
		}

		if (beanContext != null)
			this.noArgConstructor = beanContext.getConstructor(innerClass);

		Class c = innerClass;
		if (c.isPrimitive()) {
			if (c == Boolean.TYPE)
				classCategory = BOOLEAN;
			else if (c == Byte.TYPE || c == Short.TYPE || c == Integer.TYPE || c == Long.TYPE || c == Float.TYPE || c == Double.TYPE) {
				classCategory = NUMBER;
				if (c == Float.TYPE || c == Double.TYPE)
					classCategory = DECIMAL;
			}
			else if (c == Character.TYPE)
				classCategory = CHAR;
		} else {
			if (Delegate.class.isAssignableFrom(c))
				isDelegate = true;
			if (c == Object.class)
				classCategory = OBJ;
			else if (c.isEnum())
				classCategory = ENUM;
			else if (CharSequence.class.isAssignableFrom(c)) {
				if (c.equals(String.class))
					classCategory = STR;
				else
					classCategory = CHARSEQ;
			}
			else if (Number.class.isAssignableFrom(c)) {
				classCategory = NUMBER;
				if (Float.class.isAssignableFrom(c) || Double.class.isAssignableFrom(c))
					classCategory = DECIMAL;
			}
			else if (Collection.class.isAssignableFrom(c))
				classCategory = COLLECTION;
			else if (Map.class.isAssignableFrom(c)) {
				if (BeanMap.class.isAssignableFrom(c))
					classCategory = BEANMAP;
				else
					classCategory = MAP;
			}
			else if (c == Character.class)
				classCategory = CHAR;
			else if (c == Boolean.class)
				classCategory = BOOLEAN;
			else if (Date.class.isAssignableFrom(c) || Calendar.class.isAssignableFrom(c))
				classCategory = DATE;
			else if (c.isArray())
				classCategory = ARRAY;
			else if (URL.class.isAssignableFrom(c) || URI.class.isAssignableFrom(c) || c.isAnnotationPresent(com.ibm.juno.core.annotation.URI.class))
				classCategory = URI;
			else if (Reader.class.isAssignableFrom(c))
				classCategory = READER;
			else if (InputStream.class.isAssignableFrom(c))
				classCategory = INPUTSTREAM;
		}

		// Find valueOf(String) or fromString(String) methods if present.
		for (Method m : c.getMethods()) {
			int mod = m.getModifiers();
			if (Modifier.isStatic(mod) && Modifier.isPublic(mod)) {
				String mName = m.getName();
				if (mName.equals("valueOf") || mName.equals("fromString")) {
					Class<?>[] args = m.getParameterTypes();
					if (args.length == 1 && args[0] == String.class) {
						this.valueOfMethod = m;
						break;
					}
				}
			}
		}
		// Find constructor(String) method if present.
		for (Constructor cs : c.getConstructors()) {
			int mod = cs.getModifiers();
			if (Modifier.isPublic(mod)) {
				Class<?>[] args = cs.getParameterTypes();
				if (args.length == 1 && args[0] == String.class) {
					this.stringConstructor = cs;
					break;
				}
			}
		}

		if (beanContext != null) {

			// If this is an array, get the element type.
			if (classCategory == ARRAY)
				elementType = beanContext.getClassType(innerClass.getComponentType());

			// If this is a MAP, see if it's parameterized (e.g. AddressBook extends HashMap<String,Person>)
			if (classCategory == MAP) {
				ClassType[] parameters = beanContext.findParameters(innerClass, innerClass);
				if (parameters != null && parameters.length == 2) {
					keyType = parameters[0];
					valueType = parameters[1];
				} else {
					keyType = OBJECT;
					valueType = OBJECT;
				}
			}

			// If this is a COLLECTION, see if it's parameterized (e.g. AddressBook extends LinkedList<Person>)
			if (classCategory == COLLECTION) {
				ClassType[] parameters = beanContext.findParameters(innerClass, innerClass);
				if (parameters != null && parameters.length == 1) {
					elementType = parameters[0];
				} else {
					elementType = OBJECT;
				}
			}

			// Find XML-related stuff.
			elementName = findElementName(innerClass);
			namespace = findNamespace(innerClass);
			xmlFormat = findXmlFormat(innerClass);
		}
	}

	private XmlFormat findXmlFormat(Class<?> c) {
		Xml xml = c.getAnnotation(Xml.class);
		if (xml != null)
			return xml.format();
		return XmlFormat.NORMAL;
	}

	private String findElementName(Class<?> c) {
		if (c == null)
			return null;
		Xml xml = c.getAnnotation(Xml.class);
		if (xml != null && ! xml.elementName().isEmpty())
			return xml.elementName();
		String s = findElementName(c.getSuperclass());
		if (s != null)
			return s;
		for (Class<?> c2 : c.getInterfaces()) {
			s = findElementName(c2);
			if (s != null)
				return s;
		}
		return null;
	}

	/**
	 * Returns <jk>true</jk> if this class is a superclass of or the same as the specified class.
	 * @param c The comparison class.
	 * @return <jk>true</jk> if this class is a superclass of or the same as the specified class.
	 */
	public boolean isAssignableFrom(Class<?> c) {
		return innerClass.isAssignableFrom(c);
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of or the same as the specified class.
	 * @param c The comparison class.
	 * @return <jk>true</jk> if this class is a subclass of or the same as the specified class.
	 */
	public boolean isInstanceOf(Class<?> c) {
		return c.isAssignableFrom(innerClass);
	}

	private Namespace findNamespace(Class<?> c) {
		if (c == null)
			return null;

		Namespace ns = null;

		// Check for @Xml.ns and nsUri on this class.
		Xml xml = c.getAnnotation(Xml.class);
		if (xml != null) {

			// If ns or nsUri is specified.
			if (! (xml.ns().isEmpty() && xml.nsUri().isEmpty())) {

				// If both ns and nsUri is defined, use that.
				if ((!xml.ns().isEmpty()) && (!xml.nsUri().isEmpty()))
					return NamespaceFactory.get(xml.ns(), xml.nsUri());

				// If only ns is defined, need to find nsUri.
				if (! xml.ns().isEmpty()) {
					ns = findNamespaceByName(c, xml.ns());
					if (ns != null)
						return ns;
					throw new BeanRuntimeException(c, "Found @Xml.ns annotation with no matching URI.");
				}
				throw new BeanRuntimeException(c, "Found @Xml.nsUri annotation with no matching name.");
			}
		}

		// Is it defined on the package?
		Package p = c.getPackage();
		xml = (p == null ? null : p.getAnnotation(Xml.class));
		if (xml != null && ! xml.ns().isEmpty()) {
			if (xml.nsUri().isEmpty())
				ns = findNamespaceByName(p, xml.ns());
			else
				ns = NamespaceFactory.get(xml.ns(), xml.nsUri());
		}
		if (ns != null)
			return ns;

		// Check superclass
		ns = findNamespace(c.getSuperclass());
		if (ns != null)
			return ns;

		// Check interfaces
		for (Class<?> c2 : c.getInterfaces()) {
			ns = findNamespace(c2);
			if (ns != null)
				return ns;
		}

		return null;
	}

	Namespace findNamespaceByName(String name) {
		return findNamespaceByName(innerClass, name);
	}

	private Namespace findNamespaceByName(Class<?> c, String name) {
		if (c == null)
			return null;

		// Check this class.
		Xml xml = c.getAnnotation(Xml.class);
		if (xml != null) {
			for (XmlNs xmlNs : xml.namespaces()) {
				if (xmlNs.name().equals(name))
					return NamespaceFactory.get(xmlNs.name(), xmlNs.uri());
			}
		}

		// Check this package.
		Namespace ns = findNamespaceByName(c.getPackage(), name);
		if (ns != null)
			return ns;

		// Check superclass
		ns = findNamespaceByName(c.getSuperclass(), name);
		if (ns != null)
			return ns;

		// Check interfaces
		for (Class<?> c2 : c.getInterfaces()) {
			ns = findNamespaceByName(c2, name);
			if (ns != null)
				return ns;
		}

		return null;
	}

	private Namespace findNamespaceByName(Package p, String name) {
		if (p == null)
			return null;
		Xml xml = p.getAnnotation(Xml.class);
		if (xml != null) {
			for (XmlNs xmlNs : xml.namespaces()) {
				if (xmlNs.name().equals(name))
					return NamespaceFactory.get(xmlNs.name(), xmlNs.uri());
			}
		}
		return null;
	}

	private Filter getFilter(BeanContext context) {
		try {
			if (innerClass.isAnnotationPresent(Bean.class)) {
				Class<? extends Filter> c = innerClass.getAnnotation(Bean.class).filter();
				if (c != NullObjectFilter.class)
					return c.newInstance();
			}
			if (context == null)
				return null;
			return context.getFilter(innerClass);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Set element type on non-cached <code>Collection</code> types.
	 */
	protected ClassType<T> setElementType(ClassType<?> elementType) {
		this.elementType = elementType;
		return this;
	}

	/**
	 * Set key type on non-cached <code>Map</code> types.
	 */
	protected ClassType<T> setKeyType(ClassType<?> keyType) {
		this.keyType = keyType;
		return this;
	}

	/**
	 * Set value type on non-cached <code>Map</code> types.
	 */
	protected ClassType<T> setValueType(ClassType<?> valueType) {
		this.valueType = valueType;
		return this;
	}

	/**
	 * Returns the {@link Class} object that this class type wraps.
	 * @return The wrapped class object.
	 */
	public Class<T> getInnerClass() {
		return innerClass;
	}

	/**
	 * Returns the generalized form of this class if there is an {@link ObjectFilter} associated with it.
	 * @return The filtered class type, or this object if no filter is associated with the class.
	 */
	public ClassType<?> getFilteredClassType() {
		return filteredClassType;
	}

	/**
	 * For array and {@code Collection} types, returns the class type of the components of the array or {@code Collection}.
	 * @return The element class type, or <jk>null</jk> if this class is not an array or Collection.
	 */
	public ClassType<?> getElementType() {
		return elementType;
	}

	/**
	 * For {@code Map} types, returns the class type of the keys of the {@code Map}.
	 * @return The key class type, or <jk>null</jk> if this class is not a Map.
	 */
	public ClassType<?> getKeyType() {
		return keyType;
	}

	/**
	 * For {@code Map} types, returns the class type of the values of the {@code Map}.
	 * @return The value class type, or <jk>null</jk> if this class is not a Map.
	 */
	public ClassType<?> getValueType() {
		return valueType;
	}

	/**
	 * Returns <jk>true</jk> if this class implements {@link Delegate}, meaning
	 * 	it's a representation of some other object.
	 * @return <jk>true</jk> if this class implements {@link Delegate}.
	 */
	public boolean isDelegate() {
		return isDelegate;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link Map}.
	 * @return <jk>true</jk> if this class is a subclass of {@link Map}.
	 */
	public boolean isMap() {
		return classCategory == MAP || classCategory == BEANMAP;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link BeanMap}.
	 * @return <jk>true</jk> if this class is a subclass of {@link BeanMap}.
	 */
	public boolean isBeanMap() {
		return classCategory == BEANMAP;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link Collection}.
	 * @return <jk>true</jk> if this class is a subclass of {@link Collection}.
	 */
	public boolean isCollection() {
		return classCategory == COLLECTION;
	}

	/**
	 * Returns <jk>true</jk> if this class is an {@link Enum}.
	 * @return <jk>true</jk> if this class is an {@link Enum}.
	 */
	public boolean isEnum() {
		return classCategory == ENUM;
	}

	/**
	 * Returns <jk>true</jk> if this class is an array.
	 * @return <jk>true</jk> if this class is an array.
	 */
	public boolean isArray() {
		return classCategory == ARRAY;
	}

	/**
	 * Returns <jk>true</jk> if this class is a bean.
	 * @return <jk>true</jk> if this class is a bean.
	 */
	public boolean isBean() {
		// isBean and beanMeta are lazy loaded.
		if (classCategory == UNKNOWN && beanMeta == null)
			getBeanMeta();
		return classCategory == BEAN;
	}


	/**
	 * Returns <jk>true</jk> if this class is {@link Object}.
	 * @return <jk>true</jk> if this class is {@link Object}.
	 */
	public boolean isObject() {
		return classCategory == OBJ;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link Number}.
	 * @return <jk>true</jk> if this class is a subclass of {@link Number}.
	 */
	public boolean isNumber() {
		return classCategory == NUMBER || classCategory == DECIMAL;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link Float} or {@link Double}.
	 * @return <jk>true</jk> if this class is a subclass of {@link Float} or {@link Double}.
	 */
	public boolean isDecimal() {
		return classCategory == DECIMAL;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link Boolean}.
	 * @return <jk>true</jk> if this class is a {@link Boolean}.
	 */
	public boolean isBoolean() {
		return classCategory == BOOLEAN;
	}

	/**
	 * Returns <jk>true</jk> if this class is a subclass of {@link CharSequence}.
	 * @return <jk>true</jk> if this class is a subclass of {@link CharSequence}.
	 */
	public boolean isCharSequence() {
		return classCategory == STR || classCategory == CHARSEQ;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link String}.
	 * @return <jk>true</jk> if this class is a {@link String}.
	 */
	public boolean isString() {
		return classCategory == STR;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link Character}.
	 * @return <jk>true</jk> if this class is a {@link Character}.
	 */
	public boolean isChar() {
		return classCategory == CHAR;
	}

	/**
	 * Returns <jk>true</jk> if this class is a primitive.
	 * @return <jk>true</jk> if this class is a primitive.
	 */
	public boolean isPrimitive() {
		return innerClass.isPrimitive();
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link Date} or {@link Calendar}.
	 * @return <jk>true</jk> if this class is a {@link Date} or {@link Calendar}.
	 */
	public boolean isDate() {
		return classCategory == DATE;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link URI} or {@link URL}.
	 * @return <jk>true</jk> if this class is a {@link URI} or {@link URL}.
	 */
	public boolean isUri() {
		return classCategory == URI;
	}

	/**
	 * Returns <jk>true</jk> if this class is a {@link Reader}.
	 * @return <jk>true</jk> if this class is a {@link Reader}.
	 */
	public boolean isReader() {
		return classCategory == READER;
	}

	/**
	 * Returns <jk>true</jk> if this class is an {@link InputStream}.
	 * @return <jk>true</jk> if this class is an {@link InputStream}.
	 */
	public boolean isInputStream() {
		return classCategory == INPUTSTREAM;
	}

	/**
	 * Returns <jk>true</jk> if instance of this object can be <jk>null</jk>.
	 * <p>
	 * 	Objects can be <jk>null</jk>, but primitives cannot, except for chars which can be represented
	 * 	by <code>(<jk>char</jk>)0</code>.
	 * @return <jk>true</jk> if instance of this class can be null.
	 */
	public boolean isNullable() {
		if (innerClass.isPrimitive())
			return classCategory == CHAR;
		return true;
	}

	/**
	 * Returns the {@link ObjectFilter} associated with this class.
	 * @return The {@link ObjectFilter} associated with this class, or <jk>null</jk> if there is no object filter
	 * 	associated with this class.
	 */
	public ObjectFilter<T,?> getObjectFilter() {
		return objectFilter;
	}

	/**
	 * Returns the {@link BeanMeta} associated with this class.
	 * @return The {@link BeanMeta} associated with this class, or <jk>null</jk> if there is no bean meta
	 * 	associated with this class.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public BeanMeta<T> getBeanMeta() {

		if (beanMeta != null)
			return beanMeta;

		// If beanMeta is null and isBean is true, then beanMeta hasn't been initialized yet.
		if (classCategory == UNKNOWN) {

			synchronized (this) {

				// Make sure someone didn't already set it while this thread was blocked.
				if (beanMeta != null)
					return beanMeta;

				// If it has an object filter, then it's not a bean.
				if (objectFilter != null) {
					classCategory = OTHER;
					notABeanReason = "Has object filter";

				} else {
					BeanMeta newMeta = new BeanMeta(this, beanContext, beanFilter);
					notABeanReason = newMeta.init();
					if (notABeanReason != null)
						classCategory = OTHER;
					else {
						this.beanMeta = newMeta;
						this.classCategory = BEAN;
					}
				}
			}
		}

		return beanMeta;
	}

	/**
	 * Returns the no-arg constructor for this class.
	 * @return The no-arg constructor for this class, or <jk>null</jk> if it does not exist.
	 */
	public Constructor<? extends T> getConstructor() {
		return noArgConstructor;
	}

	/**
	 * Returns the XML namespace associated with this class.
	 * <p>
	 * 	Namespace is determined in the following order:
	 * <ol>
	 * 	<li>{@link Xml#ns()} annotation defined on class.
	 * 	<li>{@link Xml#ns()} annotation defined on package.
	 * 	<li>{@link Xml#ns()} annotation defined on superclasses.
	 * 	<li>{@link Xml#ns()} annotation defined on superclass packages.
	 * 	<li>{@link Xml#ns()} annotation defined on interfaces.
	 * 	<li>{@link Xml#ns()} annotation defined on interface packages.
	 * </ol>
	 * @return The namespace associated with this class, or <jk>null</jk> if no namespace is
	 * 	associated with it.
	 */
	public Namespace getNamespace() {
		return namespace;
	}

	/**
	 * Returns the {@link Xml#elementName()} annotation for this class.
	 * <p>
	 * 	XML element name is found in the following order:
	 * <ol>
	 * 	<li>{@link Xml#elementName()} annotation defined on class.
	 * 	<li>{@link Xml#elementName()} annotation defined on superclasses.
	 * 	<li>{@link Xml#elementName()} annotation defined on interfaces.
	 * </ol>
	 * @return The XML element name to use for this class, or <jk>null</jk> if no element name
	 * 	was specified.
	 */
	public String getElementName() {
		return elementName;
	}

	/**
	 * Returns the {@link Xml#format()} annotation for this class.
	 * <p>
	 * 	XML format is found in the following order:
	 * <ol>
	 * 	<li>{@link Xml#format()} annotation defined on class.
	 * 	<li>{@link Xml#format()} annotation defined on superclasses.
	 * 	<li>{@link Xml#format()} annotation defined on interfaces.
	 * </ol>
	 * @return The XML for to use for this class, or {@link XmlFormat#NORMAL} if no XML format
	 * 	was specified.
	 */
	public XmlFormat getXmlFormat() {
		return xmlFormat;
	}

	/**
	 * Returns the interface proxy invocation handler for this class.
	 * @return The interface proxy invocation handler, or <jk>null</jk> if it does not exist.
	 */
	public InvocationHandler getProxyInvocationHandler() {
		if (classCategory == UNKNOWN)
			getBeanMeta();
		if (invocationHandler == null
				&& beanContext != null
				&& beanContext.useInterfaceProxies
				&& classCategory == BEAN
				&& innerClass.isInterface()) {
			beanMeta = getBeanMeta();
			if (beanMeta != null)
				invocationHandler = new BeanProxyInvocationHandler<T>(getBeanMeta());
		}
		return invocationHandler;
	}

	/**
	 * Returns <jk>true</jk> if this class has a no-arg constructor or invocation handler.
	 * @return <jk>true</jk> if this class has a no-arg constructor or invocation handler.
	 */
	public boolean canCreateNewInstance() {
		return (getConstructor() != null || getProxyInvocationHandler() != null || (isBean() && getBeanMeta().readOnlyConstructor != null));
	}

	/**
	 * Returns <jk>true</jk> if this class can call the {@link #newInstance(String)} method.
	 * @return <jk>true</jk> if this class has a no-arg constructor or invocation handler.
	 */
	public boolean canCreateNewInstanceFromString() {
		return (valueOfMethod != null || stringConstructor != null);
	}

	/**
	 * Returns the reason why this class is not a bean, or <jk>null</jk> if it is a bean.
	 * @return The reason why this class is not a bean, or <jk>null</jk> if it is a bean.
	 */
	public String getNotABeanReason() {
		return notABeanReason;
	}

	/**
	 * Create a new instance of the main class of this declared type from a <code>String</code> input.
	 * <p>
	 * In order to use this method, the class must have one of the following methods:
	 * <ul>
	 * 	<li><code><jk>public static</jk> T valueOf(String in);</code>
	 * 	<li><code><jk>public static</jk> T fromString(String in);</code>
	 * 	<li><code><jk>public</jk> T(String in);</code>
	 *	</ul>
	 * @param arg The input argument value.
	 *
	 * @return A new instance of the object, or <jk>null</jk> if there is no no-arg constructor on the object.
	 * @throws IllegalAccessException If the <code>Constructor</code> object enforces Java language access control and the underlying constructor is inaccessible.
	 * @throws IllegalArgumentException If the parameter type on the method was invalid.
	 * @throws InstantiationException If the class that declares the underlying constructor represents an abstract class, or
	 * 	does not have one of the methods described above.
	 * @throws InvocationTargetException If the underlying constructor throws an exception.
	 */
	@SuppressWarnings("unchecked")
	public T newInstance(String arg) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException, InstantiationException {
		Method m = valueOfMethod;
		if (m != null)
			return (T)m.invoke(null, arg);
		Constructor<T> c = stringConstructor;
		if (c != null)
			return c.newInstance(arg);
		throw new InstantiationError("No string constructor or valueOf(String) method found for class '"+getInnerClass().getName()+"'");
	}


	/**
	 * Create a new instance of the main class of this declared type.
	 *
	 * @return A new instance of the object, or <jk>null</jk> if there is no no-arg constructor on the object.
	 * @throws IllegalAccessException If the <code>Constructor</code> object enforces Java language access control and the underlying constructor is inaccessible.
	 * @throws IllegalArgumentException If one of the following occurs:
	 * 	<ul>
	 * 		<li>The number of actual and formal parameters differ.
	 * 		<li>An unwrapping conversion for primitive arguments fails.
	 * 		<li>A parameter value cannot be converted to the corresponding formal parameter type by a method invocation conversion.
	 * 		<li>The constructor pertains to an enum type.
	 * 	</ul>
	 * @throws InstantiationException If the class that declares the underlying constructor represents an abstract class.
	 * @throws InvocationTargetException If the underlying constructor throws an exception.
	 */
	@SuppressWarnings("unchecked")
	public T newInstance() throws IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {
		Constructor<? extends T> c = getConstructor();
		if (c != null)
			return c.newInstance((Object[])null);
		InvocationHandler h = getProxyInvocationHandler();
		if (h != null)
			return (T)Proxy.newProxyInstance(this.getClass().getClassLoader(), new Class[] { getInnerClass(), java.io.Serializable.class }, h);
		return null;
	}

	/**
	 * Checks to see if the specified class type is the same as this one.
	 *
	 * @param t The specified class type.
	 * @return <jk>true</jk> if the specified class type is the same as the class for this type.
	 */
	public boolean equals(ClassType<?> t) {
		if (t == null)
			return false;
		return t.getInnerClass() == this.getInnerClass();
	}

	@Override
	public String toString() {
		return toString(new StringBuilder()).toString();
	}

	/**
	 * Appends this object as a readable string to the specified string builder.
	 * @param sb The string builder to append this object to.
	 * @return The same string builder passed in (for method chaining).
	 */
	protected StringBuilder toString(StringBuilder sb) {
		switch(classCategory) {
			case ARRAY:
				return elementType.toString(sb).append("[]");
			case MAP:
			case BEANMAP:
				return sb.append(innerClass.getName()).append(keyType.isObject() && valueType.isObject() ? "" : "<"+keyType+","+valueType+">");
			case COLLECTION:
				return sb.append(innerClass.getName()).append(elementType.isObject() ? "" : "<"+elementType+">");
			default:
				return sb.append(innerClass.getName());
		}
	}
}
