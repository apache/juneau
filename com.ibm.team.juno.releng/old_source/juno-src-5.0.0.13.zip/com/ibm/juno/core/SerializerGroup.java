package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Cors. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;

/**
 * Represents a group of {@link Serializer Serializers}.
 * <p>
 * 	This class servers the following purposes:
 * <ul>
 * 	<li>Associate a single {@link BeanContext} with multiple serializers to reduce {@link ClassType} caching and
 * 			make it easier to modify bean context settings with multiple simultaneous serializers.
 * 	<li>Associate serializers with content type strings.
 * </ul>
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Construct a new serializer group</jc>
 * 	SerializerGroup g = <jk>new</jk> SerializerGroup();
 *
 * 	<jc>// Add some serializerMappings to it</jc>
 * 	g.add(<jk>new</jk> JsonSerializer(), <js>"text/json"</js>, <js>"application/json"</js>)
 * 	 .add(<jk>new</jk> XmlSerializer(), <js>"text/xml"</js>);
 *
 * 	<jc>// Change bean context settings for all serializers in the group.</jc>
 * 	g.getBeanContext()
 * 		.setProperty(<jsf>REQUIRE_SERIALIZABLE</jsf>, <jk>true</jk>)
 * 		.addFilters(CalendarFilter.<jsf>DEFAULT_ISO8601DT</jsf>)
 * 		.lock();
 *
 * 	<jc>// Serialize a bean to JSON </jc>
 * 	AddressBook addressBook = <jk>new</jk> AddressBook();  <jc>// Bean to serialize.</jc>
 * 	String json = g.getSerializer(<js>"text/json"</js>).serialize(addressBook);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SerializerGroup extends Lockable {

	private Map<String,Serializer> serializerMappings = new LinkedHashMap<String,Serializer>();
	private Map<Serializer,String[]> serializers = new HashMap<Serializer,String[]>();

	/**
	 * Default constructor.
	 * <p>
	 * 	A default unlocked bean context will be created for this group.
	 */
	public SerializerGroup() {
		super();
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The group to clone.  Underlying serializers will also be cloned.
	 */
	protected SerializerGroup(SerializerGroup copyFrom) {
		for (Map.Entry<Serializer,String[]> e : copyFrom.serializers.entrySet())
			add(e.getKey().clone(), e.getValue());
	}

	/**
	 * Adds the specified serializer to this group.
	 * @param serializer The serializer being added to this group.
	 * @param contentTypes The content types handled by this serializer (e.g. <js>"text/json"</js>).
	 * @return This object (for method chaining).
	 */
	public SerializerGroup add(Serializer serializer, String...contentTypes) {
		for (String ct : contentTypes)
			serializerMappings.put(ct, serializer);
		serializers.put(serializer, contentTypes);
		return this;
	}

	/**
	 * Returns the serializer associated with the specified content type.
	 * @param contentType The content types associated to the serializer (e.g. <js>"text/json"</js>).
	 * @return The serializer, or <jk>null</jk> if no serializer is associated with the specified content type.
	 */
	public Serializer getSerializer(String contentType) {
		return serializerMappings.get(contentType);
	}

	/**
	 * Returns the content types handled by all serializers in this group.
	 * @return The set of all content types handled by all serializers in this group.
	 */
	public Set<String> getSupportedContentTypes() {
		return serializerMappings.keySet();
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on serializers
	//--------------------------------------------------------------------------------

	/**
	 * Shortcut for calling {@link Serializer#setProperty(String, Object)} on all serializers in this group.
	 * @param property The property name.
	 * @param value The property value.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public SerializerGroup setProperty(String property, Object value) throws LockedException {
		checkLock();
		for (Serializer s : serializers.keySet())
			s.setProperty(property, value);
		return this;
	}

	/**
	 * Shortcut for calling {@link Serializer#setProperties(JsonMap)} on all serializers in this group.
	 * @param properties The properties to set.  Ignored if <jk>null</jk>.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public SerializerGroup setProperties(JsonMap properties) {
		if (properties != null) {
			checkLock();
			for (Map.Entry<String,Object> e : properties.entrySet())
				setProperty(e.getKey(), e.getValue());
		}
		return this;
	}

	/**
	 * Shortcut for calling {@link Serializer#setBeanContext(BeanContext)} on all serializers in this group.
	 * @param beanContext The new bean context to associate with all serializers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public SerializerGroup setBeanContext(BeanContext beanContext) throws LockedException {
		for (Serializer s : serializers.keySet())
			s.setBeanContext(beanContext);
		return this;
	}

	/**
	 * Shortcut for calling {@link Serializer#addNotBeanClassPatterns(String[])} on all serializers in this group.
	 * @param patterns The new class patterns to add to the underlying bean context of all serializers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public SerializerGroup addNotBeanClassPatterns(String... patterns) throws LockedException {
		for (Serializer s : serializers.keySet())
			s.addNotBeanClassPatterns(patterns);
		return this;
	}

	/**
	 * Shortcut for calling {@link Serializer#addNotBeanClasses(Class[])} on all serializers in this group.
	 * @param classes The classes to specify as not-beans to the underlying bean context of all serializers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public SerializerGroup addNotBeanClasses(Class<?>...classes) throws LockedException {
		for (Serializer s : serializers.keySet())
			s.addNotBeanClasses(classes);
		return this;
	}

	/**
	 * Shortcut for calling {@link Serializer#addFilters(Filter[])} on all serializers in this group.
	 * @param filters The filters to add to the underlying bean context of all serializers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public SerializerGroup addFilters(Filter...filters) throws LockedException {
		for (Serializer s : serializers.keySet())
			s.addFilters(filters);
		return this;
	}

	/**
	 * Shortcut for calling {@link Serializer#addFilters(Class[])} on all serializers in this group.
	 * @param classes The classes to add bean filters for to the underlying bean context of all serializers in this group.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public SerializerGroup addFilters(Class<?>...classes) throws LockedException {
		for (Serializer s : serializers.keySet())
			s.addFilters(classes);
		return this;
	}

	/**
	 * Shortcut for calling {@link Serializer#addImplClass(Class, Class)} on all serializers in this group.
	 * @param <T> The interface or abstract class type.
	 * @param interfaceClass The interface or abstract class.
	 * @param implClass The implementation class.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public <T> SerializerGroup addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		for (Serializer s : serializers.keySet())
			s.addImplClass(interfaceClass, implClass);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public SerializerGroup lock() {
		super.lock();
		this.serializerMappings = Collections.unmodifiableMap(serializerMappings);
		this.serializers = Collections.unmodifiableMap(serializers);
		for (Serializer s : serializers.keySet())
			s.lock();
		return this;
	}

	@Override
	public SerializerGroup clone() {
		return new SerializerGroup(this);
	}
}
