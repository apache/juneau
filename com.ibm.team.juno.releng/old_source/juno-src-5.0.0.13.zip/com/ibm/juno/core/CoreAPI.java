package com.ibm.juno.core;

import java.util.*;


/**
 * Common super class for all serializers, parsers, and serializer/parser groups.
 * <p>
 * 	All subclasses use an instance of a bean context.  This class
 * 	allows those subclasses to access that bean context in a common way.
 * <p>
 * 	Also provides a mechanism for locking settings on the class.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class CoreAPI extends Lockable {

	/** The bean context used by this object. */
	protected BeanContext beanContext;

	/**
	 * Default constructor.
	 * <p>
	 * 	A default unlocked bean context will be created for this object.
	 */
	protected CoreAPI() {
		this(new BeanContext());
	}

	/**
	 * Constructor.
	 * @param beanContext The bean context to associate with this object.
	 */
	protected CoreAPI(BeanContext beanContext) {
		this.beanContext = beanContext;
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The object to clone.  Underlying bean context will also be cloned.
	 */
	protected CoreAPI(CoreAPI copyFrom) {
		this.beanContext = copyFrom.beanContext.clone();
	}

	/**
	 * Sets the {@code beanContext} setting on this object.
	 *
	 * @param beanContext The new value for this setting.  Default is {@link BeanContext#DEFAULT}.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public CoreAPI setBeanContext(BeanContext beanContext) throws LockedException {
		checkLock();
		this.beanContext = beanContext;
		return this;
	}

	/**
	 * Returns the current value of the {@code beanContext} setting.
	 * @return The current setting value.
	 */
	public BeanContext getBeanContext() {
		return beanContext;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on BeanContext
	//--------------------------------------------------------------------------------

	/**
	 * Sets a property on this class.
	 * @param property The property name.
	 * @param value The property value.
	 * @return This class (for method chaining).
	 * @throws LockedException If {@link #lock()} has been called on this object.
	 */
	public CoreAPI setProperty(String property, Object value) throws LockedException {
		checkLock();
		beanContext.setProperty(property, value);
		return this;
	}

	/**
	 * Sets multiple properties on this class.
	 * @param properties The properties to set on this class.
	 * @return This class (for method chaining).
	 * @throws LockedException If {@link #lock()} has been called on this object.
	 */
	public CoreAPI setProperties(JsonMap properties) throws LockedException {
		checkLock();
		beanContext.setProperties(properties);
		return this;
	}

	/**
	 * Shortcut for calling <code>getBeanContext().addNotBeanClassPatterns(String...)</code>.
	 * @see BeanContext#addNotBeanClassPatterns(String...)
	 * @param patterns The new setting value for the bean context.
	 * @throws LockedException If {@link BeanContext#lock()} was called on this class or the bean context.
	 * @return This object (for method chaining).
	 */
	public CoreAPI addNotBeanClassPatterns(String... patterns) throws LockedException {
		beanContext.addNotBeanClassPatterns(patterns);
		return this;
	}

	/**
	 * Shortcut for calling <code>getBeanContext().addNotBeanClasses(Class...)</code>.
	 * @see BeanContext#addNotBeanClasses(Class...)
	 * @param classes The new setting value for the bean context.
	 * @throws LockedException If {@link BeanContext#lock()} was called on this class or the bean context.
	 * @return This object (for method chaining).
	 */
	public CoreAPI addNotBeanClasses(Class<?>...classes) throws LockedException {
		beanContext.addNotBeanClasses(classes);
		return this;
	}

	/**
	 * Shortcut for calling <code>getBeanContext().addFilters(Filter...)</code>.
	 * @see BeanContext#addFilters(Filter...)
	 * @param s The new setting value for the bean context.
	 * @throws LockedException If {@link BeanContext#lock()} was called on this class or the bean context.
	 * @return This object (for method chaining).
	 */
	public CoreAPI addFilters(Filter...s) throws LockedException {
		beanContext.addFilters(s);
		return this;
	}

	/**
	 * Shortcut for calling <code>getBeanContext().addFilters(Class...)</code>.
	 * @see BeanContext#addFilters(Class...)
	 * @param classes The new setting value for the bean context.
	 * @throws LockedException If {@link BeanContext#lock()} was called on this class or the bean context.
	 * @return This object (for method chaining).
	 */
	public CoreAPI addFilters(Class<?>...classes) throws LockedException {
		beanContext.addFilters(classes);
		return this;
	}

	/**
	 * Shortcut for calling <code>getBeanContext().addImplClass(Class, Class)</code>.
	 * @see BeanContext#addImplClass(Class, Class)
	 * @param interfaceClass The interface class.
	 * @param implClass The implementation class.
	 * @throws LockedException If {@link BeanContext#lock()} was called on this class or the bean context.
	 * @param <T> The class type of the interface.
	 * @return This object (for method chaining).
	 */
	public <T> CoreAPI addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		beanContext.addImplClass(interfaceClass, implClass);
		return this;
	}

	/**
	 * Shortcut for calling <code>getBeanContext().addImplClasses(Map)</code>.
	 * @param implClasses The implementation class mappings to add to this context.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public CoreAPI addImplClasses(Map<Class<?>,Class<?>> implClasses) throws LockedException {
		checkLock();
		beanContext.addImplClasses(implClasses);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public CoreAPI lock() {
		super.lock();
		beanContext.lock();
		return this;
	}

	@Override
	public CoreAPI clone() {
		throw new RuntimeException(new CloneNotSupportedException());
	}
}
