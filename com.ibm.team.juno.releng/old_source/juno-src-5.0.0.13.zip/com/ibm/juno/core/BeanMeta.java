package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.beans.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.xml.annotation.*;


/**
 * Encapsulates all access to the properties of a bean class (like a souped-up {@link java.beans.BeanInfo}).
 * <p>
 * 	Uses introspection to find all the properties associated with this class.  If the {@link Bean @Bean} annotation
 * 	is present on the class, or the class has a {@link BeanFilter} registered with it in the bean context,
 * 	then that information is used to determine the properties on the class.
 * 	Otherwise, the {@code BeanInfo} functionality in Java is used to determine the properties on the class.
 * <p>
 * 	The order of the properties are as follows:
 * 	<ul>
 * 		<li>If {@link Bean @Bean} annotation is specified on class, then the order is the same as the list of properties in the annotation.
 * 		<li>If {@link Bean @Bean} annotation is not specified on the class, then the order is based on the following.
 * 			<ul>
 * 				<li>Public fields (same order as {@code Class.getFields()}).
 * 				<li>Properties returned by {@code BeanInfo.getPropertyDescriptors()}.
 * 				<li>Non-standard getters/setters with {@link BeanProperty @BeanProperty} annotation defined on them.
 * 			</ul>
 * 	</ul>
 * 	<br>
 * 	The order can also be overridden through the use of a {@link BeanFilter}.
 *
 * @param <T> The class type that this metadata applies to.
 * @author Barry M. Caceres
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class BeanMeta<T> {

	/** The target class type that this meta object describes. */
	protected ClassType<T> classType;

	/** The target class that this meta object describes. */
	protected Class<T> c;

	/** The properties on the target class. */
	protected Map<String,BeanPropertyMeta<T>> properties;

	/** The getter properties on the target class. */
	protected Map<Method,String> getterProps = new HashMap<Method,String>();

	/** The setter properties on the target class. */
	protected Map<Method,String> setterProps = new HashMap<Method,String>();

	/** The bean context that created this metadata object. */
	protected BeanContext beanContext;

	/** Optional bean filter associated with the target class. */
	protected BeanFilter<? extends T> filter;

	/** Type variables implemented by this bean. */
	protected Map<Class<?>,Class<?>[]> typeVarImpls;

	/** For beans with constructors with BeanConstructor annotation, this is the list of constructor arg properties. */
	protected String[] readOnlyConstructorProperties;

	/** For beans with constructors with BeanConstructor annotation, this is the annotated constructor. */
	protected Constructor<T> readOnlyConstructor;

	private PropertyNamer propertyNamer;
	Map<String,BeanPropertyMeta<T>> xmlAttrs;
	Map<String,BeanPropertyMeta<T>> childElementProperties;
	BeanPropertyMeta<T> beanUriProperty;


	BeanMeta() {}

	/**
	 * Constructor.
	 *
	 * @param classType The target class.
	 * @param beanContext The bean context that created this object.
	 * @param filter Optional bean filter associated with the target class.  Can be <jk>null</jk>.
	 */
	@SuppressWarnings("unchecked")
	protected BeanMeta(ClassType<T> classType, BeanContext beanContext, BeanFilter<? extends T> filter) {
		this.classType = classType;
		this.beanContext = beanContext;
		this.filter = filter;
		this.c = (Class<T>)(filter == null ? classType.getInnerClass() : filter.forClass());
	}

	/**
	 * Returns the class type of this bean.
	 * @return The class type of this bean.
	 */
	public ClassType<T> getClassType() {
		return classType;
	}

	/**
	 * Initializes this bean meta, and returns an error message if the specified class is not
	 * a bean for any reason.
	 *
	 * @return Reason why this class isn't a bean, or <jk>null</jk> if no problems detected.
	 */
	@SuppressWarnings("unchecked")
	protected String init() throws BeanRuntimeException {

		try {

			Bean ba = c.getAnnotation(Bean.class);
			boolean addClassProperty = (ba != null ? ba.addClassProperty() : false);

			Map<String,BeanPropertyMeta<T>> normalProps = new LinkedHashMap<String,BeanPropertyMeta<T>>();

			/// See if this class matches one the patterns in the exclude-class list.
			if (beanContext.isIgnoredClass(c))
				return "Class matches exclude-class list";

			// Get the associated property descriptors for this class.
			PropertyDescriptor[] propertyDescriptors = getProperties(c);

			// Make sure it's serializable.
			if (ba == null && beanContext.beansRequireSerializable && !Serializable.class.isAssignableFrom(c))
				return "Class is not serializable";

			// Look for @BeanConstructor constructor.
			for (Constructor<?> x : c.getConstructors()) {
				if (x.isAnnotationPresent(BeanConstructor.class)) {
					if (readOnlyConstructor != null)
						throw new BeanRuntimeException(c, "Multiple instances of '@BeanConstructor' found.");
					readOnlyConstructor = (Constructor<T>)x;
					readOnlyConstructorProperties = x.getAnnotation(BeanConstructor.class).properties();
					if (readOnlyConstructorProperties.length != x.getParameterTypes().length)
						throw new BeanRuntimeException(c, "Number of properties defined in '@BeanConstructor' annotation does not match number of parameters in constructor.");
					if (! Modifier.isPublic(readOnlyConstructor.getModifiers()))
						throw new BeanRuntimeException(c, " '@BeanConstructor' annotation used on a non-public constructor.");
				}
			}

			// Make sure it has a no-arg constructor.
			Constructor<?> noArgConstructor = classType.getConstructor();
			if (noArgConstructor == null) {
				if (readOnlyConstructor == null) {
					if (ba != null && addClassProperty)
						throw new BeanRuntimeException(c, "Class is denoted as 'addClassProperty' but does not have the required no-arg constructor");
					if (ba == null && beanContext.beansRequireDefaultConstructor)
						return "Class does not have the required no-arg constructor";
				}
			} else {
				if (beanContext.beansRequireDefaultConstructor && ! Modifier.isPublic(noArgConstructor.getModifiers()))
					return "No-arg constructor is not declared public.";
			}

			// Explicitly defined property names in @Bean annotation.
			Set<String> fixedBeanProps = new LinkedHashSet<String>();

			if (ba != null) {

				// Get the 'properties' attribute if specified.
				for (String p : ba.properties())
					fixedBeanProps.add(p);

				// Make sure an object filter isn't associated with it.
				if (classType.getObjectFilter() != null)
					return "Class has an object filter associated with it";

				propertyNamer = ba.propertyNamer().newInstance();
			}

			if (propertyNamer == null)
				propertyNamer = new PropertyNamerDefault();

			// First populate the properties with those specified in the bean annotation to
			// ensure that ordering first.
			for (String name : fixedBeanProps)
				normalProps.put(name, new BeanPropertyMeta<T>(this, name));

			// Get all public fields.
			// Note that if 'BeanContext.includeBeanFieldProperties' is false, we still want to pick up public fields with @BeanProperty annotations.
			for (Field f : c.getFields()) {
				String name = findPropertyName(f, beanContext.includeBeanFieldProperties, fixedBeanProps);
				if (name != null) {
					if (! normalProps.containsKey(name))
						normalProps.put(name, new BeanPropertyMeta<T>(this, name));
					normalProps.get(name).setField(f);
				}
			}

			// Get all getters and setters.
			if (beanContext.includeBeanMethodProperties) {

				Map<String,Method> fluentSetters = new HashMap<String,Method>();

				// Prepopulate props with getters to maintain proper order.
				for (Method m : c.getMethods()) {
					String name = findPropertyName(m, beanContext.includeBeanMethodProperties, fixedBeanProps);
					if (name != null) {
						if (! normalProps.containsKey(name)) {
							BeanPropertyMeta<T> p = new BeanPropertyMeta<T>(this, name);
							normalProps.put(name, p);
						}

						// java.beans.Introspector doesn't find fluent-style setters, so keep track of them.
						if (m.getName().startsWith("set") && m.getParameterTypes().length == 1 && m.getReturnType().isAssignableFrom(c))
							fluentSetters.put(name, m);
					}
				}

				for (PropertyDescriptor pd : propertyDescriptors) {
					Method getter = pd.getReadMethod();
					Method setter = pd.getWriteMethod();
					if (setter == null)
						setter = fluentSetters.get(pd.getName());
					String name = propertyNamer.getPropertyName(pd.getName());
					if (fixedBeanProps.isEmpty() || fixedBeanProps.contains(name)) {
						if (getPropertyAnnotationName(getter) != null)
							getter = null;
						if (getPropertyAnnotationName(setter) != null)
							setter = null;
						if (! normalProps.containsKey(name))
							normalProps.put(name, new BeanPropertyMeta<T>(this, name));
						normalProps.get(name).setGetter(getter).setSetter(setter);
					}
				}
			}

			// Get methods with @BeanProperty annotations on them.
			for (Method m : c.getMethods()) {
				if (m.isAnnotationPresent(BeanProperty.class)) {
					String name = findPropertyName(m, beanContext.includeBeanMethodProperties, fixedBeanProps);
					if (name != null) {
						BeanPropertyMeta<T> p = normalProps.get(name);
						int l = m.getParameterTypes().length;
						if (l == 0)
							p.setGetter(m);
						else if (l == 1)
							p.setSetter(m);
						else
							throw new BeanRuntimeException("Cannot use @BeanProperty annotation on method with more than 1 parameter");
					}
				}
			}

			typeVarImpls = new HashMap<Class<?>,Class<?>[]>();
			findTypeVarImpls(c, typeVarImpls);
			if (typeVarImpls.isEmpty())
				typeVarImpls = null;

			xmlAttrs = new LinkedHashMap<String,BeanPropertyMeta<T>>();

			// Eliminate invalid properties, and set the contents of getterProps and setterProps.
			for (Iterator<BeanPropertyMeta<T>> i = normalProps.values().iterator(); i.hasNext();) {
				BeanPropertyMeta<T> p = i.next();
				try {
					if (p.validate()) {

						if (p.getGetter() != null)
							getterProps.put(p.getGetter(), p.getName());

						if (p.getSetter() != null)
							setterProps.put(p.getSetter(), p.getName());

						if (p.getXmlFormat() == XmlFormat.ATTR)
							xmlAttrs.put(p.getName(), p);

						if (p.isBeanUri())
							beanUriProperty = p;

					} else {
						i.remove();
					}
				} catch (ClassNotFoundException e) {
					throw new BeanRuntimeException(c, e.getLocalizedMessage());
				}
			}

			// Check for missing properties.
			for (String fp : fixedBeanProps)
				if (! normalProps.containsKey(fp))
					throw new BeanRuntimeException(c, "The property '%s' was defined on the @Bean(properties=X) annotation but wasn't found on the class definition.", fp);

			// Mark constructor arg properties.
			if (readOnlyConstructor != null) {
				for (String fp : readOnlyConstructorProperties) {
					BeanPropertyMeta<T> m = normalProps.get(fp);
					if (m == null)
						throw new BeanRuntimeException(c, "The property '%s' was defined on the @BeanConstructor(properties=X) annotation but wasn't found on the class definition.", fp);
					m.setAsConstructorArg();
				}
			}

			// Make sure at least one property was found.
			if (ba == null && beanContext.beansRequireSomeProperties && normalProps.size() == 0)
				return "No properties detected on bean class";

			properties = new LinkedHashMap<String,BeanPropertyMeta<T>>();

			properties.putAll(normalProps);

			// If a filter is defined, look for inclusion and exclusion lists.
			if (filter != null) {

				// Eliminated excluded properties if BeanFilter.excludeKeys is specified.
				if (filter.excludeKeys != null) {
					for (String k : filter.excludeKeys)
						properties.remove(k);

				// Only include specified properties if BeanFilter.includeKeys is specified.
				// Note that the order must match includeKeys.
				} else if (filter.includeKeys != null) {
					Map<String,BeanPropertyMeta<T>> properties2 = new LinkedHashMap<String,BeanPropertyMeta<T>>();
					for (String k : filter.includeKeys) {
						if (properties.containsKey(k))
							properties2.put(k, properties.get(k));
					}
					properties = properties2;
				}
			}

			// We return this through the Bean.keySet() interface, so make sure it's not modifiable.
			properties = Collections.unmodifiableMap(properties);

			// Look for any properties with @Xml.childElementName specified.
			for (BeanPropertyMeta<T> p : properties.values()) {
				if (p.getChildElementName() != null) {
					String n = p.getChildElementName();
					if (childElementProperties == null)
						childElementProperties = new LinkedHashMap<String,BeanPropertyMeta<T>>();
					if (childElementProperties.containsKey(n))
						throw new BeanRuntimeException(c, "The same @Xml.childElementName value of '%s' was defined on multiple bean properties.", n);
					childElementProperties.put(n, p);
				}
			}

		} catch (BeanRuntimeException e) {
			throw e;
		} catch (Exception e) {
			return "Exception:  " + e.getLocalizedMessage();
		}

		return null;
	}

	private PropertyDescriptor[] getProperties(Class<?> c1) throws IntrospectionException {
		if (! c1.isInterface())
			return Introspector.getBeanInfo(c1, Object.class).getPropertyDescriptors();
		if (c1.getInterfaces().length == 0)
			return Introspector.getBeanInfo(c1, null).getPropertyDescriptors();

		// Introspector doesn't look beyond one level of interfaces, so if we have an interface
		// that extends another interface, we have to get those properties separately.
		return getInterfaceProperties(c1, new LinkedHashMap<String,PropertyDescriptor>()).values().toArray(new PropertyDescriptor[0]);
	}

	private Map<String,PropertyDescriptor> getInterfaceProperties(Class<?> c1, Map<String,PropertyDescriptor> m) throws IntrospectionException {
		for (PropertyDescriptor p : Introspector.getBeanInfo(c1, null).getPropertyDescriptors())
			m.put(p.getName(), p);
		for (Class<?> c2 : c1.getInterfaces())
			getInterfaceProperties(c2, m);
		return m;
	}

	/**
	 * Returns the metadata on all properties associated with this bean.
	 *
	 * @return Metadata on all properties associated with this bean.
	 */
	public Collection<BeanPropertyMeta<T>> getMetaProperties() {
		return this.properties.values();
	}

	/**
	 * Returns the list of properties annotated with an {@link Xml#format()} of {@link XmlFormat#ATTR}.
	 * In other words, the list of properties that should be rendered as XML attributes instead of child elements.
	 *
	 * @return Metadata on the XML attribute properties of the bean.
	 */
	public Map<String,BeanPropertyMeta<T>> getXmlAttrProperties() {
		return xmlAttrs;
	}

	/**
	 * Returns metadata about the specified property.
	 *
	 * @param name The name of the property on this bean.
	 * @return The metadata about the property, or <jk>null</jk> if no such property exists
	 * 	on this bean.
	 */
	public BeanPropertyMeta<T> getMetaProperty(String name) {
		return this.properties.get(name);
	}

	private String getPropertyAnnotationName(Method m) {
		if (m == null)
			return null;
		BeanProperty p = m.getAnnotation(BeanProperty.class);
		if (p == null)
			return null;
		String name = p.name();
		if (name.isEmpty())
			return null;
		return name;
	}

	/**
	 * Returns the property name of the specified method if it appears to be a valid getter, or has
	 * 	a BeanProperty annotation associated with it.
	 */
	private String findPropertyName(Method m, boolean includeGettersByDefault, Set<String> fixedBeanProps) {
		BeanProperty bp = m.getAnnotation(BeanProperty.class);
		int mod = m.getModifiers();
		if ((! Modifier.isPublic(mod)) || Modifier.isStatic(mod) || Modifier.isTransient(mod))
			return null;
		if (includeGettersByDefault || bp != null) {
			if (bp != null && ! bp.name().equals("")) {
				String name = bp.name();
				if (fixedBeanProps.isEmpty() || fixedBeanProps.contains(name))
					return name;
				throw new BeanRuntimeException(c, "Method property '%s' identified in @BeanProperty, but missing from @Bean", name);
			}
			int numParams = m.getParameterTypes().length;
			String name = m.getName();
			if (name.startsWith("is") && numParams == 0)
				name = name.substring(2);
			else if (name.startsWith("get") && numParams == 0)
				name = name.substring(3);
			else if (name.startsWith("set") && numParams == 1)
				name = name.substring(3);
			else
				return null;
			name = propertyNamer.getPropertyName(name);
			if (fixedBeanProps.isEmpty() || fixedBeanProps.contains(name))
				return name;
		}
		return null;
	}


	/**
	 * Returns the property name of the specified field if it's a valid property.
	 * Returns null if the field isn't a valid property.
	 */
	private String findPropertyName(Field f, boolean includeFieldsByDefault, Set<String> fixedBeanProps) {
		BeanProperty bp = f.getAnnotation(BeanProperty.class);
		int mod = f.getModifiers();
		if ((! Modifier.isPublic(mod)) || Modifier.isStatic(mod) || Modifier.isTransient(mod))
			return null;
		if (includeFieldsByDefault || bp != null) {
			if (bp != null && ! bp.name().equals("")) {
				String name = bp.name();
				if (fixedBeanProps.isEmpty() || fixedBeanProps.contains(name))
					return name;
				throw new BeanRuntimeException(c, "Method property '%s' identified in @BeanProperty, but missing from @Bean", name);
			}
			String name = propertyNamer.getPropertyName(f.getName());
			if (fixedBeanProps.isEmpty() || fixedBeanProps.contains(name))
				return name;
		}
		return null;
	}

	/**
	 * Recursively determines the classes represented by parameterized types in the class hierarchy of
	 * the specified type, and puts the results in the specified map.<br>
	 * <p>
	 * 	For example, given the following classes...
	 * <p class='bcode'>
	 * 	public static class BeanA&lt;T> {
	 * 		public T x;
	 * 	}
	 * 	public static class BeanB extends BeanA&lt;Integer>} {...}
	 * <p>
	 * 	...calling this method on {@code BeanB.class} will load the following data into {@code m} indicating
	 * 	that the {@code T} parameter on the BeanA class is implemented with an {@code Integer}:
	 * <p class='bcode'>
	 * 	{BeanA.class:[Integer.class]}
	 * <p>
	 * 	TODO:  This code doesn't currently properly handle the following situation:
	 * <p class='bcode'>
	 * 	public static class BeanB&ltT extends Number> extends BeanA&ltT>;
	 * 	public static class BeanC extends BeanB&ltInteger>;
	 * <p>
	 * 	When called on {@code BeanC}, the variable will be detected as a {@code Number}, not an {@code Integer}.<br>
	 * 	If anyone can figure out a better way of doing this, please do so!
	 *
	 * @param t The type we're recursing.
	 * @param m Where the results are loaded.
	 */
	private static void findTypeVarImpls(Type t, Map<Class<?>,Class<?>[]> m) {
		if (t instanceof Class) {
			Class<?> c = (Class<?>)t;
			findTypeVarImpls(c.getGenericSuperclass(), m);
			for (Type ci : c.getGenericInterfaces())
				findTypeVarImpls(ci, m);
		} else if (t instanceof ParameterizedType) {
			ParameterizedType pt = (ParameterizedType)t;
			Type rt = pt.getRawType();
			if (rt instanceof Class) {
				Type[] gImpls = pt.getActualTypeArguments();
				Class<?>[] gTypes = new Class[gImpls.length];
				for (int i = 0; i < gImpls.length; i++) {
					Type gt = gImpls[i];
					if (gt instanceof Class)
						gTypes[i] = (Class<?>)gt;
					else if (gt instanceof TypeVariable) {
						TypeVariable<?> tv = (TypeVariable<?>)gt;
						for (Type upperBound : tv.getBounds())
							if (upperBound instanceof Class)
								gTypes[i] = (Class<?>)upperBound;
					}
				}
				m.put((Class<?>)rt, gTypes);
				findTypeVarImpls(pt.getRawType(), m);
			}
		}
	}

	@Override
	public String toString() {
		return c.getName();
	}
}
