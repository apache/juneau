package com.ibm.juno.server.serializers;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.SerializerProperties.*;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.xml.*;
import com.ibm.juno.server.*;

/**
 * Serializes POJOs to HTTP responses as XML.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"text/xml"</js></ul></td>
 * 		<td><ul><li><js>"text/xml"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlRestSerializer extends RestSerializerSerializer {

	private XmlSerializer serializer;

	/**
	 * Constructor using {@link XmlSerializer#DEFAULT} as the POJO serializer.
	 */
	public XmlRestSerializer() {
		this(XmlSerializer.DEFAULT_CONDENSED.clone());
	}

	/**
	 * Construct using the specified {@link XmlSerializer} as the POJO serializer.
	 * @param serializer The serializer.
	 */
	public XmlRestSerializer(XmlSerializer serializer) {
		super(serializer);
		this.serializer = serializer;
	}

	@Override
	public void serialize(RestRequest req, Object output, Writer out, JsonMap properties, String matchingAccept) throws IOException, SerializeException {
		boolean useIndentation = properties.getBoolean(USE_INDENTATION, serializer.isUseIndentation());
		char quoteChar = properties.get(char.class, QUOTE_CHAR, serializer.getQuoteChar());
		String uriContext = properties.getString(URI_CONTEXT, serializer.getUriContext());
		String uriAuthority = properties.getString(URI_AUTHORITY, serializer.getUriAuthority());
		XmlSerializerWriter w = new XmlSerializerWriter(out, useIndentation, quoteChar, uriContext, uriAuthority);
		w.append("<?xml")
			.attr("version", "1.0")
			.attr("encoding", "UTF-8")
			.appendln("?>");
		serializer.serialize(w, output, properties);
		w.flush();
		w.close();
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"text/xml"};
	}
}
