package com.ibm.juno.server.serializers;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.server.*;

/**
 * Serializes POJOs to HTTP responses as Java {@link ObjectOutputStream ObjectOutputStreams}.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"application/x-java-serialized-object"</js></ul></td>
 * 		<td><ul><li><js>"application/x-java-serialized-object"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JavaObjectRestSerializer extends RestSerializer {

	@Override
	public void serialize(RestRequest req, RestResponse res) throws IOException {
		ObjectOutputStream oos = new ObjectOutputStream(res.getOutputStream());
		oos.writeObject(res.getOutput());
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"application/x-java-serialized-object"};
	}
}
