package com.ibm.juno.server;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.server.annotation.*;

/**
 * Used for serializing POJOs returned by REST Java methods to the HTTP response.
 * <p>
 * 	Subclasses must implement the {@link #getMediaTypes()} and {@link RestSerializer#serialize(RestRequest, Object, Writer, JsonMap, String)} methods.
 * <p>
 * 	Subclasses can optionally implement the {@link #getResponseContentType()} and {@link #getHeaders(RestRequest, JsonMap)} methods.
 * <p>
 * 	For the most part, it's usually just a wrapper around an existing {@link Serializer} object that allows
 * 	you to set additional language-specific information (such as an HTML body or XML declaration tag).
 * 	However, there is no requirement that instances of this class use a serializer.
 * <p>
 * 	<code>RestSerializers</code> are registered with {@link RestServlet RestServlets} in one of the following ways:
 * <ul>
 * 	<li>Through the use of a {@link RestResource#serializers()} annotation.
 * 	<li>Through the use of a {@link RestMethod#serializers()} annotation.
 * 	<li>By overriding the {@link RestServlet#getSerializerGroup()} method and manually constructing the
 * 		{@link RestSerializerGroup} for the resource.
 *	</ul>
 * <p>
 * 	See {@link RestSerializerGroup} for more information.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class RestSerializer {

	private MediaRange[] mediaTypes;

	/**
	 * Method called by the servlet to invoke this serializer.
	 */
	void handle(RestRequest req, RestResponse res) throws IOException, SerializeException {
		JsonMap headers = getHeaders(req, res.getProperties());
		for (String key : headers.keySet())
			res.setHeader(key, headers.getString(key));
		String ct = getResponseContentType();
		if (ct != null)
			res.setContentType(ct);
		serialize(req, res);
	}

	/**
	 * Normal serialization method.
	 * <p>
	 * Most subclasses can use this method for serialization.
	 * <p>
	 * The writer will be automatically flushed and closed after this method call.
	 *
	 * @param req The HTTP request object, for optionally accessing request information.
	 * @param output The POJO output response returned by the REST Java method or set via {@link RestResponse#setOutput(Object)} that
	 * 	this serializer should serialize.
	 * @param out The negotiated output writer returned by {@link RestResponse#getWriter()}.
	 * @param properties The response properties which are a combination of the following:
	 * 	<ul>
	 * 		<li>Properties set on the REST servlet via {@link RestResource#properties()}.
	 * 		<li>Properties set on the REST Java method via {@link RestMethod#properties()}.
	 * 		<li>Properties set programmatically via {@link RestResponse#setProperty(String, Object)}.
	 * 	</ul>
	 * @param mediaType The <code>media-type</code> portion of the <code>Content-Type</code> response header.
	 * @throws IOException Thrown if a problem occurred trying to send output to the output stream.
	 * @throws SerializeException Thrown if a problem occurred trying to convert output.
	 */
	public void serialize(RestRequest req, Object output, Writer out, JsonMap properties, String mediaType) throws IOException, SerializeException {
		throw new UnsupportedOperationException();
	}

	/**
	 * Lower-level serialization method.
	 * <p>
	 * Subclasses that need full access to the {@link RestResponse} method can use this method for serialization.
	 * <p>
	 * For example, if this serializer writes out a byte stream instead of a character stream, this method
	 * can be used to access the {@link RestResponse#getOutputStream()} method.
	 * <p>
	 * The POJO output object can be accessed through {@link RestResponse#getOutput()}.
	 * <p>
	 * The response properties (set via {@link RestResponse#setProperty(String, Object)} can be accessed through {@link RestResponse#getProperties()}.
	 *
	 * @param req The HTTP request object.
	 * @param res The HTTP response object.
	 * @throws IOException Thrown if a problem occurred trying to send output to the output stream.
	 * @throws SerializeException Thrown if a problem occurred trying to convert output.
	 */
	public void serialize(RestRequest req, RestResponse res) throws IOException, SerializeException {
		Writer w = res.getWriter();
		serialize(req, res.getOutput(), w, res.getProperties(), res.getMediaType());
		w.close();
	}

	/**
	 * Returns the HTTP <code>Accept</code> media-type values that this serializer handles.
	 * @return The HTTP <code>Accept</code> media-type values that this serializer handles.
	 */
	public abstract String[] getMediaTypes();

	MediaRange[] getMediaTypeRanges() {
		if (mediaTypes == null) {
			String[] accept = getMediaTypes();
			List<MediaRange> l = new LinkedList<MediaRange>();
			for (int i = 0; i < accept.length; i++)
				l.addAll(Arrays.asList(MediaRange.parse(accept[i])));
			mediaTypes = l.toArray(new MediaRange[l.size()]);
		}
		return mediaTypes;
	}

	/**
	 * Optionally specify the HTTP <code>Content-Type</code> on the response header.
	 * <p>
	 * This overrides the header value normally set to the matching value from the {@link #getMediaTypes()} method.
	 *
	 * @return The HTTP content type that this serializer produces, or <jk>null</jk>
	 * 	to just use the matching <code>Accept</code> value.
	 */
	public String getResponseContentType() {
		return null;
	}

	/**
	 * Optionally returns a set of HTTP header values to set on the response object before the
	 * 	{@link #serialize(RestRequest, Object, Writer, JsonMap, String)} method is called.
	 * <p>
	 * By default, returns an empty {@link JsonMap} object initialized with the {@link BeanContext}
	 * 	of the servlet returned by the {@link RestServlet#getBeanContext()} method.
	 * Therefore, subclasses can choose to append to this object to take advantage of {@link Filter Filters}
	 * 	and properties defined on the servlet class through the {@link RestResource#properties()} annoation.
	 *
	 * @param req The HTTP request object, for optionally accessing request information.
	 * @param properties The HTTP response properties.
	 * @return The set of HTTP header values to set on the response object.
	 */
	public JsonMap getHeaders(RestRequest req, JsonMap properties) {
		return new JsonMap().setBeanContext(req.getServlet().getBeanContext());
	}
}
