package com.ibm.juno.server;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;
import java.net.*;
import java.nio.charset.*;
import java.util.*;
import java.util.zip.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.rdfxml.*;
import com.ibm.juno.core.xml.*;

/**
 * Represents an HTTP response for a REST resource.
 * <p>
 * Essentially an extended {@link HttpServletResponse} with some special convenience methods
 * 	that allow you to easily output POJOs as responses.
 * <p>
 * Since this class extends {@link HttpServletResponse}, developers are free to use these
 * 	convenience methods, or revert to using lower level methods like any other servlet response.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<ja>@RestMethod</ja>(name=<js>"GET"</js>)
 * 	<jk>public void</jk> doGet(RestRequest req, RestResponse res) {
 * 		r.addProperty(HtmlRestSerializerProperties.<jsf>TITLE</jsf>, <js>"My title"</js>)
 * 			.setOutput(<js>"Simple string response"</js>);
 * 	}
 * </p>
 * <p>
 * 	See {@link RestServlet} for more information about usage on this class.
 *
 * @author jbognar
 */
public class RestResponse extends HttpServletResponseWrapper {

	private RestRequest request;
	private Object output;                      // The POJO being sent to the output.
	private boolean isNullOutput;               // The output is null (as opposed to not being set at all)
	private JsonMap properties;                 // Response properties
	private RestSerializerGroup serializerGroup;

	private static final SortedMap<String,Charset> availableCharsets = Charset.availableCharsets();

	/**
	 * Constructor.
	 */
	RestResponse(RestRequest req, HttpServletResponse res, JsonMap defaultResponseHeaders) {
		super(res);
		this.request = req;

		// Find acceptable charset
		String cs = null;
		for (MediaRange r : MediaRange.parse(req.getHeader("accept-charset", "utf-8"))) {
			if (r.getType().equals("*"))
				cs = "utf-8";
			else if (availableCharsets.containsKey(r.getType()))
				cs = r.getType();
			if (cs != null)
				break;
		}

		if (cs == null)
			throw new RestException(SC_NOT_ACCEPTABLE, "No supported charsets in header 'Accept-Charset': '%s'", req.getHeader("accept-charset"));

		res.setCharacterEncoding(cs);
		for (Map.Entry<String,Object> e : defaultResponseHeaders.entrySet())
			setHeader(e.getKey(), e.getValue().toString());
	}

	/**
	 * Sets the serializer group for the response.
	 */
	RestResponse setSerializerGroup(RestSerializerGroup serializerGroup) {
		this.serializerGroup = serializerGroup;
		return this;
	}

	/**
	 * Returns the output serializer for the response.
	 */
	RestSerializer getOutputSerializer() {

		MediaRange[] accept = request.getAcceptMediaTypes();
		String matchingAccept = serializerGroup.findMatch(accept);
		if (matchingAccept != null) {
			RestSerializer r = serializerGroup.getRestSerializer(matchingAccept);
			setContentType(matchingAccept);
			return r;
		}

		throw new RestException(SC_NOT_ACCEPTABLE,
			"Unsupported media-type in request header 'Accept': '%s'\n\tSupported media-types: %s",
			request.getHeader("accept", "").replace(' ', '+'), serializerGroup.getSupportedContentTypes()
		);
	}

	/**
	 * Sets the HTTP output on the response.
	 * <p>
	 * 	Calling this method is functionally equivalent to returning the object in the REST Java method.
	 * <p>
	 * 	Can be of any of the following types:
	 * 	<ul>
	 * 	  <li> {@link InputStream}
	 * 	  <li> {@link Reader}
	 * 	  <li> Any serializable type defined in <a href='../package-summary.html#PojoCategories'>POJO Categories</a>
	 * 	</ul>
	 * <p>
	 * 	If it's an {@link InputStream} or {@link Reader}, you must also specify the content-type using the {@link #setContentType(String)} method.
	 *
	 * @param output The output to serialize to the connection.
	 * @return This object (for method chaining).
	 */
	public RestResponse setOutput(Object output) {
		this.output = output;
		this.isNullOutput = output == null;
		return this;
	}

	/**
	 * Add a serializer property to send to the serializers to override a default value.
	 * <p>
	 * Can be any value specified in the following classes:
	 * <ul>
	 * 	<li>{@link SerializerProperties}
	 * 	<li>{@link JsonSerializerProperties}
	 * 	<li>{@link XmlSerializerProperties}
	 * 	<li>{@link RdfXmlSerializerProperties}
	 *	</ul>
	 *
	 * @param key The setting name.
	 * @param value The setting value.
	 * @return This object (for method chaining).
	 */
	public RestResponse setProperty(String key, Object value) {
		properties.put(key, value);
		return this;
	}

	/**
	 * Returns the properties set via {@link #setProperty(String, Object)}.
	 * @return A map of all the property values set.
	 */
	public JsonMap getProperties() {
		return properties;
	}

	/**
	 * Servlet calls this method to initialize the properties.
	 */
	RestResponse setProperties(JsonMap properties) {
		this.properties = properties;
		return this;
	}

	/**
	 * Shortcut method that allows you to use varargs to simplify setting array output.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Instead of...</jc>
	 * 	response.setOutput(<jk>new</jk> Object[]{x,y,z});
	 *
	 * 	<jc>// ...call this...</jc>
	 * 	response.setOutput(x,y,z);
	 * </p>
	 *
	 * @param output The output to serialize to the connection.
	 * @return This object (for method chaining).
	 */
	public RestResponse setOutputs(Object...output) {
		this.output = output;
		return this;
	}

	/**
	 * Returns the output that was set by calling {@link #setOutput(Object)}.
	 *
	 * @return The output object.
	 */
	public Object getOutput() {
		return output;
	}

	/**
	 * Returns <jk>true</jk> if this response has any output associated with it.
	 * @return <jk>true</jk> if {@code setInput()} has been called.
	 */
	public boolean hasOutput() {
		return output != null || isNullOutput;
	}

	/**
	 * Sets the output to a plain-text message regardless of the content type.
	 *
	 * @param text The output text to send.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to write to the writer.
	 */
	public RestResponse sendPlainText(String text) throws IOException {
		setContentType("text/plain");
		getWriter().write(text);
		return this;
	}

	/**
	 * Equivalent to {@link HttpServletResponse#getOutputStream()}, except
	 * wraps the output stream in a {@link GZIPOutputStream} if the
	 * <code>Content-Encoding</code> response header is set to <js>"gzip"</js>.
	 */
	@Override
	public ServletOutputStream getOutputStream() throws IOException {

		if (request.isGZip()) {
			setHeader("content-encoding", "gzip");
			setContentLength(-1);
			final GZIPOutputStream os2 = new GZIPOutputStream(super.getOutputStream());
			return new ServletOutputStream(){
				@Override
				public void write(int b) throws IOException {
					os2.write(b);
				}
				@Override
				public void flush() throws IOException {
					os2.flush();
				}
				@Override
				public void close() throws IOException {
					os2.finish();
					os2.close();
				}
			};
		}

		return super.getOutputStream();
	}

	/**
	 * Equivalent to {@link HttpServletResponse#getWriter()}, except
	 * wraps the underlying output stream in a {@link GZIPOutputStream} if the
	 * <code>Content-Encoding</code> response header is set to <js>"gzip"</js>.
	 */
	@Override
	public PrintWriter getWriter() throws IOException {
		// If plain text requested, override it now.
		if (request.isPlainText()) {
			setHeader("content-type", "text/plain");
			setProperty(SerializerProperties.USE_INDENTATION, true);
		}

		boolean useGZip = request.getHeader("accept-encoding", "").contains("gzip");

		try {
			if (useGZip)
				return new PrintWriter(new BufferedWriter(new OutputStreamWriter(getOutputStream(), getCharacterEncoding())));
			return super.getWriter();
		} catch (UnsupportedEncodingException e) {
			String ce = getCharacterEncoding();
			setCharacterEncoding("UTF-8");
			throw new RestException(SC_NOT_ACCEPTABLE, "Unsupported charset in request header 'Accept-Charset': '%s'", ce);
		}
	}

	/**
	 * Returns the <code>Content-Type</code> header stripped of the charset attribute if present.
	 * @return The <code>media-type</code> portion of the <code>Content-Type</code> header.
	 */
	public String getMediaType() {
		String contentType = getContentType();
		if (contentType == null)
			return null;
		int i = contentType.indexOf(';');
		if (i == -1)
			return contentType;
		return contentType.substring(0, i).trim();

	}

	/**
	 * Returns the value of the <code>Content-Charset</code> header value.
	 * <p>
	 * Defaults to <js>"UTF-8"</js> if not specified.
	 */
	@Override
	public String getCharacterEncoding() {
		String s = super.getCharacterEncoding();
		return (s == null ? "UTF-8" : s);
	}

	/**
	 * Convenience method for redirecting to a {@link URL}.
	 * @param url The URL to redirect to.
	 * @throws IOException If {@link HttpServletResponse#sendRedirect(String)} throws an exception.
	 */
	public void sendRedirect(URL url) throws IOException {
		super.sendRedirect(url.toString());
	}

	/**
	 * Convenience method for redirecting to a {@link URI}.
	 * @param uri The URL to redirect to.
	 * @throws IOException If {@link HttpServletResponse#sendRedirect(String)} throws an exception.
	 */
	public void sendRedirect(URI uri) throws IOException {
		super.sendRedirect(uri.toString());
	}
}
