package com.ibm.juno.server;

import com.ibm.juno.core.*;
import com.ibm.juno.server.annotation.*;

/**
 * Subclass of {@link RestSerializer RestSerializers} that use an instance of {@link Serializer} for serialization.
 * <p>
 * This allows servlet annotations ({@link RestResource#filters()}, {@link RestResource#converters()}, {@link RestResource#properties()} to
 * 	be applied to the inner serializer during servlet initialization.
 *
 * <p>
 * 	See {@link RestSerializerGroup} for more information.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class RestSerializerSerializer extends RestSerializer {

	/** The inner serializer */
	protected Serializer serializer;

	/**
	 * Serializer based constructor.
	 * <p>
	 * Use this constructor for REST serializers that use an instance of {@link Serializer} for serialization.
	 *
	 * @param serializer The {@link Serializer}
	 */
	public RestSerializerSerializer(Serializer serializer) {
		this.serializer = serializer;
	}

	/**
	 * Returns the serializer being used by this rest serializer.
	 * @return The serializer used by this rest serializer.
	 */
	protected Serializer getSerializer() {
		return serializer;
	}

	/**
	 * Sets the serializer used by this rest serializer.
	 */
	protected void setSerializer(Serializer serializer) {
		this.serializer = serializer;
	}
}
