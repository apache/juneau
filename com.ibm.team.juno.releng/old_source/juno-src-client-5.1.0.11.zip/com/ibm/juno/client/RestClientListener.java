/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.client;

/**
 * Listener that can be attached to clients via the {@link RestClient#addListener(RestClientListener)} method.
 * <p>
 * Useful for debugging purposes.
 */
public interface RestClientListener {

	/**
	 * Gets called immediately after an HTTP connection is made.
	 */
	public void onConnect(RestCall restCall);
}
