/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.parser;

/**
 * Configurable properties common to all {@link Parser} classes.
 * <p>
 * 	Use the {@link Parser#setProperty(String, Object)} method to set property values.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserProperties implements Cloneable {

	// Placeholder for potential future parser properties.

	@Override
	public ParserProperties clone() throws CloneNotSupportedException {
		return (ParserProperties)super.clone();
	}
}
