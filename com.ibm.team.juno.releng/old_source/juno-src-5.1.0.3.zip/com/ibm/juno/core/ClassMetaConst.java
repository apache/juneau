/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core;

/**
 * Static reusable constants of type {@link ClassMeta}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ClassMetaConst {

	/** Reusable instance that represents 'anything'. */
	public static final ClassMeta<Object> OBJECT = new ClassMeta<Object>(Object.class, null);

	/** Reusable instance that represents 'anything'. */
	public static final ClassMeta<String> STRING = new ClassMeta<String>(String.class, null);

}
