/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.ini;

import static com.ibm.juno.core.ini.ConfigFile.Format.*;
import static java.lang.String.*;

import java.io.*;
import java.nio.charset.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.utils.*;

/**
 * Utility class for working with INI-style configuration files.
 * <p>
 * An example of an INI file...
 * <p class='bcode'>
 * 	<jc># Default section</jc>
 * 	key1 = 1
 * 	key2 = true
 * 	key3 = [1,2,3]
 * 	key4 = http://foo
 *
 * 	<jc># Section 1</jc>
 * 	<jk>[section1]</jk>
 * 	key1 = 2
 * 	key2 = false
 * 	key3 = [4,5,6]
 * 	key4 = http://bar
 * </p>
 * <h6 class='topic'>Features</h6>
 * <ul>
 * 	<li>Entries are accessed through keys of the form <js>"section/key"</js> or <js>"key"</js>.
 * 	<li>INI file layout (e.g. comments, formatting, ordering) is persisted at save time.
 * 	<li>Automatic conversion of values to and from a variety of POJOs.
 * 	<li>Ability to alter comments programmatically.
 * 	<li>All the built-in features of {@link ObjectMap}.
 * 	<li>Ability to export to batch and shell scripts with set/export commands for each config file entry.
 * 	<li>Command-line functions:
 * 		<ul>
 * 			<li>Set config file variables.
 * 			<li>Generate batch environment variable files.
 * 			<li>Generate shell script environment variable files.
 * 		</ul>
 * 	<li>Supported for encoded values.
 * </ul>
 * <p>
 * This class can be used to easily access contents of this file, using the various capabilities of the {@link ObjectMap} class, like so...
 * <p class='bcode'>
 * 	<jk>int</jk> key1;
 * 	<jk>boolean</jk> key2;
 * 	<jk>int</jk>[] key3;
 * 	URL key4;
 *
 * 	<jc>// Load our config file</jc>
 * 	ConfigFile f = <jk>new</jk> ConfigFile(<js>"C:/temp/MyConfig.ini"</js>);
 *
 * 	<jc>// Read values from default section</jc>
 * 	key1 = f.getInt(<js>"key1"</js>);
 * 	key2 = f.getBoolean(<js>"key2"</js>);
 * 	key3 = f.get(<jk>int</jk>[].<jk>class</jk>, <js>"key3"</js>);
 * 	key4 = f.get(URL.<jk>class</jk>, <js>"key4"</js>);
 *
 * 	<jc>// Read values from section #1</jc>
 * 	key1 = f.getInt(<js>"section1/key1"</js>);
 * 	key2 = f.getBoolean(<js>"section1/key2"</js>);
 * 	key3 = f.get(<jk>int</jk>[].<jk>class</jk>, <js>"section1/key3"</js>);
 * 	key4 = f.get(URL.<jk>class</jk>, <js>"section1/key4"</js>);
 * </p>
 * <p>
 * The interface also allows config files to be easily constructed programmatically...
 * <p class='bcode'>
 * 	<jc>// Construct the sample INI file programmatically</jc>
 * 	ConfigFile cf = <jk>new</jk> ConfigFile(<js>"C:/temp/MyConfig.ini"</js>)
 * 		.addLines(<jk>null</jk>,                     <jc>// The default 'null' section</jc>
 * 			<js>"# Default section"</js>,             <jc>// A regular comment</jc>
 * 			<js>"key1 = 1"</js>,                      <jc>// A numeric entry</jc>
 * 			<js>"key2 = true"</js>,                   <jc>// A boolean entry</jc>
 * 			<js>"key3 = [1,2,3]"</js>,                <jc>// An array entry</jc>
 * 			<js>"key4 = http://foo"</js>,             <jc>// A POJO entry</jc>
 * 			<js>""</js>)                              <jc>// A blank line</jc>
 * 		.addHeaderComments(<js>"section1"</js>,      <jc>// The 'section1' section</jc>
 * 			<js>"# Section 1"</js>)                   <jc>// A header comment</jc>
 * 		.addLines(<js>"section1"</js>,               <jc>// The 'section1' section</jc>
 * 			<js>"key1 = 2"</js>,                      <jc>// A numeric entry</jc>
 * 			<js>"key2 = false"</js>,                  <jc>// A boolean entry</jc>
 * 			<js>"key3 = [4,5,6]"</js>,                <jc>// An array entry</jc>
 * 			<js>"key4 = http://bar"</js>)             <jc>// A POJO entry</jc>
 * 		.save();                            <jc>// Save to MyConfig.ini</jc>
 * </p>
 * <p>
 * The following is equivalent, except uses {@link #put(String, Object)} to set values.
 * Note how we're setting values as POJOs which will be automatically converted to strings when persisted to disk.
 * <p class='bcode'>
 * 	<jc>// Construct the sample INI file programmatically</jc>
 * 	ConfigFile cf = <jk>new</jk> ConfigFile(<js>"C:/temp/MyConfig.ini"</js>)
 * 		.addLines(<jk>null</jk>,
 * 			<js>"# Default section"</js>)
 * 		.addHeaderComments(<js>"section1"</js>,
 * 			<js>"# Section 1"</js>);
 * 	cf.put(<js>"key1"</js>, 1);
 * 	cf.put(<js>"key2"</js>, <jk>true</jk>);
 * 	cf.put(<js>"key3"</js>, <jk>new int</jk>[]{1,2,3});
 * 	cf.put(<js>"key4"</js>, <jk>new</jk> URL(<js>"http://foo"</js>));
 * 	cf.put(<js>"section1/key1"</js>, 2);
 * 	cf.put(<js>"section1/key2"</js>, <jk>false</jk>);
 * 	cf.put(<js>"section1/key3"</js>, <jk>new int</jk>[]{4,5,6});
 * 	cf.put(<js>"section1/key4"</js>, <jk>new</jk> URL(<js>"http://bar"</js>));
 * 	cf.save();
 * </p>
 * <p>
 * Below shows a small example of possible conversions from strings:
 * </p>
 * <p class='bcode'>
 * 	<jc>// Strings with default values</jc>
 * 	<jc>// key1 = foobar</jc>
 * 	String key1 = cf.getString(<js>"key1"</js>, <js>"not specified"</js>);
 *
 * 	<jc>// Numbers</jc>
 * 	<jc>// key2 = 123</jc>
 * 	<jk>float</jk> key2 = cf.getFloat(<js>"key2"</js>, -1);
 *
 * 	<jc>// Booleans</jc>
 * 	<jc>// key3 = true</jc>
 * 	<jk>boolean</jk> key3 = cf.getBoolean(<js>"key3"</js>, <jk>false</jk>);
 *
 * 	<jc>// Objects convertable to and from strings</jc>
 * 	<jc>// key4 = http://foo</jc>
 * 	URL key4 = cf.get(URL.<jk>class</jk>, <js>"key4"</js>);
 *
 * 	<jc>// Arrays of objects</jc>
 * 	<jc>// key5 = ['http://foo']</jc>
 * 	URL[] key5 = cf.get(URL[].<jk>class</jk>, <js>"key5"</js>);
 *
 * 	<jc>// Lists of objects</jc>
 * 	<jc>// key6 = ['http://foo']</jc>
 * 	ClassMeta cm = BeanContext.<jsf>DEFAULT</jsf>.getCollectionClassMeta(LinkedList.<jk>class</jk>, URL.<jk>class</jk>);
 * 	List&lt;URL&gt; key6 = cf.get(cm, <js>"key6"</js>);
 *
 * 	<jc>// Arrays of primitives</jc>
 * 	<jc>// key7 = [1,2,3]</jc>
 * 	<jk>int</jk>[] key7 = cf.get(<jk>int</jk>[].<jk>class</jk>, <js>"key7"</js>);
 *
 * 	<jc>// Enums</jc>
 * 	<jc>// key8 = MINUTES</jc>
 * 	TimeUnit key8 = cf.get(TimeUnit.<jk>class</jk>, <js>"key8"</js>);
 *
 * 	<jc>// Beans</jc>
 * 	<jc>// key9 = {name:'John Smith', addresses:[{street:'101 Main St', city:'Anywhere', state:'TX'}]}</jc>
 * 	Person key9 = cf.get(Person.<jk>class</jk>, <js>"key9"</js>);
 *
 * 	<jc>// Generic Maps</jc>
 * 	<jc>// key10 = {foo:'bar',baz:123}</jc>
 * 	Map key10 = cf.getObjectMap(<js>"key10"</js>);
 * </p>
 * <p>
 * Config files can also be serialized to windows batch and shell script files that will
 * 	export config file variables to set/export commands to make them easily available through command-line environment variables.
 * See the {@link #serializeTo(Writer, Format)} method for more details.
 * <p>
 * This class also has a {@link #main(String[])} method that allows you to create env variable files or update
 * 	config files from a command line.  See the {@link #main(String[])} method for more details.
 *
 * <h6 class='topic'>Encoded entries</h6>
 * Values can be marked for encoding by appending <js>'*'</js> to the end of the key name.
 * This can be useful for obscuring sensitive information, such as passwords.
 * <p>
 * If an unencoded value is detected in the file, it will be encoded and saved during the initial load.
 * <p>
 * For example, the following password is marked for encoding....
 * <p class='bcode'>
 * 	<jk>[MyHost]</jk>
 * 	url = http://localhost:9080/foo
 * 	user = me
 * 	password* = mypassword
 * </p>
 * <p>
 * After initial loading, the file contents will contain an encoded value...
 * <p class='bcode'>
 * 	<jk>[MyHost]</jk>
 * 	url = http://localhost:9080/foo
 * 	user = me
 * 	password* = {AwwJVhwUQFZEMg==}
 * </p>
 * <p>
 * The default encoder is {@link XorEncoder}, which is a simple XOR+Base64 encoder.
 * If desired, a stronger custom encoder can be specified through the {@link #setEncoder(Encoder)} method.
 *
 * <h6 class='topic'>Other notes</h6>
 * <ul>
 * 	<li>Use the {@link #setBeanContext(BeanContext)} method if you're serializing/parsing POJOs with filters.
 * </ul>
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ConfigFile extends ObjectMap {
	private static final long serialVersionUID = 1L;

	private String path;
	private transient File file;
	private Map<String,Section> sections = new LinkedHashMap<String,Section>();
	private transient Encoder encoder = new XorEncoder();
	private boolean hasBeenModified = false;

	/**
	 * Valid formats that can be passed to the {@link ConfigFile#serializeTo(Writer, Format)} method.
	 */
	public static enum Format {
		/** Normal INI file format*/
		INI,

		/** Batch file with "set X" commands */
		BATCH,

		/** Shell script file with "export X" commands */
		SHELL;
	}

	/**
	 * Default constructor.
	 * <p>
	 * Creates an in-memory config file that can later be saved through {@link #serializeTo(Writer)}.
	 */
	public ConfigFile() {}

	/**
	 * File-based constructor.
	 * <p>
	 * Loads the contents of the specified file into this config file.
	 * <p>
	 * If file does not initially exist, this object will start off empty.
	 *
	 * @param file The INI file on disk.
	 * @throws IOException If a problem occurred trying to read the contents of the file.
	 */
	public ConfigFile(File file) throws IOException {
		this(file.getAbsolutePath());
	}

	/**
	 * Path-based constructor.
	 * <p>
	 * Loads the contents of the specified file by path into this config file.
	 * <p>
	 * If file does not initially exist, this object will start off empty.
	 *
	 * @param path The path to the INI file on disk.
	 * @throws IOException If a problem occurred trying to read the contents of the file.
	 */
	public ConfigFile(String path) throws IOException {
		this.path = path;
		reload();
	}

	private File getFile() throws IOException {
		if (file == null) {
			if (path == null)
				throw new IOException("No file specified on ConfigFile class.  reload() can only be used on ConfigFile objects constructed through ConfigFile(File).");
			file = new File(path);
		}
		return file;
	}

	/**
	 * Reader-based constructor.
	 * <p>
	 * Loads the contents of the specified reader into this config file.
	 * The reader will automatically be closed after reading the contents.
	 *
	 * @param r The reader to read the config file contents from.
	 * @throws IOException If a problem occurred trying to read the contents from the reader.
	 */
	public ConfigFile(Reader r) throws IOException {
		loadContents(r instanceof BufferedReader ? (BufferedReader)r : new BufferedReader(r));
	}

	/**
	 * Reloads ths config file object from the persisted file contents.
	 * <p>
	 * This method is only valid if a <code>File</code> has been associated with this config file
	 * 	by using the {@link #ConfigFile(File)} constructor or the {@link #saveTo(File)} method.
	 *
	 * @return This object (for method chaining).
	 * @throws IOException If file could not be read, or file is not associated with this object.
	 */
	public ConfigFile reload() throws IOException {
		sections.clear();
		if (getFile().exists()) {
			BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(getFile()), Charset.defaultCharset()));
			loadContents(r);
		}
		return this;
	}

	/**
	 * Optionally override the encoder used for encoded entries.
	 * <p>
	 * By default, the {@link XorEncoder} class is used for encoding entries marked with '*'.
	 * @param encoder The new encoder.
	 * @return This object (for method chaining).
	 */
	public ConfigFile setEncoder(Encoder encoder) {
		this.encoder = encoder;
		return this;
	}

	/**
	 * Gets the entry with the specified key.
	 * <p>
	 * The key can be in one of the following formats...
	 * <ul>
	 * 	<li><js>"key"</js> - A value in the default section (i.e. defined above any <code>[section]</code> header).
	 * 	<li><js>"section/key"</js> - A value from the specified section.
	 * </ul>
	 * @return The value, or <jk>null</jk> if the section or key does not exist.
	 */
	@Override
	public Object get(Object key) {
		String[] k = parseKey(key);
		Section s = getSection(k[0]);
		if (s == null)
			return null;
		return s.get(k[1]);
	}

	/**
	 * Removes the entry with the specified key.
	 * <p>
	 * The key can be in one of the following formats...
	 * <ul>
	 * 	<li><js>"key"</js> - A value in the default section (i.e. defined above any <code>[section]</code> header).
	 * 	<li><js>"section/key"</js> - A value from the specified section.
	 * </ul>
	 * @return The value, or <jk>null</jk> if the section or key does not exist.
	 */
	@Override
	public Object remove(Object key) {
		String[] k = parseKey(key);
		Section s = getSection(k[0]);
		if (s == null)
			return null;
		return s.remove(k[1]);
	}

	/**
	 * Adds an entry with the specified key.
	 * <p>
	 * The key can be in one of the following formats...
	 * <ul>
	 * 	<li><js>"key"</js> - A value in the default section (i.e. defined above any <code>[section]</code> header).
	 * 	<li><js>"section/key"</js> - A value from the specified section.
	 * </ul>
	 * <p>
	 * If the section does not exist, it will automatically be created.
	 *
	 * @return The previous value, or <jk>null</jk> if the section or key did not previously exist.
	 */
	@Override
	public Object put(String key, Object val) {
		String[] k = parseKey(key);
		return addSection(k[0]).put(k[1], val);
	}

	/**
	 * Adds arbitrary lines to the specified config file section.
	 * <p>
	 * The lines can be any of the following....
	 * <ul>
	 * 	<li><js>"# comment"</js> - A comment line.
	 * 	<li><js>"key=val"</js> - A key/value pair (equivalent to calling {@link #put(String, Object)}.
	 * 	<li><js>" foobar "</js> - Anything else (interpreted as a comment).
	 * </ul>
	 * <p>
	 * If the section does not exist, it will automatically be created.
	 *
	 * @param section The name of the section to add lines to, or <jk>null</jk> to add to the beginning unnamed section.
	 * @param lines The lines to add to the section.
	 * @return This object (for method chaining).
	 */
	public ConfigFile addLines(String section, String...lines) {
		addSection(section).addLines(lines);
		return this;
	}

	/**
	 * Adds header comments to the specified section.
	 * <p>
	 * Header comments are defined as lines that start with <jk>"#"</jk> immediately preceding a section header <jk>"[section]"</jk>.
	 * These are handled as part of the section itself instead of being interpreted as comments in the previous section.
	 * <p>
	 * Header comments can be of the following formats...
	 * <ul>
	 * 	<li><js>"# comment"</js> - A comment line.
	 * 	<li><js>"comment"</js> - Anything else (will automatically be prefixed with <js>"# "</js>).
	 * </ul>
	 * <p>
	 * If the section does not exist, it will automatically be created.
	 *
	 * @param section The name of the section to add lines to, or <jk>null</jk> to add to the default section.
	 * @param headerComments The comment lines to add to the section.
	 * @return This object (for method chaining).
	 */
	public ConfigFile addHeaderComments(String section, String...headerComments) {
		addSection(section).addHeaderComments(headerComments);
		return this;
	}

	/**
	 * Returns the sections in the config file.
	 * <p>
	 * The default section has <jk>null</jk> for it's name.
	 * <p>
	 * Returns objects are mutable.  Changes to sections will be reflected in <code>ConfigFile</code> object.
	 *
	 * @return The sections in the config file.
	 */
	public Collection<Section> getSections() {
		return sections.values();
	}

	/**
	 * Appends a section to this config file if it does not already exist.
	 * <p>
	 * Returns the existing section if it already exists.
	 *
	 * @param name The section name, or <jk>null</jk> for the default section.
	 * @return The appended or existing section.
	 */
	public Section addSection(String name) {
		if (sections.containsKey(name))
			return sections.get(name);
		Section s = new Section(name);
		this.sections.put(s.name, s);
		return s;
	}

	/**
	 * Returns the section with the specified name, or <jk>null</jk> if section does not exist.
	 *
	 * @param name The section name, or <jk>null</jk> for the default section.
	 * @return The section, or <jk>null</jk> if section does not exist.
	 */
	public Section getSection(String name) {
		return sections.get(name);
	}

	/**
	 * Removes the section with the specified name.
	 *
	 * @param name The name of the section to remove, or <jk>null</jk> for the default section.
	 * @return The removed section, or <jk>null</jk> if named section does not exist.
	 */
	public Section removeSection(String name) {
		return sections.remove(name);
	}

	@Override
	public boolean containsKey(Object key) {
		String[] k = parseKey(key);
		Section s = getSection(k[0]);
		if (s == null)
			return false;
		return s.containsKey(k[1]);
   }

	/**
	 * Saves this config file to disk.
	 *
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to save file to disk, or file is not associated with this object.
	 */
	public synchronized ConfigFile save() throws IOException {
		hasBeenModified = false;
		Writer w = new OutputStreamWriter(new FileOutputStream(getFile()), Charset.defaultCharset());
		try {
			serializeTo(w);
		} finally {
			w.close();
		}
		return this;
	}

	/**
	 * Saves this config file to the specified writer as an INI file.
	 * <p>
	 * The writer will automatically be closed.
	 *
	 * @param w The writer to send the output to.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to send contents to the writer.
	 */
	@Override
	public ConfigFile serializeTo(Writer w) throws IOException {
		return serializeTo(w, INI);
	}

	/**
	 * Same as {@link #serializeTo(Writer)}, except allows you to explicitely specify a format.
	 *
	 * @param w The writer to send the output to.
	 * @param format The {@link Format} of the output.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to send contents to the writer.
	 */
	public ConfigFile serializeTo(Writer w, Format format) throws IOException {
		PrintWriter pw = (w instanceof PrintWriter ? (PrintWriter)w : new PrintWriter(w));
		for (Section s : sections.values())
			s.writeTo(pw, format);
		pw.flush();
		pw.close();
		w.close();
		return this;
	}

	/**
	 * Saves this config file to the specified file.
	 * <p>
	 * If no file was previously associated with this config file, calling {@link #save()} will save to
	 * 	the same file.
	 *
	 * @param f The file to send the output to.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to send contents to the file.
	 */
	public ConfigFile saveTo(File f) throws IOException {
		if (file == null) {
			path = f.getAbsolutePath();
			getFile();
		}
		Writer w = new OutputStreamWriter(new FileOutputStream(f), Charset.defaultCharset());
		try {
			serializeTo(w);
		} finally {
			w.close();
		}
		return this;
	}

	/**
	 * Returns the config file contents as a string.
	 * <p>
	 * The contents of the string are the same as the contents that would be serialized to disk.
	 */
	@Override
	public String toString() {
		try {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			serializeTo(pw);
			pw.flush();
			pw.close();
			return sw.toString();
		} catch (IOException e) {
			return e.getLocalizedMessage();
		}
	}

	private void loadContents(BufferedReader r) throws IOException {
		String line = null;
		Section section = addSection(null);
		while ((line = r.readLine()) != null) {
			if (line.matches("\\s*\\[.*\\].*")) {
				String sn = line.substring(line.indexOf('[')+1, line.indexOf(']')).trim();
				section = addSection(sn)
					.addHeaderComments(section.removeTrailingComments());
			}
			else
				section.addLines(line);
		}
		r.close();
		if (hasBeenModified)
			save();
	}

	private String[] parseKey(Object key) {
		if (key == null)
			throw new NullPointerException("ConfigFile does not support null keys.");
		String k = key.toString();
		int i = k.indexOf('/');
		String sn = (i == -1 ? null : k.substring(0, i));
		String sk = (i == -1 ? k : k.substring(i+1));
		return new String[]{sn,sk};
	}

	/**
	 * Defines a section in a config file.
	 *
	 * @author James Bognar (jbognar@us.ibm.com).
	 */
	public class Section extends ObjectMap {
		private String name;
		private LinkedList<String> lines = new LinkedList<String>();
		private List<String> headerComments = new LinkedList<String>();

		private Section(String name) {
			this.name = name;
		}

		/**
		 * Returns the name of this section, or <jk>null</jk> if this is the default section.
		 * @return The name of this section, or <jk>null</jk> if this is the default section.
		 */
		public String getName() {
			return name;
		}

		/**
		 * Add lines to this section.
		 * @see ConfigFile#addLines(String, String...) for a description.
		 * @param l The lines to add to this section.
		 * @return This object (for method chaining).
		 */
		public Section addLines(String...l) {
			for (String line : l) {
				if (line.matches("\\s*\\#.*"))
					this.lines.add(line);
				else if (line.matches("\\s*\\S+\\s*\\=.*")) {
					String key = line.substring(0, line.indexOf('=')).trim();
					String val = line.substring(line.indexOf('=')+1).trim();
					put(key, val);
				} else
					this.lines.add(line);
			}
			return this;
		}

		/*
		 * Remove all "#*" lines at the end of this section so they can
		 * be associated with the next section.
		 */
		private List<String> removeTrailingComments() {
			LinkedList<String> l = new LinkedList<String>();
			while ((! lines.isEmpty()) && lines.getLast().startsWith("#"))
				l.addFirst(lines.removeLast());
			return l;
		}

		/**
		 * Adds header comments to this section.
		 * @see ConfigFile#addHeaderComments(String, String...) for a description.
		 * @param comments The comment lines to add to this section.
		 * @return This object (for method chaining).
		 */
		public Section addHeaderComments(String...comments) {
			for (String c : comments) {
				if (! c.startsWith("#"))
					c = "# " + c;
				this.headerComments.add(c);
			}
			return this;
		}

		/**
		 * Adds header comments to this section.
		 * @see ConfigFile#addHeaderComments(String, String...) for a description.
		 * @param comments The comment lines to add to this section.
		 * @return This object (for method chaining).
		 */
		public Section addHeaderComments(List<String> comments) {
			this.headerComments.addAll(comments);
			return this;
		}

		/**
		 * Removes any existing header comments on this section.
		 * @return This object (for method chaining).
		 */
		public Section clearHeaderComments() {
			this.headerComments.clear();
			return this;
		}

		@Override
		public Object put(String key, Object val) {
			boolean encoded = key.endsWith("*");
			if (encoded) {
				key = key.substring(0, key.lastIndexOf('*'));
				String v = (val == null ? "" : val.toString()).trim();
				if (v.startsWith("{") && v.endsWith("}"))
					val = encoder.decode(v.substring(1, v.length()-1));
				else
					hasBeenModified = true;
			}
			if (! super.containsKey(key))
				lines.add((encoded ? '*' : '>') + key);
			return super.put(key, val);
		}

		@Override
		public void clear() {
			lines.clear();
			super.clear();
		}

		@Override
		public Object remove(Object key) {
			if (super.containsKey(key))
				for (Iterator<String> i = lines.iterator(); i.hasNext();) {
					String l = i.next();
					if (l.length() > 0 && l.charAt(0) == '>' && l.substring(1).equals(key))
						i.remove();
				}
			return super.remove(key);
		}

		private String getValString(String key) {
			Object val = super.get(key);
			return (val == null ? "" : getBeanContext().convertToType(val, String.class));
		}

		private void writeTo(PrintWriter w, Format format) {
			if (format == INI) {
				for (String s : headerComments)
					w.append(s).println();
				if (name != null)
					w.append('[').append(name).append(']').println();
				for (String l : lines) {
					char c = (l.length() > 0 ? l.charAt(0) : 0);
					if (c == '>' || c == '*'){
						boolean encode = c == '*';
						String key = l.substring(1);
						String val = getValString(key);
						w.append(key);
						if (encode)
							w.append('*');
						w.append(" = ");
						if (encode)
							w.append('{').append(encoder.encode(val)).append('}');
						else
							w.append(val);
						w.println();
					} else {
						w.append(l).println();
					}
				}

			} else if (format == BATCH) {
				String section = (name == null ? null : name.replaceAll("\\.\\/", "_"));
				String nl = "\r\n";
				for (String l : headerComments) {
					l = trimComment(l);
					if (! l.isEmpty())
						w.append("rem ").append(l);
					w.append(nl);
				}
				for (String l : lines) {
					char c = (l.length() > 0 ? l.charAt(0) : 0);
					if (c == '>' || c == '*') {
						String key = l.substring(1);
						String val = getValString(key);
						w.append("set ");
						if (name != null)
							w.append(section).append("_");
						w.append(key.replaceAll("\\.\\/", "_")).append(" = ").append(val).append(nl);
					} else {
						l = trimComment(l);
						if (! l.isEmpty())
							w.append("rem ").append(l);
						w.append(nl);
					}
				}

			} else if (format == SHELL) {
				String section = (name == null ? null : name.replaceAll("\\.\\/", "_"));
				for (String l : headerComments) {
					l = trimComment(l);
					if (! l.isEmpty())
						w.append("# ").append(l);
					w.append('\n');
				}
				for (String l : lines) {
					char c = (l.length() > 0 ? l.charAt(0) : 0);
					if (c == '>' || c == '*'){
						String key = l.substring(1);
						String val = getValString(key).replaceAll("\\\\", "\\\\\\\\");
						w.append("export ");
						if (name != null)
							w.append(section).append("_");
						w.append(key.replaceAll("\\.\\/", "_")).append('=').append('"').append(val).append('"').append('\n');
					} else {
						l = trimComment(l);
						if (! l.isEmpty())
							w.append("# ").append(l);
						w.append('\n');
					}
				}
			}
		}
	}

	private String trimComment(String s) {
		if (s == null)
			return "";
		return s.replaceAll("^\\s*\\#\\s*", "").trim();
	}

	/**
	 * Implements command-line features for working with INI configuration files.
	 * <p>
	 * <h6 class='topic'>Usage</h6>
	 * Invoke as a normal Java program...
	 * <p class='bcode'>
	 * 	java com.ibm.juno.core.ini.ConfigFile [args]
	 * </p>
	 * Arguments can be any of the following...
	 * <ul>
	 * 	<li>No arguments<br>
	 * 		Prints usage message.<br>
	 * 		<br>
	 * 	<li><code>createBatchEnvFile -configfile &lt;configFile&gt; -envfile &lt;batchFile&gt; [-verbose]</code><br>
	 * 		Creates a batch file that will set each config file entry as an environment variable.<br>
	 * 		Characters in the keys that are not valid as environment variable names (e.g. <js>'/'</js> and <js>'.'</js>)
	 * 			will be converted to underscores.<br>
	 * 		<br>
	 * 	<li><code>createShellEnvFile -configFile &lt;configFile&gt; -envFile &lt;configFile&gt; [-verbose]</code>
	 * 		Creates a shell script that will set each config file entry as an environment variable.<br>
	 * 		Characters in the keys that are not valid as environment variable names (e.g. <js>'/'</js> and <js>'.'</js>)
	 * 			will be converted to underscores.<br>
	 * 		<br>
	 * 	<li><code>setVals -configFile &lt;configFile&gt; -vals [var1=val1 [var2=val2...]] [-verbose]</code>
	 * 		Sets values in config files.<br>
	 * </ul>
	 * <p>
	 * For example, the following command will create the file <code>'MyConfig.bat'</code> from the contents of the file <code>'MyConfig.cfg'</code>.
	 * <p class='bcode'>
	 * 	java com.ibm.juno.core.ini.ConfigFile createBatchEnvFile -configfile C:\foo\MyConfig.cfg -batchfile C:\foo\MyConfig.bat
	 * </p>
	 * @param args Command-line arguments
	 */
	public static void main(String[] args) {

		Args a = new Args(args);
		String command = a.getMainArg(0);
		boolean verbose = a.containsKey("verbose");
		String configFile = a.getArg("configFile");
		String envFile = a.getArg("envFile");

		try {
			ConfigFile cf = new ConfigFile(configFile);

			if (command.equalsIgnoreCase("setVals")) {
				List<String> vals = a.getArgs("vals");

				if (! (configFile.isEmpty() || vals.isEmpty())) {
					if (verbose)
						System.err.println(format("Updating config file '%s'", new File(configFile).getAbsolutePath()));
					for (String val : vals) {
						String[] x = val.split("\\=");
						if (x.length != 2)
							throw new RuntimeException("Invalid format for value: '"+val+"'.  Must be in the format 'key=value'");
						if (verbose)
							System.err.println(format("Setting '%s' to '%s'", x[0], x[1]));
						cf.put(x[0], x[1]);
					}
					cf.save();
					if (verbose)
						System.err.println("Done.");
					return;
				}
			} else if (command.equalsIgnoreCase("createBatchEnvFile")) {
				if (! envFile.isEmpty()) {
					Writer fw = new OutputStreamWriter(new FileOutputStream(envFile), Charset.defaultCharset());
					try {
						cf.serializeTo(fw, BATCH);
						if (verbose)
							System.err.println("Done.");
						return;
					} finally {
						fw.close();
					}
				}

			} else if (command.equalsIgnoreCase("createShellEnvFile")) {
				if (! envFile.isEmpty()) {
					Writer fw = new OutputStreamWriter(new FileOutputStream(envFile), Charset.defaultCharset());
					try {
						cf.serializeTo(fw, SHELL);
						if (verbose)
							System.err.println("Done.");
						return;
					} finally {
						fw.close();
					}
				}
			}

			printUsageAndExit();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void printUsageAndExit() {
		System.err.println("---Usage---");
		System.err.println("java -cp juno.jar com.ibm.juno.core.ini.ConfigFile createBatchEnvFile -configFile <configFile> -envFile <envFile> [-verbose]");
		System.err.println("java -cp juno.jar com.ibm.juno.core.ini.ConfigFile createShellEnvFile -configFile <configFile> -envFile <envFile> [-verbose]");
		System.err.println("java -cp juno.jar com.ibm.juno.core.ini.ConfigFile setVals -configFile <configFile> -vals [var1 val1 [var2 val2...]] [-verbose]");
		System.exit(2);
	}

}
