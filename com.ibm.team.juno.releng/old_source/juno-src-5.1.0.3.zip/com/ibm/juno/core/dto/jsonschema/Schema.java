/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.dto.jsonschema;

import java.net.URI;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.annotation.*;

/**
 * Represents a top-level schema object in the JSON-Schema core specification.
 * <p>
 * 	Refer to {@link com.ibm.juno.core.dto.jsonschema} for usage information.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("hiding")
@Xml(name="schema")
public class Schema {
	private String name;                                   // Property name.  Not serialized.
	private URI id;
	private URI schemaVersion;
	private String title;
	private String description;
	private JsonType typeJsonType;                         // JsonType representation of type
	private JsonTypeArray typeJsonTypeArray;               // JsonTypeArray representation of type
	private Map<String,Schema> definitions;
	private Map<String,Schema> properties;
	private Map<String,Schema> patternProperties;
	private Map<String,Schema> dependencies;
	private Schema itemsSchema;                            // Schema representation of items
	private SchemaArray itemsSchemaArray;                  // SchemaArray representation of items
	private Number multipleOf;
	private Number maximum;
	private Boolean exclusiveMaximum;
	private Number minimum;
	private Boolean exclusiveMinimum;
	private Integer maxLength;
	private Integer minLength;
	private String pattern;
	private Boolean additionalItemsBoolean;                // Boolean representation of additionalItems
	private SchemaArray additionalItemsSchemaArray;        // SchemaArray representation of additionalItems
	private Integer maxItems;
	private Integer minItems;
	private Boolean uniqueItems;
	private Integer maxProperties;
	private Integer minProperties;
	private List<String> required;
	private Boolean additionalPropertiesBoolean;           // Boolean representation of additionalProperties
	private Schema additionalPropertiesSchema;             // Schema representation of additionalProperties
	private List<String> _enum;
	private List<Schema> allOf;
	private List<Schema> anyOf;
	private List<Schema> oneOf;
	private Schema not;
	private URI ref;
	private SchemaMap schemaMap;
	private Schema master = this;

	/**
	 * Default constructor.
	 */
	public Schema() {}

	//--------------------------------------------------------------------------------
	// Bean properties
	//--------------------------------------------------------------------------------

	/**
	 * Returns the name of this property, or <jk>null</jk> if it is not set.
	 */
	@BeanIgnore
	public String getName() {
		return name;
	}

	/**
	 * Sets the name of this property.
	 * @return This object (for method chaining).
	 */
	@BeanIgnore
	public Schema setName(String name) {
		this.name = name;
		return this;
	}

	/**
	 * Returns the <code>id</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public URI getId() {
		return id;
	}

	/**
	 * Sets the <code>id</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setId(URI id) {
		this.id = id;
		return this;
	}

	/**
	 * Sets the <code>id</code> property on this bean.
	 * The parameter must be a valid URI.  It can be <jk>null</jk>.
	 * @return This object (for method chaining).
	 */
	public Schema setId(String id) {
		return setId(id == null ? null : URI.create(id));
	}

	/**
	 * Returns the <code>$schema</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	@BeanProperty(name="$schema")
	public URI getSchemaVersionUri() {
		return schemaVersion;
	}

	/**
	 * Sets the <code>$schema</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	@BeanProperty(name="$schema")
	public Schema setSchemaVersionUri(URI schemaVersion) {
		this.schemaVersion = schemaVersion;
		return this;
	}

	/**
	 * Sets the <code>$schema</code> property on this bean.
	 * The parameter must be a valid URI.  It can be <jk>null</jk>.
	 * @return This object (for method chaining).
	 */
	public Schema setSchemaVersionUri(String schemaVersion) {
		return setSchemaVersionUri(schemaVersion == null ? null : URI.create(schemaVersion));
	}

	/**
	 * Returns the <code>title</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the <code>title</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setTitle(String title) {
		this.title = title;
		return this;
	}

	/**
	 * Returns the <code>description</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the <code>description</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setDescription(String description) {
		this.description = description;
		return this;
	}

	/**
	 * Returns the <code>type</code> property on this bean, or <jk>null</jk> if it is not set.
	 * Can be either a {@link JsonType} or {@link JsonTypeArray} depending on what value was used to set it.
	 */
	@BeanProperty(filter=JsonTypeOrJsonTypeArrayFilter.class)
	public Object getType() {
		if (typeJsonType != null)
			return typeJsonType;
		return typeJsonTypeArray;
	}

	/**
	 * Convenience method for returning the <code>type</code> property when it is a {@link JsonType} value.
	 * @return The currently set value, or <jk>null</jk> if the property is not set, or is set as a {@link JsonTypeArray}.
	 */
	@BeanIgnore
	public JsonType getTypeAsJsonType() {
		return typeJsonType;
	}

	/**
	 * Convenience method for returning the <code>type</code> property when it is a {@link JsonTypeArray} value.
	 * @return The currently set value, or <jk>null</jk> if the property is not set, or is set as a {@link JsonType}.
	 */
	@BeanIgnore
	public JsonTypeArray getTypeAsJsonTypeArray() {
		return typeJsonTypeArray;
	}

	/**
	 * Sets the <code>type</code> property on this bean.
	 * This object must be of type {@link JsonType} or {@link JsonTypeArray}.
	 * @return This object (for method chaining).
	 * @throws BeanRuntimeException If invalid object type passed in.
	 */
	public Schema setType(Object type) {
		this.typeJsonType = null;
		this.typeJsonTypeArray = null;
		if (type != null) {
			if (type instanceof JsonType)
				this.typeJsonType = (JsonType)type;
			else if (type instanceof JsonTypeArray)
				this.typeJsonTypeArray = (JsonTypeArray)type;
			else
				throw new BeanRuntimeException(SchemaProperty.class, "Invalid attribute type ''{0}'' passed in.  Must be one of the following:  SimpleType, SimpleTypeArray", type.getClass().getName());
		}
		return this;
	}

	/**
	 * Appends to the <code>type</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addTypes(JsonType...types) {
		if (this.typeJsonTypeArray == null)
			this.typeJsonTypeArray = new JsonTypeArray();
		this.typeJsonTypeArray.addAll(types);
		return this;
	}

	/**
	 * Used during parsing to convert the <code>type</code> property to the correct class type.
	 * <ul>
	 * 	<li>If parsing a JSON-array, converts to a {@link JsonTypeArray}.
	 * 	<li>If parsing a JSON-object, converts to a {@link JsonType}.
	 * </ul>
	 * Serialization method is a no-op.
	 */
	public static class JsonTypeOrJsonTypeArrayFilter extends PojoFilter<Object,Object> {

		@Override
		public Object filter(Object o, BeanContext beanContext) throws SerializeException {
			return o;
		}

		@Override
		public Object unfilter(Object o, ClassMeta<?> hint, BeanContext beanContext) throws ParseException {
			ClassMeta<?> cm = (o instanceof Collection ? beanContext.getClassMeta(JsonTypeArray.class) : beanContext.getClassMeta(JsonType.class));
			return beanContext.convertToType(o, cm);
		}
	}

	/**
	 * Returns the <code>definitions</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Map<String,Schema> getDefinitions() {
		return definitions;
	}

	/**
	 * Sets the <code>definitions</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setDefinitions(Map<String,Schema> definitions) {
		this.definitions = definitions;
		if (definitions != null)
			setMasterOn(definitions.values());
		return this;
	}

	/**
	 * Appends to the <code>definitions</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addDefinition(String name, Schema definition) {
		if (this.definitions == null)
			this.definitions = new LinkedHashMap<String,Schema>();
		this.definitions.put(name, definition);
		setMasterOn(definition);
		return this;
	}

	/**
	 * Returns the <code>properties</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Map<String,Schema> getProperties() {
		return properties;
	}

	/**
	 * Returns the property with the specified name.
	 * This is equivalent to calling <code>getProperty(name, <jk>false</jk>)</code>.
	 * @param name The property name.
	 * @return The property with the specified name, or <jk>null</jk> if no property is specified.
	 */
	public Schema getProperty(String name) {
		return getProperty(name, false);
	}

	/**
	 * Returns the property with the specified name.
	 * If <code>resolve</code> is <jk>true</jk>, the property object will automatically be
	 * 	resolved by calling {@link #resolve()}.
	 * Therefore, <code>getProperty(name, <jk>true</jk>)</code> is equivalent to calling
	 * 	<code>getProperty(name).resolve()</code>, except it's safe from a potential <code>NullPointerException</code>.
	 * @param name - The property name.
	 * @param resolve - If <jk>true</jk>, calls {@link #resolve()} on object before returning.
	 * @return The property with the specified name, or <jk>null</jk> if no property is specified.
	 */
	public Schema getProperty(String name, boolean resolve) {
		if (properties == null)
			return null;
		Schema s = properties.get(name);
		if (s == null)
			return null;
		if (resolve)
			s = s.resolve();
		return s;
	}

	/**
	 * Sets the <code>properties</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setProperties(Map<String,Schema> properties) {
		this.properties = properties;
		if (properties != null)
			for (Map.Entry<String,Schema> e : properties.entrySet()) {
				Schema value = e.getValue();
				setMasterOn(value);
				value.setName(e.getKey());
			}
		return this;
	}

	/**
	 * Appends to the <code>properties</code> property on this bean.
	 * Properties must have their <code>name</code> property set on them when using this method.
	 * @return This object (for method chaining).
	 * @throws BeanRuntimeException If property is found without a set <code>name</code> property.
	 */
	public Schema addProperties(Schema...properties) {
		if (this.properties == null)
			this.properties = new LinkedHashMap<String,Schema>();
		for (Schema p : properties) {
			if (p.getName() == null)
				throw new BeanRuntimeException(Schema.class, "Invalid property passed to Schema.addProperties().  Property name was null.");
			setMasterOn(p);
			this.properties.put(p.getName(), p);
		}
		return this;
	}

	/**
	 * Returns the <code>patternProperties</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Map<String,Schema> getPatternProperties() {
		return patternProperties;
	}

	/**
	 * Sets the <code>patternProperties</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setPatternProperties(Map<String,Schema> patternProperties) {
		this.patternProperties = patternProperties;
		if (patternProperties != null)
			for (Map.Entry<String,Schema> e : patternProperties.entrySet()) {
				Schema s = e.getValue();
				setMasterOn(s);
				s.setName(e.getKey());
			}
		return this;
	}

	/**
	 * Appends to the <code>properties</code> property on this bean.
	 * Properties must have their <code>name</code> property set to the pattern string when using this method.
	 * @return This object (for method chaining).
	 * @throws BeanRuntimeException If property is found without a set <code>name</code> property.
	 */
	public Schema addPatternProperties(SchemaProperty...properties) {
		if (this.patternProperties == null)
			this.patternProperties = new LinkedHashMap<String,Schema>();
		for (Schema p : properties) {
			if (p.getName() == null)
				throw new BeanRuntimeException(Schema.class, "Invalid property passed to Schema.addProperties().  Property name was null.");
			setMasterOn(p);
			this.patternProperties.put(p.getName(), p);
		}
		return this;
	}

	/**
	 * Returns the <code>dependencies</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Map<String,Schema> getDependencies() {
		return dependencies;
	}

	/**
	 * Sets the <code>dependencies</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setDependencies(Map<String,Schema> dependencies) {
		this.dependencies = dependencies;
		if (dependencies != null)
			setMasterOn(dependencies.values());
		return this;
	}

	/**
	 * Appends to the <code>dependencies</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addDependency(String name, Schema dependency) {
		if (this.dependencies == null)
			this.dependencies = new LinkedHashMap<String,Schema>();
		this.dependencies.put(name, dependency);
		setMasterOn(dependency);
		return this;
	}

	/**
	 * Returns the <code>items</code> property on this bean, or <jk>null</jk> if it is not set.
	 * Can be either a {@link Schema} or {@link SchemaArray} depending on what value was used to set it.
	 */
	@BeanProperty(filter=SchemaOrSchemaArrayFilter.class)
	public Object getItems() {
		if (itemsSchema != null)
			return itemsSchema;
		return itemsSchemaArray;
	}

	/**
	 * Convenience method for returning the <code>items</code> property when it is a {@link Schema} value.
	 * @return The currently set value, or <jk>null</jk> if the property is not set, or is set as a {@link SchemaArray}.
	 */
	@BeanIgnore
	public Schema getItemsAsSchema() {
		return itemsSchema;
	}

	/**
	 * Convenience method for returning the <code>items</code> property when it is a {@link SchemaArray} value.
	 * @return The currently set value, or <jk>null</jk> if the property is not set, or is set as a {@link Schema}.
	 */
	@BeanIgnore
	public SchemaArray getItemsAsSchemaArray() {
		return itemsSchemaArray;
	}

	/**
	 * Used during parsing to convert the <code>items</code> property to the correct class type.
	 * <ul>
	 * 	<li>If parsing a JSON-array, converts to a {@link SchemaArray}.
	 * 	<li>If parsing a JSON-object, converts to a {@link Schema}.
	 * </ul>
	 * Serialization method is a no-op.
	 */
	public static class SchemaOrSchemaArrayFilter extends PojoFilter<Object,Object> {

		@Override
		public Object filter(Object o, BeanContext beanContext) throws SerializeException {
			return o;
		}

		@Override
		public Object unfilter(Object o, ClassMeta<?> hint, BeanContext beanContext) throws ParseException {
			ClassMeta<?> cm = (o instanceof Collection ? beanContext.getClassMeta(SchemaArray.class) : beanContext.getClassMeta(Schema.class));
			return beanContext.convertToType(o, cm);
		}
	}

	/**
	 * Sets the <code>items</code> property on this bean.
	 * This object must be of type {@link Schema} or {@link SchemaArray}.
	 * @return This object (for method chaining).
	 * @throws BeanRuntimeException If invalid object type passed in.
	 */
	public Schema setItems(Object items) {
		this.itemsSchema = null;
		this.itemsSchemaArray = null;
		if (items != null) {
			if (items instanceof Schema) {
				this.itemsSchema = (Schema)items;
				setMasterOn(this.itemsSchema);
			} else if (items instanceof SchemaArray) {
				this.itemsSchemaArray = (SchemaArray)items;
				setMasterOn(this.itemsSchemaArray);
			} else
				throw new BeanRuntimeException(SchemaProperty.class, "Invalid attribute type ''{0}'' passed in.  Must be one of the following:  Schema, SchemaArray", items.getClass().getName());
		}
		return this;
	}

	/**
	 * Appends to the <code>items</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addItems(Schema...items) {
		if (this.itemsSchemaArray == null)
			this.itemsSchemaArray = new SchemaArray();
		this.itemsSchemaArray.addAll(items);
		setMasterOn(items);
		return this;
	}

	/**
	 * Returns the <code>multipleOf</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Number getMultipleOf() {
		return multipleOf;
	}

	/**
	 * Sets the <code>multipleOf</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setMultipleOf(Number multipleOf) {
		this.multipleOf = multipleOf;
		return this;
	}

	/**
	 * Returns the <code>maximum</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Number getMaximum() {
		return maximum;
	}

	/**
	 * Sets the <code>maximum</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setMaximum(Number maximum) {
		this.maximum = maximum;
		return this;
	}

	/**
	 * Returns the <code>exclusiveMaximum</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Boolean isExclusiveMaximum() {
		return exclusiveMaximum;
	}

	/**
	 * Sets the <code>exclusiveMaximum</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setExclusiveMaximum(Boolean exclusiveMaximum) {
		this.exclusiveMaximum = exclusiveMaximum;
		return this;
	}

	/**
	 * Returns the <code>minimum</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Number getMinimum() {
		return minimum;
	}

	/**
	 * Sets the <code>minimum</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setMinimum(Number minimum) {
		this.minimum = minimum;
		return this;
	}

	/**
	 * Returns the <code>exclusiveMinimum</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Boolean isExclusiveMinimum() {
		return exclusiveMinimum;
	}

	/**
	 * Sets the <code>exclusiveMinimum</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setExclusiveMinimum(Boolean exclusiveMinimum) {
		this.exclusiveMinimum = exclusiveMinimum;
		return this;
	}

	/**
	 * Returns the <code>maxLength</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Integer getMaxLength() {
		return maxLength;
	}

	/**
	 * Sets the <code>maxLength</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setMaxLength(Integer maxLength) {
		this.maxLength = maxLength;
		return this;
	}

	/**
	 * Returns the <code>minLength</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Integer getMinLength() {
		return minLength;
	}

	/**
	 * Sets the <code>minLength</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setMinLength(Integer minLength) {
		this.minLength = minLength;
		return this;
	}

	/**
	 * Returns the <code>pattern</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public String getPattern() {
		return pattern;
	}

	/**
	 * Sets the <code>pattern</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setPattern(String pattern) {
		this.pattern = pattern;
		return this;
	}

	/**
	 * Returns the <code>additionalItems</code> property on this bean, or <jk>null</jk> if it is not set.
	 * Can be either a {@link Boolean} or {@link SchemaArray} depending on what value was used to set it.
	 */
	@BeanProperty(filter=BooleanOrSchemaArrayFilter.class)
	public Object getAdditionalItems() {
		if (additionalItemsBoolean != null)
			return additionalItemsBoolean;
		return additionalItemsSchemaArray;
	}

	/**
	 * Convenience method for returning the <code>additionalItems</code> property when it is a {@link Boolean} value.
	 * @return The currently set value, or <jk>null</jk> if the property is not set, or is set as a {@link SchemaArray}.
	 */
	@BeanIgnore
	public Boolean getAdditionalItemsAsBoolean() {
		return additionalItemsBoolean;
	}

	/**
	 * Convenience method for returning the <code>additionalItems</code> property when it is a {@link SchemaArray} value.
	 * @return The currently set value, or <jk>null</jk> if the property is not set, or is set as a {@link Boolean}.
	 */
	@BeanIgnore
	public List<Schema> getAdditionalItemsAsSchemaArray() {
		return additionalItemsSchemaArray;
	}

	/**
	 * Sets the <code>additionalItems</code> property on this bean.
	 * This object must be of type {@link Boolean} or {@link SchemaArray}.
	 * @return This object (for method chaining).
	 * @throws BeanRuntimeException If invalid object type passed in.
	 */
	public Schema setAdditionalItems(Object additionalItems) {
		this.additionalItemsBoolean = null;
		this.additionalItemsSchemaArray = null;
		if (additionalItems != null) {
			if (additionalItems instanceof Boolean)
				this.additionalItemsBoolean = (Boolean)additionalItems;
			else if (additionalItems instanceof SchemaArray) {
				this.additionalItemsSchemaArray = (SchemaArray)additionalItems;
				setMasterOn(this.additionalItemsSchemaArray);
			} else
				throw new BeanRuntimeException(SchemaProperty.class, "Invalid attribute type ''{0}'' passed in.  Must be one of the following:  Boolean, SchemaArray", additionalItems.getClass().getName());
		}
		return this;
	}

	/**
	 * Appends to the <code>additionalItems</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addAdditionalItems(Schema...additionalItems) {
		if (this.additionalItemsSchemaArray == null)
			this.additionalItemsSchemaArray = new SchemaArray();
		this.additionalItemsSchemaArray.addAll(additionalItems);
		setMasterOn(additionalItems);
		return this;
	}

	/**
	 * Used during parsing to convert the <code>additionalItems</code> property to the correct class type.
	 * <ul>
	 * 	<li>If parsing a JSON-array, converts to a {@link SchemaArray}.
	 * 	<li>If parsing a JSON-boolean, converts to a {@link Boolean}.
	 * </ul>
	 * Serialization method is a no-op.
	 */
	public static class BooleanOrSchemaArrayFilter extends PojoFilter<Object,Object> {

		@Override
		public Object filter(Object o, BeanContext beanContext) throws SerializeException {
			return o;
		}

		@Override
		public Object unfilter(Object o, ClassMeta<?> hint, BeanContext beanContext) throws ParseException {
			ClassMeta<?> cm = (o instanceof Collection ? beanContext.getClassMeta(SchemaArray.class) : beanContext.getClassMeta(Boolean.class));
			return beanContext.convertToType(o, cm);
		}
	}

	/**
	 * Returns the <code>maxItems</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Integer getMaxItems() {
		return maxItems;
	}

	/**
	 * Sets the <code>maxItems</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setMaxItems(Integer maxItems) {
		this.maxItems = maxItems;
		return this;
	}

	/**
	 * Returns the <code>minItems</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Integer getMinItems() {
		return minItems;
	}

	/**
	 * Sets the <code>minItems</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setMinItems(Integer minItems) {
		this.minItems = minItems;
		return this;
	}

	/**
	 * Returns the <code>uniqueItems</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Boolean getUniqueItems() {
		return uniqueItems;
	}

	/**
	 * Sets the <code>uniqueItems</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setUniqueItems(Boolean uniqueItems) {
		this.uniqueItems = uniqueItems;
		return this;
	}

	/**
	 * Returns the <code>maxProperties</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Integer getMaxProperties() {
		return maxProperties;
	}

	/**
	 * Sets the <code>maxProperties</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setMaxProperties(Integer maxProperties) {
		this.maxProperties = maxProperties;
		return this;
	}

	/**
	 * Returns the <code>minProperties</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Integer getMinProperties() {
		return minProperties;
	}

	/**
	 * Sets the <code>minProperties</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setMinProperties(Integer minProperties) {
		this.minProperties = minProperties;
		return this;
	}

	/**
	 * Returns the <code>required</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public List<String> getRequired() {
		return required;
	}

	/**
	 * Sets the <code>required</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setRequired(List<String> required) {
		this.required = required;
		return this;
	}

	/**
	 * Appends to the <code>required</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addRequired(List<String> required) {
		if (this.required == null)
			this.required = new LinkedList<String>();
		for (String r : required)
			this.required.add(r);
		return this;
	}

	/**
	 * Appends to the <code>required</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addRequired(String...required) {
		if (this.required == null)
			this.required = new LinkedList<String>();
		for (String r : required)
			this.required.add(r);
		return this;
	}

	/**
	 * Appends to the <code>required</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addRequired(SchemaProperty...properties) {
		if (this.required == null)
			this.required = new LinkedList<String>();
		for (SchemaProperty p : properties)
			this.required.add(p.getName());
		return this;
	}

	/**
	 * Returns the <code>additionalProperties</code> property on this bean, or <jk>null</jk> if it is not set.
	 * Can be either a {@link Boolean} or {@link SchemaArray} depending on what value was used to set it.
	 */
	@BeanProperty(filter=BooleanOrSchemaFilter.class)
	public Object getAdditionalProperties() {
		if (additionalPropertiesBoolean != null)
			return additionalItemsBoolean;
		return additionalPropertiesSchema;
	}

	/**
	 * Convenience method for returning the <code>additionalProperties</code> property when it is a {@link Boolean} value.
	 * @return The currently set value, or <jk>null</jk> if the property is not set, or is set as a {@link Schema}.
	 */
	@BeanIgnore
	public Boolean getAdditionalPropertiesAsBoolean() {
		return additionalPropertiesBoolean;
	}

	/**
	 * Convenience method for returning the <code>additionalProperties</code> property when it is a {@link Schema} value.
	 * @return The currently set value, or <jk>null</jk> if the property is not set, or is set as a {@link Boolean}.
	 */
	@BeanIgnore
	public Schema getAdditionalPropertiesAsSchema() {
		return additionalPropertiesSchema;
	}

	/**
	 * Sets the <code>additionalProperties</code> property on this bean.
	 * This object must be of type {@link Boolean} or {@link Schema}.
	 * @return This object (for method chaining).
	 * @throws BeanRuntimeException If invalid object type passed in.
	 */
	public Schema setAdditionalProperties(Object additionalProperties) {
		this.additionalPropertiesBoolean = null;
		this.additionalPropertiesSchema = null;
		if (additionalProperties != null) {
			if (additionalProperties instanceof Boolean)
				this.additionalPropertiesBoolean = (Boolean)additionalProperties;
			else if (additionalProperties instanceof Schema) {
				this.additionalPropertiesSchema = (Schema)additionalProperties;
				setMasterOn(this.additionalPropertiesSchema);
			} else
				throw new BeanRuntimeException(SchemaProperty.class, "Invalid attribute type ''{0}'' passed in.  Must be one of the following:  Boolean, Schema", additionalProperties.getClass().getName());
		}
		return this;
	}

	/**
	 * Used during parsing to convert the <code>additionalProperties</code> property to the correct class type.
	 * <ul>
	 * 	<li>If parsing a JSON-object, converts to a {@link Schema}.
	 * 	<li>If parsing a JSON-boolean, converts to a {@link Boolean}.
	 * </ul>
	 * Serialization method is a no-op.
	 */
	public static class BooleanOrSchemaFilter extends PojoFilter<Object,Object> {

		@Override
		public Object filter(Object o, BeanContext beanContext) throws SerializeException {
			return o;
		}

		@Override
		public Object unfilter(Object o, ClassMeta<?> hint, BeanContext beanContext) throws ParseException {
			ClassMeta<?> cm = (o instanceof Boolean ? beanContext.getClassMeta(Boolean.class) : beanContext.getClassMeta(Schema.class));
			return beanContext.convertToType(o, cm);
		}
	}

	/**
	 * Returns the <code>enum</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public List<String> getEnum() {
		return _enum;
	}

	/**
	 * Sets the <code>enum</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setEnum(List<String> _enum) {
		this._enum = _enum;
		return this;
	}

	/**
	 * Appends to the <code>enum</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addEnum(String..._enum) {
		if (this._enum == null)
			this._enum = new LinkedList<String>();
		for (String e : _enum)
			this._enum.add(e);
		return this;
	}

	/**
	 * Returns the <code>allOf</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public List<Schema> getAllOf() {
		return allOf;
	}

	/**
	 * Sets the <code>allOf</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setAllOf(List<Schema> allOf) {
		this.allOf = allOf;
		setMasterOn(allOf);
		return this;
	}

	/**
	 * Appends to the <code>allOf</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addAllOf(Schema...allOf) {
		if (this.allOf == null)
			this.allOf = new LinkedList<Schema>();
		setMasterOn(allOf);
		for (Schema s : allOf)
			this.allOf.add(s);
		return this;
	}

	/**
	 * Returns the <code>anyOf</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public List<Schema> getAnyOf() {
		return anyOf;
	}

	/**
	 * Sets the <code>anyOf</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setAnyOf(List<Schema> anyOf) {
		this.anyOf = anyOf;
		setMasterOn(anyOf);
		return this;
	}

	/**
	 * Appends to the <code>anyOf</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addAnyOf(Schema...anyOf) {
		if (this.anyOf == null)
			this.anyOf = new LinkedList<Schema>();
		setMasterOn(anyOf);
		for (Schema s : anyOf)
			this.anyOf.add(s);
		return this;
	}

	/**
	 * Returns the <code>oneOf</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public List<Schema> getOneOf() {
		return oneOf;
	}

	/**
	 * Sets the <code>oneOf</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setOneOf(List<Schema> oneOf) {
		this.oneOf = oneOf;
		setMasterOn(oneOf);
		return this;
	}

	/**
	 * Appends to the <code>oneOf</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema addOneOf(Schema...oneOf) {
		if (this.oneOf == null)
			this.oneOf = new LinkedList<Schema>();
		setMasterOn(oneOf);
		for (Schema s : oneOf)
			this.oneOf.add(s);
		return this;
	}

	/**
	 * Returns the <code>not</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	public Schema getNot() {
		return not;
	}

	/**
	 * Sets the <code>not</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	public Schema setNot(Schema not) {
		this.not = not;
		setMasterOn(not);
		return this;
	}

	/**
	 * Returns the <code>$ref</code> property on this bean, or <jk>null</jk> if it is not set.
	 */
	@BeanProperty(name="$ref")
	public URI getRef() {
		return ref;
	}

	/**
	 * Sets the <code>$ref</code> property on this bean.
	 * @return This object (for method chaining).
	 */
	@BeanProperty(name="$ref")
	public Schema setRef(URI ref) {
		this.ref = ref;
		return this;
	}

	private void setMasterOn(Schema s) {
		if (s != null)
			s.setMaster(this);
	}

	private void setMasterOn(Schema[] ss) {
		if (ss != null)
			for (Schema s : ss)
				setMasterOn(s);
	}

	private void setMasterOn(Collection<Schema> ss) {
		if (ss != null)
			for (Schema s : ss)
				setMasterOn(s);
	}

	private void setMasterOn(SchemaArray ss) {
		if (ss != null)
			for (Schema s : ss)
				setMasterOn(s);
	}

	/**
	 * Sets the master schema for this schema and all child schema objects (e.g. properties).
	 * All child elements in a schema should point to a single "master" schema in order to
	 * 	locate registered SchemaMap objects for resolving external schemas.
	 * @param master The master schema to associate on this and all children.  Can be <jk>null</jk>.
	 */
	protected void setMaster(Schema master) {
		this.master = master;
		if (definitions != null)
			for (Schema s : definitions.values())
				s.setMaster(master);
		if (properties != null)
			for (Schema s : properties.values())
				s.setMaster(master);
		if (patternProperties != null)
			for (Schema s : patternProperties.values())
				s.setMaster(master);
		if (dependencies != null)
			for (Schema s : dependencies.values())
				s.setMaster(master);
		if (itemsSchema != null)
			itemsSchema.setMaster(master);
		if (itemsSchemaArray != null)
			for (Schema s : itemsSchemaArray)
				s.setMaster(master);
		if (additionalItemsSchemaArray != null)
			for (Schema s : additionalItemsSchemaArray)
				s.setMaster(master);
		if (additionalPropertiesSchema != null)
			additionalPropertiesSchema.setMaster(master);
		if (allOf != null)
			for (Schema s : allOf)
				s.setMaster(master);
		if (anyOf != null)
			for (Schema s : anyOf)
				s.setMaster(master);
		if (oneOf != null)
			for (Schema s : oneOf)
				s.setMaster(master);
		if (not != null)
			not.setMaster(master);
	}


	/**
	 * Sets the <code>$ref</code> property on this bean.
	 * The parameter must be a valid URI.  It can be <jk>null</jk>.
	 * @return This object (for method chaining).
	 */
	public Schema setRef(String ref) {
		return setRef(ref == null ? null : URI.create(ref));
	}

	/**
	 * If this schema is a reference to another schema (i.e. has its <code>$ref</code> property set),
	 * 	this method will retrieve the referenced schema from the schema map registered with this schema.
	 * If this schema is not a reference, or no schema map is registered with this schema, this method
	 * 	is a no-op and simply returns this object.
	 */
	public Schema resolve() {
		if (ref == null || master.schemaMap == null)
			return this;
		return master.schemaMap.get(ref);
	}

	/**
	 * Associates a schema map with this schema for resolving other schemas identified
	 * 	through <code>$ref</code> properties.
	 * @param schemaMap - The schema map to associate with this schema.  Can be <jk>null</jk>.
	 * @return This object (for method chaining).
	 */
	public Schema setSchemaMap(SchemaMap schemaMap) {
		this.schemaMap = schemaMap;
		return this;
	}
}
