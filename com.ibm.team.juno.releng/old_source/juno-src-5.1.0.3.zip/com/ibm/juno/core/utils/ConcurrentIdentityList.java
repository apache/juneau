/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.utils;

import java.util.*;
import java.util.concurrent.*;

/**
 * Combination of a {@link LinkedList} and {@link ConcurrentSkipListSet}.
 * <ul>
 * 	<li>Duplicate objects (by identity) will be skipped during insertion.
 * 	<li>Order of insertion maintained.
 * </ul>
 * <p>
 * 	This class is thread safe.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <T> Entry type.
 */
public class ConcurrentIdentityList<T> extends LinkedList<T> {
	Set<T> set = new ConcurrentSkipListSet<T>();

	@Override
	public boolean add(T t) {
		if (set.add(t))
			return super.add(t);
		return false;
	}

	@Override
	public boolean contains(Object t) {
		return set.contains(t);
	}
}
