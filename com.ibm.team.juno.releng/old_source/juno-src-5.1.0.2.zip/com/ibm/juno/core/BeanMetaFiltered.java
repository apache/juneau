/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core;

import java.util.*;

import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.utils.*;

/**
 * Sames as {@link BeanMeta}, except the list of bean properties are limited
 * by a {@link BeanProperty#properties()} annotation.
 *
 * @param <T> The class type that this metadata applies to.
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class BeanMetaFiltered<T> extends BeanMeta<T> {

	private final BeanMeta<T> innerMeta;
	private final String[] pNames;

	/**
	 * Wrapper constructor.
	 * @param innerMeta - The unfiltered bean meta of the bean property.
	 * @param pNames - The list of filtered property names.
	 */
	public BeanMetaFiltered(BeanMeta<T> innerMeta, String[] pNames) {
		this.innerMeta = innerMeta;
		this.properties = new LinkedHashMap<String,BeanPropertyMeta<T>>();
		for (String p : pNames)
			properties.put(p, innerMeta.getMetaProperty(p));
		this.pNames = pNames;
	}

	/**
	 * Wrapper constructor.
	 * @param innerMeta - The unfiltered bean meta of the bean property.
	 * @param pNames - The list of filtered property names.
	 */
	public BeanMetaFiltered(BeanMeta<T> innerMeta, Collection<String> pNames) {
		this(innerMeta, pNames.toArray(new String[pNames.size()]));
	}

	@Override
	public ClassMeta<T> getClassMeta() {
		return innerMeta.classMeta;
	}

	@Override
	public Collection<BeanPropertyMeta<T>> getMetaProperties() {
		return properties.values();
	}

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<String,BeanPropertyMeta<T>> getXmlAttrProperties() {
		return new FilteredMap(innerMeta.xmlAttrs, pNames);
	}

	@Override
	public BeanPropertyMeta<T> getMetaProperty(String name) {
		return properties.get(name);
	}

	@Override
	public String toString() {
		return innerMeta.c.getName();
	}
}
