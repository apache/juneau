/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.utils;

import java.lang.reflect.*;
import java.util.*;

/**
 * Quick and dirty utilities for working with arrays.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ArrayUtils {

	/**
	 * Appends one or more elements to an array.
	 * @param <T> The element type.
	 * @param array The array to append to.
	 * @param newElements The new elements to append to the array.
	 * @return A new array with the specified elements appended.
	 */
	@SuppressWarnings("unchecked")
	public static final <T> T[] append(T[] array, T...newElements) {
		if (newElements.length == 0)
			return array;
		T[] a = (T[])Array.newInstance(newElements[0].getClass(), array.length + newElements.length);
		for (int i = 0; i < array.length; i++)
			a[i] = array[i];
		for (int i = 0; i < newElements.length; i++)
			a[i+array.length] = newElements[i];
		return a;
	}

	/**
	 * Creates a new array with reversed entries.
	 * @param <T> The class type of the array.
	 * @param array The array to reverse.
	 * @return A new array with reversed entries.
	 */
	@SuppressWarnings("unchecked")
	public static final <T> T[] reverse(T[] array) {
		Class<T> c = (Class<T>)array.getClass().getComponentType();
		T[] a2 = (T[])Array.newInstance(c, array.length);
		for (int i = 0; i < array.length; i++)
			a2[a2.length-i-1] = array[i];
		return a2;
	}

	/**
	 * Converts the specified array to a <code>Set</code>.
	 * <p>
	 * 	The order of the entries in the set are the same as the array.
	 *
	 * @param <T> The entry type of the array.
	 * @param array The array being wrapped in a <code>Set</code> interface.
	 * @return The new set.
	 */
	public static final <T> Set<T> asSet(final T[] array) {
		return new AbstractSet<T>() {

			@Override
			public Iterator<T> iterator() {
				return new Iterator<T>() {
					int i = 0;

					@Override
					public boolean hasNext() {
						return i < array.length;
					}

					@Override
					public T next() {
						if (i >= array.length)
							throw new NoSuchElementException();
						T t = array[i];
						i++;
						return t;
					}

					@Override
					public void remove() {
						throw new UnsupportedOperationException();
					}
				};
			}

			@Override
			public int size() {
				return array.length;
			}
		};
	}
}
