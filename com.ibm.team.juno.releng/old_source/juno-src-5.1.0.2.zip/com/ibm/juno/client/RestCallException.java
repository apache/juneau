/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.client;

import static java.lang.String.*;

import java.io.*;
import java.net.*;
import java.util.regex.*;

import org.apache.http.client.*;

/**
 * Exception representing a <code>400+</code> HTTP response code against a remote resource.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestCallException extends IOException {

	private int responseCode;
	private String response, responseStatusMessage;
	private Throwable cause;
	HttpResponseException e;

	/** Constructor. */
	protected RestCallException(String msg) {
		super(msg);
	}

	/**
	 * Constructor.
	 *
	 * @param e The inner cause of the exception.
	 */
	protected RestCallException(Exception e) {
		super(e.getLocalizedMessage());
		if (e instanceof FileNotFoundException) {
			responseCode = 404;
		} else if (e.getMessage() != null) {
			Pattern p = Pattern.compile("[^\\d](\\d{3})[^\\d]");
			Matcher m = p.matcher(e.getMessage());
			if (m.find())
				responseCode = Integer.parseInt(m.group(1));
		}
		setStackTrace(e.getStackTrace());
	}

	/**
	 * Constructor.
	 *
	 * @param responseCode The response code.
	 * @param responseMsg The response message.
	 * @param method The HTTP method (for message purposes).
	 * @param url The HTTP URL (for message purposes).
	 * @param response The reponse from the server.
	 */
	protected RestCallException(int responseCode, String responseMsg, String method, URI url, String response) {
		super(format("HTTP method '%s' call to '%s' caused response code '%s,%s'.%nResponse: %n%s%n", method, url, responseCode, responseMsg, response));
		this.responseCode = responseCode;
		this.responseStatusMessage = responseMsg;
		this.response = response;
	}

	/**
	 * Returns the HTTP response status code.
	 *
	 * @return The response status code.  If a connection could not be made at all, returns <code>0<code>.
	 */
	public int getResponseCode() {
		return responseCode;
	}

	/**
	 * Returns the HTTP response message body text.
	 *
	 * @return The response message body text.
	 */
	public String getResponseMessage() {
		return response;
	}

	/**
	 * Returns the response status message as a plain string.
	 *
	 * @return The response status message.
	 */
	public String getResponseStatusMessage() {
		return responseStatusMessage;
	}

	@Override
	public Throwable getCause() {
		return cause;
	}

	/**
	 * Sets the inner cause for this exception.
	 * @param cause The inner cause.
	 * @return This object (for method chaining).
	 */
	public RestCallException setCause(Throwable cause) {
		this.cause = cause;
		return this;
	}
}
