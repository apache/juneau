package com.ibm.juno.server.serializers;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.SerializerProperties.*;
import static com.ibm.juno.core.xml.XmlSerializerProperties.*;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.rdfxml.*;
import com.ibm.juno.core.xml.*;
import com.ibm.juno.server.*;

/**
 * Serializes POJOs to HTTP responses as RDF/XML.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"text/xml+rdf"</js></ul></td>
 * 		<td><ul><li><js>"text/xml+rdf"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfRestSerializer extends RestSerializerSerializer {

	private RdfXmlSerializer serializer;

	/**
	 * Constructor using {@link RdfXmlSerializer#DEFAULT} as the POJO serializer.
	 */
	public RdfRestSerializer() {
		this(
			RdfXmlSerializer.DEFAULT_CONDENSED.clone()
				.setProperty(ADD_NAMESPACE_URIS_TO_ROOT, true)
				.setProperty(AUTO_DETECT_NAMESPACES, true)
		);
	}

	/**
	 * Construct using the specified {@link XmlSerializer} as the POJO serializer.
	 *
	 * @param serializer The serializer.
	 */
	public RdfRestSerializer(RdfXmlSerializer serializer) {
		super(serializer);
		this.serializer = serializer;
	}

	@Override
	public void serialize(RestRequest req, Object output, Writer out, JsonMap properties, String matchingAccept) throws IOException, SerializeException {
		boolean useIndentation = properties.getBoolean(USE_INDENTATION, serializer.isUseIndentation());
		char quoteChar = properties.get(char.class, QUOTE_CHAR, serializer.getQuoteChar());
		XmlSerializerWriter w = new XmlSerializerWriter(out, useIndentation, quoteChar);
		boolean en = serializer.isEnableNamespaces();
		Namespace rdfNs = serializer.getRdfNamespace();
		Namespace dnsNs = serializer.getDefaultNamespace();
		String
			rdf = (en ? rdfNs.getName() : null),
			rdfUri = (en ? rdfNs.getUri() : null),
			dns = (en ? dnsNs.getName() : null),
			dnsUri = (en ? dnsNs.getUri() : null);

		w.append("<?xml")
			.attr("version", "1.0")
			.attr("encoding", "UTF-8")
			.appendln("?>");
		w.oTag(rdf, "RDF");
		if (rdf != null)
			w.attr("xmlns", rdf, rdfUri);
		if (dns != null)
			w.attr("xmlns", dns, dnsUri);
		w.appendln(">");
		serializer.serialize(w, output, req.getRequestURL().toString(), properties);
		w.eTag(rdf, "RDF");
		w.flush();
		w.close();
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"text/xml+rdf"};
	}
}
