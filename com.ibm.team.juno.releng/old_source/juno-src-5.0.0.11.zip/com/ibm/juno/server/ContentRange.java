/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2010. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  Use,
 * duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *******************************************************************************/

package com.ibm.juno.server;

import java.lang.reflect.*;
import java.util.*;


/**
 * The abstract base class for representing weighted types typically found in the
 * content negotiation <js>"accept-*"</js> and <js>"content-*"</js> headers for RFC2616.
 */
public abstract class ContentRange implements Comparable<ContentRange> {

	/**
	 * The type enclosed by this content range.
	 */
	final protected String type;

	/**
	 * The 'q' ("quality") value for this type.
	 */
	final protected Float qValue;

	/**
	 * Returns the type enclosed by this content range.
	 *
	 * @return The type of this content range.
	 * 	Never <jk>null</jk>.
	 * 	The returned string will be normalized to lowercase from its original input value.
	 */
	public String getType() {
		return type;
	}

	/**
	 * Returns the 'q' ("quality") value for this type, as described in Section 3.9 of RFC2616.
	 * The domain is "short floating point", with a range of 0.0 to 1.0, with 0.0 as "unacceptable" and 1.0 as "most acceptable".
	 *
	 * @return The 'q' value for this type.
	 * 	Never <jk>null</jk>.
	 * 	If 'q' value doesn't make sense for the context (e.g. this range was extracted from a <js>"content-*"</js> header, as opposed to <js>"accept-*"</js>
	 * 		header, its value will always be <js>"1"</js>.
	 */
	public Float getQValue() {
		return qValue;
	}

	/**
	 * Creates a ContentRange object with the referenced values.
	 *
	 * @param type The type of this content range.
	 * 	May be <jk>null</jk>.
	 * 	Setting to <jk>null</jk> or the empty string is the equivalent to setting to <js>"*"</js> (all types).
	 * 	The string is normalized to lowercase and all LWS removed.
	 * @param qValue The quality value of this range.
	 * 	May be <jk>null</jk>.
	 * 	Note that the permissible range of values are <code>0</code> to <code>1.0</code>.
	 * 	Setting to <jk>null</jk> is the equivalent to setting a quality value of <js>"1.0</js>.
	 */
	public ContentRange(String type, Float qValue) {
		if (type == null || type.length() == 0)
			type = "*";

		this.type = type.toLowerCase().trim();

		if (qValue == null)
			this.qValue = new Float(1.0);
		else if (qValue < 0 || qValue > 1)
			throw new NumberFormatException("qValue cannot be less than '0' or greater than '1.0'");
		else
			this.qValue = qValue;
	}

	interface RangeParseCallback {

		/**
		 * Creates a ContentRange derivation. Called when a <code>ContentRange</code> has been parsed.
		 *
		 * @param type The type to create.
		 * 	May be <jk>null</jk> or empty.
		 * 	If non-<jk>null</jk> the name is normalized to lowercase with leading/trailing whitespace trimmed.
		 * @param parameters The optional parameters to the type.
		 * 	May be <jk>null</jk>.
		 * 	If non-<jk>null</jk> the name/values are normalized to lowercase with leading/trailing whitespace trimmed.
		 * @param qValue The quality value for the type.
		 * 	May be <jk>null</jk>.
		 * @param extensions The extensions to the quality value.
		 * 	May be <jk>null</jk>.
		 * 	If non-<jk>null</jk> the name/values are normalized to lowercase with leading/trailing whitespace trimmed.
		 * @return The created <code>ContentRange</code>.
		 * 	May be <jk>null</jk> to indicate that a content range should not be created and added to the parsed ranges.
		 */
		ContentRange rangeParsed(String type, HashMap<String,String[]> parameters, Float qValue, HashMap<String,String[]> extensions);

		/**
		 * Called prior to sorting a completed range.
		 * <p>
		 * Implementations have the opportunity to modify the referenced collection prior to the sort.
		 *
		 * @param range The completed range, prior to sorting.
		 * 	Never <jk>null</jk>.
		 */
		void preSort(ArrayList<ContentRange> range);

		/**
		 * Called immediately after sorting a completed range, but prior to returning.
		 * <p>
		 * Implementations have the opportunity to modify the referenced sorted collection prior to it being returned from the parse.
		 *
		 * @param range The completed range, immediately after sorting but prior to returning.
		 * 	Never <jk>null</jk>.
		 */
		void postSort(ArrayList<ContentRange> range);
	}

	/**
	 * Parses an <code>Accept*</code> header value string, and returns the set of <code>ContentRanges</code> that describes the values parsed.
	 *
	 * @param value The header value string to be parsed.
	 * 	May be <jk>null</jk> or empty.
	 * @param cb The interface callback to call for creating and sorting <code>ContentRange</code> derivations.
	 * 	Must not be <jk>null</jk>.
	 * @return The sorted <code>ContentRanges</code>.
	 * 	Never <jk>null</jk>.
	 */
	static ContentRange[] parse(String value, RangeParseCallback cb) {

		if (cb == null)
			throw new IllegalArgumentException("RangeParseCallback must not be null");

		ArrayList<ContentRange> ranges = new ArrayList<ContentRange>(5);

		if (value == null)
			value = "";
		if (value.length() == 0) {
			ContentRange range = cb.rangeParsed(null, null, null, null);
			if (range != null)
				ranges.add(range);
		}

		StringTokenizer rangeTokenizer = new StringTokenizer(value, ",");
		while (rangeTokenizer.hasMoreTokens()) {
			StringTokenizer parmTokenizer = new StringTokenizer(rangeTokenizer.nextToken(), ";");
			if (parmTokenizer.countTokens() == 0)
				continue;

			// There is at least a type.
			String type = parmTokenizer.nextToken().toLowerCase().trim();
			Float qValue = null;
			HashMap<String,String[]> parameters = null;
			HashMap<String,String[]> extensions = null;

			int numTokens = parmTokenizer.countTokens();
			if (numTokens == 0) {
				// Only the type of the range is specified
				ContentRange range = cb.rangeParsed(type, parameters, qValue, extensions);
				if (range != null)
					ranges.add(range);
				continue;
			}

			// There are either parameters or a qvalue next
			String nextToken = parmTokenizer.nextToken().toLowerCase();
			String[] parm = splitPair(nextToken, '=');
			if (parm[0].equalsIgnoreCase("q")) {
				qValue = new Float(parm[1]);
			} else {
				parameters = new HashMap<String,String[]>();
				parameters.put(parm[0].toLowerCase(), new String[] { parm[1].toLowerCase() });
				while (parmTokenizer.hasMoreTokens()) {
					nextToken = parmTokenizer.nextToken().toLowerCase();
					parm = splitPair(nextToken, '=');
					if (parm[0].equalsIgnoreCase("q")) {
						qValue = new Float(parm[1]);
						break;
					}
					ContentRange.updateParmMap(parameters, parm);
				}
			}

			if (parmTokenizer.hasMoreTokens()) {
				// If we got here, then we're parsing the q-value extensions
				extensions = new HashMap<String,String[]>();
				while (parmTokenizer.hasMoreTokens()) {
					nextToken = parmTokenizer.nextToken().toLowerCase();
					parm = splitPair(nextToken, '=');
					ContentRange.updateParmMap(extensions, parm);
				}
			}

			// Finally, add the new ContentRange to the list
			ContentRange range = cb.rangeParsed(type, parameters, qValue, extensions);
			if (range != null)
				ranges.add(range);
		}

		// Sort the list prior to return.
		cb.preSort(ranges);
		Collections.sort(ranges);
		cb.postSort(ranges);
		return ranges.toArray(new ContentRange[ranges.size()]);
	}

	/**
	 * Updates a parameter map (parameter as described in RFC2616 as token=token pair) with a parameter token.
	 * <p>
	 * If the LHS of the parameter is already in the map, then the maps set of values is appended
	 * to with the parameter RHS, else a new name/value pair is added to the map.
	 * The name/values are normalized to lower-case.
	 *
	 * @param parmMap The parameter map to update.
	 * 	Must not be <jk>null</jk>.
	 * @param token The <code>token=token</code> token, tokenized into a name/value pair (name at array position <code>0</code>, value at <code>1</code>).
	 *  	Must not be <jk>null</jk>.
	 */
	static private void updateParmMap(Map<String,String[]> parmMap, String[] parm) {

		String name = parm[0].toLowerCase();
		String value = parm[1].toLowerCase();

		if (parmMap.containsKey(name)) {
			String[] values = parmMap.get(name);
			String[] newVals = (String[]) Array.newInstance(String.class, values.length + 1);
			System.arraycopy(values, 0, newVals, 0, values.length);
			newVals[newVals.length - 1] = value;
			parmMap.put(name, newVals);
		} else {
			parmMap.put(name, new String[] { value });
		}
	}

	/**
	 * <code>ContentRanges</code> are considered equal if their qValues and types compare equal (case-insensitive compare for type).
	 *
	 * @return <jk>true</jk>if the qValues and types compare equal, <jk>false</jk> if not.
	 */
	@Override
	public boolean equals(Object o) {
		if (o == null || !(o instanceof ContentRange))
			return false;
		if (this == o)
			return true;

		ContentRange that = (ContentRange) o;
		return qValue.equals(that.qValue) && type.equalsIgnoreCase(that.type);
	}

	/**
	 * Returns a hash based on this instance's <code>type</code>.
	 *
	 * @return Returns the hashcode of the instance's type.
	 */
	@Override
	public int hashCode() {
		return type.hashCode();
	}

	/**
	 * Provides a string representation of this media range, suitable for use as an <code>Accept</code> header value.
	 * <p>
	 * Note that the literal text values used to create this range may be normalized to lowercase on
	 * 	construction, and will be represented as such here - the values may not compare equal wrt case-sensitivity
	 * 	with the values used to create this instance.
	 *
	 * @return A media range suitable for use as an Accept header value. Never <code>null</code>.
	 */
	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();

		buf.append(type);

		 // '1' is equivalent to specifying no qValue.
		if (qValue.floatValue() != 1.0)
			buf.append(String.format(";q=%s", qValue.toString()));

		return buf.toString();
	}

	/**
	 * Compares two <code>ContentRanges</code> for equality.
	 * <p>
	 * The values are first compared according to <code>qValue</code> values.
	 * Should those values be equal, the <code>type</code> is then lexicographically
	 * compared (case-insensitive) in ascending order, with the <js>"*"</js> type demoted last in that order.
	 *
	 * @param that The range to compare to. If <jk>null</jk> or not of type <code>ContentRange</code>, this instance is promoted.
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ContentRange that) {

		if (that == null)
			return 1;

		float lhs = qValue.floatValue();
		float rhs = that.qValue.floatValue();

		if (lhs == rhs) {
			String thisType = type;
			String thatType = that.type;
			if (thisType.equals(thatType))
				return 0;
			else if (thisType.equals("*"))
				return 1;
			else if (thatType.equals("*"))
				return -1;
			else
				return thisType.compareTo(thatType);
		} else if (lhs < rhs)
			return 1;
		else
			return -1;
	}

	/**
	 * Returns the value described in {@link #splitPair(String, char)}, as if
	 * the char argument were set to <code>/</code>.  Additionally, returns
	 * <code>{ "*", "*" }</code> if the string argument is set to <code>"*"</code>.
	 *
	 * @see #splitPair(String, char)
	 */
	static String[] splitAcceptPairAllowingSingleAsterisk(String token) {
		// Java programmatic clients will by default use this single asterisk in
		// their accept header.  Allow this (even though it is contrary to HTTP
		// specs).
		if (token.equals("*"))
			return new String[] { "*", "*" };
		return splitPair(token, '/');
	}

    /**
     * Returns the value described in {@link #splitPair(String, char, boolean)},
     * as if the boolean argument were set to <code>true</code>.
     *
     * @see #splitPair(String, char, boolean)
     */
    static String[] splitPair(String token, char ch) {
        return splitPair(token, ch, true);
    }

    /**
     * Returns a two element array containing the left and right-hand sides
     * of a token as separated by the specified <code>ch</code>.  The token
     * is split on the first occurrence of the specified character.  Any LWS
     * occurring on either end of the split tokens is removed.
     *
     * @param token The parameter pair. Must be non-<code>null</code>. If
     * <code>mustExist</code> is <code>true</code>, then the token must contain
     * an embedded reference to <code>ch</code>.

     * @param ch The character to split on.
     *
     * @param mustExist <code>true</code> if the split character <code>ch</code>
     * must exist in <code>token</code>, <code>false</code> if not.
     *
     * @return The split pair of strings.  If <code>mustExist</code> is <code>true</code>,
     * the LHS of the split is found in element '0', the RHS in element '1'.  If
     * <code>mustExist</code> is <code>false</code> and the split character is not
     * found, the trimmed token is found in element '0', and the empty string in
     * element '1'.
     */
    static String[] splitPair(String token, char ch, boolean mustExist) {

        int ndx = token.indexOf(ch);
        if (ndx == -1) {
            if (mustExist)
                throw new IllegalArgumentException(String.format("token is expected to be in 'name%svalue' format", new Character(ch).toString()));

            return new String[] { token.trim(), "" };
        }

        String[] retVal = new String[2];
        retVal[0] = token.substring(0, ndx).trim();
        retVal[1] = token.substring(ndx+1).trim();

        return retVal;
    }
}
