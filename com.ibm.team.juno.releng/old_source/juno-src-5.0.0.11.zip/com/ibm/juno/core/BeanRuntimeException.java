package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

/**
 * General bean runtime operation exception.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class BeanRuntimeException extends RuntimeException {

	/**
	 * @param message The error message.
	 */
	protected BeanRuntimeException(String message) {
		super(message);
	}

	/**
	 * Shortcut for calling
	 * <code><jk>new</jk> BeanRuntimeException(String.format(c.getName() + <js>": "</js> + message, args));</code>
	 *
	 * @param c The class name of the bean that caused the exception.
	 * @param message The error message.
	 * @param args Arguments passed in to the {@code String.format()} method.
	 */
	public BeanRuntimeException(Class<?> c, String message, Object... args) {
		this(c.getName() + ": " + format(message, args));
	}

	/**
	 * Shortcut for calling
	 * <code><jk>new</jk> BeanRuntimeException(String.format(c.getName() + <js>": "</js> + message, args), cause);</code>
	 *
	 * @param c The class name of the bean that caused the exception.
	 * @param cause The initial cause of the exception.
	 * @param message The error message.
	 * @param args Arguments passed in to the {@code String.format()} method.
	 */
	public BeanRuntimeException(Class<?> c, Throwable cause, String message, Object... args) {
		this(c.getName() + ": " + (message == null ? cause.getLocalizedMessage() : format(message, args)), cause);
	}

	/**
	 * @param message The error message.
	 * @param cause The initial cause of the exception.
	 */
	public BeanRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause The initial cause of the exception.
	 */
	public BeanRuntimeException(Throwable cause) {
		super(cause);
	}

	/**
	 * Same as String.format(s, args), except first checks to see if there are any args.
	 */
	private static String format(String s, Object[] args) {
		return args.length == 0 ? s : String.format(s, args);
	}
}
