package com.ibm.juno.core.json;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.SerializerProperties.*;
import static com.ibm.juno.core.json.JsonSerializerProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;

/**
 * Serializes POJO models to JSON.
 * <p>
 * 	The conversion is as follows...
 * 	<ul>
 * 		<li>Maps (e.g. {@link HashMap HashMaps}, {@link TreeMap TreeMaps}) are converted to JSON objects.
 * 		<li>Collections (e.g. {@link HashSet HashSets}, {@link LinkedList LinkedLists}) and Java arrays are converted to JSON arrays.
 * 		<li>{@link String Strings} are converted to JSON strings.
 * 		<li>{@link Number Numbers} (e.g. {@link Integer}, {@link Long}, {@link Double}) are converted to JSON numbers.
 * 		<li>{@link Boolean Booleans} are converted to JSON booleans.
 * 		<li>{@code nulls} are converted to JSON nulls.
 * 		<li>{@code arrays} are converted to JSON arrays.
 * 		<li>{@code beans} are converted to JSON objects.
 * 	</ul>
 * <p>
 * 	The types above are considered "JSON-primitive" object types.  Any non-JSON-primitive object types are transformed
 * 		into JSON-primitive object types through {@link Filter Filters} associated through the {@link BeanContext#addFilters(Filter...)}
 * 		method.  Several default filters are provided for transforming Dates, Enums, Iterators, etc...
 * <p>
 * 	This serializer provides several serialization options.  Typically, one of the predefined DEFAULT serializers will be sufficient.
 * 	However, custom serializers can be constructed to fine-tune behavior.
 *
 * <h6 class='topic'>Configurable settings</h6>
 * 	This class has configurable properties that can be set through the {@link #setProperty(String, Object)} method.
 * <p>
 * 	See {@link JsonSerializerProperties} for settings applicable to this class.
 * <p>
 * 	See {@link SerializerProperties} for settings applicable to all {@link Serializer Serializers}.
 * <p>
 * 	See {@link BeanContextProperties} for settings applicable to the {@link BeanContext} associated with this class.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Use one of the default serializers to serialize a POJO</jc>
 * 	String json = JsonSerializer.<jsf>DEFAULT_STRICT</jsf>.serialize(someObject);
 *
 * 	<jc>// Create a custom serializer for strict syntax using double quote characters</jc>
 * 	JsonSerializer serializer = <jk>new</jk> JsonSerializer()
 * 		.setProperty(<jsf>STRICT_MODE</jsf>, <jk>true</jk>)
 * 		.setProperty(<jsf>QUOTE_CHAR</jsf>, <js>'"'</js>);
 *
 * 	<jc>// Clone an existing serializer and modify it to use double-quotes</jc>
 * 	JsonSerializer serializer = JsonSerializer.<jsf>DEFAULT</jsf>
 * 		.setProperty(<jsf>QUOTE_CHAR</jsf>, <js>'"'</js>);
 *
 * 	<jc>// Serialize a POJO to JSON</jc>
 * 	String json = serializer.serialize(someObject);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonSerializer extends Serializer {

	/** Default serializer, all default settings.*/
	public static final JsonSerializer DEFAULT =
		new JsonSerializer().lock();

	/** Default serializer, no whitespace added.*/
	public static final JsonSerializer DEFAULT_CONDENSED =
		new JsonSerializer()
			.setProperty(USE_WHITESPACE, false)
			.setProperty(USE_INDENTATION, false)
			.lock();

	/** Default serializer, single quotes. */
	public static final JsonSerializer DEFAULT_SQ =
		new JsonSerializer()
			.setProperty(QUOTE_CHAR, '\'')
			.lock();

	/** Default serializer, no whitespace, single quotes.*/
	public static final JsonSerializer DEFAULT_SQC =
		new JsonSerializer()
			.setProperty(USE_WHITESPACE, false)
			.setProperty(USE_INDENTATION, false)
			.setProperty(QUOTE_CHAR, '\'')
			.lock();

	/** Default serializer, strict JSON notation.*/
	public static final JsonSerializer DEFAULT_STRICT =
		new JsonSerializer()
			.setProperty(STRICT_MODE, true)
			.lock();

	/** Default serializer, strict JSON notation, no whitespace or indentation.*/
	public static final JsonSerializer DEFAULT_STRICT_CONDENSED =
		new JsonSerializer()
			.setProperty(STRICT_MODE, true)
			.setProperty(USE_WHITESPACE, false)
			.setProperty(USE_INDENTATION, false)
			.lock();

	/** Default serializer, add "_class" attributes to beans so that the parser can reconstruct them.*/
	public static final JsonSerializer DEFAULT_RECONSTRUCTIBLE =
		new JsonSerializer()
			.setProperty(ADD_CLASS_ATTRS, true)
			.lock();

	/** JSON serializer properties currently set on this serializer. */
	protected JsonSerializerProperties jsp = new JsonSerializerProperties();

	/**
	 * Default constructor.
	 * <p>
	 * 	A default unlocked bean context will be created for this serializer.
	 */
	public JsonSerializer() {
	}

	/**
	 * Constructor.
	 * @param beanContext The bean context to associate with this serializer.
	 */
	public JsonSerializer(BeanContext beanContext) {
		super(beanContext);
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The serializer to clone.  Underlying bean context will also be cloned.
	 */
	public JsonSerializer(JsonSerializer copyFrom) {
		super(copyFrom);
		this.jsp = new JsonSerializerProperties(copyFrom.jsp);
	}

	//--------------------------------------------------------------------------------
	// Properties
	//--------------------------------------------------------------------------------

	@Override
	public JsonSerializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (jsp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	@Override
	public Writer serialize(Writer out, Object o, JsonMap...properties) throws IOException, SerializeException {
		JsonSerializerContext ctx = new JsonSerializerContext(beanContext, sp, jsp, properties);
		JsonSerializerWriter w = new JsonSerializerWriter(out, ctx.isUseIndentation(), ctx.isUseWhitespace(), ctx.getQuoteChar(), ctx.isStrictMode());
		serializeAnything(w, o, null, ctx, "root");
		return out;
	}

	/**
	 * Workhorse method. Determines the type of object, and then calls the
	 * appropriate type-specific serialization method.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private SerializerWriter serializeAnything(JsonSerializerWriter out, Object o, ClassType<?> eType, JsonSerializerContext ctx, String attrName) throws SerializeException {
		try {

			if (o == null) {
				out.append("null");
				return out;
			}

			if (eType == null)
				eType = ClassType.OBJECT;

			boolean addClassAttr;		// Add "_class" attribute to element?
			ClassType<?> aType;			// The actual type
			ClassType<?> gType;			// The generic type

			aType = ctx.push(attrName, o, eType);

			// Handle recursion
			if (aType == null) {
				o = null;
				aType = ClassType.OBJECT;
			}

			gType = aType.getFilteredClassType();
			addClassAttr = (ctx.isAddClassAttrs() && ! eType.equals(aType));

			// Filter if necessary
			ObjectFilter filter = aType.getObjectFilter();				// The filter
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == ClassType.OBJECT)
					gType = beanContext.getClassTypeForObject(o);
			}

			// '\0' characters are considered null.
			if (o == null || (gType.isChar() && ((Character)o).charValue() == 0))
				out.append("null");
			else if (gType.isNumber() || gType.isBoolean())
				out.append(o);
			else if (gType.isBean())
				serializeBeanMap(out, beanContext.forBean(o), addClassAttr, ctx);
			else if (gType.isMap()) {
				if (o instanceof BeanMap)
					serializeBeanMap(out, (BeanMap)o, addClassAttr, ctx);
				else
					serializeMap(out, (Map)o, eType.getKeyType(), eType.getValueType(), ctx);
			}
			else if (gType.isCollection()) {
				if (addClassAttr)
					serializeCollectionMap(out, (Collection)o, gType, ctx);
				else
					serializeCollection(out, (Collection) o, eType.getElementType(), ctx);
			}
			else if (gType.isArray()) {
				if (addClassAttr)
					serializeCollectionMap(out, toList(gType.getInnerClass(), o), gType, ctx);
				else
					serializeCollection(out, toList(gType.getInnerClass(), o), eType.getElementType(), ctx);
			}
			else
				out.stringValue(o);
			ctx.pop();
			return out;
		} catch (SerializeException e) {
			throw e;
		} catch (Throwable e) {
			throw new SerializeException(e, "Exception occured trying to process object of type '%s'", (o == null ? null : o.getClass().getName()));
		}
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeMap(JsonSerializerWriter out, Map m, ClassType<?> keyType, ClassType<?> valueType, JsonSerializerContext ctx) throws IOException, SerializeException {
		int depth = ctx.getIndent();
		out.append('{');

		if (keyType == null)
			keyType = ClassType.OBJECT;
		if (valueType == null)
			valueType = ClassType.OBJECT;

		Iterator mapEntries = m.entrySet().iterator();

		while (mapEntries.hasNext()) {
			Map.Entry e = (Map.Entry) mapEntries.next();
			Object value = e.getValue();

			if (canIgnoreValue(ctx, valueType, value))
				continue;

			Object key = generalize(e.getKey());

			out.cr(depth).attr(key).append(':').s();

			serializeAnything(out, value, valueType, ctx, (key == null ? null : key.toString()));

			if (mapEntries.hasNext())
				out.append(',').s();
		}

		out.cr(depth-1).append('}');

		return out;
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeCollectionMap(JsonSerializerWriter out, Collection o, ClassType<?> gType, JsonSerializerContext ctx) throws IOException, SerializeException {
		int i = ctx.getIndent();
		out.append('{').nl();
		out.append(i, "_class:").s().stringValue(gType).append(',').nl();
		out.append(i, "items:").s();
		ctx.indent++;
		serializeCollection(out, o, gType.getElementType(), ctx);
		ctx.indent--;
		out.cr(i-1).append('}');
		return out;
	}

	@SuppressWarnings({ "rawtypes" })
	private SerializerWriter serializeBeanMap(JsonSerializerWriter out, BeanMap m, boolean addClassAttr, JsonSerializerContext ctx) throws IOException, SerializeException {
		int depth = ctx.getIndent();
		out.append('{');

		Iterator mapEntries = m.entrySet().iterator();

		// Print out "_class" attribute on this bean if required.
		if (addClassAttr) {
			String attr = "_class";
			out.cr(depth).attr(attr).append(':').s().q().append(m.getClassType().getInnerClass().getName()).q();
			if (mapEntries.hasNext())
				out.append(',').s();
		}

		boolean addComma = false;

		while (mapEntries.hasNext()) {
			BeanMapEntry p = (BeanMapEntry)mapEntries.next();
			BeanPropertyMeta pMeta = p.getMeta();

			if (canIgnoreProperty(ctx, pMeta))
				continue;

			Object value = null;
			try {
				value = p.getFilteredValue();
			} catch (Throwable t) {
				ctx.addWarning("Could not call getValue() on property '%s', %s", p.getKey(), t.getLocalizedMessage());
			}

			if (canIgnoreValue(ctx, pMeta.getClassType(), value))
				continue;

			if (addComma)
				out.append(',').s();

			out.cr(depth).attr(p.getKey()).append(':').s();

			serializeAnything(out, value, pMeta.getFilteredClassType(), ctx, p.getKey());

			addComma = true;
		}
		out.cr(depth-1).append('}');
		return out;
	}

	@SuppressWarnings("rawtypes")
	private SerializerWriter serializeCollection(JsonSerializerWriter out, Collection c, ClassType<?> elementType, JsonSerializerContext ctx) throws IOException, SerializeException {
		out.append('[');
		int depth = ctx.getIndent();

		for (Iterator i = c.iterator(); i.hasNext();) {

			Object value = i.next();

			if (canIgnoreValue(ctx, elementType, value))
				continue;

			out.cr(depth);

			serializeAnything(out, value, elementType, ctx, "<iterator>");

			if (i.hasNext())
				out.append(',').s();
		}
		out.cr(depth-1).append(']');
		return out;
	}

	@Override
	public Writer serializeSchema(Writer out, Object o, JsonMap...properties) throws IOException, SerializeException {
		JsonSerializerContext ctx = new JsonSerializerContext(beanContext, sp, jsp, properties);
		JsonMap schema = getSchema(beanContext.getClassTypeForObject(o), ctx, "root", null);
		return serialize(out, schema, properties);
	}

	/**
	 * Creates a schema representation of the specified class type.
	 *
	 * @param eType The class type to get the schema of.
	 * @param ctx Serialize context used to prevent infinite loops.
	 * @param attrName The name of the current attribute.
	 * @return A schema representation of the specified class.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected JsonMap getSchema(ClassType<?> eType, SerializerContext ctx, String attrName, String[] pNames) throws SerializeException {
		try {

			JsonMap out = new JsonMap();

			if (eType == null)
				eType = ClassType.OBJECT;

			ClassType<?> aType;			// The actual type (will be null if recursion occurs)
			ClassType<?> gType;			// The generic type

			aType = ctx.push(attrName, eType, null);

			gType = eType.getFilteredClassType();
			String type = null;

			if (gType.isEnum() || gType.isCharSequence() || gType.isChar())
				type = "string";
			else if (gType.isNumber())
				type = "number";
			else if (gType.isBoolean())
				type = "boolean";
			else if (gType.isBean() || gType.isMap())
				type = "object";
			else if (gType.isCollection() || gType.isArray())
				type = "array";
			else
				type = "any";

			out.put("type", type);
			out.put("description", eType.toString());
			ObjectFilter f = eType.getObjectFilter();
			if (f != null)
				out.put("filter", f);

			if (aType != null) {
				if (gType.isEnum())
					out.put("enum", getEnumStrings((Class<Enum<?>>)gType.getInnerClass()));
				else if (gType.isCollection() || gType.isArray()) {
					ClassType componentType = gType.getElementType();
					if (gType.isCollection() && Set.class.isAssignableFrom(gType.getInnerClass()))
						out.put("uniqueItems", true);
					out.put("items", getSchema(componentType, ctx, "items", pNames));
				} else if (gType.isBean()) {
					JsonMap properties = new JsonMap();
					BeanMeta bm = beanContext.getBeanMeta(gType.getInnerClass());
					if (pNames != null)
						bm = new BeanMetaFiltered(bm, pNames);
					for (Iterator<BeanPropertyMeta<?>> i = bm.getMetaProperties().iterator(); i.hasNext();) {
						BeanPropertyMeta p = i.next();
						properties.put(p.getName(), getSchema(p.getClassType(), ctx, p.getName(), p.getProperties()));
					}
					out.put("properties", properties);
				}
			}
			ctx.pop();
			return out;
		} catch (Throwable e) {
			throw new SerializeException(e, "Exception occured trying to process object of type '%s'", eType);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List<String> getEnumStrings(Class<? extends Enum> c) {
		List<String> l = new LinkedList<String>();
		try {
			for (Object e : EnumSet.allOf(c))
				l.add(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on CoreAPI
	//--------------------------------------------------------------------------------

	@Override
	public JsonSerializer setBeanContext(BeanContext beanContext) throws LockedException {
		super.setBeanContext(beanContext);
		return this;
	}

	@Override
	public JsonSerializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override
	public JsonSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override
	public JsonSerializer addFilters(Filter...s) throws LockedException {
		super.addFilters(s);
		return this;
	}

	@Override
	public JsonSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override
	public <T> JsonSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public JsonSerializer lock() {
		super.lock();
		return this;
	}

	@Override
	public JsonSerializer clone() {
		return new JsonSerializer(this);
	}
}
