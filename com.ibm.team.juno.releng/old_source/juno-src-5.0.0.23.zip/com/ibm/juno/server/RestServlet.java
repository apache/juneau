package com.ibm.juno.server;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.serializer.SerializerProperties.*;
import static com.ibm.juno.server.RestServletProperties.*;
import static com.ibm.juno.server.annotation.Inherit.*;
import static java.lang.String.*;
import static javax.servlet.http.HttpServletResponse.*;

import java.beans.*;
import java.io.*;
import java.lang.annotation.*;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;
import java.util.logging.*;
import java.util.regex.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.encoders.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.utils.*;
import com.ibm.juno.server.RestServletNls.NlsClass;
import com.ibm.juno.server.RestServletNls.NlsClass.NlsMethod;
import com.ibm.juno.server.RestServletNls.NlsClass.NlsResponse;
import com.ibm.juno.server.RestServletNls.NlsVar;
import com.ibm.juno.server.annotation.*;
import com.ibm.juno.server.annotation.Properties;
import com.ibm.juno.server.labels.*;
import com.ibm.juno.server.labels.MethodDescription.Response;
import com.ibm.juno.server.labels.MethodDescription.Var;

/**
 *	Servlet implementation of a REST resource.
 * <p>
 * 	Refer to {@link com.ibm.juno.server} for an overview of the REST server API.
 *
 *
 * <h6 class='topic'>Deploying REST servlets</h6>
 * Since REST servlets are subclasses of <code>HttpServlet</code>, they are deployed in a J2EE
 * 	container like any other servlet, typically a <code>web.xml</code> file.
 * <p>
 * Unlike the <code>JAX-RS</code> specification, there is no <ja>@Path</ja> annotation for identifying
 * 	servlet paths.
 * This feature was specifically not implemented to prevent the need for a separate configuration
 * 	setup step whereby REST resources must be identified programatically or through a
 * 	classloader scan.
 * The {@link RestServlet} class does not depend on any classloader scanning or external setup
 * 	other than registering the servlet with the J2EE container.
 * <p>
 * However, REST servlets can also be deployed by declaring them as children of another REST servlet
 * 	through the use of the {@link RestChild} annotation on a public getter method.
 *
 *
 * <h6 class='topic'>Implementing new servlets</h6>
 *
 * In general, a REST servlet implementation defines the following...
 * <ul>
 * 	<li>An optional {@link RestResource} annotation on the servlet class.
 * 	<li>One or more public methods annotated with {@link RestMethod}.
 * 	<li>Zero or more REST parsers used to convert HTTP request body content to POJOs.
 * 	<li>Zero or more REST serializers used to convert POJOs to the HTTP response body content.
 * </ul>
 * <p>
 *	Implementers will typically subclass directly from this class.
 * However, the following subclass also provided for convenience...
 * <ul>
 * 	<li>{@link RestServletDefault} - Provides a default set of serializers and parsers for a variety of <code>Accept</code> and <code>Content-Type</code> types.
 * </ul>
 *
 *
 * <h6 class='topic'>@RestResource annotation</h6>
 * <p>
 * Implementations can optionally be annotated with {@link RestResource @RestResource}.
 * It provides various convenience annotations for defining servlet-level configuration data on the class.
 * <p>
 * See the {@link RestResource @RestResource} annotation for more information.
 *
 *
 * <h6 class='topic'>@RestChild annotation - Child resources</h6>
 *	<p>
 *	Child resources can be attached to parent resources using the {@link RestChild @RestChild} annnotation...
 * <p class='bcode'>
 * 	<jk>public</jk> MyResource <jk>extends</jk> RestServlet {
 *
 * 		<ja>@RestChild</ja>(name=<js>"foo"</js>)
 * 		<jk>public</jk> RestServlet getFoo() <jk>throws</jk> Exception {
 * 			<jc>// Return a 'foo' RestServlet </jc>
 * 		}
 * <p>
 * See the {@link RestChild @RestChild} annotation for information on defining REST child resources.
 *
 *
 * <h6 class='topic'>@RestMethod annotation - Implementing REST method handlers</h6>
 *	<p>
 *	Subclasses of this class need only identify RESTful methods using the {@link RestMethod @RestMethod} annotation.
 * <p class='bcode'>
 * 	<ja>@RestMethod</ja>(name=<js>"X"</js>, pattern=<js>"/*"</js>)
 * 	<jk>public</jk> Object doX(...) {...}
 * </p>
 * <p>
 * See the {@link RestMethod @RestMethod} annotation for information on defining REST methods.
 *
 *
 * <h6 class='topic'>Specifying serializers for serializing response POJOs</h6>
 * <p>
 * REST servlets use the {@link ISerializer} API for defining serializers for serializing response POJOs.
 * <p>
 * The servlet will pick which serializer to use by matching the request <code>Accept</code> header with the
 * 	media types defined through the {@link ISerializer#getMediaTypes()} method (or {@link Produces} annotation).
 * <p>
 * REST serializers can be associated with REST servlets in the following ways:
 * <ul>
 * 	<li>Through the {@link RestResource#serializers()} annotation on the class.
 * 	<li>Through the {@link RestMethod#serializers()} annotations on individual REST methods of the class.
 * 	<li>By overriding the {@link #createSerializerGroup()} method and setting the serializers programmatically.
 * </ul>
 * <p>
 * The following are equivalent ways of defining serializers used by a servlet...
 * <p class='bcode'>
 * 	<jc>// Example #1 - Serializers defined on servlet through annotation</jc>
 * 	<ja>@RestResource</ja>(
 * 		serializers={JsonSerializer.<jk>class</jk>, XmlSerializer.<jk>class</jk>}
 * 	)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 * 		...
 * 	}
 *
 * 	<jc>// Example #2 - Serializers defined on method through annotation</jc>
 * 	<ja>@RestMethod</ja>(name=<js>"GET"</js>, pattern=<js>"/*"</js>
 * 		serializers={JsonSerializer.<jk>class</jk>, XmlSerializer.<jk>class</jk>}
 * 	)
 * 	<jk>public</jk> Object doGet() {
 * 		...
 * 	}
 *
 * 	<jc>// Example #3 - Serializers defined on servlet by overriding the getSerializerGroup method</jc>
 * 	<ja>@Override</ja>
 * 	<jk>public</jk> SerializerGroup getSerializerGroup() {
 *
 * 		SerializerGroup g = <jk>new</jk> SerializerGroup()
 * 			.append(JsonSerializer.<jk>class</jk>, XmlSerializer.<jk>class</jk>);
 *
 * 		<jk>return</jk> g;
 * 	}
 * </p>
 *
 *
 * <h6 class='topic'>Specifying parsers for parsing request POJOs</h6>
 * <p>
 * REST servlets use the {@link IParser} API for defining parsers for parsing request body content and converting them into POJOs.
 * <p>
 * The servlet will pick which parser to use by matching the request <code>Content-Type</code> header with the
 * 	media types defined through the {@link IParser#getMediaTypes()} method (or {@link Consumes} annotation).
 * <p>
 * REST parsers can be associated with REST servlets in the following ways:
 * <ul>
 * 	<li>Through the {@link RestResource#parsers()} annotation on the class.
 * 	<li>Through the {@link RestMethod#parsers()} annotations on individual REST methods of the class.
 * 	<li>By overriding the {@link #createParserGroup()} method and setting the parsers programmatically.
 * </ul>
 * <p>
 * The following are equivalent ways of defining parsers used by a servlet...
 * <p class='bcode'>
 * 	<jc>// Example #1 - Parsers defined on servlet through annotation</jc>
 * 	<ja>@RestResource</ja>(
 * 		parsers={JsonParser.<jk>class</jk>, XmlParser.<jk>class</jk>}
 * 	)
 * 	<jk>public</jk> MyRestServlet <jk>extends</jk> RestServlet {
 * 		...
 * 	}
 *
 * 	<jc>// Example #2 - Parsers defined on method through annotation</jc>
 * 	<ja>@RestMethod</ja>(name=<js>"GET"</js>, pattern=<js>"/*"</js>
 * 		parsers={JsonParser.<jk>class</jk>, XmlParser.<jk>class</jk>}
 * 	)
 * 	<jk>public void</jk> doPut(<ja>@Content</ja> Foo input) {
 * 		...
 * 	}
 *
 * 	<jc>// Example #3 - Parsers defined on servlet by overriding the getParserGroup method</jc>
 * 	<ja>@Override</ja>
 * 	<jk>public</jk> ParserGroup getParserGroup() {
 *
 * 		ParserGroup g = <jk>new</jk> ParserGroup()
 * 			.append(JsonParser.<jk>class</jk>, XmlParser.<jk>class</jk>);
 *
 * 		<jk>return</jk> g;
 * 	}
 * </p>
 *
 * <h6 class='topic'>Built-in URL parameters</h6>
 * <p>
 * The following URL parameters have special meaning and can be passed in through the URL of the request:
 * <ul>
 * 	<li><code>&amp;plainText</code> -
 * 		Useful for debugging.
 * 		Response will always be <code>Content-Type: text/plain</code> and the returned text will be human-readable
 * 			(i.e. {@link SerializerProperties#USE_INDENTATION} and {@link JsonSerializerProperties#USE_WHITESPACE} enabled).
 * 	<li><code>&amp;debug</code> -
 * 		Request body content will be dumped to log file.
 * 	<li><code>&amp;noTrace</code> -
 * 		If an error occurs, don't log the stack trace to the log file.
 * 		Useful for automated JUnit testcases testing error states to prevent the log file from filling up with
 * 			useless stack traces.
 * </ul>
 * <p>
 * If {@link RestServletProperties#ALLOW_HEADER_PARAMS} is enabled, HTTP headers can be passed as URL parameters (case insensitive).
 * <p>
 * If {@link RestServletProperties#ALLOW_METHOD_PARAM} is enabled, the HTTP method name can also be specified as a URL parameter.
 * <p>
 * If {@link RestServletProperties#ALLOW_CONTENT_PARAM} is enabled, the HTTP body content on PUT and POST methods can be passed in as a URL parameter.
 *
 *
 * <h6 class='topic'>OPTIONS pages</h6>
 *	<p>
 *		The {@link ResourceOptions} bean can be used to easily construct OPTIONs pages.
 *	<p>
 *		Typically, options pages can be defined like so:
 * </p>
 * <p class='bcode'>
 * 	<ja>@RestMethod</ja>(name=<js>"OPTIONS"</js>, pattern=<js>"/*"</js>)
 * 	<jk>public</jk> ResourceOptions doOptions(RestRequest req) {
 * 		<jk>return new</jk> ResourceOptions(<jk>this</jk>, req);
 * 	}
 * </p>
 *
 *
 * <h6 class='topic'>Logging</h6>
 * <p>
 * It's expected that your application handles it's own logging in it's own way.
 * To facilitate that, the following methods are provided for you to override and handle logging yourself:
 * <ul>
 * 	<li>{@link #onError(HttpServletRequest, HttpServletResponse, RestException, boolean)} - Called whenever a non-2xx status occurs during a request.
 * 	<li>{@link #onSuccess(RestRequest, RestResponse, long)} - Called whenever a request completes successfully.
 * </ul>
 *
 *
 * <h6 class='topic'>Request execution flow</h6>
 * <p>
 * 	The request execution flow attempts to make it as easy as possible to modify request settings
 * 		at various stages of execution.
 * <p>
 * 	Communication between the servlet, serializers, and parsers is possible through the modifiable
 * 	<code>properties</code> object, an {@link ObjectMap} that exists for the duration of the request.
 * <p>
 * 	By default, the <code>properties</code> object is loaded with values from {@link RestResource#properties()} (for servlet-level
 * 		properties) and {@link RestMethod#properties()} (for method-level properties).
 * 	This properties object (and request and response headers) can be modified at various steps of execution.
 * <p>
 * 	Here is the order of execution during a single request...
 * <ol>
 * 	<li>{@link RestServlet#service(HttpServletRequest, HttpServletResponse) service(request, response)} called.<br>
 * 		<code>properties</code> object constructed for request.<br>
 * 		<br>
 * 	<li>{@link RestResource#defaultRequestHeaders()} and {@link RestMethod#defaultRequestHeaders} added to {@link RestRequest}.<br>
 * 		<br>
 * 	<li>{@link RestResource#defaultResponseHeaders()} added to {@link RestResponse}.<br>
 * 		<br>
 * 	<li>{@link RestServlet#onPreCall(RestRequest, ObjectMap) onPreCall(request, properties)} called.<br>
 * 		Request headers and properties can be modified.<br>
 * 		<br>
 * 	<li>Parser found based on request <js>"Content-Type"</js> header.<br>
 * 		<br>
 * 	<li>{@link ReaderParser#parse(Reader, ClassType, ObjectMap, String) Parser.parse(in, classType, properties, mediaType)} called.<br>
 * 		Properties can be modified.<br>
 * 		<br>
 * 	<li>REST Java method invoked.<br>
 * 		Properties can be modified (accessed via {@link Properties} parameter or by calling {@link RestResponse#getProperties()}.<br>
 * 		<br>
 * 	<li>{@link RestServlet#onPostCall(RestRequest, RestResponse, ObjectMap) onPostCall(request, response, properties)} called.<br>
 * 		Request and response headers and properties can be modified.<br>
 * 		<br>
 * 	<li>Serializer found based on request <js>"Accept"</js> header.<br>
 * 		<br>
 * 	<li>{@link ISerializer#getResponseHeaders(ObjectMap) Serializer.getResponseHeaders(properties)} called.<br>
 * 		Properties can be modified.<br>
 * 		Results added to response headers.<br>
 * 		<br>
 * 	<li>{@link ISerializer#getResponseContentType() Serializer.getResponseContentType()} called.<br>
 * 		If not <jk>null</jk>, set as response <js>"Content-Type"</js> header.<br>
 * 		<br>
 * 	<li>{@link WriterSerializer#serialize(Object, Writer, ObjectMap, String) Serializer.serialize(object, out, properties, mediaType)} called.<br>
 * 		Properties can be modified.<br>
 * 		<br>
 *	</ol>
 *
 * <h6 class='topic'>Other Notes</h6>
 *	<ul>
 *		<li>Subclasses can use either {@link #init(ServletConfig)} or {@link #init()} for initialization
 *			just like any other servlet.
 *		<li>The {@link SerializerProperties#URI_CONTEXT} property is automatically set to the context root (e.g. <js>"/mycontextroot"</js>) of the web application during servlet initialization.
 *			This value can be overridden through the {@link RestResource#properties()} or {@link RestMethod#properties()} annotations, or through {@link RestResponse#setProperty(String, Object)}.
 *		<li>The {@link SerializerProperties#URI_AUTHORITY} property is automatically set to the HTTP authority (e.g. <js>"https://myhost:9443"</js>) during each request.
 *			This value can be overridden through the {@link RestMethod#properties()} annotations, or through {@link RestResponse#setProperty(String, Object)}.
 *	</ul>
 *
 * @author jbognar
 */
@SuppressWarnings({"rawtypes"})
public abstract class RestServlet extends HttpServlet {

	// Map of HTTP method names (e.g. GET/PUT/...) to ResourceMethod implementations for it.  Populated during resource initialization.
	private final Map<String,ResourceMethod> restMethods = new LinkedHashMap<String,ResourceMethod>();

	// The list of all @RestMethod annotated methods in the order they appear in the class.
	private final List<SimpleMethod> javaRestMethods = new LinkedList<SimpleMethod>();

	// Child resources of this resource defined through getX() methods on this class.
	private final Map<String,RestServlet> childResources = new HashMap<String,RestServlet>();

	private SerializerGroup cSerializers;                  // Class-level serializers.
	private ParserGroup cParsers;                          // Class-level parsers.
	private BeanContext cBeanContext;                      // Class-level bean context.
	EncoderGroup cEncoders;                                // Class-level encoders.
	private ObjectMap cProperties = new ObjectMap();       // Class-level properties.
	private Class<?>[] cFilters;                           // Class-level POJO filters.
	private RestGuard[] cGuards;                           // Class-level guards
	private RestConverter[] cConverters;                   // Class-level converters
	ObjectMap cDefaultRequestHeaders;                      // Class-level default request headers.
	ObjectMap cDefaultResponseHeaders;                     // Class-level default request headers.

	private ServletConfig servletConfig;
	private volatile boolean isInitialized = false;
	private Exception initException;                       // Exception thrown by init() method (cached so it can be thrown on all subsequent requests).
	private Logger logger;
	private RestServletNls msgs;                           // NLS messages.
	private String contextPath;

	private boolean renderResponseStackTraces, useStackTraceHashes;
	private Map<Integer,Integer> stackTraceHashes = new HashMap<Integer,Integer>();

	@Override
	@SuppressWarnings("hiding")
	public synchronized void init(ServletConfig servletConfig) throws ServletException {
		try {
			if (isInitialized)
				return;
			this.servletConfig = servletConfig;

			ServletContext ctx = servletConfig.getServletContext();
			contextPath = ctx.getContextPath();
			cProperties.put(URI_CONTEXT, contextPath);

			// Get the initialization parameters.
			for (Enumeration ep = servletConfig.getInitParameterNames(); ep.hasMoreElements();) {
				String p = (String)ep.nextElement();
				String initParam = servletConfig.getInitParameter(p);
				if (initParam.matches("^\\s*[\\[\\{].*"))
					cProperties.put(p, JsonParser.DEFAULT.parse(initParam, Object.class));
				else
					cProperties.put(p, initParam);
			}

			super.init(servletConfig);

			// @RestResource annotations from bottom to top.
			List<RestResource> rr = ReflectionUtils.findAnnotations(RestResource.class, getClass());

			// @RestResource annotations from top to bottom.
			List<RestResource> rrr = new ArrayList<RestResource>(rr);
			Collections.reverse(rrr);

			List<RestGuard> guards = new LinkedList<RestGuard>();
			List<RestConverter> converters = new LinkedList<RestConverter>();

			// Guards and Converters are loaded in child-to-parent order.
			for (RestResource r : rr) {

				// Find resource resource bundle location.
				if (msgs == null && ! r.messages().isEmpty())
					msgs = new RestServletNls(this.getClass(), r.messages());

				// Initialize class-level guards.
				for (Class<? extends RestGuard> c : r.guards())
					guards.add(c.newInstance());

				// Initialize class-level converters.
				for (Class<? extends RestConverter> c : r.converters())
					converters.add(c.newInstance());
			}

			this.cGuards = guards.toArray(new RestGuard[guards.size()]);
			this.cConverters = converters.toArray(new RestConverter[converters.size()]);

			if (msgs == null)
				msgs = new RestServletNls(this.getClass(), "");

			cSerializers = createSerializerGroup();
			cParsers = createParserGroup();
			cBeanContext = createBeanContext();
			cEncoders = new EncoderGroup().append(IdentityEncoder.INSTANCE);

			Set<Class<?>> filters = new LinkedHashSet<Class<?>>();
			cDefaultRequestHeaders = new ObjectMap();
			cDefaultResponseHeaders = new ObjectMap();

			// Filters/Properties/Headers are loaded in parent-to-child order to allow overrides.
			for (RestResource r : rrr) {

				cEncoders.append(r.encoders());
				cSerializers.append(r.serializers());
				cParsers.append(r.parsers());

				for (Class c : r.filters())
					filters.add(c);

				for (Property p : r.properties()) {
					Object value = p.value();
					if (p.nls())
						value = '\u0000' + value.toString();
					cProperties.append(p.name(), value);
				}

				for (String s : r.defaultRequestHeaders()) {
					String[] h = parseHeader(s);
					if (h == null)
						throw new ServletException(String.format("Invalid default request header specified: [%s].  Must be in the format: [Header-Name: header-value]", s));
					cDefaultRequestHeaders.append(h[0], h[1]);
				}

				for (String s : r.defaultResponseHeaders()) {
					String[] h = parseHeader(s);
					if (h == null)
						throw new ServletException(String.format("Invalid default response header specified: [%s].  Must be in the format: [Header-Name: header-value]", s));
					cDefaultResponseHeaders.append(h[0], h[1]);
				}
			}

			cFilters = filters.toArray(new Class[filters.size()]);

			cSerializers.addFilters(cFilters).setProperties(cProperties);
			cParsers.addFilters(cFilters).setProperties(cProperties);
			cBeanContext.addFilters(cFilters).setProperties(cProperties);

			this.renderResponseStackTraces = cProperties.getBoolean(RENDER_RESPONSE_STACK_TRACES, false);
			this.useStackTraceHashes = cProperties.getBoolean(USE_STACK_TRACE_HASHES, true);

			// Discover the @RestMethod methods available on the resource.
			for (java.lang.reflect.Method method : this.getClass().getMethods()) {
				if (method.isAnnotationPresent(RestMethod.class)) {

					if (! Modifier.isPublic(method.getModifiers()))
						throw new ServletException(
							format("@RestMethod method %s.%s must be defined as public.", this.getClass().getName(), method.getName())
						);

					SimpleMethod sm = new SimpleMethod(method);
					javaRestMethods.add(sm);
					ResourceMethod rm = restMethods.get(sm.httpMethod);
					if (rm == null)
						restMethods.put(sm.httpMethod, sm);
					else if (rm instanceof MultiMethod)
						((MultiMethod)rm).addSimpleMethod(sm);
					else
						restMethods.put(sm.httpMethod, new MultiMethod((SimpleMethod)rm, sm));
				}
			}

			for (ResourceMethod m : restMethods.values())
				m.complete();

			// Discover the RestChild methods.
			for (java.lang.reflect.Method method : this.getClass().getMethods()) {

				if (method.isAnnotationPresent(RestChild.class)) {

					if (method.getParameterTypes().length != 0)
						throw new ServletException(
							format("@RestChild methods %s.%s cannot have any parameters.", this.getClass().getName(), method.getName())
						);

					if (! RestServlet.class.isAssignableFrom(method.getReturnType()))
						throw new ServletException(
							format("@RestChild method %s.%s must return an instance of RestServlet.", this.getClass().getName(), method.getName())
						);

					RestChild rc = method.getAnnotation(RestChild.class);
					String pattern = (rc == null ? "" : rc.name());
					if (pattern.startsWith("/"))
						pattern = pattern.substring(1);
					if (pattern.isEmpty())
						pattern = Introspector.decapitalize(method.getName().substring(3));
					RestServlet resource = (RestServlet)method.invoke(this);

					if (resource == null)
						throw new ServletException(
							format("@RestChild method %s.%s returned null.", this.getClass().getName(), method.getName())
						);

					resource.init(servletConfig);
					childResources.put(pattern, resource);
				}
			}

			// Lock objects for safety.
			cSerializers.lock();
			cParsers.lock();
			cBeanContext.lock();

		} catch (ServletException e) {
			initException = e;
			throw e;
		} catch (Exception e) {
			initException = e;
			throw new ServletException(e);
		} catch (Throwable e) {
			initException = new Exception(e);
			throw new ServletException(e);
		} finally {
			isInitialized = true;
		}
	}

	private String[] parseHeader(String s) {
		int i = s.indexOf(':');
		if (i == -1)
			return null;
		String name = s.substring(0, i).trim().toLowerCase(Locale.ENGLISH);
		String val = s.substring(i+1).trim();
		return new String[]{name,val};
	}

	/**
	 * Creates a {@link RestRequest} object based on the specified incoming {@link HttpServletRequest} object.
	 * <p>
	 * 	Subclasses may choose to override this method to provide a specialized request object.
	 *
	 * @param req The request object from the {@link #service(HttpServletRequest, HttpServletResponse)} method.
	 * @return The wrapped request object.
	 * @throws ServletException If any errors occur trying to interpret the request.
	 */
	protected RestRequest createRequest(HttpServletRequest req) throws ServletException {
		return new RestRequest(this, req);
	}

	/**
	 * Creates a {@link RestResponse} object based on the specified incoming {@link HttpServletResponse} object
	 * 	 and the request returned by {@link #createRequest(HttpServletRequest)}.
	 * <p>
	 * 	Subclasses may choose to override this method to provide a specialized response object.
	 *
	 * @param req The request object returned by {@link #createRequest(HttpServletRequest)}.
	 * @param res The response object from the {@link #service(HttpServletRequest, HttpServletResponse)} method.
	 * @return The wrapped response object.
	 * @throws ServletException If any erros occur trying to interpret the request or response.
	 */
	protected RestResponse createResponse(RestRequest req, HttpServletResponse res) throws ServletException {
		return new RestResponse(this, req, res);
	}

	/**
	 * Creates the bean context used for parsing URL parameters, path variables, and header values.
	 * <p>
	 * By default, returns a clone of {@link BeanContext#DEFAULT}.
	 * <p>
	 * Subclasses can override this method to provide their own bean context with specialized settings.
	 *
	 * @return The bean context associated with this servlet.
	 */
	public BeanContext createBeanContext() {
		return BeanContext.DEFAULT.clone();
	}

	/**
	 * Returns the bean context associated with this resource.
	 * <p>
	 * This object consists of the bean context returned by {@link #createBeanContext()}
	 * 	with servlet-level properties and filters applied, then locked.
	 * <p>
	 * Subclasses can override this method to provide their own customized bean context.
	 * When overridden, servlet-level properties and filters are not applied.
	 * @return The bean context associated with this resource.
	 */
	public BeanContext getBeanContext() {
		return cBeanContext;
	}

	/**
	 * Creates the serializer group for containing serializers used for serializing output POJOs for HTTP requests.
	 * <p>
	 * By default, returns an empty serializer group.
	 * It's up to subclasses to add entries to it either programmatically, or through
	 * 	{@link RestResource#serializers()} annotations on the servlet class.
	 * <p>
	 * 	See {@link SerializerGroup} for more information.
	 *
	 * @return The group of serializers.
	 * @throws Exception If serializer group could not be constructed for any reason.
	 */
	public SerializerGroup createSerializerGroup() throws Exception {
		return new SerializerGroup();
	}

	/**
	 * Returns the serializer group associated with this resource.
	 * <p>
	 * This object consists of the serializer group returned by {@link #createSerializerGroup()}
	 * 	with servlet-level properties and filters applied, then locked.
	 * <p>
	 * Subclasses can override this method to provide their own customized serializer group.
	 * When overridden, servlet-level properties and filters are not applied.
	 * @return The serializer group associated with this resource.
	 */
	public SerializerGroup getSerializerGroup() {
		return cSerializers;
	}

	/**
	 * Creates the parser group for containing parser used for parsing HTTP input into POJOs.
	 * <p>
	 * By default, returns an empty parser group.
	 * It's up to subclasses to add entries to it either programmatically, or through
	 * 	{@link RestResource#parsers()} annotations on the servlet class.
	 * <p>
	 * 	See {@link ParserGroup} for more information.
	 *
	 * @return The group of parsers.
	 * @throws Exception If parser group could not be constructed for any reason.
	 */
	public ParserGroup createParserGroup() throws Exception {
		return new ParserGroup();
	}

	/**
	 * Returns the parser group associated with this resource.
	 * <p>
	 * This object consists of the parser group returned by {@link #createParserGroup()}
	 * 	with servlet-level properties and filters applied, then locked.
	 * <p>
	 * Subclasses can override this method to provide their own customized parser group.
	 * When overridden, servlet-level properties and filters are not applied.
	 * @return The parser group associated with this resource.
	 */
	public ParserGroup getParserGroup() {
		return cParsers;
	}

	/**
	 * Returns whether this resource class can provide an OPTIONS page.
	 * <p>
	 * By default, returns <jk>true</jk>.
	 * <p>
	 * Subclasses can override this method to prevent the <code>options</code> link from showing up in the HTML serialized output.
	 *
	 * @return <jk>true</jk> if this resource has implemented the {@code doOptions()} method.
	 */
	public boolean hasOptionsPage() {
		return true;
	}

	/**
	 * Specify a class-level property.
	 * <p>
	 * Typically, properties in {@link RestServletProperties} can be set in the {@link Servlet#init(ServletConfig)} method.
	 *
	 * @param key The property name.
	 * @param value The property value.
	 * @return This object (for method chaining).
	 */
	public synchronized RestServlet setProperty(String key, Object value) {
		cProperties.put(key, value);
		return this;
	}

	/**
	 * The main service method.
	 * <p>
	 * 	Subclasses can optionally override this method if they want to tailor the behavior of requests.
	 */
	@Override
	public void service(HttpServletRequest r1, HttpServletResponse r2) throws ServletException, IOException {

		long startTime = System.currentTimeMillis();

		try {

			if (initException != null)
				throw new RestException(SC_INTERNAL_SERVER_ERROR, initException);

			if (! isInitialized)
				throw new RestException(SC_INTERNAL_SERVER_ERROR, "Servlet has not been initialized");

			String pathInfo = r1.getPathInfo();
			if (pathInfo == null)
				pathInfo = "";
			if (pathInfo.startsWith("/"))
				pathInfo = pathInfo.substring(1);

			// See if this is a request for '/htdocs/juno.css' or '/htdocs/javadoc.css'
			// If so, handle it special.
			if (pathInfo.startsWith("htdocs/") || pathInfo.contains("/htdocs/")) {
				if (serviceHtDocs(pathInfo, r2))
					return;
			}

			// If this resource has child resources, try to recursively call them.
			if (! (childResources.isEmpty() && ! pathInfo.isEmpty())) {
				int i = pathInfo.indexOf('/');
				String pathInfoPart = i == -1 ? pathInfo : pathInfo.substring(0, i);
				RestServlet childResource = childResources.get(pathInfoPart);
				if (childResource != null) {
					final String pathInfoRemainder = i == -1 ? null : pathInfo.substring(i);
					final String servletPath = r1.getServletPath() + "/" + pathInfoPart;
					final HttpServletRequest childRequest = new HttpServletRequestWrapper(r1) {
						@Override
						public String getPathInfo() {
							return pathInfoRemainder;
						}
						@Override
						public String getServletPath() {
							return servletPath;
						}
					};
					childResource.service(childRequest, r2);
					return;
				}
			}

			RestServlet resource = this;
			RestRequest req = null;
			RestResponse res = null;

			req = createRequest(r1);
			res = createResponse(req, r2);

			String method = req.getMethod();
			String methodUC = method.toUpperCase();

			// Class-level guards
			for (RestGuard guard : cGuards)
				guard.guard(req, res);

			// If the specified method has been defined in a subclass, invoke it.
			int rc = SC_METHOD_NOT_ALLOWED;
			if (resource.restMethods.containsKey(methodUC)) {
				rc = resource.restMethods.get(methodUC).invoke(method, pathInfo, resource, req, res);
			} else if (resource.restMethods.containsKey("*")) {
				rc = resource.restMethods.get("*").invoke(method, pathInfo, resource, req, res);
			}

			// If not invoked above, see if it's an OPTIONs request
			if (rc != SC_OK) {
				String onPath = pathInfo.isEmpty() ? "" : format(" on path '%s'", pathInfo);
				if (rc == SC_NOT_FOUND)
					throw new RestException(rc, "Method '%s' not found on resource with matching pattern%s.", methodUC, onPath);
				else if (rc == SC_PRECONDITION_FAILED)
					throw new RestException(rc, "Method '%s' not found on resource%s with matching matcher.", methodUC, onPath);
				else if (rc == SC_METHOD_NOT_ALLOWED)
					throw new RestException(rc, "Method '%s' not found on resource.", methodUC);
				else
					throw new ServletException("Invalid method response: " + rc);
			}

			if (res.hasOutput()) {
				Object output = res.getOutput();

				// Do any class-level filtering.
				for (RestConverter converter : cConverters)
					output = converter.convert(this, req, output);

				res.setOutput(output);

				// Now serialize the output if there was any.
				// Some subclasses may write to the OutputStream or Writer directly.
				resource.serialize(req, res, output);
			}

			onSuccess(req, res, System.currentTimeMillis() - startTime);

		} catch (RestException e) {
			handleError(r1, r2, e);
		} catch (Throwable e) {
			handleError(r1, r2, new RestException(SC_INTERNAL_SERVER_ERROR, e));
		}
	}

	private synchronized void handleError(HttpServletRequest req, HttpServletResponse res, RestException e) throws IOException {
		Integer c = 1;
		if (useStackTraceHashes) {
			int h = e.hashCode();
			c = stackTraceHashes.get(h);
			if (c == null)
				c = 1;
			else
				c++;
			stackTraceHashes.put(h, c);
			e.setOccurrence(c);
		}
		String q = req.getQueryString();
		boolean noTrace = (q == null ? false : q.toLowerCase().indexOf("notrace") != -1);
		onError(req, res, e, noTrace);
		renderError(req, res, e);
	}

	/**
	 * Method for rendering response errors.
	 * <p>
	 * The default implementation renders a plain text English message, optionally with a stack trace
	 * if {@link RestServletProperties#RENDER_RESPONSE_STACK_TRACES} is enabled.
	 * <p>
	 * Subclasses can override this method to provide their own custom error response handling.
	 *
	 * @param req The servlet request.
	 * @param res The servlet response.
	 * @param e The exception that occurred.
	 * @throws IOException Can be thrown if a problem occurred trying to write to the output stream.
	 */
	protected void renderError(HttpServletRequest req, HttpServletResponse res, RestException e) throws IOException {

		int status = e.getStatus();
		res.setStatus(status);
		res.setContentType("text/plain");
		res.setHeader("Content-Encoding", "identity");
		PrintWriter w = null;
		try {
			w = res.getWriter();
		} catch (IllegalStateException e2) {
			w = new PrintWriter(res.getOutputStream());
		}
		String httpMessage = RestUtils.getHttpResponseText(status);
		if (httpMessage != null)
			w.append("HTTP ").append(String.valueOf(status)).append(": ").append(httpMessage).append("\n\n");
		if (renderResponseStackTraces)
			e.printStackTrace(w);
		else
			w.append(e.getFullStackMessage());
		w.flush();
		w.close();
	}

	/**
	 * Callback method for logging errors during HTTP requests.
	 * <p>
	 * Typically, subclasses will override this method and log errors themselves.
	 * <p>
	 * The default implementation simply logs errors to the <code>RestServlet</code> logger.
	 * <p>
	 * Here's a typical implementation showing how stack trace hashing can be used to reduce log file sizes...
	 * <p class='bcode'>
	 * 	<jk>protected void</jk> onError(HttpServletRequest req, HttpServletResponse res, RestException e, <jk>boolean</jk> noTrace) {
	 * 		String qs = req.getQueryString();
	 * 		String msg = <js>"HTTP "</js> + req.getMethod() + <js>" "</js> + e.getStatus() + <js>" "</js> + req.getRequestURI() + (qs == <jk>null</jk> ? <js>""</js> : <js>"?"</js> + qs);
	 * 		<jk>int</jk> c = e.getOccurrence();
	 *
	 * 		<jc>// USE_STACK_TRACE_HASHES is disabled, so we have to log the exception every time.</jc>
	 * 		<jk>if</jk> (c == 0)
	 * 			myLogger.log(Level.<jsf>WARNING</jsf>, <jsm>format</jsm>(<js>"[%s] %s"</js>, e.getStatus(), msg), e);
	 *
	 * 		<jc>// This is the first time we've countered this error, so log a stack trace
	 *			// unless ?noTrace was passed in as a URL parameter.</jc>
	 * 		<jk>else if</jk> (c == 1 && ! noTrace)
	 * 			myLogger.log(Level.<jsf>WARNING</jsf>, <jsm>format</jsm>(<js>"[%h.%s.%s] %s"</js>, e.hashCode(), e.getStatus(), c, msg), e);
	 *
	 * 		<jc>// This error occurred before.
	 *			// Only log the message, not the stack trace.</jc>
	 * 		<jk>else</jk>
	 * 			myLogger.log(Level.<jsf>WARNING</jsf>, <jsm>format</jsm>(<js>"[%h.%s.%s] %s, %s"</js>, e.hashCode(), e.getStatus(), c, msg, e.getLocalizedMessage()));
	 * 	}
	 * </p>
	 *
	 * @param req The servlet request object.
	 * @param res The servlet response object.
	 * @param e Exception indicating what error occurred.
	 * @param noTrace <jk>true</jk> if <code>&noTrace</code> was passed as a URL parameter.
	 * 	This indicates a request that a stack trace not be logged.
	 * 	Useful for JUnit testing when your testing error conditions and you don't want the log file filling up with
	 * 		noisy stack traces.
	 */
	protected void onError(HttpServletRequest req, HttpServletResponse res, RestException e, boolean noTrace) {
		String qs = req.getQueryString();
		String msg = "HTTP " + req.getMethod() + " " + e.getStatus() + " " + req.getRequestURI() + (qs == null ? "" : "?" + qs);
		int c = e.getOccurrence();
		Logger log = getLogger();
		if (c == 0)
			log.log(Level.WARNING, format("[%s] %s", e.getStatus(), msg), e);
		else if (c == 1 && ! noTrace)
			log.log(Level.WARNING, format("[%h.%s.%s] %s", e.hashCode(), e.getStatus(), c, msg), e);
		else
			log.log(Level.WARNING, format("[%h.%s.%s] %s, %s", e.hashCode(), e.getStatus(), c, msg, e.getLocalizedMessage()));
	}

	/**
	 * Callback method for listening for successful completion of requests.
	 * <p>
	 * Subclasses can override this method for gathering performance statistics.
	 * <p>
	 * The default implementation does nothing.
	 *
	 * @param req The HTTP request.
	 * @param res The HTTP response.
	 * @param time The time in milliseconds it took to process the request.
	 */
	protected void onSuccess(RestRequest req, RestResponse res, long time) {}

	/**
	 * Callback method that gets invoked right before the REST Java method is invoked.
	 * <p>
	 * Subclasses can override this method to override request headers or set request-duration properties
	 * 	before the Java method is invoked.
	 *
	 * @param req The HTTP servlet request object.
	 * @param properties The request-duration properties preloaded with values from the following...
	 * 	<ol>
	 * 		<li>{@link RestResource#properties()}
	 * 		<li>{@link RestMethod#properties()}
	 * 	</ol>
	 * @throws RestException If any error occurs.
	 */
	protected void onPreCall(RestRequest req, ObjectMap properties) throws RestException {}

	/**
	 * Callback method that gets invoked right after the REST Java method is invoked, but before
	 * 	the serializer is invoked.
	 * <p>
	 * Subclasses can override this method to override request and response headers, or
	 * 	set/override properties used by the serializer.
	 *
	 * @param req The HTTP servlet request object.
	 * @param res The HTTP servlet response object.
	 * @param properties The request-duration properties.
	 * @throws RestException If any error occurs.
	 */
	protected void onPostCall(RestRequest req, RestResponse res, ObjectMap properties) throws RestException {};

	/**
	 * The main method for serializing POJOs passed in through the {@link RestResponse#setOutput(Object)} method.
	 * <p>
	 * 	Subclasses may override this method if they wish to modify the way the output is rendered, or support
	 * 	other output formats.
	 */
	protected void serialize(RestRequest req, RestResponse res, Object output) throws IOException, RestException {

		if (output instanceof InputStream) {
			res.setHeader("content-type", res.getContentType());
			OutputStream os = res.getOutputStream();
			IOUtils.pipe((InputStream)output, os);
			os.close();

		} else if (output instanceof Reader) {
			Writer w = res.getWriter();
			IOUtils.pipe((Reader)output, w);
			w.close();

		// Otherwise, we're going to convert it using one of the registered serializers.
		} else {

			SerializerGroup g = res.serializerGroup;
			String accept = req.getHeader("accept");
			String matchingAccept = g.findMatch(accept);
			if (matchingAccept != null) {
				ISerializer r = g.getSerializer(matchingAccept);
				String contentType = r.getResponseContentType();
				if (contentType == null)
					contentType = res.getContentType();
				if (contentType == null)
					contentType = matchingAccept;
				res.setContentType(contentType);
				ObjectMap headers = r.getResponseHeaders(res.getProperties());
				if (headers != null)
					for (String key : headers.keySet())
						res.setHeader(key, headers.getString(key));

				try {
					if (r instanceof IOutputStreamSerializer) {
						IOutputStreamSerializer s2 = (IOutputStreamSerializer)r;
						OutputStream os = res.getOutputStream();
						s2.serialize(output, os, res.getProperties(), matchingAccept, res.getCharacterEncoding());
						os.close();
					} else {
						IWriterSerializer s2 = (IWriterSerializer)r;
						Writer w = res.getWriter();
						s2.serialize(output, w, res.getProperties(), matchingAccept);
						w.close();
					}
				} catch (SerializeException e) {
					throw new RestException(SC_INTERNAL_SERVER_ERROR, e);
				}
			} else {
				throw new RestException(SC_NOT_ACCEPTABLE,
					"Unsupported media-type in request header 'Accept': '%s'\n\tSupported media-types: %s",
					req.getHeader("accept", "").replace(' ', '+'), g.getSupportedMediaTypes()
				);
			}
		}
	}

	/**
	 * Returns the class-level properties currently associated with this servlet.
	 * <p>
	 * The class level properties are set in the following ways:
	 * <ul>
	 * 	<li>Through servlet-init parameters.
	 * 	<li>By calling {@link #setProperty(String, Object)} (typically during servlet initialization).
	 * 	<li>By adding entries to the returned map directly.
	 * </ul>
	 * An {@link ObjectMap} is used to make it simpler to access init parameters of different types.
	 * <p>
	 * <b>Important note:</b>  The returned {@code Map} is mutable.  Therefore, subclasses are free to override
	 * or set additional initialization parameters in their {@code init()} method.
	 * <p>
	 * This method can be called from {@link HttpServlet#init(ServletConfig)} or {@link HttpServlet#init()}.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Old way of getting a boolean init parameter</jc>
	 * 	String s = getInitParam(<js>"allowMethodParam"</js>);
	 * 	if (s == <jk>null</jk>)
	 * 		s = <js>"false"</js>;
	 * 	<jk>boolean</jk> b = Boolean.parseBoolean(s);
	 *
	 * 	<jc>// New simplified way of getting a boolean init parameter</jc>
	 * 	<jk>boolean</jk> b = getProperties().getBoolean(<js>"allowMethodParam"</js>, <jk>false</jk>);
	 * </p>
	 *
	 * @return The resource init parameters as an {@link ObjectMap}.
	 */
	public ObjectMap getProperties() {
		return cProperties;
	}

	@Override
	public ServletConfig getServletConfig() {
		return servletConfig;
	}

	// In-memory cache of images and stylesheets in the com.ibm.juno.server.htdocs package.
	private static Map<String,ByteArrayOutputStream> htDocsCache = new HashMap<String,ByteArrayOutputStream>();

	/**
	 * Handle .../htdocs/... requests (i.e. requests for juno.css and images).
	 */
	private boolean serviceHtDocs(String pathInfo, HttpServletResponse res) throws IOException {

		pathInfo = pathInfo.substring(pathInfo.indexOf("htdocs/")+7);

		// See if this resource is already cached.
		// If not, cache it now.
		if (! htDocsCache.containsKey(pathInfo)) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream(0);
			final InputStream is = RestServlet.class.getResourceAsStream("htdocs/" + pathInfo);
			if (is != null)
				IOUtils.pipe(is, baos);
			htDocsCache.put(pathInfo, baos);
		}

		ByteArrayOutputStream baos = htDocsCache.get(pathInfo);
		if (baos.size() == 0)
			return false;

		res.setHeader("Cache-Control", "max-age=86400, public");
		OutputStream os = res.getOutputStream();
		htDocsCache.get(pathInfo).writeTo(os);
		os.flush();
		return true;
	}

	/**
	 * Returns a list of valid {@code Accept} content types for this resource.
	 * <p>
	 * 	Typically used by subclasses during {@code OPTIONS} requests.
	 * <p>
	 * 	Subclasses can override or expand this list as they see fit.
	 *
	 * @return The list of valid {@code Accept} content types for this resource.
	 */
	public Collection<String> getSupportedAcceptTypes() {
		return getSerializerGroup().getSupportedMediaTypes();
	}

	/**
	 * Returns a list of valid {@code Content-Types} for input for this resource.
	 * <p>
	 * 	Typically used by subclasses during {@code OPTIONS} requests.
	 * <p>
	 * 	Subclasses can override or expand this list as they see fit.
	 *
	 * @return The list of valid {@code Content-Type} header values for this resource.
	 */
	public Collection<String> getSupportedContentTypes() {
		return getParserGroup().getSupportedMediaTypes();
	}

	/**
	 * Returns localized descriptions of all REST methods defined on this class that the user of the current
	 * 	request is allowed to access.
	 * <p>
	 * 	Useful for OPTIONS pages.
	 * <p>
	 * 	This method does not cache results, since it's expected to be called infrequently.
	 *
	 * @param req The current request.
	 * @return Localized descriptions of all REST methods defined on this class.
	 */
	public Collection<MethodDescription> getMethodDescriptions(RestRequest req) {
		List<MethodDescription> l = new LinkedList<MethodDescription>();
		Locale locale = req.getLocale();
		NlsClass cm = msgs.getNlsClass(locale);

		for (SimpleMethod sm : javaRestMethods)
			if (sm.isRequestAllowed(req))
				l.add(sm.getMethodDescription(cm.getMethod(sm.method.getName())));

		return l;
	}

	/**
	 * Returns the localized description of this REST resource.
	 * <p>
	 * 	Pulled from this classes resource bundle identified by the {@link RestResource#messages()} annotation.
	 * <p>
	 * 	Looks for the following keys in the resource bundle:
	 * <ol>
	 * 	<li><code>{ClassName}.RestResource</code>
	 * 	<li><code>RestResource</code>
	 *	</ol>
	 * <p>
	 * 	This method does not cache results, since it's expected to be called infrequently.
	 *
	 * @param locale The client locale.
	 * @return The localized description of this REST resource, or <jk>null</jk> if no resource description was found.
	 */
	public String getResourceDescription(Locale locale) {
		return msgs.getNlsClass(locale).getDescription();
	}

	/**
	 * Gets a localized message from the resource bundle identified by the {@link RestResource#messages()} annotation.
	 * <p>
	 * 	If resource bundle location was not specified, or the resource bundle was not found,
	 * 	returns the string "{!!key}".
	 * <p>
	 * 	If message was not found in the resource bundle, returns the string "{!key}".
	 * @param locale The client locale.
	 * @param key The resource bundle key.
	 * @param args Optional {@link java.text.MessageFormat} variable values to replace.
	 * @return The localized message.
	 */
	public String getMessage(Locale locale, String key, Object...args) {
		return msgs.getMessage(locale, key, args);
	}

	/**
	 * Returns the resource bundle identified by the {@link RestResource#messages()} annotation for the specified locale.
	 * @param locale The resource bundle locale.
	 * @return The resource bundle.  Never <jk>null</jk>.
	 */
	public SafeResourceBundle getResourceBundle(Locale locale) {
		return msgs.getBundle(locale);
	}

	/**
	 * Programmatically adds the specified resource as a child to this resource.
	 * <p>
	 * 	This method can be used in a resources {@link #init()} method to define child resources
	 * 	accessible through a child URL.
	 * <p>
	 * 	Typically, child methods are defined via {@link RestChild} annotated methods.  However, this
	 * 	method is provided to handle child resources determined at runtime.
	 *
	 * @param name The sub-URL under which this resource is accessible.<br>
	 * 	For example, if the parent resource URL is <js>"/foo"</js>, and this name is <js>"bar"</js>, then
	 * 	the child resource will be accessible via the URL <js>"/foo/bar"</js>.
	 * @param resource The child resource.
	 * @throws ServletException Thrown by the child init() method.
	 */
	public void addChildResource(String name, RestServlet resource) throws ServletException {
		resource.init(getServletConfig());
		childResources.put(name, resource);
	}

	/**
	 * Returns the logger associated with this servlet.
	 * <p>
	 * Subclasses can override this method to provide their own logger.
	 * @return The logger associated with this servlet.
	 */
	public Logger getLogger() {
		if (logger == null)
			logger =  Logger.getLogger(getClass().getName());
		return logger;
	}

	private abstract class ResourceMethod {
		abstract int invoke(String methodName, String pathInfo, RestServlet resource, RestRequest req, RestResponse res) throws RestException;

		void complete() {
			// Do nothing by default.
		}
	}

	@SuppressWarnings("hiding")
	static enum ParamType {
		REQ, RES, ATTR, CONTENT, HEADER, METHOD, PARAM, HASPARAM, REMAINDER, PROPERTIES, MESSAGES
	}

	static class MethodParam {

		ParamType paramType;
		Class<?> classType;
		String name = "";

		MethodParam(Class<?> classType, Annotation[] annotations) throws ServletException {
			this.classType = classType;
			if (HttpServletRequest.class.isAssignableFrom(classType))
				paramType = ParamType.REQ;
			else if (HttpServletResponse.class.isAssignableFrom(classType))
				paramType = ParamType.RES;
			else for (Annotation a : annotations) {
				if (a instanceof Attr) {
					paramType = ParamType.ATTR;
					name = ((Attr)a).value();
				} else if (a instanceof Header) {
					paramType = ParamType.HEADER;
					name = ((Header)a).value();
				} else if (a instanceof Param) {
					paramType = ParamType.PARAM;
					name = ((Param)a).value();
				} else if (a instanceof HasParam) {
					paramType = ParamType.HASPARAM;
					name = ((HasParam)a).value();
				} else if (a instanceof Content) {
					paramType = ParamType.CONTENT;
					name = "CONTENT";
				} else if (a instanceof com.ibm.juno.server.annotation.Method) {
					paramType = ParamType.METHOD;
					if (classType != String.class)
						throw new ServletException("@Method parameters must be of type String");
				} else if (a instanceof Remainder) {
					paramType = ParamType.REMAINDER;
					if (classType != String.class)
						throw new ServletException("@Remainder parameters must be of type String");
				} else if (a instanceof Properties) {
					paramType = ParamType.PROPERTIES;
					name = "PROPERTIES";
				} else if (a instanceof Messages) {
					paramType = ParamType.MESSAGES;
					name = "MESSAGES";
				}
			}
			if (paramType == null)
				paramType = ParamType.ATTR;
		}

		private Object getValue(RestRequest req, RestResponse res) throws ParseException, IOException {
			switch(paramType) {
				case REQ:        return req;
				case RES:        return res;
				case ATTR:       return req.getAttribute(classType, name);
				case CONTENT:    return req.getInput(classType);
				case HEADER:     return req.getHeader(classType, name);
				case METHOD:     return req.getMethod();
				case PARAM:      return req.getParam(classType, name);
				case HASPARAM:   return req.getServlet().getBeanContext().convertToType(req.hasParam(name), classType);
				case REMAINDER:  return req.getRemainder();
				case PROPERTIES: return res.getProperties();
				case MESSAGES:   return req.getResourceBundle();
			}
			return null;
		}
	}

	/**
	 * Add default per-request properties.
	 * <p>
	 * Subclasses can override this method to add their own properties programatically.
	 *
	 * @param p The properties to add to.
	 * @param req The HTTP servlet request.
	 */
	public void addDefaultProperties(ObjectMap p, RestRequest req) {
		if (! p.containsKey(URI_AUTHORITY)) {
			int serverPort = req.getServerPort();
			String serverName = req.getServerName();
			p.put(URI_AUTHORITY, req.getScheme() + "://" + serverName + (serverPort == 80 || serverPort == 443 ? "" : ":" + serverPort));
		}
		p.put(URI_SERVLET_PATH, req.getServletPath());
		p.put(URI_PATH_INFO, req.getPathInfo());
		p.put(METHOD, req.getMethod());
	}

	/*
	 * Represents a single Java servlet method annotated with @RestMethod.
	 */
	private class SimpleMethod extends ResourceMethod implements Comparable<SimpleMethod>  {
		private String httpMethod;
		private java.lang.reflect.Method method;
		private UrlPattern pattern;
		private MethodParam[] params;
		private RestGuard[] guards;
		private RestMatcher[] matchers;
		private RestConverter[] mConverters;
		private SerializerGroup mSerializers;            // Method-level serializers
		private ParserGroup mParsers;                    // Method-level parsers
		private ObjectMap mProperties;                   // Method-level properties
		private ObjectMap mDefaultRequestHeaders;        // Method-level default request headers
		private int priority;

		private SimpleMethod(java.lang.reflect.Method method) throws Exception {
			this.method = method;

			RestMethod m = method.getAnnotation(RestMethod.class);
			if (m == null)
				throw new Exception(format("@RestMethod annotation not found on method '%s.%s'", method.getDeclaringClass().getName(), method.getName()));

			this.mSerializers = getSerializerGroup();
			this.mParsers = getParserGroup();
			this.mProperties = cProperties;

			ArrayList<Inherit> si = new ArrayList<Inherit>(Arrays.asList(m.serializersInherit()));
			ArrayList<Inherit> pi = new ArrayList<Inherit>(Arrays.asList(m.parsersInherit()));

			if (m.serializers().length > 0 || m.parsers().length > 0 || m.properties().length > 0 || m.filters().length > 0) {
				mSerializers = (si.contains(SERIALIZERS) || m.serializers().length == 0 ? mSerializers.clone() : new SerializerGroup());
				mParsers = (pi.contains(PARSERS) || m.parsers().length == 0 ? mParsers.clone() : new ParserGroup());
			}

			httpMethod = m.name().toUpperCase();
			if (httpMethod.equals("") && method.getName().startsWith("do"))
				httpMethod = method.getName().substring(2).toUpperCase();
			if (httpMethod.equals(""))
				throw new Exception(format("@RestMethod name not specified on method '%s.%s'", method.getDeclaringClass().getName(), method.getName()));
			if (httpMethod.equals("METHOD"))
				httpMethod = "*";

			String p = m.pattern();
			mConverters = new RestConverter[m.converters().length];
			for (int i = 0; i < mConverters.length; i++)
				mConverters[i] = m.converters()[i].newInstance();

			guards = new RestGuard[m.guards().length];
			for (int i = 0; i < guards.length; i++)
				guards[i] = m.guards()[i].newInstance();

			matchers = new RestMatcher[m.matchers().length];
			for (int i = 0; i < matchers.length; i++)
				matchers[i] = m.matchers()[i].newInstance();

			if (m.serializers().length > 0) {
				mSerializers.append(m.serializers());
				if (si.contains(FILTERS))
					mSerializers.addFilters(cFilters);
				if (si.contains(PROPERTIES))
					mSerializers.setProperties(cProperties);
			}

			if (m.parsers().length > 0) {
				mParsers.append(m.parsers());
				if (pi.contains(FILTERS))
					mParsers.addFilters(cFilters);
				if (pi.contains(PROPERTIES))
					mParsers.setProperties(cProperties);
			}

			if (m.properties().length > 0) {
				mProperties = new ObjectMap().setInner(cProperties);
				for (Property p1 : m.properties()) {
					String n = p1.name(), v = p1.value();
					if (p1.nls())
						mProperties.put(n, '\u0000' + v);
					else {
						mProperties.put(n, v);
						mSerializers.setProperty(n, v);
						mParsers.setProperty(n, v);
					}
				}
			}

			if (m.filters().length > 0) {
				mSerializers.addFilters(m.filters());
				mParsers.addFilters(m.filters());
			}

			mDefaultRequestHeaders = new ObjectMap();
			for (String s : m.defaultRequestHeaders()) {
				String[] h = parseHeader(s);
				if (h == null)
					throw new ServletException(String.format("Invalid default request header specified: [%s].  Must be in the format: [Header-Name: header-value]", s));
				mDefaultRequestHeaders.append(h[0], h[1]);
			}

			pattern = new UrlPattern(p);

			int attrIdx = 0;
			Class<?>[] pt = method.getParameterTypes();
			Annotation[][] pa = method.getParameterAnnotations();
			params = new MethodParam[pt.length];
			for (int i = 0; i < params.length; i++) {
				params[i] = new MethodParam(pt[i], pa[i]);
				if (params[i].paramType == ParamType.ATTR && params[i].name.isEmpty()) {
					if (pattern.vars.length <= attrIdx)
						throw new ServletException("Number of attribute parameters in method "+method.getName()+" exceeds the number of URL pattern variables.");
					params[i].name = pattern.vars[attrIdx++];
				}
			}

			mSerializers.lock();
			mParsers.lock();

			// Need this to access methods in anonymous inner classes.
			method.setAccessible(true);
		}

		private MethodDescription getMethodDescription(NlsMethod nlsMethod) {
			String javaMethod = method.getName();
			String desc = nlsMethod.getDescription();
			MethodDescription d = new MethodDescription(javaMethod, httpMethod, pattern.patternString, desc);

			if (method.getReturnType() != Void.TYPE)
				d.setResponseContent(method.getReturnType().getSimpleName());

			if (method.isAnnotationPresent(RestMethod.class)) {
				RestMethod rm = method.getAnnotation(RestMethod.class);
				d.setConverters(rm.converters());
				d.setGuards(rm.guards());
				d.setMatchers(rm.matchers());
				if (mParsers != getParserGroup())
					d.setAccept(mParsers.getSupportedMediaTypes());
				if (mSerializers != getSerializerGroup())
					d.setContentType(mSerializers.getSupportedMediaTypes());


				// URL variable descriptions
				for (MethodParam p : params) {
					switch(p.paramType) {
						case ATTR:
						case HEADER:
						case PARAM:
						case CONTENT:
							String cat = p.paramType.name().toLowerCase();
							NlsVar v = nlsMethod.getRequestVar(cat, p.name);
							Var v2 = d.addRequestVar(cat, p.name);
							v2.classType = p.classType.getSimpleName();
							if (v != null)
								v2.description = v.description;
							break;
						default:
					}
				}

				for (NlsVar v : nlsMethod.requestVars)
					d.addRequestVar(v.category, v.name).description = v.description;

				for (int rc : rm.rc())
					d.addResponse(rc);

				for (NlsResponse rcm : nlsMethod.getResponses()) {
					Response res = d.addResponse(rcm.httpStatus);
					if (rcm.description != null)
						res.description = rcm.description;
					for (NlsVar v : rcm.responseVars) {
						Var v2 = res.addResponseVar(v.category, v.name);
						v2.description = v.description;
					}
				}
			}

			return d;
		}

		private boolean isRequestAllowed(RestRequest req) {
			for (RestGuard guard : guards)
				if (! guard.isRequestAllowed(req))
					return false;
			return true;
		}

		@Override
		int invoke(String methodName, String pathInfo, RestServlet resource, RestRequest req, RestResponse res) throws RestException {

			String[] patternVals = pattern.match(pathInfo);
			if (patternVals == null)
				return SC_NOT_FOUND;

			if (patternVals.length > pattern.vars.length) {
				String remainder = patternVals[pattern.vars.length];
				if (remainder.startsWith("/"))
					remainder = remainder.substring(1);
				req.setRemainder(remainder);
			}
			for (int i = 0; i < pattern.vars.length; i++)
				req.setAttribute(pattern.vars[i], patternVals[i]);

			// If the method implements matchers, test them.
			if (matchers.length > 0) {
				boolean matches = false;
				for (RestMatcher m : matchers)
					matches |= m.matches(req);
				if (! matches)
					return SC_PRECONDITION_FAILED;
			}

			req.addDefaultHeaders(mDefaultRequestHeaders);
			ObjectMap properties = new LocalizedObjectMap(mProperties, req.getResourceBundle());
			addDefaultProperties(properties, req);

			req.setProperties(properties);
			res.setProperties(properties);

			req.setParserGroup(mParsers);
			res.setSerializerGroup(mSerializers);

			onPreCall(req, properties);

			Object[] args = new Object[params.length];
			for (int i = 0; i < params.length; i++) {
				try {
					args[i] = params[i].getValue(req, res);
				} catch (RestException e) {
					throw e;
				} catch (Exception e) {
					throw new RestException(SC_BAD_REQUEST, e,
						"Invalid data conversion.  Could not convert %s '%s' to type '%s' on method '%s.%s'.",
						params[i].paramType.name().toLowerCase(), params[i].name, params[i].classType, method.getDeclaringClass().getName(), method.getName()
					);
				}
			}

			try {

				for (RestGuard guard : guards)
					guard.guard(req, res);

				Object output = method.invoke(resource, args);
				if (! method.getReturnType().equals(Void.TYPE))
					res.setOutput(output);

				onPostCall(req, res, properties);

				if (res.hasOutput()) {
					output = res.getOutput();
					for (RestConverter converter : mConverters)
						output = converter.convert(resource, req, output);
					res.setOutput(output);
				}
			} catch (IllegalArgumentException e) {
				throw new RestException(SC_INTERNAL_SERVER_ERROR,
					"Invalid argument type passed to the following method: '%s'.\n\tArgument types: %s",
					method.toString(), ClassUtils.getClassTypeStrings(args)
				);
			} catch (InvocationTargetException e) {
				Throwable e2 = e.getTargetException();		// Get the throwable thrown from the doX() method.
				if (e2 instanceof RestException)
					throw (RestException)e2;
				if (e2 instanceof ParseException)
					throw new RestException(SC_BAD_REQUEST, e2);
				if (e2 instanceof InvalidDataConversionException)
					throw new RestException(SC_BAD_REQUEST, e2);
				throw new RestException(SC_INTERNAL_SERVER_ERROR, e2);
			} catch (RestException e) {
				throw e;
			} catch (Exception e) {
				throw new RestException(SC_INTERNAL_SERVER_ERROR, e);
			}
			return SC_OK;
		}

		@Override
		public String toString() {
			return "SimpleMethod: name=" + httpMethod + ", pattern=" + pattern.patternString + ", matchers=" + matchers.length;
		}

		/*
		 * compareTo() method is used to keep SimpleMethods ordered in the MultiMethod.tempCache list.
		 * It maintains the order in which matches are made during requests.
		 */
		@Override
		public int compareTo(SimpleMethod o) {

			int c = new Integer(o.priority).compareTo(priority);
			if (c != 0)
				return c;

			c = pattern.compareTo(o.pattern);
			if (c != 0)
				return c;

			c = new Integer(o.matchers.length).compareTo(matchers.length);
			if (c != 0)
				return c;

			c = new Integer(o.guards.length).compareTo(guards.length);
			if (c != 0)
				return c;

			return 0;
		}
	}

	/*
	 * Represents a group of SimpleMethods that all belong to the same HTTP method (e.g. "GET").
	 */
	private class MultiMethod extends ResourceMethod {
		SimpleMethod[] childMethods;
		List<SimpleMethod> tempCache = new LinkedList<SimpleMethod>();
		Set<String> collisions = new HashSet<String>();

		private MultiMethod(SimpleMethod... simpleMethods) {
			for (SimpleMethod m : simpleMethods)
				addSimpleMethod(m);
		}

		private void addSimpleMethod(SimpleMethod m) {
			if (m.guards.length == 0 && m.matchers.length == 0) {
				String p = m.httpMethod + ":" + m.pattern;
				if (collisions.contains(p))
					throw new RuntimeException(
						String.format("Duplicate Java methods assigned to the same method/pattern:  method='%s', pattern='%s'", m.httpMethod, m.pattern)
					);
				collisions.add(p);
			}
			tempCache.add(m);
		}

		@Override
		void complete() {
			Collections.sort(tempCache);
			collisions = null;
			childMethods = tempCache.toArray(new SimpleMethod[tempCache.size()]);
		}

		@Override
		int invoke(String methodName, String pathInfo, RestServlet resource, RestRequest req, RestResponse res) throws RestException {
			int maxRc = 0;
			for (SimpleMethod m : childMethods) {
				int rc = m.invoke(methodName, pathInfo, resource, req, res);
				if (rc == SC_OK)
					return SC_OK;
				maxRc = Math.max(maxRc, rc);
			}
			return maxRc;
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder("MultiMethod: [\n");
			for (SimpleMethod sm : childMethods)
				sb.append("\t" + sm + "\n");
			sb.append("]");
			return sb.toString();
		}
	}

	private static class UrlPattern implements Comparable<UrlPattern> {
		private Pattern pattern;
		private String patternString;
		private boolean isDotAll;
		private String[] vars = new String[0];

		private UrlPattern(String patternString) {
			this.patternString = patternString;
			if (patternString.startsWith("/"))
				patternString = patternString.substring(1);
			if (patternString.equals("*")) {
				isDotAll = true;
				return;
			}

			// Find all {xxx} variables.
			Pattern p = Pattern.compile("\\{([^\\}]+)\\}");
			List<String> vl = new LinkedList<String>();
			Matcher m = p.matcher(patternString);
			while (m.find())
				vl.add(m.group(1));
			this.vars = vl.toArray(new String[vl.size()]);

			patternString = patternString.replaceAll("\\{[^\\}]+\\}", "([^\\/]+)");
			patternString = patternString.replaceAll("\\/\\*$", "((?:)|(?:\\/.*))");
			pattern = Pattern.compile(patternString);
		}

		private String[] match(String s) {

			if (isDotAll)
				return new String[]{s};

			Matcher m = pattern.matcher(s);
			if (! m.matches())
				return null;

			String[] v = new String[m.groupCount()];

			for (int i = 0; i < m.groupCount(); i++)
				v[i] = decode(m.group(i+1));

			return v;
		}

		@Override
		public int compareTo(UrlPattern o) {
			String s1 = patternString.replaceAll("\\{[^\\}]+\\}", ".").replaceAll("\\w+", "X");
			String s2 = o.patternString.replaceAll("\\{[^\\}]+\\}", ".").replaceAll("\\w+", "X");
			if (s1.isEmpty())
				s1 = "+";
			if (s2.isEmpty())
				s2 = "+";
			if (! s1.endsWith("/*"))
				s1 = s1 + "/W";
			if (! s2.endsWith("/*"))
				s2 = s2 + "/W";
			int c = s2.compareTo(s1);
			if (c == 0)
				return o.patternString.compareTo(patternString);
			return c;
		}
	}

	private static String decode(String s) {
		if (s == null)
			return s;
		boolean needsDecode = false;
		for (int i = 0; i < s.length() && ! needsDecode; i++) {
			char c = s.charAt(i);
			if (c == '+' || c == '%')
				needsDecode = true;
		}
		try {
			if (needsDecode)
				return URLDecoder.decode(s, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e); // Won't happen.
		}
		return s;
	}

	/*
	 * Same as {@link ObjectMap}, except values that start with '\u0000' are replaced
	 * with values from the specified resource bundle.
	 */
	private static class LocalizedObjectMap extends ObjectMap {

		private ResourceBundle rb;

		LocalizedObjectMap(ObjectMap m, ResourceBundle rb) {
			setInner(m);
			this.rb = rb;
		}

		@Override
		public Object get(Object key) {
			Object o = super.get(key);
			if (rb != null && o != null && o instanceof String) {
				String s = o.toString();
				if (s.length() > 0 && s.charAt(0) == '\u0000')
					return rb.getObject(s.substring(1));
			}
			return o;
		}
	}
}
