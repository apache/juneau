package com.ibm.juno.server.annotation;

/**
 * Inheritance values for the {@link RestMethod#serializersInherit()} and {@link RestMethod#parsersInherit()}
 * 	annotations.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public enum Inherit {

	/** Inherit serializers from parent. */
	SERIALIZERS,

	/** Inherit parsers from parent. */
	PARSERS,

	/** Inherit filters from parent. */
	FILTERS,

	/** Inherit properties from parent. */
	PROPERTIES
}
