package com.ibm.juno.core.json;

import static com.ibm.juno.core.json.JsonSerializerProperties.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Context object that lives for the duration of a single serialization of {@link JsonSerializer} and its subclasses.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonSerializerContext extends SerializerContext {

	private final boolean simpleMode, useWhitespace;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param jsp Default JSON serializer properties.
	 * @param op Override properties.
	 */
	protected JsonSerializerContext(BeanContext beanContext, SerializerProperties sp, JsonSerializerProperties jsp, ObjectMap op) {
		super(beanContext, sp, op);
		if (op == null || op.isEmpty()) {
			simpleMode = jsp.simpleMode;
			useWhitespace = jsp.useWhitespace;
		} else {
			simpleMode = op.getBoolean(SIMPLE_MODE, jsp.simpleMode);
			useWhitespace = op.getBoolean(USE_WHITESPACE, jsp.useWhitespace);
		}
	}

	/**
	 * Returns the {@link JsonSerializerProperties#SIMPLE_MODE} setting value in this context.
	 * @return The {@link JsonSerializerProperties#SIMPLE_MODE} setting value in this context.
	 */
	public final boolean isSimpleMode() {
		return simpleMode;
	}

	/**
	 * Returns the {@link JsonSerializerProperties#USE_WHITESPACE} setting value in this context.
	 * @return The {@link JsonSerializerProperties#USE_WHITESPACE} setting value in this context.
	 */
	public final boolean isUseWhitespace() {
		return useWhitespace;
	}
}
