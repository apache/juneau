// XML namespaces used in this package
@Xml(ns="c",
	namespaces={
		@XmlNs(name="c", uri="http://developer.cognos.com/schemas/xmldata/1/")
	}
)
package com.ibm.juno.core.cognos;
import com.ibm.juno.core.xml.annotation.*;

