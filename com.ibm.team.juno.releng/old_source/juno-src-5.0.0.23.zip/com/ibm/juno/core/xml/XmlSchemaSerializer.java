package com.ibm.juno.core.xml;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJO metadata to HTTP responses as XML.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>text/xml+schema</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>text/xml</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Produces the XML-schema representation of the XML produced by the {@link XmlSerializer} class with the same properties.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link XmlSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Produces(value="text/xml+schema",contentType="text/xml")
public class XmlSchemaSerializer extends XmlSerializer {

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer, XmlSerializer
	public void serialize(Object output, Writer out, ObjectMap properties, String mediaType) throws IOException, SerializeException {
		XmlSerializerContext ctx = new XmlSerializerContext(beanContext, sp, xsp, properties);
		XmlSerializerWriter w = (out instanceof XmlSerializerWriter ? (XmlSerializerWriter)out : new XmlSerializerWriter(out, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority()));
		serializeSchema(output, w, properties, mediaType);
	}
}
