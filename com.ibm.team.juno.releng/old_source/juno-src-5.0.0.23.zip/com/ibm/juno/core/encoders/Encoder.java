package com.ibm.juno.core.encoders;

import java.io.*;

import javax.servlet.http.*;

import com.ibm.juno.client.*;
import com.ibm.juno.server.*;
import com.ibm.juno.server.annotation.*;

/**
 * Used for enabling decompression on requests and compression on responses, such as support for GZIP compression.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Used to wrap input and output streams withing compression/decompression streams.
 * <p>
 * 	Encoders are registered with {@link RestServlet RestServlets} through the {@link RestResource#encoders()} annotation.
 * <p>
 * 	Encoders are registered with {@link RestClient RestClients} through the {@link RestClient#setEncoder(Encoder)} method.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class Encoder {

	/**
	 * Converts the specified compressed input stream into an uncompressed stream.
	 * @param is The compressed stream.
	 * @return The uncompressed stream.
	 * @throws RestException If any errors occur, such as an {@link HttpServletResponse#SC_BAD_REQUEST} on a stream that's not a valid GZIP input stream.
	 */
	public abstract InputStream getInputStream(InputStream is) throws RestException;

	/**
	 * Converts the specified uncompressed output stream into an uncompressed stream.
	 * @param os The uncompressed stream.
	 * @return The compressed stream stream.
	 * @throws RestException If any errors occur.
	 */
	public abstract OutputStream getOutputStream(OutputStream os) throws RestException;

	/**
	 * Returns the codings in <code>Content-Encoding</code> and <code>Accept-Encoding</code> headers
	 * 	that this encoder handles (e.g. <js>"gzip"</js>).
	 * @return The codings that this encoder handles.
	 */
	public abstract String[] getCodings();
}
