package com.ibm.juno.core.filter;

import com.ibm.juno.core.annotation.*;

/**
 * Represents a no-op filter.
 * <p>
 * 	Used as the default value for the {@link BeanProperty#filter()} annotation to
 * 	represent a <jk>null</jk>.
 */
public class NullFilter extends PojoFilter<Object,Object> {

	/** Reusable filter that represents a 'null' filter. */
	public static final NullFilter INSTANCE = new NullFilter();
}
