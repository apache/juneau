package com.ibm.juno.core.jena;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.jena.Constants.*;
import static com.ibm.juno.core.jena.RdfProperties.*;
import static com.ibm.juno.core.xml.XmlUtils.*;

import java.io.*;
import java.util.*;

import com.hp.hpl.jena.rdf.model.*;
import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Serializes POJO models to RDF.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link RdfSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 *
 * <h6 class='topic'>Behavior-specific subclasses</h6>
 * <p>
 * 	The following direct subclasses are provided for language-specific serializers:
 * <ul>
 * 	<li>{@link RdfSerializer.Xml} - RDF/XML.
 * 	<li>{@link RdfSerializer.XmlAbbrev} - RDF/XML-ABBREV.
 * 	<li>{@link RdfSerializer.NTriple} - N-TRIPLE.
 * 	<li>{@link RdfSerializer.Turtle} - TURTLE.
 * 	<li>{@link RdfSerializer.N3} - N3.
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@Produces(value="text/xml+rdf+abbrev", contentType="text/xml+rdf")
public class RdfSerializer extends WriterSerializer {

	/** Produces RDF/XML output */
	@Produces("text/xml+rdf")
	public static class Xml extends RdfSerializer {
		/** Constructor */
		public Xml() {
			setProperty(RDF_LANGUAGE, LANG_RDF_XML);
		}
	}

	/** Produces RDF/XML-ABBREV output */
	@Produces(value="text/xml+rdf+abbrev", contentType="text/xml+rdf")
	public static class XmlAbbrev extends RdfSerializer {
		/** Constructor */
		public XmlAbbrev() {
			setProperty(RDF_LANGUAGE, LANG_RDF_XML_ABBREV);
		}
	}

	/** Produces N-TRIPLE output */
	@Produces(value="text/n-triple")
	public static class NTriple extends RdfSerializer {
		/** Constructor */
		public NTriple() {
			setProperty(RDF_LANGUAGE, LANG_NTRIPLE);
		}
	}

	/** Produces TURTLE output */
	@Produces(value="text/turtle")
	public static class Turtle extends RdfSerializer {
		/** Constructor */
		public Turtle() {
			setProperty(RDF_LANGUAGE, LANG_TURTLE);
		}
	}

	/** Produces N3 output */
	@Produces(value="text/n3")
	public static class N3 extends RdfSerializer {
		/** Constructor */
		public N3() {
			setProperty(RDF_LANGUAGE, LANG_N3);
		}
	}


	/** Jena serializer properties currently set on this serializer. */
	protected transient RdfSerializerProperties rsp = new RdfSerializerProperties();


	@Override // ISerializer
	public void serialize(Object o, Writer out, ObjectMap properties, String mediaType) throws IOException, SerializeException {
		serialize(out, o, null, properties);
	}

	/**
	 * @param out The output writer.
	 * @param o The object to serialize.
	 * @param properties Override properties.
	 * @param rootUrl The url of the root document (overridden by URI on root bean if present).
	 * @throws IOException If a problem occurred trying to write to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serialize(Writer out, Object o, String rootUrl, ObjectMap properties) throws IOException, SerializeException {
		RdfSerializerContext ctx = new RdfSerializerContext(beanContext, sp, rsp, properties);
		Model model = ctx.model;
		Resource r = null;

		ClassType ct = beanContext.getClassTypeForObject(o);
		if (ct == null)
			ct = ClassType.OBJECT;
		RDFNode n = serializeAnything(o, false, ct.getNamespace(), ClassType.OBJECT, ctx, false);
		if (n.isLiteral()) {
			r = model.createResource(rootUrl);
			r.addProperty(ctx.pValue, n);
		} else {
			r = n.asResource();
		}

		if (ctx.addRootProperty)
			r.addProperty(ctx.pRoot, "true");

		ctx.writer.write(model, out, "http://unknown/");
	}

	private RDFNode serializeAnything(Object o, boolean isURI, Namespace ns, ClassType<?> eType, RdfSerializerContext ctx, boolean isBeanProperty) throws SerializeException {
		Model m = ctx.model;

		ClassType<?> aType = null;						// The actual type
		ClassType<?> wType = null;						// The wrapped type
		ClassType<?> gType = ClassType.OBJECT;		// The generic type

		aType = ctx.push("", o, eType);

		if (eType == null)
			eType = ClassType.OBJECT;

		// Handle recursion
		if (aType == null) {
			o = null;
			aType = ClassType.OBJECT;
		}

		if (o != null) {

			if (aType.isDelegate()) {
				wType = aType;
				aType = ((Delegate)o).getClassType();
			}

			gType = aType.getFilteredClassType();

			// Filter if necessary
			IPojoFilter filter = aType.getPojoFilter();
			if (filter != null) {
				o = filter.filter(o, beanContext);

				// If the filter's getFilteredClass() method returns Object, we need to figure out
				// the actual type now.
				if (gType == ClassType.OBJECT)
					gType = beanContext.getClassTypeForObject(o);
			}
		} else {
			gType = eType.getFilteredClassType();
		}

		RDFNode n = null;

		if (o == null || gType.isChar() && ((Character)o).charValue() == 0) {
			if (isBeanProperty) {
				if (! ctx.isTrimNulls()) {
					n = m.createResource(NIL);
				}
			} else {
				n = m.createResource(NIL);
			}

		} else if (gType.isUri() || isURI) {
			n = m.createResource(getUri(o, null, ctx));

		} else if (gType.isCharSequence() || gType.isChar()) {
			n = m.createLiteral(encodeTextShallow(o));

		} else if (gType.isNumber() || gType.isBoolean()) {
			if (! ctx.addLiteralTypes)
				n = m.createLiteral(o.toString());
			else
				n = m.createTypedLiteral(o);

		} else if (gType.isMap() || (wType != null && wType.isMap())) {
			if (o instanceof BeanMap) {
				BeanMap bm = (BeanMap)o;
				String uri = getUri(bm.getBeanUri(), null, ctx);
				n = m.createResource(uri);
				serializeBeanMap(bm, (Resource)n, ctx);
			} else {
				Map m2 = (Map)o;
				n = m.createResource();
				serializeMap(m2, (Resource)n, gType, ctx);
			}

		} else if (gType.isBean()) {
			BeanMap bm = beanContext.forBean(o);
			String uri = getUri(bm.getBeanUri(), null, ctx);
			n = m.createResource(uri);
			serializeBeanMap(bm, (Resource)n, ctx);

		} else if (gType.isCollection() || (wType != null && wType.isCollection())) {
			Seq list = m.createSeq();
			n = serializeCollection((Collection)o, gType, list, ctx);

		} else if (gType.isArray()) {
			Seq list = m.createSeq();
			n = serializeCollection(toList(gType.getInnerClass(), o), gType, list, ctx);
		} else {
			n = m.createLiteral(encodeTextShallow(o));
		}

		if (ctx.isAddClassAttrs() && n != null && n.isResource()) {
			if (o != null && ! eType.equals(aType))
				n.asResource().addProperty(ctx.pClass, aType.toString());
			else if (o == null)
				n.asResource().addProperty(ctx.pClass, eType.toString());
		}

		ctx.pop();

		return n;
	}

	private String getUri(Object uri, Object uri2, RdfSerializerContext ctx) {
		String s = null;
		if (uri != null)
			s = uri.toString();
		if ((s == null || s.isEmpty()) && uri2 != null)
			s = uri2.toString();
		if (s == null)
			return null;
		if (s.indexOf(':') == -1) {
			String authority = ctx.getUriAuthority();
			String context = ctx.getUriContext();
			StringBuilder sb = new StringBuilder(s.length() + authority.length() + context.length());
			sb.append(authority);
			if ((! s.startsWith("/")) && ! context.isEmpty())
				sb.append(context).append("/");
			sb.append(s);
			s = sb.toString();
		}
		return s;
	}

	private void serializeMap(Map m, Resource r, ClassType<?> type, RdfSerializerContext ctx) throws SerializeException {

		ClassType<?> keyType = type.getKeyType(), valueType = type.getValueType();

		ArrayList<Map.Entry<Object,Object>> l = new ArrayList<Map.Entry<Object,Object>>(m.entrySet());
		Collections.reverse(l);
		for (Map.Entry<Object,Object> me : l) {
			Object value = me.getValue();

			Object key = generalize(me.getKey(), keyType);

			Namespace ns = ctx.junoBpNs;
			Model model = ctx.model;
			Property p = model.createProperty(ns.getUri(), encodeElementName(key));
			RDFNode n = serializeAnything(value, false, ns, valueType, ctx, false);
			if (n != null)
				r.addProperty(p, n);
		}
	}

	private void serializeBeanMap(BeanMap m, Resource r, RdfSerializerContext ctx) throws SerializeException {
		ArrayList<BeanMapEntry> l = new ArrayList<BeanMapEntry>(m.entrySet());
		Collections.reverse(l);
		for (BeanMapEntry bme : l) {
			BeanPropertyMeta pMeta = bme.getMeta();

			if (canIgnoreProperty(ctx, pMeta) || pMeta.isBeanUri())
				continue;

			String key = bme.getKey();
			Object value = null;
			try {
				value = bme.getFilteredValue();
			} catch (Throwable x) {
				ctx.addWarning("Could not call getValue() on property '%s', %s", key, x.getLocalizedMessage());
			}

			if (canIgnoreValue(ctx, pMeta.getClassType(), value))
				continue;

			Namespace ns = bme.getMeta().getNamespace();
			if (ns == null)
				ns = ctx.junoBpNs;
			else
				ctx.addModelPrefix(ns);

			Property p = ctx.model.createProperty(ns.getUri(), encodeElementName(key));
			RDFNode n = serializeAnything(value, pMeta.isUri(), ns, pMeta.getClassType(), ctx, true);
			if (n != null)
				r.addProperty(p, n);
		}
	}


	private Seq serializeCollection(Collection c, ClassType<?> type, Seq list, RdfSerializerContext ctx) throws SerializeException {

		ClassType<?> elementType = type.getElementType();

		int i = 1;
		for (Object e : c) {
			RDFNode n = serializeAnything(e, false, null, elementType, ctx, false);
			list = list.add(i++, n);
		}
		return list;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer, CoreApi
	public RdfSerializer setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (rsp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfSerializer addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public <T> RdfSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // ISerializer, Lockable
	public RdfSerializer lock() {
		super.lock();
		return this;
	}

	@Override // ISerializer, Lockable
	public RdfSerializer clone() {
		try {
			RdfSerializer c = (RdfSerializer)super.clone();
			c.rsp = rsp.clone();
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
