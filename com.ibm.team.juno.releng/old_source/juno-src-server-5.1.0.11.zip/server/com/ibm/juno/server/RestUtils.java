/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014, 2015. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.server;

import java.io.*;
import java.net.*;
import java.util.*;

import com.ibm.juno.core.utils.*;

/**
 * Various reusable utility methods.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public final class RestUtils {

	/**
	 * Returns readable text for an HTTP response code.
	 * @param rc The HTTP response code.
	 * @return Readable text for an HTTP response code, or <jk>null</jk> if it's an invalid code.
	 */
	public static String getHttpResponseText(int rc) {
		return httpMsgs.get(rc);
	}

	@SuppressWarnings("serial")
	private static Map<Integer,String> httpMsgs = new HashMap<Integer,String>() {{
		put(200, "OK");
		put(201, "Created");
		put(202, "Accepted");
		put(203, "Non-Authoritative Information");
		put(204, "No Content");
		put(205, "Reset Content");
		put(206, "Partial Content");
		put(300, "Multiple Choices");
		put(301, "Moved Permanently");
		put(302, "Temporary Redirect");
		put(303, "See Other");
		put(304, "Not Modified");
		put(305, "Use Proxy");
		put(307, "Temporary Redirect");
		put(400, "Bad Request");
		put(401, "Unauthorized");
		put(402, "Payment Required");
		put(403, "Forbidden");
		put(404, "Not Found");
		put(405, "Method Not Allowed");
		put(406, "Not Acceptable");
		put(407, "Proxy Authentication Required");
		put(408, "Request Time-Out");
		put(409, "Conflict");
		put(410, "Gone");
		put(411, "Length Required");
		put(412, "Precondition Failed");
		put(413, "Request Entity Too Large");
		put(414, "Request-URI Too Large");
		put(415, "Unsupported Media Type");
		put(500, "Internal Server Error");
		put(501, "Not Implemented");
		put(502, "Bad Gateway");
		put(503, "Service Unavailable");
		put(504, "Gateway Timeout");
		put(505, "HTTP Version Not Supported");
	}};

	/**
	 * Trims <js>'/'</js> characters from the end of the specified string.
	 * @return A new trimmed string, or the same string if no trimming was necessary.
	 */
	public static String trimTrailingSlashes(String s) {
		if (s == null)
			return null;
		if (s.endsWith("/")) {
			int l = s.length();
			while (l > 1 && s.charAt(l-1) == '/') {
				s = s.substring(0, l-1);
				l--;
			}
		}
		return s;
	}

	/**
	 * Trims <js>'/'</js> characters from the end of the specified string buffer contents.
	 * @return The same string buffer resized to eliminate any trailing slashes.
	 */
	public static StringBuffer trimTrailingSlashes(StringBuffer s) {
		if (s == null)
			return null;
		int l = s.length();
		if (s.charAt(l-1) == '/') {
			while (l > 1 && s.charAt(l-1) == '/') {
				s.setLength(l-1);
				l--;
			}
		}
		return s;
	}

	/**
	 * Trims <js>'/'</js> characters from both the start and end of the specified string.
	 * @return A new trimmed string, or the same string if no trimming was necessary.
	 */
	public static String trimSlashes(String s) {
		if (s == null)
			return null;
		s = trimTrailingSlashes(s);
		while (s.length() > 0 && s.charAt(0) == '/')
			s = s.substring(1);
		return s;
	}

   /**
    * Decodes a <code>application/x-www-form-urlencoded</code> string using <code>UTF-8</code> encoding scheme.
    * <p>
    * Returns <jk>null</jk> if input is <jk>null</jk>.
    */
	public static String decode(String s) {
		if (s == null)
			return s;
		boolean needsDecode = false;
		for (int i = 0; i < s.length() && ! needsDecode; i++) {
			char c = s.charAt(i);
			if (c == '+' || c == '%')
				needsDecode = true;
		}
		try {
			if (needsDecode)
				return URLDecoder.decode(s, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e); // Won't happen.
		}
		return s;
	}

	// Characters that do not need to be URL-encoded
	private static final CharSet unencodedChars = new CharSet("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.!~*'()\\");

   /**
    * Encodes a <code>application/x-www-form-urlencoded</code> string using <code>UTF-8</code> encoding scheme.
    * <p>
    * Returns <jk>null</jk> if input is <jk>null</jk>.
    */
	public static String encode(String s) {
		if (s == null)
			return null;
		boolean needsEncode = false;
		for (int i = 0; i < s.length() && ! needsEncode; i++)
			needsEncode |= unencodedChars.contains(s.charAt(i));
		try {
			if (needsEncode)
				return URLEncoder.encode(s, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e); // Won't happen.
		}
		return s;
	}

}
