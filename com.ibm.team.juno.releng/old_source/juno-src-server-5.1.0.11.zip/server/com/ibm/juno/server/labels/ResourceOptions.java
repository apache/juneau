/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014, 2015. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.server.labels;

import static javax.servlet.http.HttpServletResponse.*;

import java.util.*;

import com.ibm.juno.server.*;
import com.ibm.juno.server.annotation.*;

/**
 * Default POJO bean used for generating OPTIONS page results.
 * <p>
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ResourceOptions {
	private String description;
	private String className;
	private Collection<MethodDescription> methods;
	private ChildResourceDescriptions children;
	private Map<String,Object> properties;
	private Collection<String> accept, contentType;
	private Collection<String> guards;
	private Collection<String> filters;
	private Collection<String> converters;

	/**
	 * Constructor.
	 * @param servlet The servlet that this bean describes.
	 * @param req The HTTP servlet request.
	 */
	public ResourceOptions(RestServlet servlet, RestRequest req) {
		try {
			setClassName(servlet.getClass().getName());
			setDescription(servlet.getResourceDescription(req.getLocale()));
			setMethods(servlet.getMethodDescriptions(req));
			setProperties(servlet.getProperties());
			setAccept(servlet.getSupportedAcceptTypes());
			setContentType(servlet.getSupportedContentTypes());
			setChildren(new ChildResourceDescriptions(servlet, req));
			setGuards(servlet.getGuards());
			setFilters(servlet.getFilters());
			setConverters(servlet.getConverters());
		} catch (RestServletException e) {
			throw new RestException(SC_INTERNAL_SERVER_ERROR, e);
		}
	}

	/**
	 * Bean constructor.
	 */
	public ResourceOptions() {}

	/**
	 * Returns the description of the REST resource.
	 * @return The current bean property value.
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description of the REST resource.
	 * @param description The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setDescription(String description) {
		this.description = description;
		return this;
	}

	/**
	 * Returns the class name of the REST resource.
	 * @return The current bean property value.
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * Sets the class name of the REST resource.
	 * @param className The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setClassName(String className) {
		this.className = className;
		return this;
	}

	/**
	 * Returns the methods provided on this REST resource.
	 * @return The current bean property value.
	 */
	public Collection<MethodDescription> getMethods() {
		return methods;
	}

	/**
	 * Sets the methods provided on this REST resource.
	 * @param methods The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setMethods(Collection<MethodDescription> methods) {
		this.methods = methods;
		return this;
	}

	/**
	 * Returns the list of properties currently set on a servlet.
	 * @return The current bean property value.
	 */
	public Map<String,Object> getProperties() {
		return properties;
	}

	/**
	 * Sets the properties field on this label to a new value.
	 * This identifies properties defined on a servlet via the {@link RestResource#properties()} annotation.
	 * @param properties The new list if properties.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setProperties(Map<String,Object> properties) {
		this.properties = properties;
		return this;
	}



	/**
	 * Returns the list of allowable <code>Accept</code> header values on requests.
	 * @return The current bean property value.
	 */
	public Collection<String> getAccept() {
		return accept;
	}

	/**
	 * Sets the list of allowable <code>Accept</code> header values on requests.
	 * @param accept The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setAccept(Collection<String> accept) {
		this.accept = accept;
		return this;
	}

	/**
	 * Returns the list of allowable <code>Content-Type</code> header values on requests.
	 * @return The current bean property value.
	 */
	public Collection<String> getContentType() {
		return contentType;
	}

	/**
	 * Sets the list of allowable <code>Content-Type</code> header values on requests.
	 * @param contentType The new bean property value.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setContentType(Collection<String> contentType) {
		this.contentType = contentType;
		return this;
	}

	/**
	 * Returns the description of child resources with this resource (typically through {@link RestResource#children()} annotation).
	 * @return The description of child resources of this resource.
	 */
	public ChildResourceDescriptions getChildren() {
		return children;
	}

	/**
	 * Sets the child resource descriptions associated with this resource.
	 * @param children The child resource descriptions.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setChildren(ChildResourceDescriptions children) {
		this.children = children;
		return this;
	}


	/**
	 * Returns the list of class-wide guards associated with this resource (typically through {@link RestResource#guards()} annotation).
	 * @return The simple class names of the guards.
	 */
	public Collection<String> getGuards() {
		return guards;
	}

	/**
	 * Sets the simple class names of the guards associated with this resource.
	 * @param guards The simple class names of the guards.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setGuards(Collection<String> guards) {
		this.guards = guards;
		return this;
	}

	/**
	 * Shortcut for calling {@link #setGuards(Collection)} from {@link RestGuard} instances.
	 * @param guards Instances of guards associated with this resource.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setGuards(RestGuard[] guards) {
		Collection<String> l = new ArrayList<String>(guards.length);
		for (RestGuard g : guards)
			l.add(g.getClass().getSimpleName());
		return setGuards(l);
	}

	/**
	 * Returns the list of class-wide filters associated with this resource (typically through {@link RestResource#filters()} annotation).
	 * @return The simple class names of the filters.
	 */
	public Collection<String> getFilters() {
		return filters;
	}

	/**
	 * Sets the simple class names of the filters associated with this resource.
	 * @param filters The simple class names of the filters.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setFilters(Collection<String> filters) {
		this.filters = filters;
		return this;
	}

	/**
	 * Shortcut for calling {@link #setFilters(Collection)} from {@link Class} instances.
	 * @param filters Filter classes associated with this resource.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setFilters(Class<?>[] filters) {
		Collection<String> l = new ArrayList<String>(filters.length);
		for (Class<?> c : filters)
			l.add(c.getSimpleName());
		return setFilters(l);
	}

	/**
	 * Returns the list of class-wide converters associated with this resource (typically through {@link RestResource#converters()} annotation).
	 * @return The simple class names of the converters.
	 */
	public Collection<String> getConverters() {
		return converters;
	}

	/**
	 * Sets the simple class names of the converters associated with this resource.
	 * @param converters The simple class names of the converters.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setConverters(Collection<String> converters) {
		this.converters = converters;
		return this;
	}

	/**
	 * Shortcut for calling {@link #setConverters(Collection)} from {@link RestConverter} instances.
	 * @param converters Converter classes associated with this resource.
	 * @return This object (for method chaining).
	 */
	public ResourceOptions setConverters(RestConverter[] converters) {
		Collection<String> l = new ArrayList<String>(converters.length);
		for (RestConverter c : converters)
			l.add(c.getClass().getSimpleName());
		return setConverters(l);
	}
}
