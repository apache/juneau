/* *****************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  Use,
 * duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *******************************************************************************/
// XML namespaces used in this package
@XmlSchema(prefix="cognos", namespace="http://developer.cognos.com/schemas/xmldata/1/")
package com.ibm.juno.core.dto.cognos;
import com.ibm.juno.core.xml.annotation.*;

