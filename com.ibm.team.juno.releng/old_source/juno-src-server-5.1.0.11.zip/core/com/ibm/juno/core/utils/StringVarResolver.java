/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.utils;

import java.util.*;

/**
 * Utility class for resolving $X{arg} variables in strings.
 * Allows for recursively nested variables.
 */
public class StringVarResolver {

	// Map of Vars added through addVar() method.
	private Map<String,StringVar> varMap = new TreeMap<String,StringVar>();

	/**
	 * Construct an empty var resolver.
	 */
	public StringVarResolver() {}

	/**
	 * Register a new variable with this resolver.
	 * @param varName - The variable name (e.g. <js>"X"</js> resolves <js>"$X{...}"</js> variables).
	 * @param v - The variable resolver.
	 * @return This object (for method chaining).
	 */
	public StringVarResolver addVar(String varName, StringVar v) {
		varMap.put(varName, v);
		return this;
	}

	/**
	 * @param s - The string to resolve variables in.
	 * @return The new string with all variables resolved, or the same string if no variables were found.
	 */
	public String resolve(String s) {

		if (s == null || s.indexOf('$') == -1)
			return s;

		//--------------------------------------------------------------------------------
		// Look for all '$varType{' strings and make the appropriate replacements.
		// $X{xxx$Y{yyy}xxx}
		// states:
		// 1 - not in variable.
		// 2 - looking for {
		// 3 - looking for }
		//--------------------------------------------------------------------------------
		int state = 1;
		StringBuilder sb = null;     // StringBuilder is lazy initialized and not used if the entire string is of the format "$X{xxx}"
		boolean hasInternalVar = false;
		String varType = null;
		String varVal = null;
		int x = 0, x2 = 0;
		int depth = 0;
		int length = s.length();
		for (int i = 0; i < length; i++) {
			char c = s.charAt(i);
			if (state == 1) {
				if (c == '$') {
					if (i > 0) {
						if (sb == null)
							sb = new StringBuilder(length);
						sb.append(s, x, i);
					}
					x = i;
					x2 = i;
					state = 2;
				}
			} else if (state == 2) {
				if (c == '{') {
					varType = s.substring(x+1, i);
					x = i;
					state = 3;
				} else if (c < 'A' || c > 'z' || (c > 'Z' && c < 'a')) {  // False trigger "$X "
					if (sb == null)
						sb = new StringBuilder(length);
					sb.append(s, x, i+1);
					x = i + 1;
					state = 1;
				}
			} else {
				if (c == '{') {
					depth++;
					hasInternalVar = true;
				} else if (c == '}') {
					if (depth > 0) {
						depth--;
					} else {
						varVal = s.substring(x+1, i);
						varVal = (hasInternalVar ? resolve(varVal) : varVal);
						StringVar r = varMap.get(varType);
						if (r == null) {
							if (sb == null && length == i+1)
								return s;
							if (sb == null)
								sb = new StringBuilder(length);
							sb.append(s, x2, i+1);
							x = i+1;
						} else {
							String replacement = r.resolve(varVal);
							if (sb == null && length == i+1)
								return replacement;
							if (sb == null)
								sb = new StringBuilder(length);
							sb.append(replacement);
							x = i+1;
						}
						state = 1;
					}
				}
			}
		}
		if (sb == null)
			sb = new StringBuilder(length);
		sb.append(s, x, length);

		return sb.toString();
	}
}

