/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.utils;

import java.io.*;


/**
 * Writer that can send output to multiple writers.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class TeeWriter extends Writer {
	private Writer[] writers;

	public TeeWriter(Writer...writers) {
		this.writers = writers;
	}

	@Override
	public void write(char[] cbuf, int off, int len) throws IOException {
		for (Writer w : writers)
			w.write(cbuf, off, len);
	}

	@Override
	public void flush() throws IOException {
		for (Writer w : writers)
			w.flush();
	}

	@Override
	public void close() throws IOException {
		for (Writer w : writers)
			w.close();
	}
}
