package com.ibm.juno.server;

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.server.annotation.*;

/**
 * Represents a group of {@link RestSerializer} objects.
 * <p>
 * 	Methods defined on this interface allow all registered serializers to be organized and modified in sync.
 * <p>
 * 	The {@link RestServlet} class uses serializer groups to organize serializers.
 * <p>
 		See {@link RestServlet#getSerializerGroup()} for more information.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Construct a new rest serializer group</jc>
 * 	RestSerializerGroup g = <jk>new</jk> RestSerializerGroup();
 *
 * 	<jc>// Register some serializer with the accept types they're supposed to handle requests for</jc>
 * 	g.append(JsonRestSerializer.<jk>class</jk>, XmlRestSerializer.<jk>class</jk>)
 *
 * 	<jc>// Change settings on the serializers simultaneously</jc>
 * 	g.setProperty(<jsf>REQUIRE_SERIALIZABLE</jsf>, <jk>true</jk>)
 * 		.addFilters(CalendarFilter.<jsf>DEFAULT_ISO8601DT</jsf>);
 *
 * 	<jc>// Get one of the serializers</jc>
 * 	RestSerializer s = g.getRestSerializer(<js>"text/xml"</js>);
 * </p>
 *
 * <p>
 * 	To register new rest serializers with a resource, implementers will typically override the {@link RestServlet#getSerializerGroup()}
 * 		method and add to the group already created by the super method, or will use one the {@link RestResource#serializers()} or
 * 		{@link RestMethod#serializers()} annotations.
 *
 * <p class='bcode'>
 * 	<jk>public</jk> MyResource <jk>extends</jk> RestResourceDefault {
 *
 * 		<jc>// Override default serializer group</jc>
 * 		<ja>@Override</ja>
 * 		<jk>public</jk> RestSerializerGroup getSerializerGroup() {
 *
 * 			<jc>// Get the parent serializer group</jc>
 * 			RestSerializerGroup g = <jk>super</jk>.getSerializerGroup();
 *
 * 			<jc>// Add a new serializer to it</jc>
 * 			RestSerializer fooSerializer = <jk>new</jk> FooRestSerializer();
 * 			g.append(fooSerializer);
 *
 * 			<jc>// Return the updated serializer</jc>
 * 			<jk>return</jk> g;
 * 		}
 * 	}
 * </p>
 * <p>
 * 	Properties can be conveniently set on a resource's serializer group through the {@link RestResource#properties} annotation.
 * <p class='bcode'>
 * 	<ja>@RestResource</ja>(
 * 		properties={
 * 			<ja>@Property</ja>(name=<jsf>TRIM_NULLS</jsf>, value=<js>"true"</js>),
 * 			<ja>@Property</ja>(name=<jsf>TRIM_EMPTY_LISTS</jsf>, value=<js>"true"</js>),
 * 			<ja>@Property</ja>(name=<jsf>DEFAULT_NAMESPACES</jsf>,
 * 				value=<js>"{jp06:'http://jazz.net/xmlns/prod/jazz/process/0.6/',jp:'http://jazz.net/xmlns/prod/jazz/process/1.0/'}"</js>),
 * 		}
 * 	)
 * 	<jk>public</jk> MyRestResource <jk>extends</jk> RestServletDefault {
 * 		...
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestSerializerGroup extends SerializerGroup {

	Map<String,RestSerializer> restSerializers = new LinkedHashMap<String,RestSerializer>();
	private RestSerializerGroup parentGroup;

	private String label;

	/**
	 * Constructor.  Default bean context is used.
	 * @param label The string that gets returned when you call {@code toString()} on this object.
	 */
	public RestSerializerGroup(String label) {
		super();
		this.label = label;
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The group to clone.
	 */
	protected RestSerializerGroup(RestSerializerGroup copyFrom) {
		super(copyFrom);
		this.restSerializers = new LinkedHashMap<String,RestSerializer>(copyFrom.restSerializers);

		// Since the serializers are cloned above, we need to 'relink' them.
		for (Map.Entry<String,RestSerializer> e : restSerializers.entrySet()) {
			RestSerializer r = e.getValue();
			if (r instanceof RestSerializerSerializer) {
				RestSerializerSerializer r2 = (RestSerializerSerializer)r;
				r2.setSerializer(getSerializer(r.getMediaTypes()[0]));
			}
		}

		this.label = copyFrom.label;
	}

	/**
	 * Registers the specified REST serializers with this serializer group.
	 *
	 * @param serializers The serializers to append to this group.
	 * @return This object (for method chaining).
	 */
	public RestSerializerGroup append(RestSerializer...serializers) {
		for (RestSerializer r : serializers) {

			for (String s : r.getMediaTypes()) {
				restSerializers.put(s, r);
			}
			if (r instanceof RestSerializerSerializer) {
				RestSerializerSerializer r2 = (RestSerializerSerializer)r;
				super.add(r2.getSerializer(), r.getMediaTypes());
			}
		}
		return this;
	}

	/**
	 * Same as {@link #append(RestSerializer...)}, except specify classes instead of class instances
	 * 	 of {@link RestSerializer}.
	 * <p>
	 * Note that this can only be used on {@link RestSerializer RestSerializers} with no-arg constructors.
	 *
	 * @param serializers The serializers to append to this group.
	 * @return This object (for method chaining).
	 * @throws Exception Thrown if {@link RestSerializer} could not be constructed.
	 */
	public RestSerializerGroup append(Class<? extends RestSerializer>...serializers) throws Exception {
		for (Class<? extends RestSerializer> c : serializers)
			append(c.newInstance());
		return this;
	}

	RestSerializerGroup setParent(RestSerializerGroup parentGroup) {
		this.parentGroup = parentGroup;
		return this;
	}

	/**
	 * Returns the serializer registered to handle the specified single-value request <code>Accept</code> value.
	 * <p>
	 * <code>accept</code> should be a single content type without any q-values, such as <js>"text/json"</js>.
	 * It is assumed that content negotation has already occurred by the time this method has been called.
	 *
	 * @param accept The accept content type string (e.g. <js>"text/json"</js>
	 * @return The serializer that handles the specified accept content type, or <jk>null</jk> if
	 * 		no serializer is registered to handle it.
	 */
	public RestSerializer getRestSerializer(String accept) {
		RestSerializer s = restSerializers.get(accept);
		if (s == null && parentGroup != null)
			s = parentGroup.getRestSerializer(accept);
		return s;
	}

	String findMatch(MediaRange...accept) {
		if (accept.length == 0)
			accept = MediaRange.parse("*/*");

		for (MediaRange a : accept) {
			for (RestSerializer r : restSerializers.values()) {
				for (MediaRange a2 : r.getMediaTypeRanges())
					if (a.matches(a2))
						return a2.getType();
			}
		}

		if (parentGroup != null)
			return parentGroup.findMatch(accept);

		return null;
	}

	@Override
	public String toString() {
		return label;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods on CoreAPI
	//--------------------------------------------------------------------------------

	@Override
	public RestSerializerGroup setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	@Override
	public RestSerializerGroup setProperties(JsonMap properties) throws LockedException {
		super.setProperties(properties);
		return this;
	}

	@Override
	public RestSerializerGroup setBeanContext(BeanContext beanContext) throws LockedException {
		super.setBeanContext(beanContext);
		return this;
	}

	@Override
	public RestSerializerGroup addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override
	public RestSerializerGroup addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override
	public RestSerializerGroup addFilters(Filter...s) throws LockedException {
		super.addFilters(s);
		return this;
	}

	@Override
	public RestSerializerGroup addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override
	public <T> RestSerializerGroup addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public RestSerializerGroup lock() {
		super.lock();
		return this;
	}

	@Override
	public RestSerializerGroup clone() {
		return new RestSerializerGroup(this);
	}
}
