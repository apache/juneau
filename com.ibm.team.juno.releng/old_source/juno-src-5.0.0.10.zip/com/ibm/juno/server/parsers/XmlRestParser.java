package com.ibm.juno.server.parsers;

import com.ibm.juno.core.*;
import com.ibm.juno.core.xml.*;
import com.ibm.juno.server.*;

/**
 * Parsers HTTP request bodies with <code>Content-Type</code> of <js>"text/xml"</js> into POJOs.
 * <p>
 * For more information, refer to {@link RestParser}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlRestParser extends RestParserParser {

	/**
	 * Constructor using {@link XmlParser#DEFAULT} as the POJO parser.
	 */
	public XmlRestParser() {
		super(XmlParser.DEFAULT.clone());
	}

	/**
	 * Construct using the specified {@link XmlParser} as the POJO parser.
	 *
	 * @param parser The parser.
	 */
	public XmlRestParser(Parser parser) {
		super(parser);
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"text/xml"};
	}
}
