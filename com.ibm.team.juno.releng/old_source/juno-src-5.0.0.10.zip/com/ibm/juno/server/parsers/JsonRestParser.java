package com.ibm.juno.server.parsers;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.server.*;

/**
 * Parsers HTTP request bodies with <code>Content-Type</code> of <js>"application/json"</js> or <js>"text/json"</js> into POJOs.
 * <p>
 * For more information, refer to {@link RestParser}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonRestParser extends RestParserParser {

	/**
	 * Constructor using {@link JsonParser#DEFAULT} as the POJO parser.
	 */
	public JsonRestParser() {
		super(JsonParser.DEFAULT.clone());
	}

	/**
	 * Construct using the specified {@link JsonParser} as the POJO parser.
	 *
	 * @param parser The parser.
	 */
	public JsonRestParser(Parser parser) {
		super(parser);
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"application/json", "text/json"};
	}
}
