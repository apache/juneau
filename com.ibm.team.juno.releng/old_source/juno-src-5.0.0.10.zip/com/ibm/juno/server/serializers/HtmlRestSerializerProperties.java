package com.ibm.juno.server.serializers;

import com.ibm.juno.server.*;

/**
 * Properties associated with the {@link HtmlRestSerializer} class.
 * <p>
 * <h6 class='topic'>Example</h6>
 * <p class='bcode'>
 * 	<ja>@RestMethod</ja>(name=<js>"GET"</js>, pattern=<js>"/people/{id}/*"</js>)
 * 	<jk>public</jk> Person getPerson(RestRequest req, RestResponse res, <ja>@Attr</ja> <jk>int</jk> id) <jk>throws</jk> Exception {
 *
 * 		<jc>// Add a title to the page</jc>
 * 		res.addProperty(<jsf>TITLE</jsf>, <js>"Person information"</js>);
 *
 * 		<jk>return</jk> findPerson(id);
 * </p>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlRestSerializerProperties {

	/**
	 * Optional page title applied to the top of a page.
	 */
	public static final String TITLE = "HtmlRestSerializer.title";

	/**
	 * Optional page description applied right below the title of a page.
	 */
	public static final String DESCRIPTION = "HtmlRestSerializer.description";
}
