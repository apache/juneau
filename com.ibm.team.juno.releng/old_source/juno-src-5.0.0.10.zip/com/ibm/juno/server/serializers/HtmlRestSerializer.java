package com.ibm.juno.server.serializers;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.server.serializers.HtmlRestSerializerProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.html.*;
import com.ibm.juno.server.*;
import com.ibm.juno.server.labels.*;

/**
 * Serializes POJOs to HTTP responses as HTML.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"text/html"</js></ul></td>
 * 		<td><ul><li><js>"text/html"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlRestSerializer extends HtmlStrippedRestSerializer {

	/**
	 * Constructor using {@link HtmlSerializer#DEFAULT} as the POJO serializer.
	 */
	public HtmlRestSerializer() {
		super(HtmlSerializer.DEFAULT.clone());
	}

	/**
	 * Construct using the specified {@link HtmlSerializer} as the POJO serializer.
	 *
	 * @param serializer The serializer.
	 */
	public HtmlRestSerializer(Serializer serializer) {
		super(serializer);
	}

	@Override
	public void serialize(RestRequest req, Object output, Writer out, JsonMap properties, String matchingAccept) throws IOException, SerializeException {

		HtmlSerializerWriter w = new HtmlSerializerWriter(out, serializer);

		// Render the header.
		w.sTag("html").nl();
		w.sTag("head").nl();
		int refresh = req.getIntHeader("Refresh");
		if (refresh > 0)
			w.oTag(1, "meta")
				.attr("http-equiv", "Refresh")
				.attr("content", refresh)
				.appendln(">");
		w.oTag(1, "style")
			.attr("type", "text/css")
			.appendln(">")
				.append(2, "@import ").q().append(getStyleSheetUrl(req)).q().appendln(";")
			.eTag(1, "style").nl();
		w.eTag("head").nl();
		w.sTag("body").nl();
		// Write the title of the page.
		String title = properties.getString(TITLE);
		String description = properties.getString(DESCRIPTION);
		if (title != null)
			w.sTag(1, "h3").encodeText(title).eTag("h3");
		if (description != null)
			w.sTag(1, "h5").encodeText(description).eTag("h5");

		// Write the action links that render above the results.
		List<Link> actions = new LinkedList<Link>();
		String requestURI = req.getRequestURI(true);

		// If this is an OPTIONS request, provide a 'back' link to return to the GET request page.
		if (req.getMethod().equalsIgnoreCase("OPTIONS")) {
			actions.add(new Link("back", requestURI));
		} else {

			// Provide an 'options' link if a toOptions() method is present.
			if (req.getServlet().hasOptionsPage())
				actions.add(new Link("options", requestURI + "?method=OPTIONS"));
		}

		if (actions.size() > 0) {
			w.sTag(1, "p").nl();
			for (Iterator<Link> i = actions.iterator(); i.hasNext();) {
				Link h = i.next();
				w.oTag(2, "a").attr("href", h.getHref(), true).append('>').append(h.getName()).eTag("a").nl();
				if (i.hasNext())
					w.append(3, " - ").nl();
			}
			w.eTag(1, "p").nl();
		}

		doSerialize(w, output, properties);

		w.eTag("body").nl().eTag("html").nl();
	}

	/**
	 * Returns the URL to the cascade stylesheet to use when rendering HTML.
	 * <p>
	 * 	By default, points to the stylesheet defined in the {@code com.ibm.juno.server.htdocs} package.
	 * <p>
	 * 	Subclasses can optionally override this method to point to different stylesheets.
	 *
	 * @param req The HTTP request.
	 * @return The URL pointing to the stylesheet to use for HTML output.
	 */
	@Override
	protected String getStyleSheetUrl(RestRequest req) {
		return req.getContextPath() + req.getServletPath() + "/htdocs/juno.css";
	}

	@Override
	public String getResponseContentType() {
		return "text/html";
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"text/html"};
	}
}
