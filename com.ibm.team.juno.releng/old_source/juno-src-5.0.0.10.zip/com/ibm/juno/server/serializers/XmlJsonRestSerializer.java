package com.ibm.juno.server.serializers;

import com.ibm.juno.core.xml.*;
import com.ibm.juno.server.*;

/**
 * Serializes POJOs to HTTP responses as JSON-equivalent XML.
 * <p>
 * Essentially the same as {@link XmlRestSerializer}, except add attribute tags to the
 * 	output to identify data types.
 * <p>
 * Output produced by this serializer can be losslessly converted back into a JSON model.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"text/xml+json"</js></ul></td>
 * 		<td><ul><li><js>"text/xml"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlJsonRestSerializer extends XmlRestSerializer {

	/**
	 * Constructor using {@link XmlSerializer#DEFAULT_XMLJSON} as the POJO serializer.
	 */
	public XmlJsonRestSerializer() {
		super(XmlSerializer.DEFAULT_XMLJSON_CONDENSED.clone());
	}

	@Override
	public String getResponseContentType() {
		return "text/xml";
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"text/xml+json"};
	}
}
