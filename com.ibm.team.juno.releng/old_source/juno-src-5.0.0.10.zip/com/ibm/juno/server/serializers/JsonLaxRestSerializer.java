package com.ibm.juno.server.serializers;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import com.ibm.juno.core.json.*;
import com.ibm.juno.server.*;

/**
 * Serializes POJOs to HTTP responses as LAX JSON.
 * <p>
 * Essentially the same output as {@link JsonRestSerializer}, but only quotes attributes
 * 	when absolutely necessary.
 * <p>
 * In general, this produces output that's still parsable by all Javascript engines, and is generally more human-readable.
 * However, it doesn't strictly follow the JSON specification.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"application/json+lax"</js><li><js>"text/json+lax"</js></ul></td>
 * 		<td><ul><li><js>"application/json"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonLaxRestSerializer extends JsonRestSerializer {

	/**
	 * Constructor using {@link JsonSerializer#DEFAULT_CONDENSED} as the POJO serializer.
	 */
	public JsonLaxRestSerializer() {
		super(JsonSerializer.DEFAULT_CONDENSED.clone());
	}

	@Override
	public String getResponseContentType() {
		return "application/json";
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"application/json+lax","text/json+lax"};
	}
}
