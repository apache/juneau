package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

/**
 * Exception that indicates invalid syntax encountered during parsing.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParseException extends Exception {

	/**
	 * @param e The cause of the parse exception.
	 */
	public ParseException(Exception e) {
		super(e.getLocalizedMessage(), e);
	}

	/**
	 * @param e The cause of the parse exception.
	 * @param errorMsg The error message.
	 * @param args Optional printf arguments to replace in the error message.
	 */
	public ParseException(Exception e, String errorMsg, Object...args) {
		super(format(errorMsg, args), e);
	}

	/**
	 * @param errorMsg The error message.
	 * @param args Optional printf arguments to replace in the error message.
	 */
	public ParseException(String errorMsg, Object...args) {
		super(format(errorMsg, args));
	}

	/**
	 * @param lineNumber The line number where the parse error was detected.
	 * @param colNumber The column number where the parse error was detected.
	 * @param errorMsg The error message.
	 * @param args Optional printf arguments to replace in the error message.
	 */
	public ParseException(int lineNumber, int colNumber, String errorMsg, Object... args) {
		super("Syntax error at line=[" + lineNumber + "], column=["+colNumber+"], [" + format(errorMsg, args) + "], ");
	}

	/**
	 * Same as String.format(s, args), except first checks to see if there are any args.
	 */
	private static String format(String s, Object[] args) {
		return args.length == 0 ? s : String.format(s, args);
	}
}
