package com.ibm.juno.core.rdfxml;

import com.ibm.juno.core.*;
import com.ibm.juno.core.xml.*;


/**
 * Configurable properties on the {@link RdfXmlSerializer} class.
 * <p>
 * 	Use the {@link RdfXmlSerializer#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link RdfXmlSerializer}.
 * <ul>
 * 	<li>{@link XmlSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfXmlSerializerProperties {

	/**
	 * RDF namespace ({@link Namespace}, default=<code>{rdf:<js>'http://www.w3.org/1999/02/22-rdf-syntax-ns#'</js>}</code>).
	 * <p>
	 * Specifies the namespace for the <code>RDF</code> namespace.
	 */
	public static final String RDF_NAMESPACE = "RdfXmlSerializer.rdfNamespace";

	/** RDF/XML namespace */
	private Namespace rdfNamespace = NamespaceFactory.get("rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");

	/** Default constructor.  All default values. */
	public RdfXmlSerializerProperties() {}

	/**
	 * Copy constructor.
	 * @param copyFrom Properties to copy from.
	 */
	public RdfXmlSerializerProperties(RdfXmlSerializerProperties copyFrom) {
		this.rdfNamespace = copyFrom.rdfNamespace;
	}

	/**
	 * Returns the current {@link #RDF_NAMESPACE} value.
	 * @return The current {@link #RDF_NAMESPACE} value.
	 */
	public final Namespace getRdfNamespace() {
		return rdfNamespace;
	}

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		if (property.equals(RDF_NAMESPACE)) {
			if (value instanceof Namespace)
				rdfNamespace = (Namespace)value;
			else
				rdfNamespace = NamespaceFactory.fromString(value.toString()).get(0);
			return true;
		}
		return false;
	}
}
