package com.ibm.juno.core.rdfxml;

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.xml.*;

/**
 * Context object that lives for the duration of a single serialization of {@link RdfXmlSerializer}.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfXmlSerializerContext extends XmlSerializerContext {

	private RdfXmlSerializerProperties rxsp;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param xsp Default XML serializer properties.
	 * @param rxsp Default RDF/XML serializer properties.
	 * @param op Override properties.
	 */
	protected RdfXmlSerializerContext(BeanContext beanContext, SerializerProperties sp, XmlSerializerProperties xsp, RdfXmlSerializerProperties rxsp, JsonMap[] op) {
		super(beanContext, sp, xsp, op);
		this.rxsp = new RdfXmlSerializerProperties(rxsp);
		for (JsonMap m : op)
			for (Map.Entry<String,Object> e : m.entrySet())
				this.rxsp.setProperty(e.getKey(), e.getValue());
	}

	/**
	 * Returns the {@link RdfXmlSerializerProperties#RDF_NAMESPACE} setting value in this context.
	 * @return The {@link RdfXmlSerializerProperties#RDF_NAMESPACE} setting value in this context.
	 */
	public final Namespace getRdfNamespace() {
		return rxsp.getRdfNamespace();
	}
}
