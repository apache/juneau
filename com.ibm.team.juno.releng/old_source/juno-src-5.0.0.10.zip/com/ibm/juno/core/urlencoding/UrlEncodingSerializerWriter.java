package com.ibm.juno.core.urlencoding;

import java.io.*;
import java.net.*;

import com.ibm.juno.core.*;

/**
 * Specialized writer for serializing URL-Encoded strings.
 * <p>
 * 	<b>Note:  This class is not intended for external use.</b>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingSerializerWriter extends SerializerWriter {

	UrlEncodingSerializerWriter(Writer out, boolean useIndentation, char quoteChar) {
		super(out, useIndentation, false, quoteChar);
	}

	/**
	 * Serializes and encodes a parameter value.
	 *
	 * @param o The object to serialize and encode.
	 * @return This object (for method chaining).
	 * @throws IOException If a problem occurred trying to write to the writer.
	 */
	public UrlEncodingSerializerWriter encode(Object o) throws IOException {
		encode(out, o);
		return this;
	}

	/**
	 * Encodes a parameter and sends the results to the specified writer.
	 *
	 * @param out The output writer.
	 * @param o The object to serialize and encode.
	 * @throws IOException If a problem occurred trying to write to the writer.
	 */
	public static void encode(Writer out, Object o) throws IOException {
		try {
			if (o == null) {
				out.append("%00");
				return;
			}
			String s = o.toString();
			boolean needsReplace = false;
			for (int i = 0; i < s.length() && ! needsReplace ; i++) {
				char c = s.charAt(i);
				if (c == ' ' || c == '&' || c == '?' || c == '=' || c > 127)
					needsReplace = true;
			}

			if (! needsReplace) {
				out.append(s);
				return;
			}

			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (c == ' ')
					out.append('+');
				else if (c == '&' || c == '?' || c == '=' || c > 127)
					out.append(URLEncoder.encode(""+c, "UTF-8"));
				else
					out.append(c);
			}

		} catch (UnsupportedEncodingException e) {
			// Should never happen.
			e.printStackTrace();
		}
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on SerializerWriter
	//--------------------------------------------------------------------------------

	@Override
	public UrlEncodingSerializerWriter cr(int depth) throws IOException {
		super.cr(depth);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter appendln(int indent, String text) throws IOException {
		super.appendln(indent, text);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter appendln(String text) throws IOException {
		super.appendln(text);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter append(int indent, String text) throws IOException {
		super.append(indent, text);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter append(int indent, char c) throws IOException {
		super.append(indent, c);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter s() throws IOException {
		super.s();
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter q() throws IOException {
		super.q();
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter i(int indent) throws IOException {
		super.i(indent);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter nl() throws IOException {
		super.nl();
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter append(Object text) throws IOException {
		super.append(text);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter append(String text) throws IOException {
		super.append(text);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter appendIf(boolean b, String text) throws IOException {
		super.appendIf(b, text);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter appendIf(boolean b, char c) throws IOException {
		super.appendIf(b, c);
		return this;
	}

	@Override
	public UrlEncodingSerializerWriter append(char c) throws IOException {
		super.append(c);
		return this;
	}
}
