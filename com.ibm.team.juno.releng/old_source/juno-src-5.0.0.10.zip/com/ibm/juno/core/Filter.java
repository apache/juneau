package com.ibm.juno.core;

/**
 * Used to tailor the behavior of the bean context, and therefore how
 * serializers and parsers treat certain types of objects.
 * <p>
 * 	There are two subtypes of filters:
 * 	<ol>
 * 		<li>{@link BeanFilter} - Used to filter out properties of bean classes.
 * 		<li>{@link ObjectFilter} - Used to convert non-beans to objects that can
 * 			be serialized to JSON or XML, and parsed back into beans.
 * 	</ol>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class Filter {

	private Class<?> c;
	private boolean isBeanFilter;

	Filter(Class<?> c, boolean isBeanFilter) {
		this.c = c;
		this.isBeanFilter = isBeanFilter;
	}

	/**
	 * Returns the class that this filter applies to.
	 *
	 * @return The class that this filter applies to.
	 */
	protected Class<?> forClass() {
		return c;
	}

	/**
	 * Returns whether this filter is an instnace of {@link BeanFilter}.
	 *
	 * @return <jk>true</jk> if this filter is an instance of {@link BeanFilter},
	 * 	<jk>false</jk> if this filter is an instance of {@link ObjectFilter}.
	 */
	protected final boolean isBeanFilter() {
		return isBeanFilter;
	}
}
