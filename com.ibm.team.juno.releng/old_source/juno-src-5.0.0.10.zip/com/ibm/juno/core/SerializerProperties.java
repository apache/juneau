package com.ibm.juno.core;




/**
 * Configurable properties common to all {@link Serializer} classes.
 * <p>
 * 	Use the {@link Serializer#setProperty(String, Object)} method to set property values.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SerializerProperties {

	/**
	 * Max depth ({@link Integer}, default=<code>100</code>).
	 * <p>
	 * Abort serialization if specified depth is reached in the POJO tree.
	 * If this depth is exceeded, an exception is thrown.
	 * This prevents stack overflows from occurring when trying to serialize models with recursive references.
	 */
	public static final String MAX_DEPTH = "Serializer.maxDepth";

	/**
	 * Initial depth ({@link Integer}, default=<code>0</code>).
	 * <p>
	 * The initial indentation level at the root.
	 * Useful when constructing document fragments that need to be indented at a certain level.
	 */
	public static final String INITIAL_DEPTH = "Serializer.initialDepth";

	/**
	 * Automatically detect POJO recursions ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * Specifies that recursions should be checked for during serialization.
	 * <p>
	 * Recursions can occur when serializing models that aren't true trees, but rather contain loops.
	 * <p>
	 * When a recursion is detected, the bottom value is set to <jk>null</jk>.
	 * <p>
	 * For example, if a model contains the links A-&gt;B-&gt;C-&gt;A, then the JSON generated will look like...
	 * <code>{A:{B:{C:null}}}</code><br>
	 * <p>
	 * Note:  Checking for recursion can cause a small performance penalty.
	 */
	public static final String DETECT_RECURSIONS = "Serializer.detectRecursions";

	/**
	 * Use indentation in output ({@link Boolean}, default=<jk>true</jk>).
	 * <p>
	 * If <jk>true</jk>, newlines and indentation is added to the output to improve readability.
	 */
	public static final String USE_INDENTATION = "Serializer.useIndentation";

	/**
	 * Add class attributes to output ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, then <js>"_class"</js> attributes will be added to beans if their type cannot be inferred through reflection.
	 * This is used to recreate the correct objects during parsing if the object types cannot be inferred.
	 * For example, when serializing a {@code Map<String,Object>} field, where the bean class cannot be determined from the value type.
	 */
	public static final String ADD_CLASS_ATTRS = "Serializer.addClassAttrs";

	/**
	 * Quote character ({@link Character}, default=<js>'"'</js>.
	 * <p>
	 * This is the character used for quoting attributes and values.
	 */
	public static final String QUOTE_CHAR = "Serializer.quoteChar";

	/**
	 * Boolean.  Trim nulls from output.
	 * <p>
	 * 	If <jk>true</jk>, null values will not be serialized to the output.
	 * <p>
	 * 	Note that enabling this setting has the following effects on parsing:
	 * 	<ul>
	 * 		<li>Map entries with <jk>null</jk> values will be lost.
	 * 	</ul>
	 * <p>
	 * 	Default is <jk>false</jk>.
	 */
	public static final String TRIM_NULLS = "Serializer.trimNulls";

	/**
	 * Boolean.  Trim empty lists and arrays from output.
	 * <p>
	 * 	If <jk>true</jk>, empty list values will not be serialized to the output.
	 * <p>
	 * 	Note that enabling this setting has the following effects on parsing:
	 * 	<ul>
	 * 		<li>Map entries with empty list values will be lost.
	 * 		<li>Bean properties with empty list values will not be set.
	 * 	</ul>
	 * <p>
	 *		Default is <jk>false</jk>.
	 */
	public static final String TRIM_EMPTY_LISTS = "Serializer.trimEmptyLists";

	/**
	 * Boolean.  Trim empty maps from output.
	 * <p>
	 * 	If <jk>true</jk>, empty map values will not be serialized to the output.
	 * <p>
	 * 	Note that enabling this setting has the following effects on parsing:
	 * 	<ul>
	 * 		<li>Bean properties with empty map values will not be set.
	 * 	</ul>
	 * <p>
	 *		Default is <jk>false</jk>.
	 */
	public static final String TRIM_EMPTY_MAPS = "Serializer.trimEmptyMaps";

	private int maxDepth = 100, initialDepth = 0;
	private boolean
		detectRecursions = false,
		useIndentation = true,
		addClassAttrs = false,
		trimNulls = false,
		trimEmptyLists = false,
		trimEmptyMaps = false;
	private char quoteChar = '"';

	/** Default constructor.  All default values. */
	public SerializerProperties() {}

	/**
	 * Copy constructor.
	 * @param copyFrom Properties to copy from.
	 */
	public SerializerProperties(SerializerProperties copyFrom) {
		this.maxDepth = copyFrom.maxDepth;
		this.initialDepth = copyFrom.initialDepth;
		this.detectRecursions = copyFrom.detectRecursions;
		this.useIndentation = copyFrom.useIndentation;
		this.addClassAttrs = copyFrom.addClassAttrs;
		this.quoteChar = copyFrom.quoteChar;
		this.trimNulls = copyFrom.trimNulls;
		this.trimEmptyLists = copyFrom.trimEmptyLists;
		this.trimEmptyMaps = copyFrom.trimEmptyMaps;
	}

	/**
	 * Returns the current {@link #MAX_DEPTH} value.
	 * @return The current {@link #MAX_DEPTH} value.
	 */
	public final int getMaxDepth() {
		return maxDepth;
	}

	/**
	 * Returns the current {@link #INITIAL_DEPTH} value.
	 * @return The current {@link #INITIAL_DEPTH} value.
	 */
	public final int getInitialDepth() {
		return initialDepth;
	}

	/**
	 * Returns the current {@link #DETECT_RECURSIONS} value.
	 * @return The current {@link #DETECT_RECURSIONS} value.
	 */
	public final boolean isDetectRecursions() {
		return detectRecursions;
	}

	/**
	 * Returns the current {@link #USE_INDENTATION} value.
	 * @return The current {@link #USE_INDENTATION} value.
	 */
	public final boolean isUseIndentation() {
		return useIndentation;
	}

	/**
	 * Returns the current {@link #ADD_CLASS_ATTRS} value.
	 * @return The current {@link #ADD_CLASS_ATTRS} value.
	 */
	public final boolean isAddClassAttrs() {
		return addClassAttrs;
	}

	/**
	 * Returns the current {@link #QUOTE_CHAR} value.
	 * @return The current {@link #QUOTE_CHAR} value.
	 */
	public final char getQuoteChar() {
		return quoteChar;
	}

	/**
	 * Returns the current {@link #TRIM_NULLS} value.
	 * @return The current {@link #TRIM_NULLS} value.
	 */
	public final boolean isTrimNulls() {
		return trimNulls;
	}

	/**
	 * Returns the current {@link #TRIM_EMPTY_LISTS} value.
	 * @return The current {@link #TRIM_EMPTY_LISTS} value.
	 */
	public final boolean isTrimEmptyLists() {
		return trimEmptyLists;
	}

	/**
	 * Returns the current {@link #TRIM_EMPTY_MAPS} value.
	 * @return The current {@link #TRIM_EMPTY_MAPS} value.
	 */
	public final boolean isTrimEmptyMaps() {
		return trimEmptyMaps;
	}

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		BeanContext bc = BeanContext.DEFAULT;
		if (property.equals(MAX_DEPTH))
			maxDepth = bc.convertToType(value, Integer.class);
		else if (property.equals(DETECT_RECURSIONS))
			detectRecursions = bc.convertToType(value, Boolean.class);
		else if (property.equals(USE_INDENTATION))
			useIndentation = bc.convertToType(value, Boolean.class);
		else if (property.equals(ADD_CLASS_ATTRS))
			addClassAttrs = bc.convertToType(value, Boolean.class);
		else if (property.equals(QUOTE_CHAR))
			quoteChar = bc.convertToType(value, Character.class);
		else if (property.equals(TRIM_NULLS))
			trimNulls = bc.convertToType(value, Boolean.class);
		else if (property.equals(TRIM_EMPTY_LISTS))
			trimEmptyLists = bc.convertToType(value, Boolean.class);
		else if (property.equals(TRIM_EMPTY_MAPS))
			trimEmptyMaps = bc.convertToType(value, Boolean.class);
		else
			return false;
		return true;
	}
}
