package com.ibm.juno.core.xml.annotation;

/**
 * XML format to use when serializing a POJO.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public enum XmlFormat {

	/** Normal formatting (default) */
	NORMAL,

	/**
	 * Render property as an attribute instead of an element.
	 * <p>
	 * 	Can only be applied to properties (methods/fields) of simple types (e.g. <code>String</code>, <code>Number</code>).
	 */
	ATTR,

	/**
	 * Render property as an element instead of an attribute.
	 * <p>
	 * 	Can be applied to URL and ID bean properties that would normally be rendered as attributes.
	 */
	ELEMENT,

	/**
	 * Prevents collections and arrays from being enclosed in <xt>&lt;array&gt;</xt> elements.
	 * <p>
	 * 	Can only be applied to properties (methods/fields) of type collection or array, or collection classes.
	 */
	COLLAPSED
}