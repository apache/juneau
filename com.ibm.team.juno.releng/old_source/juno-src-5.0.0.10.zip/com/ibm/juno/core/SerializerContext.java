package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;
import java.util.logging.*;

/**
 * Context object that lives for the duration of a single serialization of {@link Serializer} and its subclasses.
 * <p>
 *  	Used by serializers for the following purposes:
 * 	<ul>
 * 		<li>Keeping track of how deep it is in a model for indentation purposes.
 * 		<li>Ensuring infinite loops don't occur by setting a limit on how deep to traverse a model.
 * 		<li>Ensuring infinite loops don't occur from loops in the model (when detectRecursions is enabled.
 * 		<li>Allowing serializer properties to be overridden on method calls.
 * 	</ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SerializerContext {

	private static Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	/** The inner serializer properties. */
	private SerializerProperties sp;

	/** The current indentation depth into the model. */
	public int indent;

	/** Contains the current objects in the current branch of the model. */
	private Map<Object,Object> set;

	/** Contains the current objects in the current branch of the model. */
	private LinkedList<Object> objectStack;

	/** Contains the attribute names of the current objects in the current branch of the model. */
	private LinkedList<String> attrNameStack;

	/** If 'true', then we're at a leaf in the model (i.e. a String, Number, Boolean, or null). */
	private boolean isBottom;

	/** Any warnings encountered. */
	private List<String> warnings = new LinkedList<String>();

	/** The bean context being used in this context. */
	private BeanContext beanContext;

	/**
	 * Create a new HashStack with the specified options.
	 *
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp The default serializer properties.
	 * @param op The override properties.
	 */
	public SerializerContext(BeanContext beanContext, SerializerProperties sp, JsonMap...op) {
		this.beanContext = beanContext;
		this.sp = new SerializerProperties(sp);
		for (JsonMap m : op)
			for (Map.Entry<String,Object> e : m.entrySet())
				this.sp.setProperty(e.getKey(), e.getValue());
		this.indent = this.sp.getInitialDepth();
		if (this.sp.isDetectRecursions()) {
			set = new IdentityHashMap<Object,Object>();
			objectStack = new LinkedList<Object>();
			attrNameStack = new LinkedList<String>();
		}
	}

	/**
	 * Returns the {@link SerializerProperties#MAX_DEPTH} setting value in this context.
	 * @return The {@link SerializerProperties#MAX_DEPTH} setting value in this context.
	 */
	public final int getMaxDepth() {
		return sp.getMaxDepth();
	}

	/**
	 * Returns the {@link SerializerProperties#INITIAL_DEPTH} setting value in this context.
	 * @return The {@link SerializerProperties#INITIAL_DEPTH} setting value in this context.
	 */
	public final int getInitialDepth() {
		return sp.getInitialDepth();
	}

	/**
	 * Returns the {@link SerializerProperties#DETECT_RECURSIONS} setting value in this context.
	 * @return The {@link SerializerProperties#DETECT_RECURSIONS} setting value in this context.
	 */
	public final boolean isDetectRecursions() {
		return sp.isDetectRecursions();
	}

	/**
	 * Returns the {@link SerializerProperties#USE_INDENTATION} setting value in this context.
	 * @return The {@link SerializerProperties#USE_INDENTATION} setting value in this context.
	 */
	public final boolean isUseIndentation() {
		return sp.isUseIndentation();
	}

	/**
	 * Returns the {@link SerializerProperties#ADD_CLASS_ATTRS} setting value in this context.
	 * @return The {@link SerializerProperties#ADD_CLASS_ATTRS} setting value in this context.
	 */
	public final boolean isAddClassAttrs() {
		return sp.isAddClassAttrs();
	}

	/**
	 * Returns the {@link SerializerProperties#QUOTE_CHAR} setting value in this context.
	 * @return The {@link SerializerProperties#QUOTE_CHAR} setting value in this context.
	 */
	public final char getQuoteChar() {
		return sp.getQuoteChar();
	}

	/**
	 * Returns the {@link SerializerProperties#TRIM_NULLS} setting value in this context.
	 * @return The {@link SerializerProperties#TRIM_NULLS} setting value in this context.
	 */
	public final boolean isTrimNulls() {
		return sp.isTrimNulls();
	}

	/**
	 * Returns the {@link SerializerProperties#TRIM_EMPTY_LISTS} setting value in this context.
	 * @return The {@link SerializerProperties#TRIM_EMPTY_LISTS} setting value in this context.
	 */
	public final boolean isTrimEmptyLists() {
		return sp.isTrimEmptyLists();
	}

	/**
	 * Returns the {@link SerializerProperties#TRIM_EMPTY_MAPS} setting value in this context.
	 * @return The {@link SerializerProperties#TRIM_EMPTY_MAPS} setting value in this context.
	 */
	public final boolean isTrimEmptyMaps() {
		return sp.isTrimEmptyMaps();
	}

	/**
	 * Push the specified object onto the stack.
	 *
	 * @param attrName The attribute name.
	 * @param o The current object being serialized.
	 * @param eType The expected class type.
	 * @return The {@link ClassType} of the object so that <code>instanceof</code> operations
	 * 	only need to be performed once (since they can be expensive).<br>
	 */
	public ClassType<?> push(String attrName, Object o, ClassType<?> eType) {
		indent++;
		isBottom = true;
		if (o == null)
			return null;
		Class<?> c = o.getClass();
		ClassType<?> ct = (eType != null && c == eType.getClass() ? eType : beanContext.getClassType(o.getClass()));
		if (ct.isCharSequence() || ct.isNumber() || ct.isBoolean())
			return ct;
		if (sp.isDetectRecursions()) {
			if (objectStack.size() > sp.getMaxDepth()) {
				Logger.getLogger(Logger.GLOBAL_LOGGER_NAME).warning("Depth too deep.  Possible recursion.\nStack:" + getStackString());
				return null;
			}
			try {
				if (set.containsKey(o))
					return null;				// If a recursion is detected, set it to NULL.
			} catch (Throwable e) {
				logger.warning("Exception of type ["+e.getMessage()+"] occurred on class of type ["+o.getClass().getName()+"]");
				return null;
			}
			isBottom = false;
			objectStack.addLast(o);
			attrNameStack.addLast(attrName);
			set.put(o, o);
		}
		return ct;
	}

	/**
	 * Pop an object off the stack.
	 */
	public void pop() {
		indent--;
		if (sp.isDetectRecursions() && ! isBottom)  {
			Object o = objectStack.removeLast();
			String s = attrNameStack.removeLast();
			Object o2 = set.remove(o);
			if (o2 == null)
				addWarning("Couldn't remove object of type ["+o.getClass().getName()+"] on attribute ["+s+"] from object stack.");
		}
		isBottom = false;
	}

	/**
	 * The current indentation depth.
	 *
	 * @return The current indentation depth.
	 */
	public int getIndent() {
		return indent;
	}

	/**
	 * Logs a warning message.
	 *
	 * @param msg The warning message.
	 * @param args Optional printf arguments to replace in the error message.
	 */
	public void addWarning(String msg, Object... args) {
		msg = args.length == 0 ? msg : String.format(msg, args);
		logger.warning(msg);
		warnings.add(msg);
	}

	/**
	 * Returns the current branch of objects as a readable string.
	 */
	private String getStackString() {
		if (! sp.isDetectRecursions())
			return null;
		StringBuilder sb = new StringBuilder("root");
		int x = objectStack.size();
		for (int i = 0; i < x; i++)
			sb.append("\n\t").append(attrNameStack.get(i) + " : " + objectStack.get(i).getClass().getName());
		return sb.toString();
	}
}
