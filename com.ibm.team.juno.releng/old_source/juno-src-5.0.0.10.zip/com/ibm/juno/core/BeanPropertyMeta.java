package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.xml.annotation.XmlFormat.*;

import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.utils.*;
import com.ibm.juno.core.xml.*;
import com.ibm.juno.core.xml.annotation.*;

/**
 * Contains metadata about a bean property.
 * <p>
 * 	Contains information such as type of property (e.g. field/getter/setter), class type of property value,
 * 	and whether any filters are associated with this property.
 * <p>
 * 	Developers will typically not need access to this class.  The information provided by it is already
 * 	exposed through several methods on the {@link BeanMap} API.
 *
 * @param <T> The class type of the bean that this metadata applies to.
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class BeanPropertyMeta<T> {

	private Field field;
	private Method getter, setter;
	private boolean isConstructorArg, isHidden, isUri, isId;

	private BeanMeta<T> beanMeta;

	private String name, childElementName, valAttr;
	private ClassType<T> classType, filteredClassType;
	private String[] properties;
	private ObjectFilter filter;
	private Namespace namespace = null, valAttrNs = null;
	private XmlFormat xmlFormat = XmlFormat.NORMAL;

	BeanPropertyMeta(BeanMeta<T> beanMeta, String name) {
		this.beanMeta = beanMeta;
		this.name = name;
	}

	BeanPropertyMeta(BeanMeta<T> beanMeta, String name, Method getter, Method setter) {
		this(beanMeta, name);
		setGetter(getter);
		setSetter(setter);
	}

	/**
	 * Returns the name of this property.
	 *
	 * @return The name of the property.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the child element name of this property if specified via {@link Xml#childElementName()}.
	 *
	 * @return The child element name of the property.
	 */
	public String getChildElementName() {
		return childElementName;
	}

	/**
	 * Returns <jk>true</jk> if {@link BeanProperty#hidden()} is set to false on this property.
	 * @return <jk>true</jk> if {@link BeanProperty#hidden()} is set to false on this property.
	 */
	public boolean isHidden() {
		return isHidden;
	}

	/**
	 * Returns the bean meta that this property belongs to.
	 * @return The bean meta that this property belongs to.
	 */
	public BeanMeta<T> getBeanMeta() {
		return beanMeta;
	}

	/**
	 * Returns the getter method for this property.
	 *
	 * @return The getter method for this bean property, or <jk>null</jk> if there is no getter method.
	 */
	public Method getGetter() {
		return getter;
	}

	/**
	 * Returns the setter method for this property.
	 *
	 * @return The setter method for this bean property, or <jk>null</jk> if there is no setter method.
	 */
	public Method getSetter() {
		return setter;
	}

	/**
	 * Returns the field for this property.
	 *
	 * @return The field for this bean property, or <jk>null</jk> if there is no field associated with this bean property.
	 */
	public Field getField() {
		return field;
	}

	/**
	 * Returns the class type of this property.
	 *
	 * @return The class type of this property.
	 */
	public ClassType<?> getClassType() {
		return classType;
	}

	/**
	 * Returns the filtered class type of this property based on whether any {@link ObjectFilter}
	 * as been associated with this bean class.
	 * <p>
	 * 	If no {@code ObjectFilter} is associated with
	 * 	this bean class, then returns the same value as {@link #getClassType()}.
	 *
	 * @return The class type of this property.
	 */
	public ClassType<?> getFilteredClassType() {
		return filteredClassType;
	}

	/**
	 * Sets the getter method for this property.
	 *
	 * @param getter The getter method to associate with this property.
	 * @return This object (for method chaining).
	 */
	BeanPropertyMeta<T> setGetter(Method getter) {
		this.getter = getter;
		return this;
	}

	/**
	 * Sets the setter method for this property.
	 *
	 * @param setter The setter method to associate with this property.
	 * @return This object (for method chaining).
	 */
	BeanPropertyMeta<T> setSetter(Method setter) {
		this.setter = setter;
		return this;
	}

	/**
	 * Sets the field for this property.
	 *
	 * @param field The field to associate with this property.
	 * @return This object (for method chaining).
	 */
	BeanPropertyMeta<T> setField(Field field) {
		this.field = field;
		return this;
	}

	/**
	 * Marks this property as only settable through a constructor arg.
	 * @return This object (for method chaining).
	 */
	BeanPropertyMeta<T> setAsConstructorArg() {
		this.isConstructorArg = true;
		return this;
	}

	/**
	 * Returns <jk>true</jk> if this bean property is marked with {@link BeanProperty#uri()} as <jk>true</jk>.
	 * @return <jk>true</jk> if this bean property is marked with {@link BeanProperty#uri()} as <jk>true</jk>.
	 */
	public boolean isUri() {
		return isUri;
	}

	/**
	 * Returns <jk>true</jk> if this bean property is marked with {@link BeanProperty#id()} as <jk>true</jk>.
	 * @return <jk>true</jk> if this bean property is marked with {@link BeanProperty#id()} as <jk>true</jk>.
	 */
	public boolean isId() {
		return isId;
	}

	/**
	 * Returns the override list of properties defined through a {@link BeanProperty#properties()} annotation
	 *  on this property..
	 * @return The list of override properties, or <jk>null</jk> if annotation not specified.
	 */
	public String[] getProperties() {
		return properties;
	}

	/**
	 * Returns the XML namespace associated with this bean property.
	 * <p>
	 * 	Namespace is determined in the following order:
	 * <ol>
	 * 	<li>{@link Xml#ns()} annotation defined on bean property field.
	 * 	<li>{@link Xml#ns()} annotation defined on bean getter.
	 * 	<li>{@link Xml#ns()} annotation defined on bean setter.
	 * 	<li>{@link Xml#ns()} annotation defined on bean.
	 * 	<li>{@link Xml#ns()} annotation defined on bean package.
	 * 	<li>{@link Xml#ns()} annotation defined on bean superclasses.
	 * 	<li>{@link Xml#ns()} annotation defined on bean superclass packages.
	 * 	<li>{@link Xml#ns()} annotation defined on bean interfaces.
	 * 	<li>{@link Xml#ns()} annotation defined on bean interface packages.
	 * </ol>
	 * @return The namespace associated with this bean property, or <jk>null</jk> if no namespace is
	 * 	associated with it.
	 */
	public Namespace getNamespace() {
		return namespace;
	}

	/**
	 * Returns the value attribute namespace from the {@link Xml#valAttr()} annotation on this bean property.
	 * @return The value attribute namespace from the {@link Xml#valAttr()} annotation on this bean property, or <jk>null</jk> if
	 * 	annotation is not defined.
	 */
	public Namespace getValAttrNamespace() {
		return valAttrNs;
	}

	/**
	 * Returns the value attribute name from the {@link Xml#valAttr()} annotation on this bean property.
	 * @return The value attribute name from the {@link Xml#valAttr()} annotation on this bean property, or <jk>null</jk> if
	 * 	annotation is not defined.
	 */
	public String getValAttr() {
		return valAttr;
	}

	/**
	 * Returns the XML format of this property from the {@link Xml#format} annotation on this bean property.
	 * @return The XML format, or {@link XmlFormat#NORMAL} if annotation not specified.
	 */
	public XmlFormat getXmlFormat() {
		return xmlFormat;
	}

	/**
	 * Returns the {@link ObjectFilter} associated with this bean property.
	 * <p>
	 * Object filters are associated with properties in the following ways (in order of precedence):
	 * <ul>
	 * 	<li>Specified in the {@link BeanProperty#filter()} annotation.
	 * 	<li>Specified on the property class type through {@link BeanContext#addFilters(Filter...)}.
	 * </ul>
	 * @return An instance of the object filter, or <jk>null</jk> if no filter is associated with this property.
	 */
	public ObjectFilter getFilter() {
		return filter;
	}

	boolean validate() throws Exception {

		BeanContext f = beanMeta.beanContext;
		Map<Class<?>,Class<?>[]> typeVarImpls = beanMeta.typeVarImpls;

		if (field == null && getter == null)
			return false;

		if (field == null && setter == null && f.beansRequireSettersForGetters && ! isConstructorArg)
			return false;

		if (field != null) {
			BeanProperty p = field.getAnnotation(BeanProperty.class);
			classType = f.getClassType(p, field.getGenericType(), typeVarImpls);
			if (p != null) {
				filter = getPropertyObjectFilter(p);
				if (p.properties().length != 0)
					properties = p.properties();
				isHidden |= p.hidden();
				isUri |= p.uri();
				isId |= p.id();
			}
			findXmlInfo(field.getAnnotation(Xml.class));
		}

		if (getter != null) {
			BeanProperty p = getter.getAnnotation(BeanProperty.class);
			if (classType == null)
				classType = f.getClassType(p, getter.getGenericReturnType(), typeVarImpls);
			if (p != null) {
				if (filter == null)
					filter = getPropertyObjectFilter(p);
				if (properties != null && p.properties().length != 0)
					properties = p.properties();
				isHidden |= p.hidden();
				isUri |= p.uri();
				isId |= p.id();
			}
			findXmlInfo(getter.getAnnotation(Xml.class));
		}

		if (setter != null) {
			BeanProperty p = setter.getAnnotation(BeanProperty.class);
			if (classType == null)
				classType = f.getClassType(p, setter.getGenericParameterTypes()[0], typeVarImpls);
			if (p != null) {
				if (filter == null)
					filter = getPropertyObjectFilter(p);
				if (properties != null && p.properties().length != 0)
					properties = p.properties();
				isHidden |= p.hidden();
				isUri |= p.uri();
				isId |= p.id();
			}
			findXmlInfo(setter.getAnnotation(Xml.class));
		}

		if (classType == null)
			return false;

		// Do some annotation validation.
		Class<?> c = classType.getInnerClass();
		if (getter != null && ! getter.getReturnType().isAssignableFrom(c))
			throw new BeanRuntimeException(beanMeta.c, "'propertyClass' attribute with value '%s' defined on property '%s' does not match the field type of '%s'", c.getName(), name, getter.getReturnType().getName());
		if (setter != null && ! setter.getParameterTypes()[0].isAssignableFrom(c))
			throw new BeanRuntimeException(beanMeta.c, "'propertyClass' attribute with value '%s' defined on property '%s' does not match the field type of '%s'", c.getName(), name, setter.getParameterTypes()[0].getName());
		if (field != null && ! field.getType().isAssignableFrom(c))
			throw new BeanRuntimeException(beanMeta.c, "'propertyClass' attribute with value '%s' defined on property '%s' does not match the field type of '%s'", c.getName(), name, field.getType().getName());

		if (filter == null)
			filter = classType.getObjectFilter();

		filteredClassType = (filter == null ? classType : f.getClassType(filter.getFilteredClass()));

		if (namespace == null)
			namespace = beanMeta.getClassType().getNamespace();

		if ((isUri || isId) && xmlFormat != ELEMENT)
			xmlFormat = ATTR;

		return true;
	}

	private void findXmlInfo(Xml xml) {
		if (xml == null)
			return;
		ClassType<?> ct = beanMeta.getClassType();
		if (! xml.elementName().isEmpty())
			throw new BeanRuntimeException(ct.getInnerClass(), "Found @Xml.elementName annotation on invalid location.  Can only be specified on types.");
		if (namespace == null) {
			String ns = xml.ns(), nsUri = xml.nsUri();
			if (! ns.isEmpty()) {
				if (nsUri.isEmpty()) {

					// Look for namespace defined on the property itself.
					for (XmlNs xmlNs : xml.namespaces())
						if (xmlNs.name().equals(ns))
							namespace = NamespaceFactory.get(xmlNs.name(), xmlNs.uri());

					// Look for namespace defined on class.
					if (namespace == null)
						namespace = ct.findNamespaceByName(ns);

					if (namespace == null)
						throw new BeanRuntimeException(ct.getInnerClass(), "Found @Xml.ns annotation with no matching URI on property '%s'", this.name);
				} else {
					namespace = NamespaceFactory.get(ns, nsUri);
				}
			}
		}
		if (xmlFormat == XmlFormat.NORMAL)
			xmlFormat = xml.format();
		if (! xml.childElementName().isEmpty())
			childElementName = xml.childElementName();
		if (xmlFormat == XmlFormat.COLLAPSED && childElementName == null)
			childElementName = name;
		String s = xml.valAttr();
		if (! s.isEmpty()) {
			if (s.indexOf(':') == -1)
				valAttr = s;
			else {
				String[] s2 = s.split(":");
				valAttrNs = ct.findNamespaceByName(s2[0]);
				valAttr = s2[1];
			}
		}
	}

	private ObjectFilter getPropertyObjectFilter(BeanProperty p) throws Exception {
		Class<? extends ObjectFilter> c = p.filter();
		if (c == NullObjectFilter.class)
			return null;
		return c.newInstance();
	}

	Object getFiltered(BeanMap<T> m) throws BeanRuntimeException {
		try {
			Object o = get(m);
			if (filter != null && o != null)
				o = filter.filter(o, this.beanMeta.beanContext);
			if (o == null)
				return null;
			if (properties != null) {
				if (classType.isArray()) {
					Object[] a = (Object[])o;
					List l = new ArrayList(a.length);
					ClassType childType = classType.getElementType();
					for (Object c : a)
						l.add(applyChildPropertiesFilter(childType, c));
					return l;
				} else if (classType.isCollection()) {
					Collection c = (Collection)o;
					List l = new ArrayList(c.size());
					ClassType childType = classType.getElementType();
					for (Object cc : c)
						l.add(applyChildPropertiesFilter(childType, cc));
					return l;
				} else {
					return applyChildPropertiesFilter(classType, o);
				}
			}
			return o;
		} catch (SerializeException e) {
			throw new BeanRuntimeException(e);
		}
	}

	private Object applyChildPropertiesFilter(ClassType ct, Object o) {
		if (o == null)
			return null;
		if (ct.isBean())
			return new BeanMap(o, new BeanMetaFiltered(ct.getBeanMeta(), properties));
		if (ct.isMap())
			return new FilteredMap((Map)o, properties);
		if (ct.isObject()) {
			if (o instanceof Map)
				return new FilteredMap((Map)o, properties);
			BeanMeta bm = this.getBeanMeta().beanContext.getBeanMeta(o.getClass());
			if (bm != null)
				return new BeanMap(o, new BeanMetaFiltered(ct.getBeanMeta(), properties));
		}
		return o;
	}

	Object get(BeanMap<T> m) throws BeanRuntimeException {
		try {
			// Read-only beans have their properties stored in a cache until getBean() is called.
			Object bean = m.bean;
			if (bean == null)
				return m.readOnlyPropertyCache.get(name);

			Object r = null;

			if (getter == null && field == null)
				throw new BeanRuntimeException(beanMeta.c, "Getter or public field not defined on property '%s'", name);

			if (getter != null)
				r = getter.invoke(bean, (Object[])null);

			else if (field != null)
				r = field.get(bean);

			return r;

		} catch (Exception e) {
			throw new BeanRuntimeException(beanMeta.c, e, "Exception occurred while getting property '%s'", name);
		}
	}

	Object setFiltered(BeanMap<T> m, Object value) throws BeanRuntimeException {
		try {
			if (filter != null)
				value = filter.unfilter(value, classType, this.beanMeta.beanContext);
			return set(m, value);
		} catch (ParseException e) {
			throw new BeanRuntimeException(e);
		}
	}

	Object set(BeanMap<T> m, Object value) throws BeanRuntimeException {

		// Read-only beans get their properties stored in a cache.
		if (m.bean == null)
			return m.readOnlyPropertyCache.put(name, value);

		boolean isMap = classType.isMap();
		boolean isCollection = classType.isCollection();

		if (field == null && setter == null && ! (isMap || isCollection)) {
			BeanContext bc = this.beanMeta.beanContext;
			if ((value == null && bc.ignoreUnknownNullBeanProperties) || bc.ignorePropertiesWithoutSetters)
				return null;
			throw new BeanRuntimeException(beanMeta.c, "Setter or public field not defined on property '%s'", name);
		}

		Object bean = m.getBean();

		try {

			Object r = beanMeta.beanContext.beanMapPutReturnsOldValue || isMap || isCollection ? get(m) : null;
			Class<?> propertyClass = classType.getInnerClass();

			if (value == null && (isMap || isCollection)) {
				if (setter != null) {
					setter.invoke(bean, new Object[] { null });
					return r;
				} else if (field != null) {
					field.set(bean, null);
					return r;
				}
				throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' to null because no setter or public field is defined", name);
			}

			if (isMap) {

				if (! (value instanceof Map)) {
					if (value instanceof CharSequence)
						value = new JsonMap((CharSequence)value);
					else
						throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s'", name, propertyClass.getName(), findClassName(value));
				}

				Map valueMap = (Map)value;
				Map propMap = (Map)r;
				ClassType<?> valueType = classType.getValueType();

				// If the property type is abstract, then we either need to reuse the existing
				// map (if it's not null), or try to assign the value directly.
				if (! classType.canCreateNewInstance()) {
					if (propMap == null) {
						if (setter == null && field == null)
							throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s' because no setter or public field is defined, and the current value is null", name, propertyClass.getName(), findClassName(value));

						if (propertyClass.isInstance(valueMap)) {
							if (! valueType.isObject()) {
								for (Map.Entry e : (Set<Map.Entry>)valueMap.entrySet()) {
									Object v = e.getValue();
									if (v != null && ! valueType.getInnerClass().isInstance(v))
										throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s' because the value types in the assigned map do not match the specified 'elementClass' attribute on the property, and the property value is currently null", name, propertyClass.getName(), findClassName(value));
								}
							}
							if (setter != null)
								setter.invoke(bean, valueMap);
							else
								field.set(bean, valueMap);
							return r;
						}
						throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s' because the assigned map cannot be converted to the specified type because the property type is abstract, and the property value is currently null", name, propertyClass.getName(), findClassName(value));
					}
				} else {
					if (propMap == null) {
						propMap = (Map)propertyClass.newInstance();
						if (setter != null)
							setter.invoke(bean, propMap);
						else if (field != null)
							field.set(bean, propMap);
						else
							throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s' because no setter or public field is defined on this property, and the existing property value is null", name, propertyClass.getName(), findClassName(value));
					} else {
						propMap.clear();
					}
				}

				// Set the values.
				for (Map.Entry e : (Set<Map.Entry>)valueMap.entrySet()) {
					Object k = e.getKey();
					Object v = e.getValue();
					if (! valueType.isObject())
						v = beanMeta.beanContext.convertToType(v, valueType);
					propMap.put(k, v);
				}

			} else if (isCollection) {

				if (! (value instanceof Collection)) {
					if (value instanceof CharSequence)
						value = new JsonList((CharSequence)value);
					else
						throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s'", name, propertyClass.getName(), findClassName(value));
				}

				Collection valueList = (Collection)value;
				Collection propList = (Collection)r;
				ClassType elementType = classType.getElementType();

				// If the property type is abstract, then we either need to reuse the existing
				// collection (if it's not null), or try to assign the value directly.
				if (! classType.canCreateNewInstance()) {
					if (propList == null) {
						if (setter == null && field == null)
							throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s' because no setter or public field is defined, and the current value is null", name, propertyClass.getName(), findClassName(value));

						if (propertyClass.isInstance(valueList)) {
							if (! elementType.isObject()) {
								for (Object v : valueList) {
									if (v != null && ! elementType.getInnerClass().isInstance(v))
										throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s' because the value types in the assigned map do not match the specified 'elementClass' attribute on the property, and the property value is currently null", name, propertyClass.getName(), findClassName(value));
								}
							}
							if (setter != null)
								setter.invoke(bean, valueList);
							else
								field.set(bean, valueList);
							return r;
						}
						throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s' because the assigned map cannot be converted to the specified type because the property type is abstract, and the property value is currently null", name, propertyClass.getName(), findClassName(value));
					}
				} else {
					if (propList == null) {
						propList = (Collection)propertyClass.newInstance();
						if (setter != null)
							setter.invoke(bean, propList);
						else if (field != null)
							field.set(bean, propList);
						else
							throw new BeanRuntimeException(beanMeta.c, "Cannot set property '%s' of type '%s' to object of type '%s' because no setter is defined on this property, and the existing property value is null", name, propertyClass.getName(), findClassName(value));
					} else {
						propList.clear();
					}
				}

				// Set the values.
				for (Object v : valueList) {
					if (! elementType.isObject())
						v = beanMeta.beanContext.convertToType(v, elementType);
					propList.add(v);
				}

			} else {
				value = beanMeta.beanContext.convertToType(value, classType);
				if (setter != null)
					setter.invoke(bean, new Object[] { value });
				else if (field != null)
					field.set(bean, value);
			}

			return r;

		} catch (BeanRuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new BeanRuntimeException(beanMeta.c, e, "Error occurred trying to set property '%s'", name);
		}
	}

	void add(BeanMap<T> m, Object value) throws BeanRuntimeException {

		// Read-only beans get their properties stored in a cache.
		if (m.bean == null) {
			if (! m.readOnlyPropertyCache.containsKey(name))
				m.readOnlyPropertyCache.put(name, new JsonList());
			((JsonList)m.readOnlyPropertyCache.get(name)).add(value);
			return;
		}

		boolean isCollection = classType.isCollection();
		boolean isArray = classType.isArray();

		if (! (isCollection || isArray))
			throw new BeanRuntimeException(beanMeta.c, "Attempt to add element to property '%s' which is not a collection or array", name);

		Object bean = m.getBean();

		ClassType<?> elementType = classType.getElementType();

		try {
			Object v = beanMeta.beanContext.convertToType(value, elementType);

			if (isCollection) {
				Collection c = null;
				if (getter != null) {
					c = (Collection)getter.invoke(bean, (Object[])null);
				} else if (field != null) {
					c = (Collection)field.get(bean);
				} else {
					throw new BeanRuntimeException(beanMeta.c, "Attempt to append to collection property '%s', but no getter or field defined.", name);
				}

				if (c != null) {
					c.add(v);
					return;
				}

				if (classType.canCreateNewInstance())
					c = (Collection)classType.newInstance();
				else
					c = new JsonList();

				c.add(v);

				if (setter != null)
					setter.invoke(bean, c);
				else if (field != null)
					field.set(bean, c);
				else
					throw new BeanRuntimeException(beanMeta.c, "Attempt to initialize collection property '%s', but no setter or field defined.", name);

			} else {

				JsonList l = new JsonList();
				Object[] oldArray = null;
				if (getter != null)
					oldArray = (Object[])getter.invoke(bean, (Object[])null);
				else if (field != null)
					oldArray = (Object[])field.get(bean);
				else
					throw new BeanRuntimeException(beanMeta.c, "Attempt to append to array property '%s', but no getter or field defined.", name);

				if (oldArray != null)
					l.append(oldArray);
				l.add(v);

				value = beanMeta.beanContext.toArray(classType, l);

				if (setter != null)
					setter.invoke(bean, new Object[]{value});
				else if (field != null)
					field.set(bean, value);
				else
					throw new BeanRuntimeException(beanMeta.c, "Attempt to append to array property '%s', but no setter defined.", name);
			}

		} catch (BeanRuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new BeanRuntimeException(null, e);
		}
	}

	private String findClassName(Object o) {
		if (o == null)
			return null;
		if (o instanceof Class)
			return ((Class<?>)o).getName();
		return o.getClass().getName();
	}

	@Override
	public String toString() {
		return name;
	}
}
