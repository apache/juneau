package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.util.*;

import com.ibm.juno.core.annotation.*;

/**
 * Filter class used to tailor metadata about bean classes.
 * <p>
 * 	Bean filters are associated with {@link BeanContext} instances to tailor the properties
 * 	returned by the {@link BeanMap#entrySet()} on {@link BeanMap} objects returned by
 * 	the {@link BeanContext#forBean(Object)} method.  Since {@link BeanContext} is
 * 	used to convert beans to maps during serialization, they can also be used to specify which properties
 * 	on a bean get serialized.
 * <p>
 * 	Some of the functionality provided by this class can also be provided through the {@link Bean#properties} annotation.
 * <p>
 * 	Filters can be used to perform the following functions:
 * 	<ul>
 * 		<li>To narrow subclasses to the API defined on a superclass (i.e. only include properties
 * 			defined on a superclass).<br>
 * 			For example, if you only want to expose properties defined on
 * 			the {@code HttpServletRequest} interface, and not vendor-specific methods defined
 * 			on subclasses, you can define the following bean filter on the bean context:<br><br>
 * 			<p class='bcode'> beanContext.addFilter(<jk>new</jk> BeanFilter(HttpServletRequest.<jk>class</jk>));</p>
 * 		<br>
 * 		<li>To explicitly exclude certain properties.<br>
 * 			If an object has a method that looks like a getter, but isn't a
 * 			true getter, it can be explicitly excluded from the list of properties by calling the {@link #setExcludeKeys(String...) setExcludeKeys()}
 * 			method.  For example, on the {@code HttpServletRequest} class, the {@code getReader()} and {@code getInputStream()} methods are
 * 			not true bean getters, so they can be excluded by specifying the following filter:<br><br>
 * 			<p class='bcode'> beanContext.addFilter(<jk>new</jk> BeanFilter(HttpServletRequest.<jk>class</jk>).setExcludeKeys(<js>"reader"</js>,<js>"inputStream"</js>));</p>
 * 		<br>
 * 		<li>To explicitly include only certain properties, or explicitly specify the order of the properties
 * 			by using the {@link #setIncludeKeys(LinkedHashSet) setIncludeKeys()} method.<br>
 * 			For example, on the {@code HttpServletRequest} class, to only
 * 			treat the {@code getMethod()} and {@code getPathInfo()} as getters, specify the following filter:<br><br>
 * 			<p class='bcode'> beanContext.addFilter(<jk>new</jk> BeanFilter(HttpServletRequest.<jk>class</jk>).setIncludeKeys(<js>"method"</js>,<js>"pathInfo"</js>));</p>
 * 	</ul>
 * <p>
 * 	Note that {@link #setExcludeKeys(String...)} and {@link #setIncludeKeys(LinkedHashSet)} are mutually exclusive, so only one method should be
 * 	called.  If both methods are used, the include keys will be ignored.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 * @param <T> The class type that this filter applies to.
 */
public class BeanFilter<T> extends Filter {

	/** The list of properties to explicitely include. */
	protected LinkedHashSet<String> includeKeys;

	/** The list of properties to explicitely exclude. */
	protected LinkedHashSet<String> excludeKeys;

	/**
	 * Create a new filter for the specified class.
	 * <p>
	 * 	Subclasses of this class will be narrowed to the specified class.
	 *
	 * @param c The class to create a new filter for.
	 */
	public BeanFilter(Class<T> c) {
		super(c, true);
	}

	/**
	 * Set the list of properties to exclude from {@link BeanMap#entrySet()}.
	 *
	 * @param keys The list of properties to exclude from the entry set.
	 * @return This object so that this method can be chained like the {@link ProcessBuilder} class.
	 */
	public BeanFilter<T> setExcludeKeys(String...keys) {
		return setExcludeKeys(new LinkedHashSet<String>(Arrays.asList(keys)));
	}

	/**
	 * Set the list of properties to exclude from {@link BeanMap#entrySet()}.
	 *
	 * @param keys The list of properties to exclude from the entry set.
	 * @return This object (for method chaining).
	 */
	public BeanFilter<T> setExcludeKeys(LinkedHashSet<String> keys) {
		excludeKeys = keys;
		return this;
	}

	/**
	 * Set the list and order of properties returned by {@link BeanMap#entrySet()}.
	 *
	 * @param keys The set of properties to return in the entry set.
	 * @return This object so that this method can be chained like the {@link ProcessBuilder} class.
	 */
	public BeanFilter<T> setIncludeKeys(String...keys) {
		return setIncludeKeys(new LinkedHashSet<String>(Arrays.asList(keys)));
	}

	/**
	 * Set the list and order of properties returned by {@link BeanMap#entrySet()}.
	 *
	 * @param keys The set of properties to return in the entry set.
	 * @return This object (for method chaining).
	 */
	public BeanFilter<T> setIncludeKeys(LinkedHashSet<String> keys) {
		includeKeys = keys;
		return this;
	}
}
