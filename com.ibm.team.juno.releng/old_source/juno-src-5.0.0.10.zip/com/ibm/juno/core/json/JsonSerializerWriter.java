package com.ibm.juno.core.json;

import java.io.*;

import com.ibm.juno.core.*;

/**
 * Specialized writer for serializing JSON.
 * <p>
 * 	<b>Note:  This class is not intended for external use.</b>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonSerializerWriter extends SerializerWriter {

	private boolean strictMode;

	/**
	 * Constructor.
	 * @param out The writer being wrapped.
	 * @param useIndentation If <jk>true</jk>, tabs will be used in output.
	 * @param useWhitespace If <jk>true</jk>, whitespace will be used in output.
	 * @param quoteChar The quote character to use (i.e. <js>'\''</js> or <js>'"'</js>)
	 * @param strictMode If <jk>true</jk>, JSON attributes will always be quoted.
	 */
	protected JsonSerializerWriter(Writer out, boolean useIndentation, boolean useWhitespace, char quoteChar, boolean strictMode) {
		super(out, useIndentation, useWhitespace, quoteChar);
		this.strictMode = strictMode;
	}

	/**
	 * Serializes the specified object as a JSON string value.
	 * @param o The object being serialized.
	 * @return This object (for method chaining).
	 * @throws IOException Should never happen.
	 */
	public JsonSerializerWriter stringValue(Object o) throws IOException {
		 /*
		  * Fixes up a Java string so that it can be used as a JSON string.<br>
		  * Does the following:<br>
		  * <ul>
		  *  <li> Replaces {@code \r?\n} with {@code \\n}<br>
		  *  <li> Replaces {@code \t} with {@code \\t}<br>
		  *  <li> Replaces {@code '} with {@code \\'}<br>
		  *  <li> Replaces {@code "} with {@code \\"}<br>
		  * </ul>
		  */
		if (o == null)
			return this;
		String s = o.toString();
		boolean doConvert = false;
		for (int i = 0; i < s.length() && ! doConvert; i++) {
			char c = s.charAt(i);
			doConvert |= (c == '\n' || c == '\t' || c == '\b' || c == '\f' || c == '\r' || c == quoteChar || c == '\\');
		}
		q();
		if (! doConvert) {
			out.append(s);
		} else {
			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (c == '\n')
					out.append('\\').append('n');
				else if (c == '\t')
					out.append('\\').append('t');
				else if (c == '\b')
					out.append('\\').append('b');
				else if (c == '\f')
					out.append('\\').append('f');
				else if (c == quoteChar)
					out.append('\\').append(quoteChar);
				else if (c == '\\')
					out.append('\\').append('\\');
				else if (c != '\r')
					out.append(c);
			}
		}
		q();
		return this;
	}

	/**
	 * Serializes the specified object as a JSON attribute name.
	 * @param o The object being serialized.
	 * @return This object (for method chaining).
	 * @throws IOException Should never happen.
	 */
	public JsonSerializerWriter attr(Object o) throws IOException {
		/*
		 * Converts a Java string to an acceptable JSON attribute name. If
		 * useStrictJson is false, then quotes will only be used if the attribute
		 * name consists of only alphanumeric characters.
		 */
		boolean doConvert = strictMode;		// Always convert when in strict mode.

		String s = null;

		// If the attribute is null, it must always be printed as null without quotes.
		if (o == null) {
			s = "null";
			doConvert = false;

		} else {
			s = o.toString();

			// Look for characters that would require the attribute to be quoted.
			if (! doConvert) {
				for (int i = 0; i < s.length() && ! doConvert; i++) {
					char c = s.charAt(i);
					doConvert |= !((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_');
				}
			}

			// If the attribute name is the string "null", then it must be converted to not confuse it with null.
			if (s.equals("null"))
				doConvert = true;
		}

		// If no conversion necessary, just print the attribute as-is.
		if (! doConvert) {
			out.append(s);
			return this;
		}

		if (doConvert)
			stringValue(s);
		else
			q().append(s).q();

		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on SerializerWriter
	//--------------------------------------------------------------------------------

	@Override
	public JsonSerializerWriter cr(int depth) throws IOException {
		super.cr(depth);
		return this;
	}

	@Override
	public JsonSerializerWriter appendln(int indent, String text) throws IOException {
		super.appendln(indent, text);
		return this;
	}

	@Override
	public JsonSerializerWriter appendln(String text) throws IOException {
		super.appendln(text);
		return this;
	}

	@Override
	public JsonSerializerWriter append(int indent, String text) throws IOException {
		super.append(indent, text);
		return this;
	}

	@Override
	public JsonSerializerWriter append(int indent, char c) throws IOException {
		super.append(indent, c);
		return this;
	}

	@Override
	public JsonSerializerWriter s() throws IOException {
		super.s();
		return this;
	}

	@Override
	public JsonSerializerWriter q() throws IOException {
		super.q();
		return this;
	}

	@Override
	public JsonSerializerWriter i(int indent) throws IOException {
		super.i(indent);
		return this;
	}

	@Override
	public JsonSerializerWriter nl() throws IOException {
		super.nl();
		return this;
	}

	@Override
	public JsonSerializerWriter append(Object text) throws IOException {
		super.append(text);
		return this;
	}

	@Override
	public JsonSerializerWriter append(String text) throws IOException {
		super.append(text);
		return this;
	}

	@Override
	public JsonSerializerWriter appendIf(boolean b, String text) throws IOException {
		super.appendIf(b, text);
		return this;
	}

	@Override
	public JsonSerializerWriter appendIf(boolean b, char c) throws IOException {
		super.appendIf(b, c);
		return this;
	}

	@Override
	public JsonSerializerWriter append(char c) throws IOException {
		super.append(c);
		return this;
	}
}
