package com.ibm.juno.core.encoders;

import static javax.servlet.http.HttpServletResponse.*;

import java.io.*;
import java.util.zip.*;

import com.ibm.juno.server.*;

/**
 * Encoder for handling <js>"gzip"</js> encoding and decoding.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class GzipEncoder extends Encoder {

	@Override
	public OutputStream getOutputStream(OutputStream os) throws RestException {
		try {
			return new GZIPOutputStream(os) {
				@Override
				public final void close() throws IOException {
					finish();
					super.close();
				}
			};
		} catch (IOException e) {
			throw new RestException(SC_INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public InputStream getInputStream(InputStream is) throws RestException {
		try {
			return new GZIPInputStream(is);
		} catch (IOException e) {
			throw new RestException(SC_BAD_REQUEST, "Could not parse input as GZIP", e);
		}
	}

	/**
	 * Returns <code>[<js>"gzip"</js>]</code>.
	 */
	@Override
	public String[] getCodings() {
		return new String[]{"gzip"};
	}
}
