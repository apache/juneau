package com.ibm.juno.client;

import java.io.*;

/**
 * Authenticator for performing BASIC HTTP authentication.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("restriction")
public class BasicAuth implements Auth {

	private final String authorization;

	/**
	 * Constructor.
	 * @param user Username.
	 * @param pw Password.
	 */
	public BasicAuth(String user, String pw) {
		try {
			authorization = "Basic " + new sun.misc.BASE64Encoder().encode((user + ":" + pw).getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Adds an <js>"Authorization: Basic xxx"</js> header to all requests.
	 */
	@Override
	public void authenticate(RestClient client) throws RestCallException {
		client.setHeader("Authorization", authorization);
	}
}
