package com.ibm.juno.core.json;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.ClassMetaConst.*;
import static com.ibm.juno.core.serializer.SerializerProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJO metadata to HTTP responses as JSON.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>application/json+schema, text/json+schema</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>application/json</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 *		Produces the JSON-schema for the JSON produced by the {@link JsonSerializer} class with the same properties.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Produces(value={"application/json+schema","text/json+schema"},contentType="application/json")
public class JsonSchemaSerializer extends JsonSerializer {

	/**
	 * Constructor.
	 */
	public JsonSchemaSerializer() {
		setProperty(DETECT_RECURSIONS, true);
	}

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // JsonSerializer
	public void serialize(Object o, JsonSerializerWriter w, SerializerContext ctx) throws IOException, SerializeException {
		if (! (ctx instanceof JsonSerializerContext))
			throw new SerializeException("Context is not an instance of JsonSerializerContext");
		ObjectMap schema = getSchema(beanContext.getClassMetaForObject(o), ctx, "root", null);
		serializeAnything(w, schema, null, (JsonSerializerContext)ctx, "root", null);
	}

	/*
	 * Creates a schema representation of the specified class type.
	 *
	 * @param eType The class type to get the schema of.
	 * @param ctx Serialize context used to prevent infinite loops.
	 * @param attrName The name of the current attribute.
	 * @return A schema representation of the specified class.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private ObjectMap getSchema(ClassMeta<?> eType, SerializerContext ctx, String attrName, String[] pNames) throws SerializeException {
		try {

			ObjectMap out = new ObjectMap();

			if (eType == null)
				eType = OBJECT;

			ClassMeta<?> aType;			// The actual type (will be null if recursion occurs)
			ClassMeta<?> gType;			// The generic type

			aType = ctx.push(attrName, eType, null);

			gType = eType.getFilteredClassMeta();
			String type = null;

			if (gType.isEnum() || gType.isCharSequence() || gType.isChar())
				type = "string";
			else if (gType.isNumber())
				type = "number";
			else if (gType.isBoolean())
				type = "boolean";
			else if (gType.isBean() || gType.isMap())
				type = "object";
			else if (gType.isCollection() || gType.isArray())
				type = "array";
			else
				type = "any";

			out.put("type", type);
			out.put("description", eType.toString());
			PojoFilter f = eType.getPojoFilter();
			if (f != null)
				out.put("filter", f);

			if (aType != null) {
				if (gType.isEnum())
					out.put("enum", getEnumStrings((Class<Enum<?>>)gType.getInnerClass()));
				else if (gType.isCollection() || gType.isArray()) {
					ClassMeta componentType = gType.getElementType();
					if (gType.isCollection() && Set.class.isAssignableFrom(gType.getInnerClass()))
						out.put("uniqueItems", true);
					out.put("items", getSchema(componentType, ctx, "items", pNames));
				} else if (gType.isBean()) {
					ObjectMap properties = new ObjectMap();
					BeanMeta bm = beanContext.getBeanMeta(gType.getInnerClass());
					if (pNames != null)
						bm = new BeanMetaFiltered(bm, pNames);
					for (Iterator<BeanPropertyMeta<?>> i = bm.getMetaProperties().iterator(); i.hasNext();) {
						BeanPropertyMeta p = i.next();
						properties.put(p.getName(), getSchema(p.getClassMeta(), ctx, p.getName(), p.getProperties()));
					}
					out.put("properties", properties);
				}
			}
			ctx.pop();
			return out;
		} catch (Throwable e) {
			throw new SerializeException("Exception occured trying to process object of type '%s'", eType).setCause(e);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List<String> getEnumStrings(Class<? extends Enum> c) {
		List<String> l = new LinkedList<String>();
		try {
			for (Object e : EnumSet.allOf(c))
				l.add(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}


	@Override // Lockable
	public JsonSchemaSerializer lock() {
		super.lock();
		return this;
	}
}
