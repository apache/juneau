package com.ibm.juno.core.json;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;

/**
 * Configurable properties on the {@link JsonParser} class.
 * <p>
 * 	Use the {@link JsonParser#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link JsonParser}.
 * <ul>
 * 	<li>{@link ParserProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonParserProperties implements Cloneable {

	/**
	 * Set strict mode ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * When in strict mode, parser throws exceptions on the following invalid JSON syntax:
	 * <ul>
	 * 	<li>Unquoted attributes.
	 * 	<li>Missing attribute values.
	 * 	<li>Concatenated strings.
	 * 	<li>Javascript comments.
	 * </ul>
	 */
	public static final String STRICT_MODE = "JsonParser.strictMode";

	private boolean
		strictMode = false;

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	protected boolean setProperty(String property, Object value) throws LockedException {
		BeanContext bc = BeanContext.DEFAULT;
		if (property.equals(STRICT_MODE))
			strictMode = bc.convertToType(value, Boolean.class);
		else
			return false;
		return true;
	}

	/**
	 * Returns the current {@link #STRICT_MODE} value.
	 * @return The current {@link #STRICT_MODE} value.
	 */
	public boolean isStrictMode() {
		return strictMode;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override
	public JsonParserProperties clone() {
		try {
			return (JsonParserProperties)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen.
		}
	}
}
