package com.ibm.juno.core.serializer;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;

/**
 * Subclass of {@link Serializer} for character-based serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all character-based serializers.
 * 	It has 3 abstract methods to implement...
 * <ul>
 * 	<li>{@link #createContext(Object, ObjectMap, String, String)}
 * 	<li>{@link #createWriter(Writer, SerializerContext)}
 * 	<li>{@link #serialize(Object, Writer, SerializerContext)}
 * </ul>
 *
 *
 * <h6 class='topic'>@Produces annotation</h6>
 * <p>
 * 	The media types that this serializer can produce is specified through the {@link Produces @Produces} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()}
 * 		and {@link #getResponseContentType()} methods.
 *
 * @param <W> The writer class type.
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class WriterSerializer<W extends Writer> extends Serializer<W> {


	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	public abstract void serialize(Object o, W out, SerializerContext ctx) throws IOException, SerializeException;


	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	/**
	 * Wraps the specified writer in a language-specific writer.
	 *
	 * @param w The writer being wrapped.
	 * @param ctx The serialize context.  Can be <jk>null</jk>.
	 * @return The wrapped writer.
	 */
	@SuppressWarnings("unchecked")
	public W createWriter(Writer w, SerializerContext ctx) {

		// Default implementation simply returns the original writer.
		return (W)w;
	}

	/**
	 * Same as {@link WriterSerializer#serialize(Object, Writer, SerializerContext)} except serializes to a <code>String</code>.
	 *
	 * @param o The object to serialize.
	 * @param ctx The serialize context.  Can be <jk>null</jk>.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o, SerializerContext ctx) throws SerializeException {
		try {
			StringWriter w = new StringWriter();
			W writer = createWriter(w, ctx);
			serialize(o, writer, ctx);
			return w.toString();
		} catch (IOException e) { // Shouldn't happen.
			throw new RuntimeException(e);
		}
	}

	/**
	 * Same as {@link #serialize(Object, SerializerContext)} with <jk>null</jk> context.
	 *
	 * @param o The object to serialize.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o) throws SerializeException {
		SerializerContext ctx = createContext(o, null, null, null);
		return serialize(o, ctx);
	}

	/**
	 * Convenience method for serializing directly to a writer.
	 *
	 * @param o The object to serialize.
	 * @param w The writer to send the output to.
	 * @throws IOException If a problem occurred trying to send output to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public void serialize(Object o, Writer w) throws SerializeException, IOException {
		SerializerContext ctx = createContext(o, null, null, null);
		W writer = createWriter(w, ctx);
		serialize(o, writer, ctx);
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Serializer
	public SerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) throws SerializeException {
		return super.createContext(o, properties, mediaType, charset);
	}


	@Override // CoreApi
	public WriterSerializer<W> addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // CoreApi
	public WriterSerializer<W> addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public WriterSerializer<W> addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> WriterSerializer<W> addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // Lockable
	public WriterSerializer<W> lock() {
		super.lock();
		return this;
	}

	@Override // CoreApi
	public WriterSerializer<W> clone() throws CloneNotSupportedException {
		WriterSerializer<W> c = (WriterSerializer<W>)super.clone();
		return c;
	}
}
