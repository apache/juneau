package com.ibm.juno.core.urlencoding;

import java.io.*;

import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.utils.*;

/**
 * Specialized writer for serializing URL-Encoding.
 * <p>
 * 	<b>Note:  This class is not intended for external use.</b>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingSerializerWriter extends SerializerWriter {

	private final boolean useTypeFlags;

	// Characters that do not need to be URL-encoded
	private static final CharSet unencodedChars = new CharSet("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.!~*'()\\");

	// Characters that need to be preceeded with an escape character.
	private static final CharSet escapedChars = new CharSet("\\&,{}[]=()");

	// Reusable byte array buffer for writing %xx sequences.
	ByteArrayOutputStream buf = new ByteArrayOutputStream(10);


	/**
	 * Constructor.
	 * @param out The writer being wrapped.
	 * @param useIndentation If <jk>true</jk>, tabs will be used in output.
	 * @param useWhitespace If <jk>true</jk>, whitespace will be used in output.
	 * @param useTypeFlags If <jk>true</jk>, <code>Booleans</code> and <code>Numbers</code> will be postfixed with type flags (e.g. <js>"^b"</js>, <js>"^i"</js>).
	 * @param uriContext The web application context path (e.g. "/contextRoot").
	 * @param uriAuthority The web application URI authority (e.g. "http://hostname:9080")
	 */
	protected UrlEncodingSerializerWriter(Writer out, boolean useIndentation, boolean useWhitespace, boolean useTypeFlags, String uriContext, String uriAuthority) {
		super(out, useIndentation, useWhitespace, '\'', uriContext, uriAuthority);
		this.useTypeFlags = useTypeFlags;
	}

	/**
	 * Serializes the specified object as a JSON string value.
	 * @param o The object being serialized.
	 * @return This object (for method chaining).
	 * @throws IOException Should never happen.
	 */
	public UrlEncodingSerializerWriter appendObject(Object o, boolean quoteEmptyStrings) throws IOException {

		boolean needsTypeFlag = false;
		if (o == null)
			o = "\u0000";
		else if (o.equals("\u0000"))
			needsTypeFlag = true;

		String s = o.toString();
		if (s.isEmpty() && quoteEmptyStrings)
			needsTypeFlag = true;

		if (useTypeFlags && (o instanceof Boolean || o instanceof Number))
			needsTypeFlag = true;

		if (needsTypeFlag)
			append('(').append(getTypeFlag(o)).append(')');

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (escapedChars.contains(c))
				append('\\');
			if (unencodedChars.contains(c))
				append(c);
			else {
				if (c == ' ')
					append('+');
				else {
					int d = -1;
					if (c >= 0xD800 && c <= 0xDBFF) {
						d = (i+1 < s.length() ? s.charAt(i+1) : -1);
						if (d >= 0xDC00 && d <= 0xDFFF) {
							i++;
						} else {
							d = -1;
						}
					}
					appendEncoded(c, d);
				}
			}
		}

		return this;
	}

	private final char getTypeFlag(Object o) {
		if (o instanceof Boolean)
			return 'b';
		if (o instanceof Number) {
			if (o instanceof Double)
				return 'd';
			if (o instanceof Float)
				return 'f';
			if (o instanceof Long)
				return 'l';
			return 'i';
		}
		return 's';
	}

	/**
	 * Serializes the specified object as a JSON attribute name.
	 * @param o The object being serialized.
	 * @return This object (for method chaining).
	 * @throws IOException Should never happen.
	 */
	public UrlEncodingSerializerWriter attr(Object o) throws IOException {
		appendObject(o, false);
		return this;
	}


   private static final int caseDiff = 'a' - 'A';

	private void appendEncoded(int c, int d) throws IOException {

		try {
			Writer writer = new OutputStreamWriter(buf, "UTF-8");
			writer.write(c);
			if (d != -1)
				writer.write(d);
			writer.flush();
		} catch (IOException e) {
			buf.reset();
			throw e;
		}

		byte[] ba = buf.toByteArray();
		for (int j = 0; j < ba.length; j++) {
			append('%');
			char c2 = Character.forDigit((ba[j] >> 4) & 0xF, 16);
			if (Character.isLetter(c2))
				c2 -= caseDiff;
			append(c2);
			c2 = Character.forDigit(ba[j] & 0xF, 16);
			if (Character.isLetter(c2))
				c2 -= caseDiff;
			append(c2);
		}

		buf.reset();
	}

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override
	public SerializerWriter appendUri(Object uri) throws IOException {
		String s = uri.toString();
		if (s.indexOf(':') == -1) {
			StringBuilder sb = new StringBuilder(uriAuthority);
			if ((! s.startsWith("/")) && ! uriContext.isEmpty())
				sb.append(uriContext).append("/");
			sb.append(s);
			s = sb.toString();
		}
		return appendObject(s, true);
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter cr(int depth) throws IOException {
		super.cr(depth);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter appendln(int indent, String text) throws IOException {
		super.appendln(indent, text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter appendln(String text) throws IOException {
		super.appendln(text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(int indent, String text) throws IOException {
		super.append(indent, text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(int indent, char c) throws IOException {
		super.append(indent, c);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter s() throws IOException {
		super.s();
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter q() throws IOException {
		super.q();
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter i(int indent) throws IOException {
		super.i(indent);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter nl() throws IOException {
		super.nl();
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(Object text) throws IOException {
		super.append(text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(String text) throws IOException {
		super.append(text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter appendIf(boolean b, String text) throws IOException {
		super.appendIf(b, text);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter appendIf(boolean b, char c) throws IOException {
		super.appendIf(b, c);
		return this;
	}

	@Override // SerializerWriter
	public UrlEncodingSerializerWriter append(char c) throws IOException {
		super.append(c);
		return this;
	}
}
