package com.ibm.juno.core.urlencoding;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;

/**
 * Configurable properties on the {@link UrlEncodingSerializer} class.
 * <p>
 * 	Use the {@link UrlEncodingSerializer#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link UrlEncodingSerializer}.
 * <ul>
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingSerializerProperties implements Cloneable {

	/**
	 * Use type flags on booleans and numbers ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, booleans and numbers will be postfixed with <js>"^X"</js> flags to
	 * 	prevent confusing them with strings with values such as <js>"true"</js> and <js>"123"</js>.
	 * <p>
	 * Possible flags:
	 * <ul>
	 * 	<li><code>^b</code> - boolean.
	 * 	<li><code>^s</code> - string.
	 * 	<li><code>^i</code> - integer/short.
	 * 	<li><code>^f</code> - float.
	 * 	<li><code>^d</code> - double.
	 * </ul>
	 * Examples when enabled:
	 * <ul>
	 * 	<li><code>{foo:<jk>true</jk>}</code> -> <code>&foo=true^b</code>
	 * 	<li><code>{foo:123}</code> -> <code>&foo=123^i</code>
	 * 	<li><code>{foo:1.1e-10}</code> -> <code>&foo=1.1e-10^d</code>
	 * </ul>
	 */
	public static final String USE_TYPE_FLAGS = "UrlEncodingSerializer.useTypeFlags";

	/**
	 * Use whitespace in output ({@link Boolean}, default=<jk>false</jk>).
	 * <p>
	 * If <jk>true</jk>, whitespace is added to the output to improve readability.
	 */
	public static final String USE_WHITESPACE = "UrlEncodingSerializer.useWhitespace";

	boolean
		useTypeFlags = false,
		useWhitespace = false;

	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		BeanContext bc = BeanContext.DEFAULT;
		if (property.equals(USE_TYPE_FLAGS))
			useTypeFlags = bc.convertToType(value, Boolean.class);
		else if (property.equals(USE_WHITESPACE))
			useWhitespace = bc.convertToType(value, Boolean.class);
		else
			return false;
		return true;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Cloneable
	public UrlEncodingSerializerProperties clone() {
		try {
			return (UrlEncodingSerializerProperties)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
