package com.ibm.juno.core.jena;

import static com.ibm.juno.core.ClassMetaConst.*;
import static com.ibm.juno.core.jena.Constants.*;
import static com.ibm.juno.core.jena.RdfProperties.*;
import static com.ibm.juno.core.utils.StringUtils.*;
import static com.ibm.juno.core.xml.XmlUtils.*;

import java.io.*;
import java.util.*;

import com.hp.hpl.jena.rdf.model.*;
import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.xml.*;

/**
 * Parses RDF into POJOs.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	Refer to <a class='doclink' href='package-summary.html#ParserConfigurableProperties'>Configurable Properties</a>
 * 		for the entire list of configurable properties.
 *
 *
 * <h6 class='topic'>Behavior-specific subclasses</h6>
 * <p>
 * 	The following direct subclasses are provided for language-specific parsers:
 * <ul>
 * 	<li>{@link RdfParser.Xml} - RDF/XML and RDF/XML-ABBREV.
 * 	<li>{@link RdfParser.NTriple} - N-TRIPLE.
 * 	<li>{@link RdfParser.Turtle} - TURTLE.
 * 	<li>{@link RdfParser.N3} - N3.
 * </ul>
 *
 *
 * <h6 class='topic'>Additional Information</h6>
 * <p>
 * 	See <a class='doclink' href='package-summary.html#TOC'>RDF Overview</a> for an overview of RDF support in Juno.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Consumes(value="text/xml+rdf")
public class RdfParser extends ReaderParser {

	/** Default XML parser, all default settings.*/
	public static final RdfParser DEFAULT_XML = new RdfParser.Xml().lock();

	/** Default Turtle parser, all default settings.*/
	public static final RdfParser DEFAULT_TURTLE = new RdfParser.Turtle().lock();

	/** Default N-Triple parser, all default settings.*/
	public static final RdfParser DEFAULT_NTRIPLE = new RdfParser.NTriple().lock();

	/** Default N3 parser, all default settings.*/
	public static final RdfParser DEFAULT_N3 = new RdfParser.N3().lock();


	/** Consumes RDF/XML input */
	@Consumes("text/xml+rdf")
	public static class Xml extends RdfParser {
		/** Constructor */
		public Xml() {
			setProperty(RDF_LANGUAGE, LANG_RDF_XML);
		}
	}

	/** Consumes N-Triple input */
	@Consumes(value="text/n-triple")
	public static class NTriple extends RdfParser {
		/** Constructor */
		public NTriple() {
			setProperty(RDF_LANGUAGE, LANG_NTRIPLE);
		}
	}

	/** Consumes Turtle input */
	@Consumes(value="text/turtle")
	public static class Turtle extends RdfParser {
		/** Constructor */
		public Turtle() {
			setProperty(RDF_LANGUAGE, LANG_TURTLE);
		}
	}

	/** Consumes N3 input */
	@Consumes(value="text/n3")
	public static class N3 extends RdfParser {
		/** Constructor */
		public N3() {
			setProperty(RDF_LANGUAGE, LANG_N3);
		}
	}


	/** Jena parser properties currently set on this parser. */
	protected transient RdfParserProperties rpp = new RdfParserProperties();


	@SuppressWarnings({ "unchecked" })
	@Override
	public <T> T parse(Reader in, ClassMeta<T> type, ParserContext ctx) throws ParseException, IOException {

		if (! (ctx instanceof RdfParserContext))
			throw new ParseException("Context is not an instance of RdfParserContext");

		type = beanContext.normalizeClassMeta(type);
		RdfParserContext ctx2 = (RdfParserContext)ctx;

		Model model = ctx2.model;
		RDFReader r = ctx2.reader;
		r.read(model, in, "http://unknown/");
		List<Resource> roots = getRoots(model, ctx2);
		if (roots.isEmpty())
			return null;
		if (roots.size() > 1)
			throw new ParseException("Too many root nodes found in model:  %s", roots.size());
		Resource r2 = roots.get(0);

		Object o = null;

		try {
			o = parseAnything(type, r2, null, ctx2);
		} catch (ParseException e) {
			throw e;
		} catch (Exception e) {
			throw new ParseException(e);
		}

		return (T)o;
	}

	@Override // Parser
	public RdfParserContext createContext(ClassMeta<?> type, ObjectMap properties, String mediaType, String charset) {
		return new RdfParserContext(type, beanContext, pp, rpp, properties);
	}

	/*
	 * Finds the roots in the model using either the "root" property to identify it,
	 * 	or by resorting to scanning the model for all nodes with no incoming predicates.
	 */
	private List<Resource> getRoots(Model m, RdfParserContext ctx) {
		List<Resource> l = new LinkedList<Resource>();

		// First try to find the root using the "http://www.ibm.com/juno/root" property.
		Property root = m.createProperty(ctx.junoNs.getUri(), JUNO_NS_ROOT);
		for (ResIterator i  = m.listResourcesWithProperty(root); i.hasNext();)
			l.add(i.next());

		if (! l.isEmpty())
			return l;

		// Otherwise, we need to find all resources that aren't objects.
		Set<RDFNode> objects = new HashSet<RDFNode>();
		for (NodeIterator i = m.listObjects(); i.hasNext();) {
			RDFNode n = i.next();
			if (n.isResource())
				objects.add(n);
		}
		for (ResIterator i = m.listSubjects(); i.hasNext();) {
			Resource r = i.next();
			if (! objects.contains(r))
				l.add(r);
		}
		return l;
	}

	private <T> BeanMap<T> parseIntoBeanMap(Resource r2, BeanMap<T> m, RdfParserContext ctx) throws ParseException {
		if (m.hasBeanUri() && r2.getURI() != null)
			m.putBeanUri(r2.getURI());
		Property subTypeIdProperty = null;
		BeanPropertyMeta<T> stp = m.getSubTypeIdProperty();
		if (stp != null) {
			subTypeIdProperty = ctx.getProperty(stp.getName());
			Statement st = r2.getProperty(subTypeIdProperty);
			if (st == null)
				throw new ParseException("Could not find subtype ID property for bean of type '%s'", m.getClassMeta());
			String subTypeId = st.getLiteral().getString();
			stp.set(m, subTypeId);
		}
		for (StmtIterator i = r2.listProperties(); i.hasNext();) {
			Statement st = i.next();
			Property p = st.getPredicate();
			if (p.equals(subTypeIdProperty))
				continue;
			String key = XmlUtils.decode(p.getLocalName());
			BeanPropertyMeta<T> pMeta = m.getPropertyMeta(key);
			if (pMeta != null) {
				RDFNode o = st.getObject();
				Object val = parseAnything(pMeta.getClassMeta(), o, pMeta, ctx);
				pMeta.set(m, val);
			} else if (! (p.equals(ctx.pRoot) || p.equals(ctx.pClass) || p.equals(subTypeIdProperty))) {
				onUnknownProperty(key, m, -1, -1);
			}
		}
		return m;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private <T> T parseAnything(ClassMeta<T> nt, RDFNode n, BeanPropertyMeta<?> p, RdfParserContext ctx) throws ParseException {

		if (nt == null)
			nt = (ClassMeta<T>)OBJECT;
		PojoFilter<T,Object> filter = (p == null ? null : p.getFilter());
		if (filter == null)
			filter = (PojoFilter<T,Object>)nt.getPojoFilter();
		ClassMeta<?> ft = (p == null ? nt.getFilteredClassMeta() : p.getFilteredClassMeta());

		if (! ft.canCreateNewInstance()) {
			if (n.isResource()) {
				Statement st = n.asResource().getProperty(ctx.pClass);
				if (st != null) {
 					String c = st.getLiteral().getString();
					ft = nt = (ClassMeta<T>)beanContext.getClassMetaFromString(c);
				}
			}
		}

		try {

			Object o = null;
			if (n.isResource() && n.asResource().getURI() != null && n.asResource().getURI().equals(NIL)) {
				// Do nothing.  Leave o == null.
			} else if (ft.isObject()) {
				if (n.isLiteral()) {
					o = n.asLiteral().getValue();
					if (o instanceof String) {
						String s = o.toString();
						s = decode(s);
						if (ctx.trimWhitespace)
							s = s.trim();
						o = s;
					}
				}
				else if (n.isResource()) {
					Resource r = n.asResource();
					if (ctx.wasAlreadyProcessed(r))
						o = r.getURI();
					else if (r.getProperty(ctx.pValue) != null) {
						o = parseAnything(OBJECT, n.asResource().getProperty(ctx.pValue).getObject(), null, ctx);
					} else if (isSeq(r, ctx)) {
						o = new ObjectList();
						Seq seq = r.as(Seq.class);
						parseIntoCollection(seq, (Collection)o, ft.getElementType(), ctx);
					} else {
						// If it has a URI and no child properties, we interpret this as an
						// external resource, and convert it to just a URL.
						String uri = r.getURI();
						if (uri != null && ! r.listProperties().hasNext()) {
							o = r.getURI();
						} else {
							o = new ObjectMap();
							parseIntoMap(r, (Map)o, null, null, ctx);
						}
					}
				} else {
					throw new ParseException("Unrecognized node type '%s' for object", n);
				}
			} else if (ft.isBoolean()) {
				o = beanContext.convertToType(getValue(n, ctx), boolean.class);
			} else if (ft.isCharSequence()) {
				String s = decode(getValue(n, ctx).toString());
				if (ctx.trimWhitespace)
					s = s.trim();
				o = s;
			} else if (ft.isChar()) {
				o = decode(getValue(n, ctx).toString()).charAt(0);
			} else if (ft.isNumber()) {
				o = parseNumber(getValue(n, ctx).toString(), (Class<? extends Number>)ft.getInnerClass());
			} else if (ft.isMap()) {
				Resource r = n.asResource();
				if (ctx.wasAlreadyProcessed(r))
					return null;
				Map m = (ft.canCreateNewInstance() ? (Map)ft.newInstance() : new ObjectMap());
				o = parseIntoMap(r, m, nt.getKeyType(), nt.getValueType(), ctx);
			} else if (ft.isCollection()) {
				o = (ft.canCreateNewInstance() ? (Collection<?>)ft.newInstance() : new ObjectList());
				Resource r = n.asResource();
				if (ctx.wasAlreadyProcessed(r))
					return null;
				if (isSeq(r, ctx)) {
					Seq seq = r.as(Seq.class);
					parseIntoCollection(seq, (Collection)o, ft.getElementType(), ctx);
				} else {
					throw new ParseException("Unrecognized node type '%s' for collection", n);
				}
			} else if (ft.isArray()) {
				ArrayList l = new ArrayList();
				Resource r = n.asResource();
				if (ctx.wasAlreadyProcessed(r))
					return null;
				if (isSeq(r, ctx)) {
					parseIntoCollection(r.as(Seq.class), l, ft.getElementType(), ctx);
				} else {
					throw new ParseException("Unrecognized node type '%s' for array", n);
				}
				o = beanContext.toArray(ft, l);
			} else if (ft.isBean() && ft.canCreateNewInstance()) {
				Resource r = n.asResource();
				if (ctx.wasAlreadyProcessed(r))
					return null;
				BeanMap<?> bm = beanContext.newBeanMap(ft.getInnerClass());
				o = parseIntoBeanMap(r, bm, ctx).getBean();
			} else if (ft.isUri() && n.isResource()) {
				o = ft.newInstance(decode(n.asResource().getURI()));
			} else if (ft.canCreateNewInstanceFromString()) {
				o = ft.newInstance(decode(getValue(n, ctx).toString()));
			} else {
				throw new ParseException("Unrecognized syntax for class type '%s'", ft);
			}

			if (filter != null && o != null)
				o = filter.unfilter(o, nt, beanContext);

			return (T)o;

		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			if (p == null)
				throw new ParseException("Error occurred trying to parse into class '%s'", ft).setCause(e);
			throw new ParseException("Error occurred trying to parse value for bean property '%s' on class '%s'",
				p.getName(), p.getBeanMeta().getClassMeta()
			).setCause(e);
		}
	}

	private boolean isSeq(RDFNode n, RdfParserContext ctx) {
		if (n.isResource()) {
			Statement st = n.asResource().getProperty(ctx.pType);
			if (st != null)
				return SEQ.equals(st.getResource().getURI());
		}
		return false;
	}

	private Object getValue(RDFNode n, RdfParserContext ctx) throws ParseException {
		if (n.isLiteral())
			return n.asLiteral().getValue();
		if (n.isResource()) {
			Statement st = n.asResource().getProperty(ctx.pValue);
			if (st != null) {
				n = st.getObject();
				if (n.isLiteral())
					return n.asLiteral().getValue();
				return parseAnything(OBJECT, st.getObject(), null, ctx);
			}
		}
		throw new ParseException("Unknown value type for node '%s'", n);
	}

	private <K,V> Map<K,V> parseIntoMap(Resource r, Map<K,V> m, ClassMeta<K> keyType, ClassMeta<V> valueType, RdfParserContext ctx) throws ParseException {
		// Add URI as "uri" to generic maps.
		if (r.getURI() != null) {
			K uri = convertAttrToType("uri", keyType);
			V value = convertAttrToType(r.getURI(), valueType);
			m.put(uri, value);
		}
		for (StmtIterator i = r.listProperties(); i.hasNext();) {
			Statement st = i.next();
			Property p = st.getPredicate();
			String key = p.getLocalName();
			if (! (key.equals("root") && p.getURI().equals(ctx.junoNs.getUri()))) {
				key = decode(key);
				RDFNode o = st.getObject();
				K key2 = convertAttrToType(key, keyType);
				V value = parseAnything(valueType, o, null, ctx);
				m.put(key2, value);
			}

		}
		// TODO Auto-generated method stub
		return m;
	}


	private <E> Collection<E> parseIntoCollection(Seq seq, Collection<E> l, ClassMeta<E> et, RdfParserContext ctx) throws ParseException {
		for (int i = 1; i <= seq.size(); i++) {
			E e = parseAnything(et, seq.getObject(i), null, ctx);
			l.add(e);
		}
		return l;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // CoreApi
	public RdfParser setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (rpp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // CoreApi
	public RdfParser addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // CoreApi
	public RdfParser addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public RdfParser addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> RdfParser addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // Lockable
	public RdfParser lock() {
		super.lock();
		return this;
	}

	@Override // Lockable
	public RdfParser clone() {
		try {
			RdfParser c = (RdfParser)super.clone();
			c.rpp = rpp.clone();
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
