package com.ibm.juno.core.jso;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.serializer.*;

/**
 * Serializes POJOs to HTTP responses as Java {@link ObjectOutputStream ObjectOutputStreams}.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>application/x-java-serialized-object</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>application/x-java-serialized-object</code>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Produces("application/x-java-serialized-object")
public class JavaSerializedObjectSerializer extends OutputStreamSerializer {

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // OutputStreamSerializer
	public void serialize(Object o, OutputStream out, SerializerContext ctx) throws IOException, SerializeException {
		ObjectOutputStream oos = new ObjectOutputStream(out);
		oos.writeObject(o);
		oos.flush();
		oos.close();
	}

	@Override // Serializer
	public JavaSerializedObjectSerializer clone() {
		try {
			return (JavaSerializedObjectSerializer)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}

	@Override
	public SerializerContext createContext(Object o, ObjectMap properties, String mediaType, String charset) throws SerializeException {
		// This serializer does not use a context object.
		return null;
	}
}
