package com.ibm.juno.core.parser;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.utils.*;

/**
 * Reader parsers with extended parser methods.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	These are special-purpose methods used for various purposes within the Juno framework.
 * 	See the individual method details for more information.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class ExtendedReaderParser extends ReaderParser {

	/**
	 * Parses the contents of the specified reader and loads the results into the specified map.
	 * <p>
	 * 	Reader must contain something that serializes to a map (such as text containing a JSON object).
	 * <p>
	 * 	Used in the following locations:
	 * <ul>
	 * 	<li>The various character-based constructors in {@link ObjectMap} (e.g. {@link ObjectMap#ObjectMap(CharSequence, DataFormat)}).
	 * </ul>
	 *
	 * @param <K> The key class type.
	 * @param <V> The value class type.
	 * @param in The reader containing the input.
	 * @param m The map being loaded.
	 * @param keyType The class type of the keys, or <jk>null</jk> to default to <code>String.<jk>class</jk></code>.<br>
	 * @param valueType The class type of the values, or <jk>null</jk> to default to whatever is being parsed.<br>
	 * @return The same map that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @throws UnsupportedOperationException If not implemented.
	 */
	public abstract <K,V> Map<K,V> parseIntoMap(Reader in, Map<K,V> m, Type keyType, Type valueType) throws ParseException, IOException;

	/**
	 * Parses the contents of the specified reader and loads the results into the specified collection.
	 * <p>
	 * 	Used in the following locations:
	 * <ul>
	 * 	<li>The various character-based constructors in {@link ObjectList} (e.g. {@link ObjectList#ObjectList(CharSequence, DataFormat)}.
	 * </ul>
	 *
	 * @param <E> The element class type.
	 * @param in The reader containing the input.
	 * @param c The collection being loaded.
	 * @param elementType The class type of the elements, or <jk>null</jk> to default to whatever is being parsed.
	 * @return The same collection that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @throws UnsupportedOperationException If not implemented.
	 */
	public abstract <E> Collection<E> parseIntoCollection(Reader in, Collection<E> c, Type elementType) throws ParseException, IOException;

	/**
	 * Parses the specified array input with each entry in the object defined by the {@code argTypes}
	 * argument.
	 * <p>
	 * 	Used for converting arrays (e.g. <js>"[arg1,arg2,...]"</js>) into an {@code Object[]} that can be passed
	 * 	to the {@code Method.invoke(target, args)} method.
	 * <p>
	 * 	Used in the following locations:
	 * <ul>
	 * 	<li>Used to parse argument strings in the {@link PojoIntrospector#invokeMethod(Object, String, String)} method.
	 * </ul>
	 *
	 * @param in The input.  Must represent an array.
	 * @param argTypes Specifies the type of objects to create for each entry in the array.
	 * @return An array of parsed objects.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @throws UnsupportedOperationException If not implemented.
	 */
	public abstract Object[] parseArgs(Reader in, ClassMeta<?>[] argTypes) throws ParseException, IOException;
}
