package com.ibm.juno.core.parser;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;


/**
 * Subclass of {@link Parser} for characters-based parsers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all character-based parsers.
 * 	It has 1 abstract method to implement...
 * <ul>
 * 	<li><code>parse(Reader, ClassMeta, ParserContext)</code>
 * </ul>
 *
 *
 * <h6 class='topic'>@Consumes annotation</h6>
 * <p>
 * 	The media types that this parser can handle is specified through the {@link Consumes @Consumes} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()} method.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class ReaderParser extends Parser<Reader> {


	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	public abstract <T> T parse(Reader in, ClassMeta<T> type, ParserContext ctx) throws ParseException, IOException;

	/**
	 * Same as <code>parse(Reader, ClassMeta, ParserContext)</code> except parses from a <code>String</code>.
	 *
	 * @param in The string containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassMetaConst#OBJECT}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @param ctx The runtime context.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 */
	public <T> T parse(CharSequence in, ClassMeta<T> type, ParserContext ctx) throws ParseException {
		if (in == null)
			return null;
		if (ctx == null)
			ctx = createContext(type, null, null, null);
		try {
			return parse(new StringReader(in.toString()), type, ctx);
		} catch (IOException e) {
			throw new ParseException(e); // Shouldn't happen.
		}
	}

	/**
	 * Same as <code>parse(Reader, Class)</code> except parses from a <code>String</code>.
	 *
	 * @param in The string containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassMetaConst#OBJECT}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 */
	public <T> T parse(CharSequence in, Class<T> type) throws ParseException {
		return parse(in, beanContext.getClassMeta(type), null);
	}

	/**
	 * Same as <code>parseMap(Reader, Class, Class, Class)</code> except parses from a <code>String</code>.
	 */
	public <K,V,T extends Map<K,V>> T parseMap(CharSequence in, Class<T> mapClass, Class<K> keyClass, Class<V> valueClass) throws ParseException {
		ClassMeta<T> cm = beanContext.getMapClassMeta(mapClass, keyClass, valueClass);
		return parse(in, cm, null);
	}

	/**
	 * Same as <code>parseCollection(Reader, Class, Class)</code> except parses from a <code>String</code>.
	 */
	public <E,T extends Collection<E>> T parseCollection(CharSequence in, Class<T> collectionClass, Class<E> entryClass) throws ParseException {
		ClassMeta<T> cm = beanContext.getCollectionClassMeta(collectionClass, entryClass);
		return parse(in, cm, null);
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Parser
	public ParserContext createContext(ClassMeta<?> type, ObjectMap properties, String mediaType, String charset) throws ParseException {
		return super.createContext(type, properties, mediaType, charset);
	}

	@Override // Parser
	public ReaderParser setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	@Override // CoreApi
	public ReaderParser setProperties(ObjectMap properties) throws LockedException {
		super.setProperties(properties);
		return this;
	}

	@Override // CoreApi
	public ReaderParser addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // CoreApi
	public ReaderParser addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public ReaderParser addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> ReaderParser addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}


	@Override // Lockable
	public ReaderParser lock() {
		super.lock();
		return this;
	}

	@Override // Lockable
	public ReaderParser clone() throws CloneNotSupportedException {
		return (ReaderParser)super.clone();
	}
}
