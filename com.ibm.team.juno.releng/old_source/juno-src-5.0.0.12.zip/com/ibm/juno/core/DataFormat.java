package com.ibm.juno.core;

import com.ibm.juno.core.html.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.core.xml.*;

/**
 * Enumerates all currently implemented parsers used by the {@link JsonMap} and {@link JsonList} classes.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public enum DataFormat {

	/** JSON format */
	JSON(JsonParser.DEFAULT),

	/** Juno-generated XML format */
	XML(XmlParser.DEFAULT),

	/** HTML format */
	HTML(HtmlParser.DEFAULT),

	/** URL encoding format */
	URLENCODING(UrlEncodingParser.DEFAULT);

	private Parser parser;

	private DataFormat(Parser parser) {
		this.parser = parser;
	}

	/**
	 * Returns the default {@link Parser} associated with this data format.
	 *
	 * @return The default parser.
	 */
	public Parser getParser() {
		return parser;
	}
}
