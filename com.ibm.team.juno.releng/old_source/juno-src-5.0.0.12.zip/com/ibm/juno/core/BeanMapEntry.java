package com.ibm.juno.core;

import java.util.*;

/**
 * Represents a single entry in a bean map.
 * <p>
 * 	This class can be used to get and set property values on a bean, or to get metadata on a property.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Construct a new bean</jc>
 * 	Person p = <jk>new</jk> Person();
 *
 * 	<jc>// Wrap it in a bean map</jc>
 * 	BeanMap&lt;Person&gt; b = BeanContext.<jsf>DEFAULT</jsf>.forBean(p);
 *
 * 	<jc>// Get a reference to the birthDate property</jc>
 * 	BeanMapEntry birthDate = b.getProperty(<js>"birthDate"</js>);
 *
 * 	<jc>// Set the property value</jc>
 * 	birthDate.setValue(<jk>new</jk> Date(1, 2, 3, 4, 5, 6));
 *
 * 	<jc>// Or if the DateFilter.DEFAULT_ISO8601DT is registered with the bean context, set a filtered value</jc>
 * 	birthDate.setFilteredValue(<js>"'1901-03-03T04:05:06-5000'"</js>);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 *
 * @param <T> The bean type.
 */
public class BeanMapEntry<T> implements Map.Entry<String,Object> {
	private final BeanMap<T> beanMap;
	private BeanPropertyMeta<T> meta;

	/**
	 * Constructor.
	 * @param beanMap The bean map that this entry belongs to.
	 * @param property The bean property.
	 */
	protected BeanMapEntry(BeanMap<T> beanMap, BeanPropertyMeta<T> property) {
		this.beanMap = beanMap;
		this.meta = property;
	}

	/**
	 * Returns the name of this property.
	 */
	@Override
	public String getKey() {
		return meta.getName();
	}

	/**
	 * Returns the value of this property.
	 */
	@Override
	public Object getValue() {
		return meta.get(this.beanMap);
	}

	/**
	 * Returns the filtered value of this property.
	 *
	 * @return The filtered value of this property.
	 */
	public Object getFilteredValue() {
		return meta.getFiltered(this.beanMap);
	}

	/**
	 * Sets the value of this property.
	 * <p>
	 * If the property is an array of type {@code X}, then the value can be a {@code Collection<X>} or {@code X[]} or {@code Object[]}.
	 * <p>
	 * If the property is a bean type {@code X}, then the value can either be an {@code X} or a {@code Map}.
	 *
	 * @return  The set value after it's been converted.
	 */
	@Override
	public Object setValue(Object value) {
		return meta.set(this.beanMap, value);
	}

	/**
	 * Sets the filtered value of this property.
	 *
	 * @param value The filtered value to set the property to.
	 * @return  The set value after it's been converted.
	 */
	public Object setFilteredValue(Object value) {
		return meta.setFiltered(this.beanMap, value);
	}

	/**
	 * Returns the bean map that contains this property.
	 *
	 * @return The bean map that contains this property.
	 */
	public BeanMap<T> getBeanMap() {
		return this.beanMap;
	}

	/**
	 * Returns the metadata about this bean property.
	 *
	 * @return Metadata about this bean property.
	 */
	public BeanPropertyMeta<T> getMeta() {
		return this.meta;
	}

	@Override
	public String toString() {
		return this.getKey() + "=" + this.getValue();
	}
}