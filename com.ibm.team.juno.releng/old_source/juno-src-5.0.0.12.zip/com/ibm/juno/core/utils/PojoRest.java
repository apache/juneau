package com.ibm.juno.core.utils;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static java.net.HttpURLConnection.*;

import java.lang.reflect.*;
import java.util.*;

import com.ibm.juno.core.*;

/**
 * Provides the ability to perform standard REST operations (GET, PUT, POST, DELETE) against
 * nodes in a POJO model.  Nodes in the POJO model are addressed using URLs.
 * <p>
 * 	A POJO model is defined as a tree model where nodes consist of consisting of the following:
 * 	<ul>
 * 		<li>{@link Map Maps} and Java beans representing JSON objects.
 * 		<li>{@link Collection Collections} and arrays representing JSON arrays.
 * 		<li>Java beans.
 * 	</ul>
 * <p>
 * 	Leaves of the tree can be any type of object.
 * <p>
 * 	Use {@link #get(String) get()} to retrieve an element from a JSON tree.<br>
 * 	Use {@link #put(String,Object) put()} to create (or overwrite) an element in a JSON tree.<br>
 * 	Use {@link #post(String,Object) post()} to add an element to a list in a JSON tree.<br>
 * 	Use {@link #delete(String) delete()} to remove an element from a JSON tree.<br>
 * <p>
 * 	Leading slashes in URLs are ignored.  So <js>"/xxx/yyy/zzz"</js> and <js>"xxx/yyy/zzz"</js> are considered identical.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Construct an unstructured POJO model</jc>
 * 	JsonMap m = <jk>new</jk> JsonMap(<js>""</js>
 * 		+ <js>"{"</js>
 * 		+ <js>"	name:'John Smith', "</js>
 * 		+ <js>"	address:{ "</js>
 * 		+ <js>"		streetAddress:'21 2nd Street', "</js>
 * 		+ <js>"		city:'New York', "</js>
 * 		+ <js>"		state:'NY', "</js>
 * 		+ <js>"		postalCode:10021 "</js>
 * 		+ <js>"	}, "</js>
 * 		+ <js>"	phoneNumbers:[ "</js>
 * 		+ <js>"		'212 555-1111', "</js>
 * 		+ <js>"		'212 555-2222' "</js>
 * 		+ <js>"	], "</js>
 * 		+ <js>"	additionalInfo:null, "</js>
 * 		+ <js>"	remote:false, "</js>
 * 		+ <js>"	height:62.4, "</js>
 * 		+ <js>"	'fico score':' &gt; 640' "</js>
 * 		+ <js>"} "</js>
 * 	);
 *
 * 	<jc>// Wrap Map inside a PojoRest object</jc>
 * 	PojoRest johnSmith = <jk>new</jk> PojoRest(m);
 *
 * 	<jc>// Get a simple value at the top level</jc>
 * 	<jc>// "John Smith"</jc>
 * 	String name = johnSmith.getString(<js>"name"</js>);
 *
 * 	<jc>// Change a simple value at the top level</jc>
 * 	johnSmith.put(<js>"name"</js>, <js>"The late John Smith"</js>);
 *
 * 	<jc>// Get a simple value at a deep level</jc>
 * 	<jc>// "21 2nd Street"</jc>
 * 	String streetAddress = johnSmith.getString(<js>"address/streetAddress"</js>);
 *
 * 	<jc>// Set a simple value at a deep level</jc>
 * 	johnSmith.put(<js>"address/streetAddress"</js>, <js>"101 Cemetery Way"</js>);
 *
 * 	<jc>// Get entries in a list</jc>
 * 	<jc>// "212 555-1111"</jc>
 * 	String firstPhoneNumber = johnSmith.getString(<js>"phoneNumbers/0"</js>);
 *
 * 	<jc>// Add entries to a list</jc>
 * 	johnSmith.post(<js>"phoneNumbers"</js>, <js>"212 555-3333"</js>);
 *
 * 	<jc>// Delete entries from a model</jc>
 * 	johnSmith.delete(<js>"fico score"</js>);
 *
 * 	<jc>// Add entirely new structures to the tree</jc>
 * 	JsonMap medicalInfo = new JsonMap(<js>""</js>
 * 		+ <js>"{"</js>
 * 		+ <js>"	currentStatus: 'deceased',"</js>
 * 		+ <js>"	health: 'non-existent',"</js>
 * 		+ <js>"	creditWorthiness: 'not good'"</js>
 * 		+ <js>"}"</js>
 * 	);
 * 	johnSmith.put(<js>"additionalInfo/medicalInfo"</js>, medicalInfo);
 * <p>
 * 	In the special case of collections/arrays of maps/beans, a special XPath-like selector notation
 * 	can be used in lieu of index numbers on GET requests to return a map/bean with a specified attribute value.<br>
 * 	The syntax is {@code @attr=val}, where attr is the attribute name on the child map, and val is the matching value.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Get map/bean with name attribute value of 'foo' from a list of items</jc>
 * 	Map m = pojoRest.getMap(<js>"/items/@name=foo"</js>);
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings({"unchecked","rawtypes"})
public class PojoRest {

	/** The list of possible request types. */
	private static final int GET=1, PUT=2, POST=3, DELETE=4;

	/** The bean context used to access beans in the model. */
	private BeanContext beanContext;

	private PojoIntrospector pojoIntrospector;

	/** If true, the root cannot be overwritten */
	private boolean rootLocked = false;

	/** The root of the model. */
	private JsonNode root;

	/**
	 * Create a new instance of a REST interface over the specified object.
	 * <p>
	 * 	Uses {@link BeanContext#DEFAULT} for working with Java beans.
	 *
	 * @param o The object to be wrapped.
	 */
	public PojoRest(Object o) {
		this(o, BeanContext.DEFAULT);
	}

	/**
	 * Create a new instance of a REST interface over the specified object.
	 * <p>
	 * 	Use this constructor if you want to provide a different {@link BeanContext} other than the default.
	 *
	 * @param o The object to be wrapped.
	 * @param beanContext The bean context to use for accessing beans as maps.
	 */
	public PojoRest(Object o, BeanContext beanContext) {
		this.beanContext = beanContext;
		// Make a node out of the root object.
		this.root = new JsonNode(null, null, o, ClassType.OBJECT);
	}

	/**
	 * Create a new instance of a REST interface over the specified object.
	 * <p>
	 * 	The parser is used as the bean context.
	 * <p>
	 * 	You must use this constructor if you want to use the {@link #invokeMethod(String, String, String)}
	 * 	or {@link #getPublicMethods(String)} methods.
	 *
	 * @param o The object to be wrapped.
	 * @param parser The parser to use for accessing beans as maps and creating new beans.
	 */
	public PojoRest(Object o, Parser parser) {
		this(o, parser.getBeanContext());
		this.pojoIntrospector = new PojoIntrospector(parser);
	}

	/**
	 * Call this method to prevent the root object from being overwritten on put("", xxx); calls.
	 *
	 * @param rootLocked The new flag value.
	 * @return This object (for method chaining).
	 */
	public PojoRest setRootLocked(boolean rootLocked) {
		this.rootLocked = rootLocked;
		return this;
	}

	/**
	 * The root object that was passed into the constructor of this method.
	 *
	 * @return The root object.
	 */
	public Object getRootObject() {
		return (root == null ? null : root.o);
	}

	/**
	 * Retrieves the element addressed by the URL.
	 *
	 * @param url The URL of the element to retrieve.
	 * 		If null or blank, returns the root.
	 * @return The addressed element, or null if that element does not exist in the tree.
	 */
	public Object get(String url) {
		return service(GET, url, null);
	}

	/**
	 * Retrieves the element addressed by the URL as the specified object type.
	 * <p>
	 * Will convert object to the specified type per {@link BeanContext#convertToType(Object, ClassType)}.
	 * @param <T> The specified object type.
	 *
	 * @param url The URL of the element to retrieve.
	 * 		If null or blank, returns the root.
	 * @param type The specified object type.
	 * @return The addressed element, or null if that element does not exist in the tree.
	 */
	public <T> T get(String url, Class<T> type) {
		return beanContext.convertToType(service(GET, url, null), type);
	}

	/**
	 * Executes the specified method with the specified parameters on the specified object.
	 *
	 * @param url The URL of the element to retrieve.
	 * @param method The method signature.
	 * 	<p>
	 * 		Can be any of the following formats:
	 * 	</p>
	 * 	<ul>
	 * 		<li>Method name only.  e.g. <js>"myMethod"</js>.
	 * 		<li>Method name with class names.  e.g. <js>"myMethod(String,int)"</js>.
	 * 		<li>Method name with fully-qualified class names.  e.g. <js>"myMethod(java.util.String,int)"</js>.
	 * 	</ul>
	 * 	<p>
	 * 		As a rule, use the simplest format needed to uniquely resolve a method.
	 * 	</p>
	 * @param args The arguments to pass as parameters to the method.<br>
	 * 	These will automatically be converted to the appropriate object type if possible.<br>
	 * 	This must be an array, like a JSON array.
	 * @return The returned object from the method call.
	 * @throws IllegalAccessException If the <code>Constructor</code> object enforces Java language access control and the underlying constructor is inaccessible.
	 * @throws IllegalArgumentException If one of the following occurs:
	 * 	<ul>
	 * 		<li>The number of actual and formal parameters differ.
	 * 		<li>An unwrapping conversion for primitive arguments fails.
	 * 		<li>A parameter value cannot be converted to the corresponding formal parameter type by a method invocation conversion.
	 * 		<li>The constructor pertains to an enum type.
	 * 	</ul>
	 * @throws InvocationTargetException If the underlying constructor throws an exception.
	 * @throws ParseException If the input contains a syntax error or is malformed.
	 */
	public Object invokeMethod(String url, String method, String args) throws InvocationTargetException, IllegalArgumentException, IllegalAccessException, ParseException {
		if (pojoIntrospector == null)
			throw new PojoRestException(HTTP_BAD_REQUEST,
				"Cannot call invokeMethod() on PojoRest constructed with just a BeanContext.  You must use PojoRest(Object,Parser) for this function."
			);
		Object o = get(url);
		if (o == null)
			return null;
		return pojoIntrospector.invokeMethod(o, method, args);
	}

	/**
	 * Returns the list of available methods that can be passed to the {@link #invokeMethod(String, String, String)} for the object
	 * 	addressed by the specified URL.
	 * @param url The URL.
	 * @return The list of methods.
	 */
	public List<String> getPublicMethods(String url) {
		if (pojoIntrospector == null)
			throw new PojoRestException(HTTP_BAD_REQUEST,
				"Cannot call getPublicMethods() on PojoRest constructed with just a BeanContext.  You must use PojoRest(Object,Parser) for this function."
			);
		Object o = get(url);
		if (o == null)
			return null;
		return pojoIntrospector.getPublicMethods(o.getClass(), true);
	}

	/**
	 * Returns the class type of the object at the specified URL.
	 *
	 * @param url The URL.
	 * @return The class type.
	 */
	public ClassType getClassType(String url) {
		JsonNode n = getNode(normalizeUrl(url), root);
		if (n == null)
			return null;
		return n.ct;
	}

	/**
	 * Sets/replaces the element addressed by the URL.
	 * <p>
	 * 	This method expands the POJO model as necessary to create the new element.
	 *
	 * @param url The URL of the element to create.
	 * 		If <jk>null</jk> or blank, the root itself is replaced with the specified value.
	 * @param val The value being set.  Value can be of any type.
	 * @return The previously addressed element, or <jk>null</jk> the element did not previously exist.
	 */
	public Object put(String url, Object val) {
		return service(PUT, url, val);
	}

	/**
	 * Adds a value to a list element in a POJO model.
	 * <p>
	 * 	The URL is the address of the list being added to.
	 * <p>
	 * 	If the list does not already exist, it will be created.
	 * <p>
	 * 	This method expands the POJO model as necessary to create the new element.
	 * <p>
	 * 	Note:  You can only post to three types of nodes:
	 * 	<ul>
	 * 		<li>{@link List Lists}
	 * 		<li>{@link Map Maps} containing integers as keys (i.e sparse arrays)
	 * 		<li>arrays
	 * 	</ul>
	 *
	 * @param url The URL of the element being added to.
	 * 		If null or blank, the root itself (assuming it's one of the types specified above) is added to.
	 * @param val The value being added.
	 * @return The URL of the element that was added.
	 */
	public String post(String url, Object val) {
		return (String)service(POST, url, val);
	}

	/**
	 * Remove an element from a POJO model.
	 * <p>
	 * qIf the element does not exist, no action is taken.
	 *
	 * @param url The URL of the element being deleted.
	 * 		If <jk>null</jk> or blank, the root itself is deleted.
	 * @return The removed element, or null if that element does not exist.
	 */
	public Object delete(String url) {
		return service(DELETE, url, null);
	}

	/**
	 * Overrides {@link Object#toString()}
	 */
	@Override
	public String toString() {
		return (root == null ? null : root.o.toString());
	}

	/** Handle nulls and strip off leading '/' char. */
	private String normalizeUrl(String url) {

		// Interpret nulls and blanks the same (i.e. as addressing the root itself)
		if (url == null)
			url = "";

		// Strip off leading slash if present.
		if (url.length() > 0 && url.charAt(0) == '/')
			url = url.substring(1);

		return url;
	}


	/*
	 * Workhorse method.
	 */
	private Object service(int method, String url, Object val) throws PojoRestException {

		if (root == null)
			return null;

		url = normalizeUrl(url);

		if (method == GET) {
			JsonNode p = getNode(url, root);
			return p == null ? null : p.o;
		}

		// Get the url of the parent and the property name of the addressed object.
		int i = url.lastIndexOf('/');
		String parentUrl = (i == -1 ? null : url.substring(0, i));
		String childKey = (i == -1 ? url : url.substring(i + 1));

		if (method == PUT) {
			if (url.length() == 0) {
				if (rootLocked)
					throw new PojoRestException(HTTP_FORBIDDEN, "Cannot overwrite root object");
				Object o = root.o;
				root = new JsonNode(null, null, val, ClassType.OBJECT);
				return o;
			}
			JsonNode n = (parentUrl == null ? root : getNode(parentUrl, root));
			if (n == null)
				throw new PojoRestException(HTTP_NOT_FOUND, "Node at URL '%s' not found.", parentUrl);
			ClassType ct = n.ct;
			Object o = n.o;
			if (ct.isMap())
				return ((Map)o).put(childKey, convert(val, ct.getValueType()));
			if (ct.isCollection() && o instanceof List)
				return ((List)o).set(parseInt(childKey), convert(val, ct.getElementType()));
			if (ct.isArray()) {
				o = setArrayEntry(n.o, parseInt(childKey), val, ct.getElementType());
				ClassType pct = n.parent.ct;
				Object po = n.parent.o;
				if (pct.isMap()) {
					((Map)po).put(n.keyName, o);
					return url;
				}
				if (pct.isBean()) {
					BeanMap m = beanContext.forBean(po);
					m.put(n.keyName, o);
					return url;
				}
				throw new PojoRestException(HTTP_BAD_REQUEST, "Cannot perform PUT on '%s' with parent node type '%s'", url, pct);
			}
			if (ct.isBean())
				return beanContext.forBean(o).put(childKey, val);
			throw new PojoRestException(HTTP_BAD_REQUEST, "Cannot perform PUT on '%s' whose parent is of type '%s'", url, ct);
		}

		if (method == POST) {
			// Handle POST to root special
			if (url.length() == 0) {
				ClassType ct = root.ct;
				Object o = root.o;
				if (ct.isCollection()) {
					Collection c = (Collection)o;
					c.add(convert(val, ct.getElementType()));
					return (c instanceof List ? url + "/" + (c.size()-1) : null);
				}
				if (ct.isArray()) {
					Object[] o2 = addArrayEntry(o, val, ct.getElementType());
					root = new JsonNode(null, null, o2, null);
					return url + "/" + (o2.length-1);
				}
				throw new PojoRestException(HTTP_BAD_REQUEST, "Cannot perform POST on '%s' of type '%s'", url, ct);
			}
			JsonNode n = getNode(url, root);
			if (n == null)
				throw new PojoRestException(HTTP_NOT_FOUND, "Node at URL '%s' not found.", url);
			ClassType ct = n.ct;
			Object o = n.o;
			if (ct.isArray()) {
				Object[] o2 = addArrayEntry(o, val, ct.getElementType());
				ClassType pct = n.parent.ct;
				Object po = n.parent.o;
				if (pct.isMap()) {
					((Map)po).put(childKey, o2);
					return url + "/" + (o2.length-1);
				}
				if (pct.isBean()) {
					BeanMap m = beanContext.forBean(po);
					m.put(childKey, o2);
					return url + "/" + (o2.length-1);
				}
				throw new PojoRestException(HTTP_BAD_REQUEST, "Cannot perform POST on '%s' with parent node type '%s'", url, pct);
			}
			if (ct.isCollection()) {
				Collection c = (Collection)o;
				c.add(convert(val, ct.getElementType()));
				return (c instanceof List ? url + "/" + (c.size()-1) : null);
			}
			throw new PojoRestException(HTTP_BAD_REQUEST, "Cannot perform POST on '%s' of type '%s'", url, ct);
		}

		if (method == DELETE) {
			if (url.length() == 0) {
				if (rootLocked)
					throw new PojoRestException(HTTP_FORBIDDEN, "Cannot overwrite root object");
				Object o = root.o;
				root = new JsonNode(null, null, null, ClassType.OBJECT);
				return o;
			}
			JsonNode n = (parentUrl == null ? root : getNode(parentUrl, root));
			ClassType ct = n.ct;
			Object o = n.o;
			if (ct.isMap())
				return ((Map)o).remove(childKey);
			if (ct.isCollection() && o instanceof List)
				return ((List)o).remove(parseInt(childKey));
			if (ct.isArray()) {
				int index = parseInt(childKey);
				Object old = ((Object[])o)[index];
				Object[] o2 = removeArrayEntry(o, index);
				ClassType pct = n.parent.ct;
				Object po = n.parent.o;
				if (pct.isMap()) {
					((Map)po).put(n.keyName, o2);
					return old;
				}
				if (pct.isBean()) {
					BeanMap m = beanContext.forBean(po);
					m.put(n.keyName, o2);
					return old;
				}
				throw new PojoRestException(HTTP_BAD_REQUEST, "Cannot perform POST on '%s' with parent node type '%s'", url, pct);
			}
			if (ct.isBean())
				return beanContext.forBean(o).put(childKey, null);
			throw new PojoRestException(HTTP_BAD_REQUEST, "Cannot perform PUT on '%s' whose parent is of type '%s'", url, ct);
		}

		return null;	// Never gets here.
	}

	private Object[] setArrayEntry(Object o, int index, Object val, ClassType componentType) {
		Object[] a = (Object[])o;
		if (a.length <= index) {
			// Expand out the array.
			Object[] a2 = (Object[])Array.newInstance(a.getClass().getComponentType(), index+1);
			System.arraycopy(a, 0, a2, 0, a.length);
			a = a2;
		}
		a[index] = convert(val, componentType);
		return a;
	}

	private Object[] addArrayEntry(Object o, Object val, ClassType componentType) {
		Object[] a = (Object[])o;
		// Expand out the array.
		Object[] a2 = (Object[])Array.newInstance(a.getClass().getComponentType(), a.length+1);
		System.arraycopy(a, 0, a2, 0, a.length);
		a2[a.length] = convert(val, componentType);
		return a2;
	}

	private Object[] removeArrayEntry(Object o, int index) {
		Object[] a = (Object[])o;
		// Shrink the array.
		Object[] a2 = (Object[])Array.newInstance(a.getClass().getComponentType(), a.length-1);
		System.arraycopy(a, 0, a2, 0, index);
		System.arraycopy(a, index+1, a2, index, a.length-index-1);
		return a2;
	}

	class JsonNode {
		Object o;
		ClassType ct;
		JsonNode parent;
		String keyName;

		JsonNode(JsonNode parent, String keyName, Object o, ClassType ct) {
			this.o = o;
			this.keyName = keyName;
			this.parent = parent;
			if (ct == null || ct == ClassType.OBJECT) {
				if (o == null)
					ct = ClassType.OBJECT;
				else
					ct = beanContext.getClassTypeForObject(o);
			}
			this.ct = ct;
		}
	};

	JsonNode getNode(String url, JsonNode n) {
		if (url == null || url.isEmpty())
			return n;
		int i = url.indexOf('/');
		String parentKey, childUrl = null;
		if (i == -1) {
			parentKey = url;
		} else {
			parentKey = url.substring(0, i);
			childUrl = url.substring(i + 1);
		}

		Object o = n.o;
		Object o2 = null;
		ClassType ct = n.ct;
		ClassType ct2 = null;
		if (o == null)
			return null;
		if (ct.isMap()) {
			o2 = ((Map)o).get(parentKey);
			ct2 = ct.getValueType();
		} else if (ct.isCollection() && o instanceof List) {
			int key = parseInt(parentKey);
			o2 = ((List)o).get(key);
			ct2 = ct.getElementType();
		} else if (ct.isArray()) {
			int key = parseInt(parentKey);
			o2 = ((Object[])o)[key];
			ct2 = ct.getElementType();
		} else if (ct.isBean()) {
			BeanMap m = beanContext.forBean(o);
			o2 = m.get(parentKey);
			BeanPropertyMeta pMeta = m.getPropertyMeta(parentKey);
			if (pMeta == null)
				throw new PojoRestException(HTTP_BAD_REQUEST,
					"Unknown property '%s' encountered while trying to parse into class '%s'",
					parentKey, m.getClassType()
				);
			ct2 = pMeta.getClassType();
		}

		if (childUrl == null)
			return new JsonNode(n, parentKey, o2, ct2);

		return getNode(childUrl, new JsonNode(n, parentKey, o2, ct2));
	}

	private Object convert(Object in, ClassType ct) {
		if (ct == null)
			return in;
		if (ct.isBean() && in instanceof Map)
			return beanContext.convertToType(in, ct);
		return in;
	}

	private int parseInt(String key) {
		try {
			return Integer.parseInt(key);
		} catch (NumberFormatException e) {
			throw new PojoRestException(HTTP_BAD_REQUEST,
				"Cannot address an item in an array with a non-integer key '%s'", key
			);
		}
	}
}
