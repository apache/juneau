package com.ibm.juno.core;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.ClassType.*;

import java.io.*;
import java.lang.reflect.*;
import java.math.*;
import java.util.*;

import com.ibm.juno.core.filters.*;
import com.ibm.juno.core.html.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.core.xml.*;

/**
 * Parent class for all parsers.
 * <p>
 * 	<ul>
 * 		<li>{@link JsonParser} - Parses JSON into POJO models.
 * 		<li>{@link XmlParser} - Parses Juno-generated XML into POJO models.
 * 		<li>{@link HtmlParser} - Parses Juno-generated HTML into POJO models.
 * 		<li>{@link UrlEncodingParser} - Serializes URL GET parameter strings and form posts into POJO models.
 *		</ul>
 *
 * <h6 class='topic'>Settings</h6>
 * 	All parsers have the following common settings defined:
 * <table class='styled'>
 * 	<tr>
 * 		<th>Name</th>
 * 		<th>Type</th>
 * 		<th>Description</th>
 * 		<th>Default value</th>
 * 	</tr>
 * 	<tr>
 * 		<td>{@link #setBeanContext(BeanContext) beanContext}</td>
 * 		<td class='code'><code>BeanContext</code></td>
 * 		<td>Defines the bean context used by this parser, which is used to convert serialized objects into beans.</td>
 * 		<td class='code'>BeanContext.<jsf>DEFAULT</jsf></td>
 * 	</tr>
 * </table>
 *
 * <a name='ValidDataConversions'></a><h6 class='topic'>Valid data conversions</h6>
 * 	Parsers can parse any parsable POJO types, as specified in the <a class='doclink' href='package-summary.html#PojoCategories'>POJO Categories</a>.
 * <p>
 * 	Some examples of conversions are shown below...
 * </p>
 * 	<table class='styled'>
 * 		<tr>
 * 			<th>Data type</th>
 * 			<th>Class type</th>
 * 			<th>JSON example</th>
 * 			<th>XML example</th>
 * 			<th>Class examples</th>
 * 		</tr>
 * 		<tr>
 * 			<td>object</td>
 * 			<td>Maps, Java beans</td>
 * 			<td class='code'>{name:<js>'John Smith'</js>,age:21}</td>
 * 			<td class='code'><xt>&lt;object&gt;
 * 	&lt;name</xt> <xa>type</xa>=<xs>'string'</xs><xt>&gt;</xt>John Smith<xt>&lt;/name&gt;
 * 	&lt;age</xt> <xa>type</xa>=<xs>'number'</xs><xt>&gt;</xt>21<xt>&lt;/age&gt;
 * &lt;/object&gt;</xt></td>
 * 			<td class='code'>HashMap, TreeMap&lt;String,Integer&gt;</td>
 * 		</tr>
 * 		<tr>
 * 			<td>array</td>
 * 			<td>Collections, Java arrays</td>
 * 			<td class='code'>[1,2,3]</td>
 * 			<td class='code'><xt>&lt;array&gt;
 * 	&lt;number&gt;</xt>1<xt>&lt;/number&gt;
 * 	&lt;number&gt;</xt>2<xt>&lt;/number&gt;
 * 	&lt;number&gt;</xt>3<xt>&lt;/number&gt;
 * &lt;/array&gt;</xt></td>
 * 			<td class='code'>List&lt;Integer&gt;, <jk>int</jk>[], Float[], Set&lt;Person&gt;</td>
 * 		</tr>
 * 		<tr>
 * 			<td>number</td>
 * 			<td>Numbers</td>
 * 			<td class='code'>123</td>
 * 			<td class='code'><xt>&lt;number&gt;</xt>123<xt>&lt;/number&gt;</xt></td>
 * 			<td class='code'>Integer, Long, Float, <jk>int</jk></td>
 *			</tr>
 * 		<tr>
 * 			<td>boolean</td>
 * 			<td>Booleans</td>
 * 			<td class='code'><jk>true</jk></td>
 * 			<td class='code'><xt>&lt;boolean&gt;</xt>true<xt>&lt;/boolean&gt;</xt></td>
 * 			<td class='code'>Boolean</td>
 * 		</tr>
 * 		<tr>
 * 			<td>string</td>
 * 			<td>CharSequences</td>
 * 			<td class='code'><js>'foobar'</js></td>
 * 			<td class='code'><xt>&lt;string&gt;</xt>foobar<xt>&lt;/string&gt;</xt></td>
 * 			<td class='code'>String, StringBuilder</td>
 * 		</tr>
 * 	</table>
 * <p>
 * 	In addition, any class types with {@link ObjectFilter ObjectFilters} associated with them on the registered
 * 		{@link #setBeanContext(BeanContext) beanContext} can also be passed in.
 * <p>
 * 	For example, if the {@link CalendarFilter} filter is used to generalize {@code Calendar} objects to {@code String} objects.  When registered
 * 	with this parser, you can construct {@code Calendar} objects from {@code Strings} using the following syntax...
 * <p class='bcode'>
 * 	Calendar c = parser.parse(<js>"'Sun Mar 03 04:05:06 EST 2001'"</js>, GregorianCalendar.<jk>class</jk>);
 * <p>
 * 	If {@link ClassType#OBJECT} or <code>Object.<jk>class</jk></code> is specified as the target type, then the parser
 * 	automatically determines the data types and generates the following object types...
 * </p>
 * <table class='styled'>
 * 	<tr><th>JSON type</th><th>Class type</th></tr>
 * 	<tr><td>object</td><td>{@link JsonMap}</td></tr>
 * 	<tr><td>array</td><td>{@link JsonList}</td></tr>
 * 	<tr><td>number</td><td>{@link Number} <br>(depending on length and format, could be {@link Integer}, {@link Double}, {@link Float}, etc...)</td></tr>
 * 	<tr><td>boolean</td><td>{@link Boolean}</td></tr>
 * 	<tr><td>string</td><td>{@link String}</td></tr>
 * </table>
 *
 * <a name='SupportedTypes'></a><h6 class='topic'>Supported types</h6>
 * <p>
 * 	Several of the methods below take {@link Type} parameters to identify the type of
 * 		object to create.  Any of the following types can be passed in to these methods...
 * </p>
 * <ul>
 * 	<li>{@link ClassType}
 * 	<li>{@link Class}
 * 	<li>{@link ParameterizedType}
 * 	<li>{@link GenericArrayType}
 * </ul>
 * <p>
 * 	However, {@code ParameterizedTypes} and {@code GenericArrayTypes} should not contain
 * 		{@link WildcardType WildcardTypes} or {@link TypeVariable TypeVariables}.
 * <p>
 * 	Passing in <jk>null</jk> or {@link ClassType#OBJECT} typically signifies that it's up to the parser
 * 	to determine what object type is being parsed parsed based on the rules above.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class Parser extends CoreAPI {

	private List<ParserListener> listeners = new LinkedList<ParserListener>();

	/**
	 * Default constructor.
	 * <p>
	 * 	A default unlocked bean context will be created for this parser.
	 */
	protected Parser() {
		super();
	}

	/**
	 * Constructor.
	 * @param beanContext The bean context to associate with this parser.
	 */
	protected Parser(BeanContext beanContext) {
		super(beanContext);
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The parser to clone.  Underlying bean context will also be cloned.
	 */
	protected Parser(Parser copyFrom) {
		this.beanContext = copyFrom.beanContext.clone();
	}

	//--------------------------------------------------------------------------------
	// Properties
	//--------------------------------------------------------------------------------

	/**
	 * Adds a {@link ParserListener} to this parser to listen for parse events.
	 *
	 * @param listener The listener to associate with this parser.
	 * @throws LockedException If {@link #lock()} was called on this object.
	 * @return This object (for method chaining).
	 */
	public Parser addListener(ParserListener listener) throws LockedException {
		checkLock();
		this.listeners.add(listener);
		return this;
	}

	/**
	 * Returns the current parser listeners associated with this parser.
	 *
	 * @return The current list of parser listeners.
	 */
	public List<ParserListener> getListeners() {
		return listeners;
	}

	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	/**
	 * Parse the content of the reader and create an object of the specified type.
	 *
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Get a ClassType instance for a normal class</jc>
	 * 	ClassType&lt;String&gt; ct = parser.getClassType(String.<jk>class</jk>);
	 * 	String s = parser.parse(reader, ct);
	 *
	 * 	<jc>// Get a ClassType instance for a parameterized map</jc>
	 * 	ClassType&lt;Map&gt; ct = parser.getClassType(TreeMap.<jk>class</jk>, String.<jk>class</jk>, Integer.<jk>class</jk>);
	 * 	Map&lt;String,Integer&gt; m = parser.parse(reader, ct);
	 * </p>
	 *
	 * @param in The reader containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassType#OBJECT}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public abstract <T> T parse(Reader in, ClassType<T> type) throws ParseException, IOException;

	/**
	 * Same as {@link #parse(Reader, ClassType)}, except accepts a {@code String} as input.
	 *
	 * @param in The string containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@link ClassType#OBJECT}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T parse(CharSequence in, ClassType<T> type) throws ParseException, IOException {
		if (in == null)
			return null;
		return parse(wrapReader(in), type);
	}

	/**
	 * Shortcut for calling: {@code parser.parse(in, parser.getClassType(type);}
	 * <p>
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Parse a simple object like a string</jc>
	 * 	String s = parser.parse(<js>"'foobar'"</js>, String.<jk>class</jk>);
	 *
	 * 	<jc>// Parse a complex object like a bean</jc>
	 * 	Person p = parser.parse(<js>"{name:'John Smith',age:21}"</js>, Person.<jk>class</jk>);
	 * </p>
	 *
	 * @param in The reader containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@code Object}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T parse(Reader in, Class<T> type) throws ParseException, IOException {
		return parse(in, beanContext.getClassType(type));
	}

	/**
	 * Same as {@link #parse(Reader, Class)}, except accepts a {@code String} as input.
	 *
	 * @param in The string containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@code Object}, object type is based on what's being parsed.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T parse(CharSequence in, Class<T> type) throws ParseException, IOException {
		if (in == null)
			return null;
		return parse(wrapReader(in), beanContext.getClassType(type));
	}

	/**
	 * Shortcut for calling: {@code parser.parse(in, parser.getCollectionClassType(collectionType, elementType));}
	 * <p>
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Parse input as a LinkedList of Integers</jc>
	 * 	List&lt;Integer&gt; l = parser.parseCollection(in, LinkedList.<jk>class</jk>, Integer.<jk>class</jk>);
	 *
	 * 	<jc>// Parse input as a Set of Strings</jc>
	 * 	Set&lt;String&gt; s = parser.parseCollection(in, HashSet.<jk>class</jk>, String.<jk>class</jk>);
	 * </p>
	 *
	 * @param in The reader containing the input.
	 * @param collectionType The collection class type.
	 * 	Must be an instantiatable subclass of {@link Collection}.
	 * @param elementType The class type of the elements in the collection.
	 * @param <T> The collection class type to create.
	 * @param <E> The class type of the elements to create in the collection.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <E, T extends Collection<E>> T parseCollection(Reader in, Class<T> collectionType, Class<E> elementType) throws ParseException, IOException {
		return parse(in, beanContext.getCollectionClassType(collectionType, elementType));
	}

	/**
	 * Similar to {@link #parseCollection(Reader, Class, Class)}, except the element types
	 * 	can be specified as a Type (e.g. {@link ParameterizedType}, {@link TypeVariable}, {@link GenericArrayType}).
	 *
	 * @param in The reader containing the input.
	 * @param collectionType The collection class type.
	 * 	Must be an instantiatable subclass of {@link Collection}.
	 * @param elementType The class type of the elements in the collection.
	 * @param <T> The collection class type to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T extends Collection<?>> T parseCollection(Reader in, Class<T> collectionType, Type elementType) throws ParseException, IOException {
		return parse(in, beanContext.getCollectionClassType(collectionType, elementType));
	}

	/**
	 * Same as {@link #parseCollection(Reader, Class, Class)}, except accepts a {@code String} as input.
	 *
	 * @param in The reader containing the input.
	 * @param collectionType The collection class type.
	 * 	Must be an instantiatable subclass of {@link Collection}.
	 * @param elementType The class type of the elements in the collection.
	 * @param <T> The collection class type to create.
	 * @param <E> The class type of the elements to create in the collection.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <E, T extends Collection<E>> T parseCollection(CharSequence in, Class<T> collectionType, Class<E> elementType) throws ParseException, IOException {
		if (in == null)
			return null;
		return parse(wrapReader(in), beanContext.getCollectionClassType(collectionType, elementType));
	}

	/**
	 * Same as {@link #parseCollection(Reader, Class, Type)}, except accepts a {@code String} as input.
	 *
	 * @param in The reader containing the input.
	 * @param collectionType The collection class type.
	 * 	Must be an instantiatable subclass of {@link Collection}.
	 * @param elementType The class type of the elements in the collection.
	 * @param <T> The collection class type to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T extends Collection<?>> T parseCollection(CharSequence in, Class<T> collectionType, Type elementType) throws ParseException, IOException {
		if (in == null)
			return null;
		return parse(wrapReader(in), beanContext.getCollectionClassType(collectionType, elementType));
	}

	/**
	 * Shortcut for calling: {@code parser.parse(in, parser.getMapClassType(mapType, keyType, valueType));}
	 * <p>
	 * <h6 class='method'>Examples:</h6>
	 * <p class='bcode'>
	 * 	<jc>// Parse input as a Map with Integer keys and MyBean values</jc>
	 * 	Map&lt;Integer,MyBean&gt; m = parser.parseMap(in, HashMap.<jk>class</jk>, Integer.<jk>class</jk>, MyBean.<jk>class</jk>);
	 *
	 * 	<jc>// Parse input as a Map with String keys and Integer values</jc>
	 * 	Map&lt;String,Integer&gt; m = parser.parseMap(in, TreeMap.<jk>class</jk>, String.<jk>class</jk>, Integer.<jk>class</jk>);
	 * </p>
	 *
	 * @param in The reader containing the input.
	 * @param mapType The map class type.
	 * 	Must be an instantiatable subclass of {@link Map}.
	 * @param keyType The class type of the keys in the map.
	 * @param valueType The class type of the values in the map.
	 * @param <T> The map class type to create.
	 * @param <K> The class type of the keys to create in the map.
	 * @param <V> The class type of the values to create in the map.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <K,V,T extends Map<K,V>> T parseMap(Reader in, Class<T> mapType, Class<K> keyType, Class<V> valueType) throws ParseException, IOException {
		return parse(in, beanContext.getMapClassType(mapType, keyType, valueType));
	}

	/**
	 * Similar to {@link #parseMap(Reader, Class, Class, Class)}, except the key and value types
	 * 	can be specified as {@code Type Types} (e.g. {@link ParameterizedType}, {@link TypeVariable}, {@link GenericArrayType}).
	 *
	 * @param in The reader containing the input.
	 * @param mapType The map class type.
	 * 	Must be an instantiatable subclass of {@link Map}.
	 * @param keyType The class type of the keys in the map.
	 * @param valueType The class type of the values in the map.
	 * @param <T> The map class type to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T extends Map<?,?>> T parseMap(Reader in, Class<T> mapType, Type keyType, Type valueType) throws ParseException, IOException {
		return parse(in, beanContext.getMapClassType(mapType, keyType, valueType));
	}

	/**
	 * Same as {@link #parseMap(Reader, Class, Class, Class)}, except accepts a {@code String} as input.
	 *
	 * @param in The reader containing the input.
	 * @param mapType The map class type.
	 * 	Must be an instantiatable subclass of {@link Map}.
	 * @param keyType The class type of the keys in the map.
	 * @param valueType The class type of the values in the map.
	 * @param <T> The class type of the object to create.
	 * @param <K> The class type of the keys to create in the map.
	 * @param <V> The class type of the values to create in the map.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <K,V,T extends Map<K,V>> T parseMap(CharSequence in, Class<T> mapType, Class<K> keyType, Class<V> valueType) throws ParseException, IOException {
		if (in == null)
			return null;
		return parse(wrapReader(in), beanContext.getMapClassType(mapType, keyType, valueType));
	}

	/**
	 * Same as {@link #parseMap(Reader, Class, Type, Type)}, except accepts a {@code String} as input.
	 *
	 * @param in The reader containing the input.
	 * @param mapType The map class type.
	 * 	Must be an instantiatable subclass of {@link Map}.
	 * @param keyType The class type of the keys in the map.
	 * @param valueType The class type of the values in the map.
	 * @param <T> The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T extends Map<?,?>> T parseMap(CharSequence in, Class<T> mapType, Type keyType, Type valueType) throws ParseException, IOException {
		if (in == null)
			return null;
		return parse(wrapReader(in), beanContext.getMapClassType(mapType, keyType, valueType));
	}

	/**
	 * Use this parsing method when you have a non-Class {@link Type} instance that you want
	 * the result to be parsed to.
	 * <p>
	 * 	Supported types:
	 * </p>
	 * <ul>
	 * 	<li>ParameterizedType
	 * 	<li>GenericArrayType
	 * 	<li>TypeVariable
	 * </ul>
	 * <p>
	 * 	Note that since {@link Type} is not a parameterized class, you will typically
	 * 	have to cast the resulting object into the correct type.
	 * </p>
	 *
	 * @param in The reader containing the input.
	 * @param type The class type of the object to create.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@SuppressWarnings("unchecked")
	public Object parse(Reader in, Type type) throws ParseException, IOException {
		return parse(in, beanContext.getClassType(type));
	}

	/**
	 * Same as {@link #parse(Reader, Type)}, except accepts a {@code String} as input.
	 *
	 * @param in The string containing the input.
	 * @param type The class type of the object to create.
	 * 	If <jk>null</jk> or {@code Object}, object type is based on what's being parsed.
	 * @return The parsed object.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@SuppressWarnings("unchecked")
	public Object parse(CharSequence in, Type type) throws ParseException, IOException {
		if (in == null)
			return null;
		return parse(wrapReader(in), beanContext.getClassType(type));
	}

	/**
	 * Same as calling: <code>Object object = parser.parse(reader, <jk>null</jk>);</code>
	 * <p>
	 * 	See <a class='doclink' href='#ValidDataConversions'>Valid data conversions</a> section for class types generated.
	 *
	 * @param in The string containing the input.
	 * @return The parsed object.  The class type is dependent on what's being parsed.
	 * @throws ParseException If the input contains a syntax error or is malformed.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public Object parse(Reader in) throws ParseException, IOException {
		return parse(in, beanContext.getClassType(Object.class));
	}

	/**
	 * Same as {@link #parse(Reader)}, except accepts a {@code String} as input.
	 * <p>
	 * 	See <a class='doclink' href='#ValidDataConversions'>Valid data conversions</a> section for class types generated.
	 *
	 * @param in The string containing the input.
	 * @return The parsed object.  The class type is dependent on what's being parsed.
	 * @throws ParseException If the input contains a syntax error or is malformed.
	 */
	public Object parse(CharSequence in) throws ParseException {
		if (in == null)
			return null;
		try {
			return parse(wrapReader(in), ClassType.OBJECT);
		} catch (IOException e) {
			throw new RuntimeException(e); // Will never happen.
		}
	}

	/**
	 * Parses the contents of the specified reader and loads the results into the specified map.
	 * <p>
	 * 	Reader must contain a JSON object (or XML/HTML equivalent).
	 * <p>
	 * 	This is an optional method.  Subclasses can choose to not implement this method.
	 *
	 * @param <K> The key class type.
	 * @param <V> The value class type.
	 * @param in The reader containing the input.
	 * @param m The map being loaded.
	 * @param keyType The class type of the keys, or <jk>null</jk> to default to <code>String.<jk>class</jk></code>.<br>
	 * @param valueType The class type of the values, or <jk>null</jk> to default to whatever is being parsed.<br>
	 * @return The same map that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @throws UnsupportedOperationException If not implemented.
	 */
	public <K,V> Map<K,V> parseIntoMap(Reader in, Map<K,V> m, Type keyType, Type valueType) throws ParseException, IOException {
		throw new UnsupportedOperationException();
	}

	/**
	 * Same as {@link #parseIntoMap(Reader, Map, Type, Type)} except takes a string for input.
	 *
	 * @param <K> The key class type.
	 * @param <V> The value class type.
	 * @param in The reader containing the input.
	 * @param m The map being loaded.
	 * @param keyType The class type of the keys, or <jk>null</jk> to default to <code>String.<jk>class</jk></code>.<br>
	 * @param valueType The class type of the values, or <jk>null</jk> to default to whatever is being parsed.<br>
	 * @return The same map that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <K,V> Map<K,V> parseIntoMap(String in, Map<K,V> m, Type keyType, Type valueType) throws ParseException, IOException {
		if (in == null)
			return null;
		return parseIntoMap(wrapReader(in), m, keyType, valueType);
	}

	/**
	 * Same as {@link #parseIntoMap(Reader, Map, Type, Type)} except assumes
	 * a key type of {@link ClassType#STRING} and a value type of {@link ClassType#OBJECT}.
	 *
	 * @param in The reader containing the input.
	 * @param m The map being loaded.
	 * @return The same map that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map parseIntoMap(Reader in, Map m) throws ParseException, IOException {
		return parseIntoMap(in, m, STRING, OBJECT);
	}

	/**
	 * Same as {@link #parseIntoMap(Reader, Map)} except takes a string for input.
	 *
	 * @param in The string containing the input.
	 * @param m The map being loaded.
	 * @return The same map that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map parseIntoMap(String in, Map m) throws ParseException, IOException {
		if (in == null)
			return null;
		return parseIntoMap(wrapReader(in), m, STRING, OBJECT);
	}

	/**
	 * Parses the contents of the specified reader and loads the results into the specified collection.
	 * <p>
	 * 	This is an optional method.  Subclasses can choose to not implement this method.
	 *
	 * @param <E> The element class type.
	 * @param in The reader containing the input.
	 * @param c The collection being loaded.
	 * @param elementType The class type of the elements, or <jk>null</jk> to default to whatever is being parsed.
	 * @return The same collection that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @throws UnsupportedOperationException If not implemented.
	 */
	public <E> Collection<E> parseIntoCollection(Reader in, Collection<E> c, Type elementType) throws ParseException, IOException {
		throw new UnsupportedOperationException();
	}

	/**
	 * Same as calling {@link #parseIntoCollection(Reader, Collection, Type)} except takes a {@code String} as input.
	 *
	 * @param <E> The element class type.
	 * @param in The string containing the input.
	 * @param c The collection being loaded.
	 * @param elementType The class type of the elements, or <jk>null</jk> to default to whatever is being parsed.
	 * @return The same collection that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <E> Collection<E> parseIntoCollection(String in, Collection<E> c, Type elementType) throws ParseException, IOException {
		if (in == null)
			return null;
		return parseIntoCollection(wrapReader(in), c, elementType);
	}

	/**
	 * Same as calling {@link #parseIntoCollection(Reader, Collection, Type)} except assumes an element type of
	 * {@link ClassType#OBJECT}.
	 *
	 * @param in The reader containing the input.
	 * @param c The collection being loaded.
	 * @return The same collection that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Collection parseIntoCollection(Reader in, Collection c) throws ParseException, IOException {
		return parseIntoCollection(in, c, OBJECT);
	}

	/**
	 * Same as calling {@link #parseIntoCollection(Reader, Collection)} except takes a {@code String} as input.
	 *
	 * @param in The reader containing the input.
	 * @param c The collection being loaded.
	 * @return The same collection that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Collection parseIntoCollection(String in, Collection c) throws ParseException, IOException {
		if (in == null)
			return null;
		return parseIntoCollection(wrapReader(in), c, OBJECT);
	}

	/**
	 * Parses the contents of the specified reader and loads the results into the specified bean map.
	 * <p>
	 * 	This is an optional method.  Subclasses can choose to not implement this method.
	 *
	 * @param <T> The class type of the bean.
	 * @param in The reader containing the input.
	 * @param m The bean map being loaded.
	 * @return The same bean map that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @throws UnsupportedOperationException If not implemented.
	 */
	public <T> BeanMap<T> parseIntoBeanMap(Reader in, BeanMap<T> m) throws ParseException, IOException {
		throw new UnsupportedOperationException();
	}

	/**
	 * Same as calling {@link #parseIntoBeanMap(Reader, BeanMap)} except takes a {@code String} as input.
	 *
	 * @param <T> The class type of the bean.
	 * @param in The string containing the input.
	 * @param m The bean map being loaded.
	 * @return The same bean map that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> BeanMap<T> parseIntoBeanMap(String in, BeanMap<T> m) throws ParseException, IOException {
		if (in == null)
			return null;
		return parseIntoBeanMap(wrapReader(in), m);
	}

	/**
	 * Parses the contents of the specified reader and loads the results into the specified bean.
	 *
	 * @param <T> The class type of the bean.
	 * @param in The reader containing the input.
	 * @param o The bean being loaded.
	 * @return The same bean map that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T parseIntoBean(Reader in, T o) throws ParseException, IOException {
		return parseIntoBeanMap(in, beanContext.forBean(o)).getBean();
	}

	/**
	 * Same as calling {@link #parseIntoBean(Reader, Object)} except takes a {@code String} as input.
	 *
	 * @param <T> The class type of the bean.
	 * @param in The string containing the input.
	 * @param o The bean being loaded.
	 * @return The same bean map that was passed in to allow this method to be chained.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 */
	public <T> T parseIntoBean(String in, T o) throws ParseException, IOException {
		if (in == null)
			return null;
		return parseIntoBeanMap(wrapReader(in), beanContext.forBean(o)).getBean();
	}

	/**
	 * Parses the specified array input with each entry in the object defined by the {@code argTypes}
	 * argument.
	 * <p>
	 * 	Used for converting arrays (e.g. <js>"[arg1,arg2,...]"</js>) into an {@code Object[]} that can be passed
	 * 	to the {@code Method.invoke(target, args)} method.
	 * <p>
	 * 	This is an optional method.  Subclasses can choose to not implement this method.
	 *
	 * @param in The input.  Must represent an array.
	 * @param argTypes Specifies the type of objects to create for each entry in the array.
	 * @return An array of parsed objects.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @throws UnsupportedOperationException If not implemented.
	 */
	public Object[] parseArgs(Reader in, ClassType<?>[] argTypes) throws ParseException, IOException {
		throw new UnsupportedOperationException();
	}

	/**
	 * Same as {@link #parseArgs(Reader, ClassType[])} except takes a {@code String} as input.
	 *
	 * @param in The input.  Must represent an array.
	 * @param argTypes Specifies the type of objects to create for each entry in the array.
	 * @return An array of parsed objects.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 */
	public Object[] parseArgs(CharSequence in, ClassType<?>[] argTypes) throws ParseException {
		if (in == null)
			return null;
		if (argTypes.length == 0)
			return new Object[0];
		try {
			return parseArgs(wrapReader(in), argTypes);
		} catch (IOException e) {
			// Should never occur.
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Wrap the specified {@link CharSequence} into a {@link Reader}.<br>
	 * <p>
	 * 	Subclasses can override this method to provide specialized readers.
	 *
	 * @param cs The string to wrap in a reader.
	 * @return The reader.
	 */
	protected Reader wrapReader(CharSequence cs) {
		return new StringReader(cs.toString());
	}

	/**
	 * Converts the specified string to the specified type.
	 *
	 * @param <T> The class type to convert the string to.
	 * @param s The string to convert.
	 * @param type The class type to convert the string to.
	 * @return The string converted as an object of the specified type.
	 * @throws ParseException If the input contains a syntax error or is malformed, or is not valid for the specified type.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected <T> T convertAttrToType(String s, ClassType<T> type) throws ParseException {
		if (s == null)
			return null;

		if (type == null)
			type = (ClassType<T>)ClassType.OBJECT;
		ObjectFilter filter = type.getObjectFilter();
		ClassType<?> gType = type.getFilteredClassType();

		Object o = s;
		if (gType.isChar())
			o = s.charAt(0);
		else if (gType.isNumber())
			o = parseNumber(s, (Class<? extends Number>)gType.getInnerClass());
		else if (gType.isBoolean())
			o = Boolean.parseBoolean(s);
		else if (gType.isEnum())
			o = Enum.valueOf((Class<Enum>)gType.getInnerClass(), s);
		else if (! (gType.isCharSequence() || gType.isObject()))
			throw new ParseException("Invalid conversion from string to class '%s'", type);

		if (filter != null)
			o = filter.unfilter(o, type, beanContext);


		return (T)o;
	}

	/**
	 * Parses a number from the specified reader stream.
	 *
	 * @param r The reader to parse the string from.
	 * @param type The number type to created. <br>
	 * 	Can be any of the following:
	 * 	<ul>
	 * 		<li> Integer
	 * 		<li> Double
	 * 		<li> Float
	 * 		<li> Long
	 * 		<li> Short
	 * 		<li> Byte
	 * 		<li> BigInteger
	 * 		<li> BigDecimal
	 * 	</ul>
	 *		If <jk>null</jk>, uses the best guess.
	 * @throws IOException If a problem occurred trying to read from the reader.
	 * @return The parsed number.
	 */
	protected Number parseNumber(ParserReader r, Class<? extends Number> type) throws IOException, ParseException {
		boolean isInt=false;
		boolean isHex=false;
		boolean isDouble=false;
		r.mark();
		int c = r.read();
		boolean isNegative = false;
		if (c == '-') {
			isNegative = true;
			c = r.read();
		}
		if (c != '0')
			isInt = true;
		while (c != -1) {
			c = r.read();
			if (c == 'x' || c == 'X') {
				isHex = true;
			} else if (c == '.') {
				isDouble = true;
			} else if ((c >= '0' && c <= '9')
				|| (isHex && ((c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
				|| (isDouble && (c == 'e' || c == 'E'|| c == '+' || c == '-'))) {
				// Do nothing.
			} else if (c != -1) {
				// Reached the end.
				r.unread();
				break;
			}
		}

		String s = r.getFromMarked();

		return getNumber(s, isNegative, isHex, isInt, isDouble, type);
	}

	/**
	 * Parses a number from the specified string.
	 *
	 * @param s The string to parse the number from.
	 * @param type The number type to created. <br>
	 * 	Can be any of the following:
	 * 	<ul>
	 * 		<li> Integer
	 * 		<li> Double
	 * 		<li> Float
	 * 		<li> Long
	 * 		<li> Short
	 * 		<li> Byte
	 * 		<li> BigInteger
	 * 		<li> BigDecimal
	 * 	</ul>
	 *		If <jk>null</jk>, uses the best guess.
	 * @return The parsed number.
	 */
	protected Number parseNumber(String s, Class<? extends Number> type) throws ParseException {
		int i = 0;
		boolean isInt=false;
		boolean isHex=false;
		boolean isDouble=false;
		int c = s.charAt(i);
		boolean isNegative = false;
		if (c == '-') {
			isNegative = true;
			i++;
		}
		if (c != '0')
			isInt = true;
		int length = s.length();
		while (i < length) {
			c = s.charAt(i);
			if (c == 'x' || c == 'X') {
				isHex = true;
			} else if (c == '.') {
				isDouble = true;
			} else if ((c >= '0' && c <= '9')
				|| (isHex && ((c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
				|| (isDouble && (c == 'e' || c == 'E'|| c == '+' || c == '-'))) {
				// Do nothing.
			} else {
				break;
			}
			i++;
		}

		return getNumber(s, isNegative, isHex, isInt, isDouble, type);
	}

	/**
	 * Returns <jk>true</jk> if this string can be parsed by {@link #parseNumber(String, Class)}
	 */
	protected boolean isNumeric(String s) {
		int i = 0;
		boolean isHex=false;
		boolean isDouble=false;
		if (s == null || s.length() == 0)
			return false;
		int c = s.charAt(i);
		if (c == '-')
			i++;
		int length = s.length();
		while (i < length) {
			c = s.charAt(i);
			if (i == 0 && (c == 'x' || c == 'X')) {
				isHex = true;
			} else if (i > 0 && c == '.' && isDouble == false && isHex == false) {
				isDouble = true;
			} else if ((c >= '0' && c <= '9')
				|| (isHex && ((c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
				|| (isDouble && (c == 'e' || c == 'E'|| c == '+' || c == '-'))) {
				// Do nothing.
			} else {
				return false;
			}
			i++;
		}
		if (isHex && s.length() == 1)
			return false;
		return true;
	}

	private Number getNumber(String s, boolean isNegative, boolean isHex, boolean isInt, boolean isDouble, Class<?> type) throws ParseException {

		try {
			// Determine the data type if it wasn't specified.
			if (type == null) {
				if (isDouble)
					type = Double.class;
				else {
					// It's either an Integer or Long
					int sLen = (isNegative ? s.length() - 1 : s.length());	// Length of number without minus sign.
					if (isHex) {
						sLen -= (isNegative ? 3 : 2);
						type = (sLen > 7 ? Long.class : Integer.class);
					} else if (isInt) {
						type = (sLen > 8 ? Long.class : Integer.class);
					} else /* Is octal */ {
						type = (sLen > 9 ? Long.class : Integer.class);
					}
				}
			}

			if (type == Double.class || type == Double.TYPE)
				return Double.valueOf(s);
			if (type == Float.class || type == Float.TYPE)
				return Float.valueOf(s);
			if (type == BigDecimal.class)
				return new BigDecimal(s);
			int base = 8;
			if (isHex) {
				s = (isNegative ? ('-' + s.substring(3)) : s.substring(2));	// Strip out 0x
				base = 16;
			}
			if (isInt)
				base = 10;
			if (type == Integer.class || type == Integer.TYPE)
				return Integer.valueOf(s, base);
			if (type == Long.class || type == Long.TYPE)
				return Long.valueOf(s, base);
			if (type == Short.class || type == Short.TYPE)
				return Short.valueOf(s, base);
			if (type == Byte.class || type == Byte.TYPE)
				return Byte.valueOf(s, base);
			if (type == BigInteger.class)
				return new BigInteger(s);
			return null;
		} catch (NumberFormatException e) {
			throw new ParseException("Could not convert string '%s' to class '%s'", s, type.getName());
		}
	}

	/**
	 * Method that gets called when an unknown bean property name is encountered.
	 *
	 * @param <T> The class type of the bean map that doesn't have the expected property.
	 * @param propertyName The unknown bean property name.
	 * @param beanMap The bean that doesn't have the expected property.
	 * @param line The line number where the property was found.  <code>-1</code> if line numbers are not available.
	 * @param col The column number where the property was found.  <code>-1</code> if column numbers are not available.
	 * @throws ParseException Automatically thrown if {@link BeanContextProperties#IGNORE_UNKNOWN_BEAN_PROPERTIES} setting
	 * 	on this parser is <jk>false</jk>
	 */
	protected <T> void onUnknownProperty(String propertyName, BeanMap<T> beanMap, int line, int col) throws ParseException {
		if (propertyName.equals("uri") || propertyName.equals("type") || propertyName.equals("_class"))
			return;
		if (! beanContext.ignoreUnknownBeanProperties)
			throw new ParseException(line, col, "Unknown property '%s' encountered while trying to parse into class '%s'", propertyName, beanMap.getClassType());
		if (listeners.size() > 0)
			for (ParserListener listener : listeners)
				listener.onUnknownProperty(propertyName, beanMap.getClassType().getInnerClass(), beanMap.getBean(), line, col);
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on CoreAPI
	//--------------------------------------------------------------------------------

	@Override
	public Parser setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	@Override
	public Parser setBeanContext(BeanContext beanContext) throws LockedException {
		super.setBeanContext(beanContext);
		return this;
	}

	@Override
	public Parser addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override
	public Parser addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override
	public Parser addFilters(Filter...s) throws LockedException {
		super.addFilters(s);
		return this;
	}

	@Override
	public Parser addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override
	public <T> Parser addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override
	public Parser addImplClasses(Map<Class<?>,Class<?>> implClasses) throws LockedException {
		super.addImplClasses(implClasses);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public Parser lock() {
		super.lock();
		return this;
	}

	@Override
	public Parser clone() {
		throw new RuntimeException(new CloneNotSupportedException());
	}
}
