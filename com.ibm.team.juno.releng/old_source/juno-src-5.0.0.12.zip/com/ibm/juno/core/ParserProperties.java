package com.ibm.juno.core;


/**
 * Configurable properties common to all {@link Parser} classes.
 * <p>
 * 	Use the {@link Parser#setProperty(String, Object)} method to set property values.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ParserProperties {

	// No common parser properties at this time.

}
