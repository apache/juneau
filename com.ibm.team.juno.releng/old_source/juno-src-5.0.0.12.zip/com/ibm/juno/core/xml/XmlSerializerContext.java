package com.ibm.juno.core.xml;

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.utils.*;

/**
 * Context object that lives for the duration of a single serialization of the {@link XmlSerializer}.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class XmlSerializerContext extends SerializerContext {

	private List<Namespace> namespaces = new IdentityList<Namespace>();
	private XmlSerializerProperties xsp = new XmlSerializerProperties();

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param xsp Default XML serializer properties.
	 * @param op Override properties.
	 */
	protected XmlSerializerContext(BeanContext beanContext, SerializerProperties sp, XmlSerializerProperties xsp, JsonMap...op) {
		super(beanContext, sp, op);
		this.xsp = new XmlSerializerProperties(xsp);
		for (JsonMap m : op)
			for (Map.Entry<String,Object> e : m.entrySet())
				this.xsp.setProperty(e.getKey(), e.getValue());

	}

	/**
	 * Returns the list of namespaces being used in the current XML serialization.
	 * @return The list of namespaces being used in the current XML serialization.
	 */
	public List<Namespace> getNamespaces() {
		return namespaces;
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ADD_JSON_TYPE_ATTRS} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ADD_JSON_TYPE_ATTRS} setting value in this context.
	 */
	public final boolean isAddJsonTypeAttrs() {
		return xsp.isAddJsonTypeAttrs();
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ADD_JSON_STRING_TYPE_ATTRS} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ADD_JSON_STRING_TYPE_ATTRS} setting value in this context.
	 */
	public final boolean isAddJsonStringTypeAttrs() {
		return xsp.isAddJsonStringTypeAttrs();
	}

	/**
	 * Returns the {@link XmlSerializerProperties#AUTO_DETECT_NAMESPACES} setting value in this context.
	 * @return The {@link XmlSerializerProperties#AUTO_DETECT_NAMESPACES} setting value in this context.
	 */
	public final boolean isAutoDetectNamespaces() {
		return xsp.isAutoDetectNamespaces();
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ENABLE_NAMESPACES} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ENABLE_NAMESPACES} setting value in this context.
	 */
	public final boolean isEnableNamespaces() {
		return xsp.isEnableNamespaces();
	}

	/**
	 * Returns the {@link XmlSerializerProperties#ADD_NAMESPACE_URIS_TO_ROOT} setting value in this context.
	 * @return The {@link XmlSerializerProperties#ADD_NAMESPACE_URIS_TO_ROOT} setting value in this context.
	 */
	public final boolean isAddNamespaceUrlsToRoot() {
		return xsp.isAddNamespaceUrlsToRoot();
	}

	/**
	 * Returns the {@link XmlSerializerProperties#DEFAULT_NAMESPACE_URI} setting value in this context.
	 * @return The {@link XmlSerializerProperties#DEFAULT_NAMESPACE_URI} setting value in this context.
	 */
	public final Namespace getDefaultNamespace() {
		return xsp.getDefaultNamespace();
	}

	/**
	 * Returns the {@link XmlSerializerProperties#DEFAULT_NAMESPACES} setting value in this context.
	 * @return The {@link XmlSerializerProperties#DEFAULT_NAMESPACES} setting value in this context.
	 */
	public final List<Namespace> getDefaultNamespaces() {
		return xsp.getDefaultNamespaces();
	}

	/**
	 * Returns the {@link XmlSerializerProperties#XSI_NAMESPACE} setting value in this context.
	 * @return The {@link XmlSerializerProperties#XSI_NAMESPACE} setting value in this context.
	 */
	public final Namespace getXsiNamespace() {
		return xsp.getXsiNamespace();
	}

	/**
	 * Returns the {@link XmlSerializerProperties#XS_NAMESPACE} setting value in this context.
	 * @return The {@link XmlSerializerProperties#XS_NAMESPACE} setting value in this context.
	 */
	public final Namespace getXsNamespace() {
		return xsp.getXsNamespace();
	}
}
