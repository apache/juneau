package com.ibm.juno.core.html;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.xml.*;

/**
 * Specialized writer for serializing HTML.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlSerializerWriter extends XmlSerializerWriter {

	/**
	 * Constructor.
	 * @param out The writer being wrapped.
	 * @param useIndentation If <jk>true</jk>, tabs will be used in output.
	 * @param quoteChar The quote character to use (i.e. <js>'\''</js> or <js>'"'</js>)
	 */
	public HtmlSerializerWriter(Writer out, boolean useIndentation, char quoteChar) {
		super(out, useIndentation, quoteChar);
	}

	/**
	 * Shortcut for calling <code><jk>new</jk> HtmlSerializerWriter(out, s.isUseIndentation(), s.getQuoteChar())</code>.
	 * @param out The writer being wrapped.
	 * @param s The serializer to copy settings from.
	 */
	public HtmlSerializerWriter(Writer out, Serializer s) {
		super(out, s.isUseIndentation(), s.getQuoteChar());
	}

	/**
	 * Serializes the specified object as valid HTML text.
	 */
	@Override
	public HtmlSerializerWriter encodeText(Object o) throws IOException {

		String s = o.toString();
		for (int i = 0; i < s.length(); i++) {
			char test = s.charAt(i);
			if (test == '&')
				append("&amp;");
			else if (test == '<')
				append("&lt;");
			else if (test == '>')
				append("&gt;");
			else if (test == '\n')
				append("<br/>");
			else if (test == '\f')
				append("<ff/>");
			else if (test == '\b')
				append("<bs/>");
			else if (test == '\t')
				append("<tb/>");
			else if (Character.isISOControl(test))
				append("&#" + (int) test + ";");
			else
				append(test);
		}

		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on XmlSerializerWriter
	//--------------------------------------------------------------------------------

	@Override
	public HtmlSerializerWriter oTag(String ns, String name, boolean needsEncoding) throws IOException {
		super.oTag(ns, name, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter oTag(String ns, String name) throws IOException {
		super.oTag(ns, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter oTag(String name) throws IOException {
		super.oTag(name);
		return this;
	}

	@Override
	public HtmlSerializerWriter oTag(int indent, String ns, String name, boolean needsEncoding) throws IOException {
		super.oTag(indent, ns, name, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter oTag(int indent, String ns, String name) throws IOException {
		super.oTag(indent, ns, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter oTag(int indent, String name) throws IOException {
		super.oTag(indent, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter tag(String ns, String name, boolean needsEncoding) throws IOException {
		super.tag(ns, name, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter tag(String ns, String name) throws IOException {
		super.tag(ns, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter tag(String name) throws IOException {
		super.tag(name);
		return this;
	}

	@Override
	public HtmlSerializerWriter tag(int indent, String name) throws IOException {
		super.tag(indent, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter tag(int indent, String ns, String name, boolean needsEncoding) throws IOException {
		super.tag(indent, ns, name, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter tag(int indent, String ns, String name) throws IOException {
		super.tag(indent, ns, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter sTag(String ns, String name) throws IOException {
		super.sTag(ns, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter sTag(String ns, String name, boolean needsEncoding) throws IOException {
		super.sTag(ns, name, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter sTag(int indent, String ns, String name) throws IOException {
		super.sTag(indent, ns, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter sTag(int indent, String name) throws IOException {
		super.sTag(indent, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter sTag(String name) throws IOException {
		super.sTag(name);
		return this;
	}

	@Override
	public HtmlSerializerWriter sTag(int indent, String ns, String name, boolean needsEncoding) throws IOException {
		super.sTag(indent, ns, name, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter eTag(String ns, String name) throws IOException {
		super.eTag(ns, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter eTag(String ns, String name, boolean needsEncoding) throws IOException {
		super.eTag(ns, name, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter eTag(int indent, String ns, String name) throws IOException {
		super.eTag(indent, ns, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter eTag(int indent, String name) throws IOException {
		super.eTag(indent, name);
		return this;
	}

	@Override
	public HtmlSerializerWriter eTag(String name) throws IOException {
		super.eTag(name);
		return this;
	}

	@Override
	public HtmlSerializerWriter eTag(int indent, String ns, String name, boolean needsEncoding) throws IOException {
		super.eTag(indent, ns, name, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter attr(String name, Object value) throws IOException {
		super.attr(name, value);
		return this;
	}

	@Override
	public HtmlSerializerWriter attr(String ns, String name, Object value) throws IOException {
		super.attr(ns, name, value);
		return this;
	}

	@Override
	public HtmlSerializerWriter attr(String ns, String name, Object value, boolean needsEncoding) throws IOException {
		super.attr(ns, name, value, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter attr(String name, Object value, boolean needsEncoding) throws IOException {
		super.attr(null, name, value, needsEncoding);
		return this;
	}

	@Override
	public HtmlSerializerWriter oAttr(String ns, String name) throws IOException {
		super.oAttr(ns, name);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on SerializerWriter
	//--------------------------------------------------------------------------------

	@Override
	public HtmlSerializerWriter cr(int depth) throws IOException {
		super.cr(depth);
		return this;
	}

	@Override
	public HtmlSerializerWriter appendln(int indent, String text) throws IOException {
		super.appendln(indent, text);
		return this;
	}

	@Override
	public HtmlSerializerWriter appendln(String text) throws IOException {
		super.appendln(text);
		return this;
	}

	@Override
	public HtmlSerializerWriter append(int indent, String text) throws IOException {
		super.append(indent, text);
		return this;
	}

	@Override
	public HtmlSerializerWriter append(int indent, char c) throws IOException {
		super.append(indent, c);
		return this;
	}

	@Override
	public HtmlSerializerWriter s() throws IOException {
		super.s();
		return this;
	}

	@Override
	public HtmlSerializerWriter q() throws IOException {
		super.q();
		return this;
	}

	@Override
	public HtmlSerializerWriter i(int indent) throws IOException {
		super.i(indent);
		return this;
	}

	@Override
	public HtmlSerializerWriter nl() throws IOException {
		super.nl();
		return this;
	}

	@Override
	public HtmlSerializerWriter append(Object text) throws IOException {
		super.append(text);
		return this;
	}

	@Override
	public HtmlSerializerWriter append(String text) throws IOException {
		super.append(text);
		return this;
	}

	@Override
	public HtmlSerializerWriter appendIf(boolean b, String text) throws IOException {
		super.appendIf(b, text);
		return this;
	}

	@Override
	public HtmlSerializerWriter appendIf(boolean b, char c) throws IOException {
		super.appendIf(b, c);
		return this;
	}

	@Override
	public HtmlSerializerWriter append(char c) throws IOException {
		super.append(c);
		return this;
	}
}
