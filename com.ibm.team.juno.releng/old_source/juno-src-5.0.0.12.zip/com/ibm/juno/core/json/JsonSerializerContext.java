package com.ibm.juno.core.json;

import java.util.*;

import com.ibm.juno.core.*;

/**
 * Context object that lives for the duration of a single serialization of {@link JsonSerializer} and its subclasses.
 * <p>
 * 	See {@link SerializerContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonSerializerContext extends SerializerContext {

	private JsonSerializerProperties jsp;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the serializer.
	 * @param sp Default general serializer properties.
	 * @param jsp Default JSON serializer properties.
	 * @param op Override properties.
	 */
	protected JsonSerializerContext(BeanContext beanContext, SerializerProperties sp, JsonSerializerProperties jsp, JsonMap[] op) {
		super(beanContext, sp, op);
		this.jsp = new JsonSerializerProperties(jsp);
		for (JsonMap m : op)
			for (Map.Entry<String,Object> e : m.entrySet())
				this.jsp.setProperty(e.getKey(), e.getValue());
	}

	/**
	 * Returns the {@link JsonSerializerProperties#STRICT_MODE} setting value in this context.
	 * @return The {@link JsonSerializerProperties#STRICT_MODE} setting value in this context.
	 */
	public final boolean isStrictMode() {
		return jsp.isStrictMode();
	}

	/**
	 * Returns the {@link JsonSerializerProperties#USE_WHITESPACE} setting value in this context.
	 * @return The {@link JsonSerializerProperties#USE_WHITESPACE} setting value in this context.
	 */
	public final boolean isUseWhitespace() {
		return jsp.isUseWhitespace();
	}
}
