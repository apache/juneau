package com.ibm.juno.core;


/**
 * Superclass of all classes that have a locked state.
 * <p>
 * 	Used to mark bean contexts, serializers, and parsers as read-only so that
 * 	settings can no longer be modified.
 * <p>
 * 	Calling {@link #lock()} on the object causes it to be put into a read-only state.
 * 	Once called, subsequent calls to {@link #checkLock()} will cause {@link LockedException LockedExceptions}
 * 		to be thrown.
 * <p>
 * 	As a rule, cloned objects are unlocked by default.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class Lockable implements Cloneable {

	private boolean isLocked = false;

	/**
	 * Locks this object so that settings on it cannot be modified.
	 * @return This object (for method chaining).
	 */
	public Lockable lock() {
		isLocked = true;
		return this;
	}

	/**
	 * @return <code><jk>true</jk></code> if this object has been locked.
	 */
	public boolean isLocked() {
		return isLocked;
	}

	/**
	 * Causes a {@link LockedException} to be thrown if this object has been locked.
	 * Otherwise, a no-op.
	 * @throws LockedException If {@link #lock()} has been called on this object.
	 */
	public void checkLock() throws LockedException {
		if (isLocked)
			throw new LockedException();
	}

	/**
	 * Creates an unlocked clone of this object.
	 */
	@Override
	public abstract Lockable clone();
}
