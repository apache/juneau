package com.ibm.juno.client;

import java.io.*;

/**
 * Authenticator for performing BASIC HTTP authentication against a reverse proxy.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("restriction")
public class BasicProxyAuthenticator implements Authenticator {

	private String authorization;

	/**
	 * Constructor.
	 * @param user Username.
	 * @param pw Password.
	 */
	public BasicProxyAuthenticator(String user, String pw) {
		try {
			authorization = "Basic " + new sun.misc.BASE64Encoder().encode((user + ":" + pw).getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// Won't happen.
		}
	}

	/**
	 * Adds a <js>"Proxy-Authorization"</js> header to all requests.
	 */
	@Override
	public void authenticate(RestClient client) throws RestCallException {
		client.addRequestHeader("Proxy-Authorization", authorization);
	}

}
