package com.ibm.juno.server.serializers;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.server.*;

/**
 * Serializes POJOs to plain text using just the <code>toString()</code> method on the serialized object.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"text/plain"</js></ul></td>
 * 		<td><ul><li><js>"text/plain"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class PlainTextRestSerializer extends RestSerializer {

	@Override
	public void serialize(RestRequest req, RestResponse res) throws IOException, SerializeException {
		Writer w = res.getWriter();
		Object o = res.getOutput();
		w.write(o == null ? "null" : o.toString());
		w.close();
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"text/plain"};
	}
}
