package com.ibm.juno.server.serializers;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.server.*;

/**
 * Serializes POJOs to URL-encoded strings.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"application/x-www-form-urlencoded"</js></ul></td>
 * 		<td><ul><li><js>"application/x-www-form-urlencoded"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingRestSerializer extends RestSerializerSerializer {

	/**
	 * Constructor using {@link UrlEncodingSerializer#DEFAULT} as the POJO serializer.
	 */
	public UrlEncodingRestSerializer() {
		super(UrlEncodingSerializer.DEFAULT.clone());
	}

	/**
	 * Construct using the specified {@link UrlEncodingSerializer} as the POJO serializer.
	 *
	 * @param serializer The serializer.
	 */
	public UrlEncodingRestSerializer(Serializer serializer) {
		super(serializer);
	}

	@Override
	public void serialize(RestRequest req, Object output, Writer out, JsonMap properties, String matchingAccept) throws IOException, SerializeException {
		serializer.serialize(out, output, properties);
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"application/x-www-form-urlencoded"};
	}
}
