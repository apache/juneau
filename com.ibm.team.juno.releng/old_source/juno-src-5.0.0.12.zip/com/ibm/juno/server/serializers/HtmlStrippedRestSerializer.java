package com.ibm.juno.server.serializers;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import static com.ibm.juno.core.SerializerProperties.*;

import java.io.*;
import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.html.*;
import com.ibm.juno.server.*;

/**
 * Serializes POJOs to HTTP responses as stripped HTML.
 * <p>
 * Produces the same output as {@link HtmlRestSerializer}, but without the header and body tags and page title and description.
 * <p>
 * Used primarily for JUnit testing the {@link HtmlRestSerializer} class.
 * <p>
 * <table class='styled'>
 * 	<tr>
 * 		<th><code>Accept</code></th>
 * 		<th><code>Content-Type</code></th>
 * 	</tr>
 * 	<tr>
 * 		<td><ul><li><js>"text/html+stripped"</js></ul></td>
 * 		<td><ul><li><js>"text/html"</js></ul></td>
 * 	</tr>
 * </table>
 * <p>
 * For more information, refer to {@link RestSerializer}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class HtmlStrippedRestSerializer extends RestSerializerSerializer {

	/**
	 * Constructor using {@link HtmlSerializer#DEFAULT} as the POJO serializer.
	 */
	public HtmlStrippedRestSerializer() {
		super(HtmlSerializer.DEFAULT.clone());
	}

	/**
	 * Construct using the specified {@link HtmlSerializer} as the POJO serializer.
	 *
	 * @param serializer The serializer.
	 */
	public HtmlStrippedRestSerializer(Serializer serializer) {
		super(serializer);
	}

	@Override
	public void serialize(RestRequest req, Object output, Writer out, JsonMap properties, String matchingAccept) throws IOException, SerializeException {
		boolean useIndentation = properties.getBoolean(USE_INDENTATION, serializer.isUseIndentation());
		char quoteChar = properties.get(char.class, QUOTE_CHAR, serializer.getQuoteChar());
		HtmlSerializerWriter w = new HtmlSerializerWriter(out, useIndentation, quoteChar);
		doSerialize(w, output, properties);
		w.flush();
	}

	void doSerialize(HtmlSerializerWriter w, Object output, JsonMap properties) throws IOException, SerializeException {
		if (output == null
			|| (output instanceof Collection && ((Collection<?>)output).size() == 0)
			|| (output.getClass().isArray() && ((Object[])output).length == 0))
			w.sTag(1, "p").append("No Results").eTag("p").nl();
		else
			serializer.serialize(w, output, properties);
	}

	/**
	 * Returns the URL to the cascade stylesheet to use when rendering HTML.
	 * <p>
	 * 	By default, points to the stylesheet defined in the {@code com.ibm.juno.server.htdocs} package.
	 * <p>
	 * 	Subclasses can optionally override this method to point to different stylesheets.
	 *
	 * @param req The HTTP request.
	 * @return The URL pointing to the stylesheet to use for HTML output.
	 */
	protected String getStyleSheetUrl(RestRequest req) {
		return req.getContextPath() + req.getServletPath() + "/htdocs/juno.css";
	}

	@Override
	public String getResponseContentType() {
		return "text/html";
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"text/html+stripped"};
	}
}
