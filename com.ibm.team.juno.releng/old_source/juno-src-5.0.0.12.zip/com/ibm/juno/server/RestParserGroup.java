package com.ibm.juno.server;

import java.util.*;

import com.ibm.juno.core.*;
import com.ibm.juno.server.annotation.*;

/**
 * Represents a group of {@link RestParser} objects.
 * <p>
 *		Methods defined on this interface allow all registered parsers to be organized and modified in sync.
 * <p>
 * 	The {@link RestServlet} class uses parser groups to organize parsers.
 		See {@link RestServlet#getParserGroup()} for more information.
 *
 * <h6 class='topic'>Examples</h6>
 * <p class='bcode'>
 * 	<jc>// Construct a new rest parser group</jc>
 * 	RestParserGroup g = <jk>new</jk> RestParserGroup();
 *
 * 	<jc>// Register some parsers with the content types they're supposed to handle</jc>
 * 	g.append(JsonParser.<jk>class</jk>, XmlParser.<jk>class</jk>);
 *
 * 	<jc>// Change settings on the parsers simultaneously</jc>
 * 	g.setProperty(<jsf>REQUIRE_SERIALIZABLE</jsf>, <jk>true</jk>)
 * 		.addFilters(CalendarFilter.<jsf>DEFAULT_ISO8601DT</jsf>);
 *
 * 	<jc>// Get one of the parsers</jc>
 * 	RestParser p = g.getRestParser(<js>"text/xml"</js>);
 * </p>
 *
 * <p>
 * 	To register new parsers with a resource, implementers will typically override the {@link RestServlet#getParserGroup()}
 * 		method and add to the group already created by the super method, or use the {@link RestResource#parsers()}
 * 		or {@link RestMethod#parsers()} annotations.
 *
 * <p class='bcode'>
 * 	<jk>public</jk> MyResource <jk>extends</jk> RestServlet {
 *
 * 		<jc>// Override default parser group</jc>
 * 		<ja>@Override</ja>
 * 		<jk>public</jk> RestParserGroup getParserGroup() {
 *
 * 			<jc>// Get the parent parser group</jc>
 * 			RestParserGroup g = <jk>super</jk>.getParserGroup();
 *
 * 			<jc>// Add a new parser to it</jc>
 * 			RestParser fooParser = <jk>new</jk> FooParser();
 * 			g.append(fooParser);
 *
 * 			<jc>// Return the updated parser</jc>
 * 			<jk>return</jk> g;
 * 		}
 * 	}
 * </p>
 * <p>
 * 	Properties can be conveniently set on a resource's parser group through the {@link RestResource#properties} annotation.
 * <p class='bcode'>
 * 	<ja>@RestResource</ja>(
 * 		properties={
 * 			<ja>@Property</ja>(name=<jsf>BEANS_REQUIRE_SERIALIZABLE</jsf>, value=<js>"true"</js>)
 * 		}
 * 	)
 * 	<jk>public</jk> MyRestResource <jk>extends</jk> RestServletDefault {
 * 		...
 * </p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestParserGroup extends ParserGroup {

	private Map<String,RestParser> restParsers = new LinkedHashMap<String,RestParser>();
	private RestParserGroup parentGroup;

	private String label;

	/**
	 * Constructor.
	 * @param label The string that gets returned when you call toString() on this object.
	 */
	public RestParserGroup(String label) {
		this.label = label;
	}

	/**
	 * Copy constructor.
	 * @param copyFrom The group to clone.
	 */
	protected RestParserGroup(RestParserGroup copyFrom) {
		super(copyFrom);
		this.label = copyFrom.label;
	}

	RestParserGroup setParent(RestParserGroup parentGroup) {
		this.parentGroup = parentGroup;
		return this;
	}

	/**
	 * Returns the parser registered to handle the specified request <code>Content-Type</code>.
	 *
	 * @param mediaType The content type string (e.g. <js>"text/json"</js>) stripped of any parameters such as <js>";charset=X"</js>.
	 * @return The REST parser that handles the specified request content type, or <jk>null</jk> if
	 * 		no parser is registered to handle it.
	 */
	public RestParser getRestParser(String mediaType) {
		RestParser p = restParsers.get(mediaType);
		if (p == null && parentGroup != null)
			p = parentGroup.getRestParser(mediaType);
		return p;
	}

	@Override
	public String toString() {
		return label;
	}

	/**
	 * Registers the specified REST parsers with this parser group.
	 *
	 * @param parsers The parsers to append to this group.
	 * @return This object (for method chaining).
	 */
	public RestParserGroup append(RestParser...parsers) {
		for (RestParser p : parsers) {
			for (String s : p.getMediaTypes())
				restParsers.put(s.toLowerCase(Locale.ENGLISH), p);
			if (p instanceof RestParserParser) {
				RestParserParser p2 = (RestParserParser)p;
				super.add(p2.getParser(), p2.getMediaTypes());
			}
		}
		return this;
	}

	/**
	 * Same as {@link #append(RestParser...)}, except specify classes instead of class instances
	 * 	 of {@link RestParser}.
	 * <p>
	 * Note that this can only be used on {@link RestParser RestParsers} with no-arg constructors.
	 *
	 * @param parsers The parsers to append to this group.
	 * @return This object (for method chaining).
	 * @throws Exception Thrown if {@link RestSerializer} could not be constructed.
	 */
	public RestParserGroup append(Class<? extends RestParser>...parsers) throws Exception {
		for (Class<? extends RestParser> c : parsers)
			append(c.newInstance());
		return this;
	}

	@Override
	public Set<String> getSupportedContentTypes() {
		Set<String> s = new LinkedHashSet<String>();
		s.addAll(restParsers.keySet());
		if (parentGroup != null)
			s.addAll(parentGroup.getSupportedContentTypes());
		return s;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on CoreAPI
	//--------------------------------------------------------------------------------

	@Override
	public RestParserGroup setProperty(String property, Object value) throws LockedException {
		super.setProperty(property, value);
		return this;
	}

	@Override
	public RestParserGroup setProperties(JsonMap properties) throws LockedException {
		super.setProperties(properties);
		return this;
	}

	@Override
	public RestParserGroup setBeanContext(BeanContext beanContext) throws LockedException {
		super.setBeanContext(beanContext);
		return this;
	}

	@Override
	public RestParserGroup addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override
	public RestParserGroup addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override
	public RestParserGroup addFilters(Filter...s) throws LockedException {
		super.addFilters(s);
		return this;
	}

	@Override
	public RestParserGroup addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override
	public <T> RestParserGroup addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	//--------------------------------------------------------------------------------
	// Overridden methods on Lockable
	//--------------------------------------------------------------------------------

	@Override
	public RestParserGroup lock() {
		super.lock();
		return this;
	}

	@Override
	public RestParserGroup clone() {
		return new RestParserGroup(this);
	}
}
