package com.ibm.juno.server.parsers;

import com.ibm.juno.core.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.server.*;

/**
 * Parsers HTTP request bodies with <code>Content-Type</code> of <js>"application/x-www-form-urlencoded"</js> into POJOs.
 * <p>
 * For more information, refer to {@link RestParser}.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingRestParser extends RestParserParser {

	/**
	 * Constructor using {@link UrlEncodingParser#DEFAULT} as the POJO parser.
	 */
	public UrlEncodingRestParser() {
		super(UrlEncodingParser.DEFAULT.clone());
	}

	/**
	 * Construct using the specified {@link JsonParser} as the POJO parser.
	 *
	 * @param parser The parser.
	 */
	public UrlEncodingRestParser(Parser parser) {
		super(parser);
	}

	@Override
	public String[] getMediaTypes() {
		return new String[]{"application/x-www-form-urlencoded"};
	}
}
