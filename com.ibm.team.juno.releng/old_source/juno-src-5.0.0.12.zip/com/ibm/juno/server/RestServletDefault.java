package com.ibm.juno.server;

import com.ibm.juno.server.annotation.*;
import com.ibm.juno.server.parsers.*;
import com.ibm.juno.server.serializers.*;

/**
 * Subclass of {@link RestServlet} with default implementations for
 * 	{@link RestServlet#getSerializerGroup()} and {@link RestServlet#getParserGroup()}.
 * <p>
 * Adds the following serializers to the serializer group:
 * <ul>
 * 	<li>{@link JsonRestSerializer}
 * 	<li>{@link JsonSchemaRestSerializer}
 * 	<li>{@link JsonLaxRestSerializer}
 * 	<li>{@link XmlRestSerializer}
 * 	<li>{@link XmlSchemaRestSerializer}
 * 	<li>{@link HtmlRestSerializer}
 * 	<li>{@link HtmlStrippedRestSerializer}
 * 	<li>{@link UrlEncodingRestSerializer}
 * 	<li>{@link SoapXmlRestSerializer}
 * 	<li>{@link RdfRestSerializer}
 * 	<li>{@link JavaObjectRestSerializer}
 * </ul>
 * <p>
 * Adds the following parsers to the parser group:
 * <ul>
 * 	<li>{@link JsonRestParser}
 * 	<li>{@link XmlRestParser}
 * 	<li>{@link HtmlRestParser}
 * 	<li>{@link UrlEncodingRestParser}
 * </ul>
 * <p>
 * Note that the list of serializers and parsers can be appended to using the {@link RestResource#serializers()} and {@link RestResource#parsers()} annotations.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestServletDefault extends RestServlet {

	@Override
	@SuppressWarnings("unchecked")
	public RestSerializerGroup getSerializerGroup() throws Exception {
		String label = "RestSerializerGroup for class ["+this.getClass().getName()+"]";

		return new RestSerializerGroup(label)
			.append(
				JsonRestSerializer.class,
				JsonSchemaRestSerializer.class,
				JsonLaxRestSerializer.class,
				XmlRestSerializer.class,
				XmlSchemaRestSerializer.class,
				HtmlRestSerializer.class,
				HtmlStrippedRestSerializer.class,
				UrlEncodingRestSerializer.class,
				SoapXmlRestSerializer.class,
				RdfRestSerializer.class,
				JavaObjectRestSerializer.class
			)
			.setBeanContext(getBeanContext());
	}

	@Override
	@SuppressWarnings("unchecked")
	public RestParserGroup getParserGroup() throws Exception {

		String label = "RestParserGroup for class ["+this.getClass().getName()+"]";

		return new RestParserGroup(label)
			.append(JsonRestParser.class, XmlRestParser.class, HtmlRestParser.class, UrlEncodingRestParser.class)
			.setBeanContext(getBeanContext());
	}
}
