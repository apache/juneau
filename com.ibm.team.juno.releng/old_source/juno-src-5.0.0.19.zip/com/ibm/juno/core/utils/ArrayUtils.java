package com.ibm.juno.core.utils;

import java.lang.reflect.*;

/**
 * Quick and dirty utilities for working with arrays.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class ArrayUtils {

	/**
	 * Appends one or more elements to an array.
	 * @param <T> The element type.
	 * @param array The array to append to.
	 * @param newElements The new elements to append to the array.
	 * @return A new array with the specified elements appended.
	 */
	@SuppressWarnings("unchecked")
	public static <T> T[] append(T[] array, T...newElements) {
		T[] a = (T[])Array.newInstance(newElements[0].getClass(), array.length + newElements.length);
		for (int i = 0; i < array.length; i++)
			a[i] = array[i];
		for (int i = 0; i < newElements.length; i++)
			a[i+array.length] = newElements[i];
		return a;
	}
}
