package com.ibm.juno.core.rdfxml;
//******************************************************************************
//*  Licensed Material - Property of IBM
//*
//*  5724-V27
//*  Copyright IBM Corp. 2011
//*
//*  The source code for this program is not published or otherwise
//*  divested of its trade secrets, irrespective of what has been
//*  deposited with the U.S. Copyright Office.
//******************************************************************************

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;

/**
 * Serializes POJOs to HTTP responses as RDF/XML.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Handles <code>Accept</code> types: <code>text/xml+rdf</code>
 * <p>
 * 	Produces <code>Content-Type</code> types: <code>text/xml+rdf</code>
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	Same as {@link RdfXmlSerializer}, except prepends <code><xt>&lt;?xml</xt> <xa>version</xa>=<xs>'1.0'</xs> <xa>encoding</xa>=<xs>'UTF-8'</xs><xt>?&gt;</xt></code> to the response
 * 	and wraps the output in an <code><xt>&lt;rdf:RDF&gt;</xt><code> tag.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfXmlDocSerializer extends RdfXmlSerializer {

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer
	public void serialize(Object output, Writer out, ObjectMap properties, String matchingAccept) throws IOException, SerializeException {
		RdfXmlSerializerContext ctx = new RdfXmlSerializerContext(beanContext, sp, xsp, rxsp, properties);
		XmlSerializerWriter w = (out instanceof XmlSerializerWriter ? (XmlSerializerWriter)out : new XmlSerializerWriter(out, ctx.isUseIndentation(), ctx.getQuoteChar(), ctx.getUriContext(), ctx.getUriAuthority()));

		boolean en = ctx.isEnableNamespaces();
		Namespace rdfNs = ctx.getRdfNamespace();
		Namespace dnsNs = ctx.getDefaultNamespace();
		String
			rdf = (en ? rdfNs.getName() : null),
			rdfUri = (en ? rdfNs.getUri() : null),
			dns = (en ? dnsNs.getName() : null),
			dnsUri = (en ? dnsNs.getUri() : null);

		w.append("<?xml")
			.attr("version", "1.0")
			.attr("encoding", "UTF-8")
			.appendln("?>");
		w.oTag(rdf, "RDF");
		if (rdf != null)
			w.attr("xmlns", rdf, rdfUri);
		if (dns != null)
			w.attr("xmlns", dns, dnsUri);
		w.appendln(">");
		doSerialize(output, w, ctx, null);
		w.eTag(rdf, "RDF");
		w.flush();
		w.close();
	}
}
