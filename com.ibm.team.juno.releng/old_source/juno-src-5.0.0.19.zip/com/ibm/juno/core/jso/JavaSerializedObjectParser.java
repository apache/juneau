package com.ibm.juno.core.jso;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;

/**
 * Parses POJOs from HTTP responses as Java {@link ObjectInputStream ObjectInputStreams}.
 *
 *
 * <h6 class='topic'>Media types</h6>
 * <p>
 * 	Consumes <code>Content-Type</code> types: <code>application/x-java-serialized-object</code>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JavaSerializedObjectParser extends InputStreamParser {

	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@SuppressWarnings("unchecked")
	@Override // IInputStreamParser
	public <T> T parse(InputStream in, ClassType<T> type, ObjectMap properties, String mediaType, String charset) throws ParseException, IOException {
		try {
			ObjectInputStream ois = new ObjectInputStream(in);
			return (T)ois.readObject();
		} catch (ClassNotFoundException e) {
			throw new ParseException(e);
		}
	}


	@Override // ILockable
	public JavaSerializedObjectParser clone() {
		try {
			return (JavaSerializedObjectParser)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
