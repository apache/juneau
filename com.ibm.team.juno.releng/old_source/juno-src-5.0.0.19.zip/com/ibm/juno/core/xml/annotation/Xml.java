package com.ibm.juno.core.xml.annotation;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.*;

import java.lang.annotation.*;

/**
 * Annotation for specifying various XML options for the XML and RDF/XML serializers.
 * <p>
 * 	Can be applied to Java packages, types, fields, and methods.
 * <p>
 * 	Can be used for the following:
 * <ul>
 * 	<li>Override the element name on the XML representation of a bean or object.
 * 	<li>Override the child element name on the XML representation of collection or array properties.
 * 	<li>Specify the XML namespace on a package, class, or method.
 * 	<li>Override the XML format on a POJO.
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Documented
@Target({TYPE,PACKAGE,FIELD,METHOD})
@Retention(RUNTIME)
@Inherited
public @interface Xml {

	/**
	 * Sets the name of the XML element in cases where the XML element has no name (e.g. the root element).
	 * <p>
	 * 	Applies only to {@link ElementType#TYPE}.
	 *
	 * <h6 class='topic'>Examples</h6>
	 * <p class='bcode'>
	 * 	<ja>@Xml</ja>(elementName=<js>"MyBean"</js>)
	 * 	<jk>public class</jk> MyBean {
	 * 		<jk>public int</jk> f1 = 123;
	 * 	}
	 * </p>
	 * <p>
	 * 	Without the <ja>@Xml</ja> annotations, serializing this bean as XML would have produced the following...
	 * </p>
	 * <p class='bcode'>
	 * 	<xt>&lt;object&gt;</xt>
	 * 		<xt>&lt;f1&gt;</xt>123<xt>&lt;/f1&gt;</xt>
	 * 	<xt>&lt;/object&gt;</xt>
	 * </p>
	 * <p>
	 * 	With the annotations, serializing this bean as XML produces the following...
	 * </p>
	 * <p class='bcode'>
	 * 	<xt>&lt;MyBean&gt;</xt>
	 * 		<xt>&lt;f1&gt;</xt>123<xt>&lt;/f1&gt;</xt>
	 * 	<xt>&lt;/MyBean&gt;</xt>
	 * </p>
	 */
	String elementName() default "";

	/**
	 * Sets the name of the XML child elements for bean properties of type collection and array.
	 * <p>
	 * 	Applies only to bean properties of type element or array.
	 *
	 * <h6 class='topic'>Examples</h6>
	 * <p class='bcode'>
	 * 	<jk>public class</jk> MyBean {
	 * 		<ja>@Xml</ja>(childElementName=<js>"child"</js>}
	 * 		<jk>public</jk> String[] <jf>children</jf> = {<js>"foo"</js>,<js>"bar"</js>};
	 * 	}
	 * </p>
	 * <p>
	 * 	Without the <ja>@Xml</ja> annotation, serializing this bean as XML would have produced the following...
	 * </p>
	 * <p class='bcode'>
	 * 	<xt>&lt;object&gt;</xt>
	 * 		<xt>&lt;children&gt;</xt>
	 * 			<xt>&lt;string&gt;</xt>foo<xt>&lt;/string&gt;</xt>
	 * 			<xt>&lt;string&gt;</xt>bar<xt>&lt;/string&gt;</xt>
	 * 		<xt>&lt;/children&gt;</xt>
	 * 	<xt>&lt;/object&gt;</xt>
	 * </p>
	 * <p>
	 * 	With the annotations, serializing this bean as XML produces the following...
	 * </p>
	 * <p class='bcode'>
	 * 	<xt>&lt;object&gt;</xt>
	 * 		<xt>&lt;children&gt;</xt>
	 * 			<xt>&lt;child&gt;</xt>foo<xt>&lt;/child&gt;</xt>
	 * 			<xt>&lt;child&gt;</xt>bar<xt>&lt;/child&gt;</xt>
	 * 		<xt>&lt;/children&gt;</xt>
	 * 	<xt>&lt;/object&gt;</xt>
	 * </p>
	 */
	String childElementName() default "";

	/**
	 * Sets the namespace name of this property, class, or package.
	 * <p>
	 * 	Can be applied to any type.
	 * <ul>
	 * 	<li>When applied to a {@link ElementType#PACKAGE}, namespace is applied to all classes (and subclasses/properties) in the package, unless
	 * 		overridden by other annotations.
	 * 	<li>When applied to a {@link ElementType#TYPE}, namespace is applied to all properties in the class, and all
	 * 		subclasses of the class.
	 * 	<li>When applied to bean properties on {@link ElementType#METHOD} and {@link ElementType#FIELD}, applies
	 * 		to the bean property.
	 * </ul>
	 * <p>
	 * 	Must either be matched to a {@link #nsUri()} annotation on the same object, or a {@link XmlNs} with the same name
	 * 	through the {@link #namespaces()} annotation on this or parent object.
	 * </p>
	 */
	String ns() default "";

	/**
	 * Sets the namespace URI of this property, class, or package.
	 * <p>
	 * 	Must be matched with a {@link #ns()} annotation.
	 */
	String nsUri() default "";

	/**
	 * Lists all namespace mappings to be used on this object and all child objects.
	 * <p>
	 * 	The purpose of this annotation is to allow namespace mappings to be defined in a single location
	 * 	and referred to by name through just the {@link #ns()} annotation.
	 * <p>
	 * 	Can be applied to packages, classes, methods, and fields.
	 * <p>
	 * 	When applied to a package, also applies to all child packages.
	 * <p>
	 * 	When applied to a class, also applies to all subclasses.
	 *
	 * <h6 class='topic'>Examples</h6>
	 * <p>
	 * 	Contents of <code>package-info.java</code>...
	 * </p>
	 * <p class='bcode'>
	 * 	<jc>// XML namespaces used within this package.</jc>
	 * 	<ja>@Xml</ja>(ns=<js>"ab"</js>,
	 * 		namespaces={
	 * 			<ja>@XmlNs</ja>(name=<js>"ab"</js>, uri=<js>"http://www.ibm.com/addressBook/"</js>),
	 * 			<ja>@XmlNs</ja>(name=<js>"per"</js>, uri=<js>"http://www.ibm.com/person/"</js>),
	 * 			<ja>@XmlNs</ja>(name=<js>"addr"</js>, uri=<js>"http://www.ibm.com/address/"</js>),
	 * 			<ja>@XmlNs</ja>(name=<js>"mail"</js>, uri="<js>http://www.ibm.com/mail/"</js>)
	 * 		}
	 * 	)
	 * 	<jk>package</jk> com.ibm.sample.addressbook;
	 * 	<jk>import</jk> com.ibm.juno.core.xml.annotation.*;
	 * </p>
	 * <p>
	 * 	Class in package using defined namespaces...
	 * </p>
	 * <p class='bcode'>
	 * 	<jk>package</jk> com.ibm.sample.addressbook;
	 *
	 * 	<jc>// Bean class, override "ab" namespace on package.</jc>
	 * 	<ja>@Xml</ja>(ns=<js>"addr"</js>)
	 * 	<jk>public class</jk> Address {
	 *
	 * 		<jc>// Bean property, use "addr" namespace on class.</jc>
	 * 		<jk>public int</jk> <jf>id</jf>;
	 *
	 * 		<jc>// Bean property, override with "mail" namespace.</jc>
	 * 		<ja>@Xml</ja>(ns=<js>"mail"</js>)
	 * 		<jk>public</jk> String <jf>street</jf>, <jf>city</jf>, <jf>state</jf>;
	 * 	}
	 * </p>
	 */
	XmlNs[] namespaces() default {};

	/**
	 * The {@link XmlFormat} to use for serializing this object type.
	 *
	 * <h6 class='topic'>Examples</h6>
	 * <p class='bcode'>
	 * 	<jk>public class</jk> MyBean {
	 *
	 * 		<jc>// Normally, bean properties would be rendered as child elements of the bean element.</jc>
	 * 		<jc>// Override so that it's rendered as a "f1='123'" attribute on the bean element instead.</jc>
	 * 		<ja>@Xml</ja>(format=XmlFormat.<jsf>ATTR</jsf>}
	 * 		<jk>public int</jk> f1 = 123;
	 *
	 * 		<jc>// Normally, bean URL properties would be rendered as XML attributes on the bean element.</jc>
	 * 		<jc>// Override so that it's rendered as an &lt;href&gt;http://foo&lt;/href&gt; child element instead.</jc>
	 * 		<ja>@BeanProperty</ja>(uri=<jk>true</jk>)
	 * 		<ja>@Xml</ja>(format=XmlFormat.<jsf>ELEMENT</jsf>}
	 * 		<jk>public</jk> URL <jf>href</jf> = <jk>new</jk> URL(<js>"http://foo"</js>);
	 *
	 * 		<jc>// Normally, collection properties would be grouped under a single &lt;children&gt; child element on the bean element.</jc>
	 * 		<jc>// Override so that entries are directly children of the bean element with each entry having an element name of &lt;child&gt;.</jc>
	 * 		<ja>@Xml</ja>(format=XmlFormat.<jsf>COLLAPSED</jsf>, childElementName=<js>"child"</js>}
	 * 		<jk>public</jk> String[] <jf>children</jf> = <js>"foo"</js>,<js>"bar"</js>};
	 * 	}
	 * </p>
	 * <p>
	 * 	Without the <ja>@Xml</ja> annotations, serializing this bean as XML would have produced the following...
	 * </p>
	 * <p class='bcode'>
	 * 	<xt>&lt;object</xt> <xa>href</xa>=<js>'http://foo'</js><xt>&gt;</xt>
	 * 		<xt>&lt;f1&gt;</xt>123<xt>&lt;/f1&gt;</xt>
	 * 		<xt>&lt;children&gt;</xt>
	 * 			<xt>&lt;string&gt;</xt>foo<xt>&lt;/string&gt;</xt>
	 * 			<xt>&lt;string&gt;</xt>bar<xt>&lt;/string&gt;</xt>
	 * 		<xt>&lt;/children&gt;</xt>
	 * 	<xt>&lt;/object&gt;</xt>
	 * </p>
	 * <p>
	 * 	With the annotations, serializing this bean as XML produces the following...
	 * </p>
	 * <p class='bcode'>
	 * 	<xt>&lt;object</xt> <xa>f1</xa>=<js>'123'</js><xt>&gt;</xt>
	 * 		<xt>&lt;href&gt;</xt>http://foo<xt>&lt;/href&gt;</xt>
	 * 		<xt>&lt;child&gt;</xt>foo<xt>&lt;/child&gt;</xt>
	 * 		<xt>&lt;child&gt;</xt>bar<xt>&lt;/child&gt;</xt>
	 * 	<xt>&lt;/object&gt;</xt>
	 * </p>
	 */
	XmlFormat format() default XmlFormat.NORMAL;

	/**
	 * Serializes a bean property value as an attribute on the property element.
	 * <p>
	 * 	When applied to a bean property, the value of the bean property is serialized to a
	 * 	string, then applied to the specified attribute value.
	 *
	 * <h6 class='topic'>Example</h6>
	 * <p class='bcode'>
	 * 	<jk>public class</jk> Bean {
	 * 		<ja>@Xml</ja>(valAttr=<js>"bar"</js>)
	 * 		<jk>public</jk> String foo = <js>"baz"</js>;
	 * 	}
	 * </p>
	 * <p>
	 * 	Without the annotation, the XML serializer will produce the following...
	 * </p>
	 * <p class='bcode'>
	 * 	<xt>&lt;object&gt;</xt>
	 * 		<xt>&lt;foo&gt;</xt>baz<xt>&lt;/foo&gt;</xt>
	 * 	<xt>&lt;/object&gt;</xt>
	 * </p>
	 * <p>
	 * 	With the annotation, the XML serializer will produce the following...
	 * </p>
	 * <p class='bcode'>
	 * 	<xt>&lt;object&gt;</xt>
	 * 		<xt>&lt;foo</xt> <xa>bar</xa>=<xs>'baz'</xs><xt>/&gt;</xt>
	 * 	<xt>&lt;/object&gt;</xt>
	 * </p>
	 *
	 * <h6 class='topic'>Notes</h6>
	 * <ul>
	 * 	<li>Can be used on any field type that can be serialized to a <code>String</code>.
	 * 	<li>Value attribute can include a namespace name (e.g. <js>"myns:bar"</js>), which will be used
	 * 		if namespaces are enabled on the serializer.
	 * </ul>
	 */
	String valAttr() default "";
}
