package com.ibm.juno.core.serializer;

import com.ibm.juno.core.*;

/**
 * Top-level interface for serializers that use internal {@link BeanContext} objects.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	The methods defined on this class are simple pass-through methods to the underlying {@link BeanContext}
 * 	object used by the parser.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public interface ICoreApiSerializer extends ISerializer {

	/**
	 * Returns the bean context being used by this serializer.
	 * @return The bean context being used by this serializer.
	 */
	public BeanContext getBeanContext();

	/**
	 * Shortcut for calling <code>getBeanContext().addNotBeanClassPatterns()</code>.
	 * See {@link BeanContext#addNotBeanClassPatterns(String...)}.
	 *
	 * @param patterns The class patterns.
	 * @return This object (for method chaining).
	 * @throws LockedException If serializer is locked.
	 */
	public ICoreApiSerializer addNotBeanClassPatterns(String... patterns) throws LockedException;

	/**
	 * Shortcut for calling <code>getBeanContext().addNotBeanClasses()</code>.
	 * See {@link BeanContext#addNotBeanClasses(Class...)}.
	 *
	 * @param classes The class that are not beans.
	 * @return This object (for method chaining).
	 * @throws LockedException If serializer is locked.
	 */
	public ICoreApiSerializer addNotBeanClasses(Class<?>...classes) throws LockedException;

	/**
	 * Shortcut for calling <code>getBeanContext().addFilters()</code>.
	 * See {@link BeanContext#addFilters(Class...)}.
	 *
	 * @param classes The filter classes or classes to be filtered.
	 * @return This object (for method chaining).
	 * @throws LockedException If serializer is locked.
	 */
	public ICoreApiSerializer addFilters(Class<?>...classes) throws LockedException;

	/**
	 * Shortcut for calling <code>getBeanContext().addImplClass()</code>.
	 * See {@link BeanContext#addImplClass(Class, Class)}.
	 *
	 * @param interfaceClass The interface class.
	 * @param implClass The implementation class.
	 * @param <T> The interface class.
	 * @return This object (for method chaining).
	 * @throws LockedException If serializer is locked.
	 */
	public <T> ICoreApiSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException;
}
