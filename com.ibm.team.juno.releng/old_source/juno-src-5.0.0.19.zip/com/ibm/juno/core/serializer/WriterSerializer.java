package com.ibm.juno.core.serializer;

import java.io.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;

/**
 * Subclass of {@link Serializer} for character-based serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all character-based serializers since it implements all
 * 	of the following interfaces...
 * <ul>
 * 	<li>{@link ISerializer}
 * 	<li>{@link ICoreApiSerializer}
 * 	<li>{@link IWriterSerializer}
 * </ul>
 * <p>
 * 	...and only has 1 remaining abstract method to implement...
 * <ul>
 * 	<li>{@link #serialize(Object, Writer, ObjectMap, String)}
 * </ul>
 *
 *
 * <h6 class='topic'>@Produces annotation</h6>
 * <p>
 * 	The media types that this serializer can produce is specified through the {@link Produces @Produces} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()}
 * 		and {@link #getResponseContentType()} methods.
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class WriterSerializer extends Serializer implements IWriterSerializer {

	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	abstract public void serialize(Object o, Writer out, ObjectMap properties, String mediaType) throws IOException, SerializeException;


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // IWriterSerializer
	public String serialize(Object o, ObjectMap properties) throws SerializeException {
		try {
			StringWriter w = new StringWriter();
			serialize(o, w, properties, null);
			return w.toString();
		} catch (IOException e) { // Shouldn't happen.
			throw new RuntimeException(e);
		}
	}

	@Override // IWriterSerializer
	public String serialize(Object o) throws SerializeException {
		return serialize(o, null);
	}
}
