package com.ibm.juno.core.rdf;

/**
 * Various RDF utility methods.
 *
 * TODO:  These need to be combined with utilities defined for the XML serializers/parsers.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfUtils {

	/**
	 * Encodes any invalid XML characters to <code>_x####_</code> sequences.
	 * @param o The object being encoded.
	 * @return The encoded string.
	 */
	public static String encode(Object o) {

		if (o == null)
			return "_x0000_";

		String s = o.toString();

		if (needsXmlEncoding(o)) {
			StringBuilder sb = new StringBuilder(s.length() >> 1);
			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (c == '_' && isEscapeSequence(s,i))
					appendPaddedHexChar(sb, c);
				else if (isValidXmlCharacter(c))
					sb.append(c);
				else
					appendPaddedHexChar(sb, c);
			}
		}
		return s;
	}

	/**
	 * Translates any _x####_ sequences (introduced by {@link #encode(Object)}) back into their original
	 * characters.
	 * @param s The string being decoded.
	 * @return The decoded string.
	 */
	public static String decode(String s) {
		if (s == null) return null;
		if (s.length() == 0)
			return s;
		if (s.indexOf('_') == -1)
			return s;

		StringBuffer sb = new StringBuffer(s.length());
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '_' && isEscapeSequence(s,i)) {

				int x = Integer.parseInt(s.substring(i+2, i+6), 16);

				// If we find _x0000_, then that means a null.
				if (x == 0)
					return null;

				sb.append((char)x);
				i+=6;
			} else {
				sb.append(c);
			}
		}
		return sb.toString();
	}

	private static boolean needsXmlEncoding(Object o) {
		if (o == null)
			return false;

		String s = o.toString();

		// See if we need to convert the string.
		// Conversion is somewhat expensive, so make sure we need to do so before hand.
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '&' || c == '<' || c == '>' || c == '\n' || ! isValidXmlCharacter(c) || (c == '_' && isEscapeSequence(s,i)))
				return true;
		}
		return false;
	}

	private static boolean isValidXmlCharacter(char c) {
		return (c >= 0x20 && c <= 0xD7FF) /*|| c == 0xA || c == 0xD*/ || (c >= 0xE000 && c <= 0xFFFD) || (c >= 0x10000 && c <= 0x10FFFF);
	}

	private static final boolean isEscapeSequence(String s, int i) {
		return s.length() > i+6
			&& s.charAt(i) == '_'
			&& s.charAt(i+1) == 'x'
			&& isAlphaNum(s.charAt(i+2))
			&& isAlphaNum(s.charAt(i+3))
			&& isAlphaNum(s.charAt(i+4))
			&& isAlphaNum(s.charAt(i+5))
			&& s.charAt(i+6) == '_';
	}

	private static final boolean isAlphaNum(char c) {
		return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z');
	}

	/*
	 * Converts an integer to a hexadecimal string padded to 4 places.
	 */
	private static void appendPaddedHexChar(StringBuilder out, int num) {
		out.append("_x");
		char[] n = new char[4];
		int a = num%16;
		n[3] = (char)(a > 9 ? 'A'+a-10 : '0'+a);
		int base = 16;
		for (int i = 1; i < 4; i++) {
			a = (num/base)%16;
			base <<= 4;
			n[3-i] = (char)(a > 9 ? 'A'+a-10 : '0'+a);
		}
		for (int i = 0; i < 4; i++)
			out.append(n[i]);
		out.append('_');
	}

}
