package com.ibm.juno.core.rdf;

import com.ibm.juno.core.*;
import com.ibm.juno.core.rdfxml.*;
import com.ibm.juno.core.serializer.*;
import com.ibm.juno.core.xml.*;


/**
 * Configurable properties on the {@link RdfXmlSerializer} class.
 * <p>
 * 	Use the {@link RdfXmlSerializer#setProperty(String, Object)} method to set property values.
 * <p>
 * 	In addition to these properties, the following properties are also applicable for {@link RdfXmlSerializer}.
 * <ul>
 * 	<li>{@link XmlSerializerProperties}
 * 	<li>{@link SerializerProperties}
 * 	<li>{@link BeanContextProperties}
 * </ul>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfParserProperties implements Cloneable {

	/**
	 * The RDF language to serialize to ({@link String}, default=<js>"RDF/XML-ABBREV"</js>).
	 * <p>
	 * 	Can be any of the following:
	 * <ul>
	 * 	<li><js>"RDF/XML"</js>
	 * 	<li><js>"N-TRIPLE"</js>
	 * 	<li><js>"TURTLE"</js>
	 * 	<li><js>"N3"</js>
	 * </ul>
	 */
	public static final String RDF_LANGUAGE = "RdfParser.rdfLanguage";

	/**
	 * The XML namespace for Juno properties ({@link Namespace}, default=<js>{j:'http://www.ibm.com/juno/'}</js>).
	 */
	public static final String JUNO_NS = "RdfParser.junoNs";

	/**
	 * The default XML namespace for bean properties ({@link Namespace}, default=<js>{j:'http://www.ibm.com/junobp/'}</js>).
	 */
	public static final String JUNO_BEAN_PROP_NS = "RdfParser.junoBpNs";

	String rdfLanguage = "RDF/XML";
	Namespace junoNs = NamespaceFactory.get("j", "http://www.ibm.com/juno/");
	Namespace junoBpNs = NamespaceFactory.get("jp", "http://www.ibm.com/junobp/");


	/**
	 * Sets the specified property value.
	 * @param property The property name.
	 * @param value The property value.
	 * @return <jk>true</jk> if property name was valid and property was set.
	 */
	public boolean setProperty(String property, Object value) {
		if (property.equals(RDF_LANGUAGE))
			rdfLanguage = value.toString();
		else
			return false;
		return true;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // Cloneable
	public RdfParserProperties clone() {
		try {
			return (RdfParserProperties)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen.
		}
	}
}
