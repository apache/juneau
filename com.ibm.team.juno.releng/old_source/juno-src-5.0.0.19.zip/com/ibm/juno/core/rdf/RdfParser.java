package com.ibm.juno.core.rdf;

import static com.ibm.juno.core.rdf.Constants.*;
import static com.ibm.juno.core.rdf.RdfParserProperties.*;

import java.io.*;
import java.util.*;

import com.hp.hpl.jena.rdf.model.*;
import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;
import com.ibm.juno.core.filter.*;
import com.ibm.juno.core.parser.*;

/**
 * Serializes POJO models to RDF <b>(***PROTOTYPE***)</b>.
 *
 *
 * <h6 class='topic'>Configurable properties</h6>
 * <p>
 * 	This class has the following properties associated with it:
 * <ul>
 * 	<li>{@link RdfParserProperties}
 * </ul>
 *
 *
 * <h6 class='topic'>Behavior-specific subclasses</h6>
 * <p>
 * 	The following direct subclasses are provided for language-specific serializers:
 * <ul>
 * 	<li>{@link RdfSerializer.Xml} - RDF/XML and RDF/XML-ABBREV.
 * 	<li>{@link RdfSerializer.NTriple} - N-TRIPLE.
 * 	<li>{@link RdfSerializer.Turtle} - TURTLE.
 * 	<li>{@link RdfSerializer.N3} - N3.
 * </ul>
 *
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@Consumes(value="text/xml+rdf")
public class RdfParser extends ReaderParser {


	/** Produces RDF/XML output */
	@Consumes("text/xml+rdf")
	public static class Xml extends RdfParser {
		/** Constructor */
		public Xml() {
			setProperty(RDF_LANGUAGE, "RDF/XML");
		}
	}

	/** Produces N-TRIPLE output */
	@Consumes(value="text/n-triple")
	public static class NTriple extends RdfParser {
		/** Constructor */
		public NTriple() {
			setProperty(RDF_LANGUAGE, "N-TRIPLE");
		}
	}

	/** Produces TURTLE output */
	@Consumes(value="text/turtle")
	public static class Turtle extends RdfParser {
		/** Constructor */
		public Turtle() {
			setProperty(RDF_LANGUAGE, "TURTLE");
		}
	}

	/** Produces N3 output */
	@Consumes(value="text/n3")
	public static class N3 extends RdfParser {
		/** Constructor */
		public N3() {
			setProperty(RDF_LANGUAGE, "N3");
		}
	}


	/** Jena parser properties currently set on this serializer. */
	protected transient RdfParserProperties rpp = new RdfParserProperties();


	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public <T> T parse(Reader in, ClassType<T> type, ObjectMap properties, String mediaType) throws ParseException, IOException {
		RdfParserContext ctx = new RdfParserContext(beanContext, null, rpp, properties);
		Model model = ctx.model;
		RDFReader r = ctx.getRDFReader();
		r.read(model, in, "http://unknown/");
		List<Resource> roots = getRoots(model, ctx);
		if (roots.isEmpty())
			throw new ParseException("No root nodes found in model.  Cannot traverse.");
		if (roots.size() > 1)
			throw new ParseException("Too many root nodes found in model:  %s", roots.size());
		Resource r2 = roots.get(0);

		Object o = null;
		IPojoFilter filter = type.getPojoFilter();

		ClassType<?> ft = type.getFilteredClassType();
		if (ft.isBean() && ft.canCreateNewInstance()) {
			BeanMap<?> m = beanContext.newBeanMap(ft.getInnerClass());
			o = parseIntoBeanMap(r2, m, ctx).getBean();
		} else {
			throw new ParseException("Invalid object type '%s' passed to parser.  Parser can only parse beans, maps, collections, and arrays, and only if they have no-arg constructors.", ft);
		}

		if (filter != null && o != null)
			o = filter.unfilter(o, type, beanContext);

		return (T)o;
	}

	/*
	 * Finds the roots in the model using either the "root" property to identify it,
	 * 	or by resorting to scanning the model for all nodes with no incoming predicates.
	 */
	private List<Resource> getRoots(Model m, RdfParserContext ctx) {
		List<Resource> l = new LinkedList<Resource>();

		// First try to find the root using the "http://www.ibm.com/juno/root" property.
		Property root = m.createProperty(ctx.junoNs.getUri(), JUNO_NS_ROOT);
		for (ResIterator i  = m.listResourcesWithProperty(root); i.hasNext();)
			l.add(i.next());

		if (! l.isEmpty())
			return l;

		// Otherwise, we need to find all resources that aren't objects.
		Set<RDFNode> objects = new HashSet<RDFNode>();
		for (NodeIterator i = m.listObjects(); i.hasNext();) {
			RDFNode n = i.next();
			if (n.isResource())
				objects.add(n);
		}
		for (ResIterator i = m.listSubjects(); i.hasNext();) {
			Resource r = i.next();
			if (! objects.contains(r))
				l.add(r);
		}
		return l;
	}

	private BeanMap<?> parseIntoBeanMap(Resource r2, BeanMap<?> m, RdfParserContext ctx) throws ParseException {
		for (StmtIterator i = r2.listProperties(); i.hasNext();) {
			Statement st = i.next();
			Property p = st.getPredicate();
			String key = p.getLocalName();
			BeanPropertyMeta<?> pMeta = m.getPropertyMeta(key);
			if (pMeta != null) {
				RDFNode o = st.getObject();
				Object val = parseAnything(pMeta.getClassType(), o, pMeta, ctx);
				m.put(key, val);
			} else if (! key.equals("root")) {
				System.err.println("Didn't find property ["+key+"]");
			}

		}
		return m;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private <T> T parseAnything(ClassType<T> nt, RDFNode n, BeanPropertyMeta<?> p, RdfParserContext ctx) throws ParseException {

		if (nt == null)
			nt = (ClassType<T>) ClassType.OBJECT;
		IPojoFilter<T,Object> filter = (p == null ? null : p.getFilter());
		if (filter == null)
			filter = (PojoFilter<T,Object>)nt.getPojoFilter();
		ClassType<?> ft = (p == null ? nt.getFilteredClassType() : p.getFilteredClassType());

		try {

			Object o = null;
			if (n.isResource() && n.asResource().getURI() != null && n.asResource().getURI().equals(NIL)) {
				// Do nothing.  Leave o == null.
			} else if (ft.isObject()) {
				o = n.asLiteral().getValue();
			} else if (ft.isBoolean()) {
				o = n.asLiteral().getBoolean();
			} else if (ft.isCharSequence()) {
				o = RdfUtils.decode(n.asLiteral().getString());
			} else if (ft.isChar()) {
				o = RdfUtils.decode(n.asLiteral().getString()).charAt(0);
			} else if (ft.isEnum()) {
				o = Enum.valueOf((Class<Enum>)ft.getInnerClass(), RdfUtils.decode(n.asLiteral().getString()));
			} else if (ft.isMap()) {
				Resource r = n.asResource();
				Map m = (ft.canCreateNewInstance() ? (Map)ft.newInstance() : new ObjectMap());
				o = parseIntoMap(r, m, nt.getKeyType(), nt.getValueType(), ctx);
			} else if (ft.isCollection()) {
				Seq seq = n.as(Seq.class);
				Collection l = (ft.canCreateNewInstance() ? (Collection<?>)ft.newInstance() : new ObjectList());
				o = parseIntoCollection(seq, l, ft.getElementType());
			} else if (ft.isNumber()) {
				o = parseNumber(n.asLiteral().getString(), (Class<? extends Number>)ft.getInnerClass());
			} else if (ft.isBean() && ft.canCreateNewInstance()) {
				Resource r = n.asResource();
				BeanMap<?> bm = beanContext.newBeanMap(ft.getInnerClass());
				o = parseIntoBeanMap(r, bm, ctx).getBean();
			} else if (ft.isArray()) {
				Seq seq = n.as(Seq.class);
				ArrayList<?> l = (ArrayList<?>)parseIntoCollection(seq, new ArrayList(), ft.getElementType());
				o = beanContext.toArray(ft, l);
			} else if (ft.canCreateNewInstanceFromString()) {
				o = ft.newInstance(RdfUtils.decode(n.asLiteral().getString()));
			} else {
				throw new ParseException("Unrecognized syntax for class type '%s'", ft);
			}

			if (filter != null && o != null)
				o = filter.unfilter(o, nt, beanContext);

			return (T)o;

		} catch (Exception e) {
			if (p == null)
				throw new ParseException("Error occurred trying to parse into class '%s'", ft).setCause(e);
			throw new ParseException("Error occurred trying to parse value for bean property '%s' on class '%s'",
				p.getName(), p.getBeanMeta().getClassType()
			).setCause(e);
		}
	}


	private <K,V> Map<K,V> parseIntoMap(Resource r, Map<K,V> m, ClassType<K> keyType, ClassType<V> valueType, RdfParserContext ctx) throws ParseException {
		for (StmtIterator i = r.listProperties(); i.hasNext();) {
			Statement st = i.next();
			Property p = st.getPredicate();
			String key = p.getLocalName();
			if (! (key.equals("root") && p.getURI().equals(ctx.junoNs.getUri()))) {
				RDFNode o = st.getObject();
				K key2 = convertAttrToType(key, keyType);
				V value = parseAnything(valueType, o, null, ctx);
				m.put(key2, value);
			}

		}
		// TODO Auto-generated method stub
		return m;
	}


	private <E> Collection<E> parseIntoCollection(Seq seq, Collection<E> l, ClassType<E> et) throws ParseException {
		for (int i = 1; i <= seq.size(); i++) {
			E e = parseAnything(et, seq.getObject(i), null, null);
			l.add(e);
		}
		return l;
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // ISerializer, CoreApi
	public RdfParser setProperty(String property, Object value) throws LockedException {
		checkLock();
		if (rpp.setProperty(property, value))
			return this;
		super.setProperty(property, value);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfParser addNotBeanClassPatterns(String... patterns) throws LockedException {
		super.addNotBeanClassPatterns(patterns);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfParser addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public RdfParser addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // ICoreApiSerializer, CoreApi
	public <T> RdfParser addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // ISerializer, Lockable
	public RdfParser lock() {
		super.lock();
		return this;
	}

	@Override // ISerializer, Lockable
	public RdfParser clone() {
		try {
			RdfParser c = (RdfParser)super.clone();
			c.rpp = rpp.clone();
			return c;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e); // Shouldn't happen
		}
	}
}
