package com.ibm.juno.core.rdf;

import static com.ibm.juno.core.rdf.Constants.*;
import static com.ibm.juno.core.rdf.RdfSerializerProperties.*;

import com.hp.hpl.jena.rdf.model.*;
import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.xml.*;

/**
 * Context object that lives for the duration of a single serialization of {@link RdfSerializer}.
 * <p>
 * 	See {@link ParserContext} for details.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RdfParserContext extends ParserContext {

	final String rdfLanguage;
	final Namespace junoNs, junoBpNs;
	final Property pType, pRoot, pItems;
	final Model model;

	/**
	 * Constructor.
	 * @param beanContext The bean context being used by the parser.
	 * @param pp Default general parser properties.
	 * @param rpp Default Jena parser properties.
	 * @param op Override properties.
	 */
	protected RdfParserContext(BeanContext beanContext, ParserProperties pp, RdfParserProperties rpp, ObjectMap op) {
		super(pp, op);
		if (op == null || op.isEmpty()) {
			this.rdfLanguage = rpp.rdfLanguage;
			this.junoNs = rpp.junoNs;
			this.junoBpNs = rpp.junoBpNs;
		} else {
			this.rdfLanguage = op.getString(RDF_LANGUAGE, rpp.rdfLanguage);
			this.junoNs = (op.containsKey(JUNO_NS) ? NamespaceFactory.parseNamespace(op.get(JUNO_NS)) : rpp.junoNs);
			this.junoBpNs = (op.containsKey(JUNO_BEAN_PROP_NS) ? NamespaceFactory.parseNamespace(op.get(JUNO_BEAN_PROP_NS)) : rpp.junoBpNs);
		}
		this.model = ModelFactory.createDefaultModel();
		addModelPrefix(junoNs);
		addModelPrefix(junoBpNs);
		this.pItems = model.createProperty(junoNs.getUri(), JUNO_NS_ITEMS);
		this.pRoot = model.createProperty(junoNs.getUri(), JUNO_NS_ROOT);
		this.pType = model.createProperty(junoNs.getUri(), JUNO_NS_TYPE);
	}

	/**
	 * @return The RDF reader class being used by the parser.
	 */
	protected RDFReader getRDFReader() {
		return model.getReader(rdfLanguage);
	}

	/**
	 * Adds the specified namespace as a model prefix.
	 * @param ns The XML namespace.
	 */
	public void addModelPrefix(Namespace ns) {
		model.setNsPrefix(ns.getName(), ns.getUri());
	}
}
