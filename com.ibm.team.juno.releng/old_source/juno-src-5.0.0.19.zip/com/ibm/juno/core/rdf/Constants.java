package com.ibm.juno.core.rdf;

import com.ibm.juno.core.serializer.*;


/**
 * Predefined Juno properties used by the {@link RdfSerializer} and {@link RdfParser} classes.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 *
 */
public class Constants {

	//--------------------------------------------------------------------------------
	// Built-in Juno properties.
	//--------------------------------------------------------------------------------

	/**
	 * RDF property identifier <js>"items"</js>.
	 * <p>
	 * For resources that are collections, this property identifies the RDF Sequence
	 * 	container for the items in the collection.
	 */
	public static final String JUNO_NS_ITEMS = "items";

	/**
	 * RDF property identifier <js>"root"</js>.
	 * <p>
	 * Property added to root nodes to help identify them as root elements during parsing.
	 * <p>
	 * Added if {@link RdfSerializerProperties#ADD_ROOT_PROPERTY} setting is enabled.
	 */
	public static final String JUNO_NS_ROOT = "root";

	/**
	 * RDF property identifier <js>"type"</js>.
	 * <p>
	 * Property added to bean resources to identify the class type.
	 * <p>
	 * Added if {@link SerializerProperties#ADD_CLASS_ATTRS} setting is enabled.
	 */
	public static final String JUNO_NS_TYPE = "type";

	/**
	 * RDF resource that identifies a <jk>null</jk> value.
	 */
	public static final String NIL = "http://www.w3.org/1999/02/22-rdf-syntax-ns#nil";
}
