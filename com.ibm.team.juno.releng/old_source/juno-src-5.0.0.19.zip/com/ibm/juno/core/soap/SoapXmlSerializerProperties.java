package com.ibm.juno.core.soap;


/**
 * Properties associated with the {@link SoapXmlSerializer} class.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SoapXmlSerializerProperties {

	/**
	 * The <code>SOAPAction</code> HTTP header value to set on responses.
	 * <p>
	 * Default is <js>"http://www.w3.org/2003/05/soap-envelope"</js>.
	 */
	public static final String SOAPACTION = "SoapXmlSerializer.SOAPAction";
}
