package com.ibm.juno.server;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;
import com.ibm.juno.core.serializer.*;

/**
 * Subclass of {@link RestServlet} with default implementations for
 * 	{@link RestServlet#getBeanContext()}, {@link RestServlet#getSerializerGroup()}, and
 * 	{@link RestServlet#getParserGroup()} that simply returns the parent objects.
 * <p>
 *		Typically used for resources where all the configuration for the bean context, serializer group,
 *			and parser group will be done on the parent resource.
 * <p>
 *		Must only be used on resources defined as children of other resources.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class RestServletChild extends RestServlet {

	/**
	 * Returns the parent bean context.
	 */
	@Override
	public BeanContext getBeanContext() {
		return getParent().getBeanContext();
	}

	/**
	 * Returns the parent serializer group.
	 */
	@Override
	public SerializerGroup getSerializerGroup() throws Exception {
		return getParent().getSerializerGroup();
	}

	/**
	 * Returns the parent parser group.
	 */
	@Override
	public ParserGroup getParserGroup() throws Exception {
		return getParent().getParserGroup();
	}
}
