/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.server.jena;

import com.ibm.juno.core.html.*;
import com.ibm.juno.core.jena.*;
import com.ibm.juno.core.jso.*;
import com.ibm.juno.core.json.*;
import com.ibm.juno.core.soap.*;
import com.ibm.juno.core.urlencoding.*;
import com.ibm.juno.core.xml.*;
import com.ibm.juno.server.*;
import com.ibm.juno.server.annotation.*;

/**
 * Subclass of {@link RestServlet} with default sets of serializers and parsers that include RDF support.
 * <p>
 * 	This class uses the {@link RdfSerializer} class which requires the Jena libraries to be available
 * 		on the classpath.
 * <p>
 *
 * Adds the following serializers to the serializer group:
 * <ul>
 * 	<li>{@link JsonSerializer}
 * 	<li>{@link JsonSchemaSerializer}
 * 	<li>{@link XmlDocSerializer}
 * 	<li>{@link com.ibm.juno.core.xml.XmlDocSerializer.Simple}
 * 	<li>{@link XmlSchemaDocSerializer}
 * 	<li>{@link HtmlDocSerializer}
 * 	<li>{@link HtmlStrippedDocSerializer}
 * 	<li>{@link UrlEncodingSerializer}
 * 	<li>{@link SoapXmlSerializer}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.Xml}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.XmlAbbrev}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.N3}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.NTriple}
 * 	<li>{@link com.ibm.juno.core.jena.RdfSerializer.Turtle}
 * 	<li>{@link JavaSerializedObjectSerializer}
 * </ul>
 * <p>
 * Adds the following parsers to the parser group:
 * <ul>
 * 	<li>{@link JsonParser}
 * 	<li>{@link XmlParser}
 * 	<li>{@link HtmlParser}
 * 	<li>{@link UrlEncodingParser}
 * 	<li>{@link com.ibm.juno.core.jena.RdfParser.Xml}
 * 	<li>{@link com.ibm.juno.core.jena.RdfParser.N3}
 * 	<li>{@link com.ibm.juno.core.jena.RdfParser.NTriple}
 * 	<li>{@link com.ibm.juno.core.jena.RdfParser.Turtle}
 * </ul>
 * <p>
 * Note that the list of serializers and parsers can be appended to using the {@link RestResource#serializers()} and {@link RestResource#parsers()} annotations.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@RestResource(
	serializers={
		HtmlDocSerializer.class, // HTML must be listed first because Internet Explore does not include text/html in their Accept header.
		HtmlStrippedDocSerializer.class,
		JsonSerializer.class,
		JsonSerializer.Simple.class,
		JsonSchemaSerializer.class,
		XmlDocSerializer.class,
		XmlDocSerializer.Simple.class,
		XmlSchemaDocSerializer.class,
		UrlEncodingSerializer.class,
		UrlEncodingSerializer.Simple.class,
		SoapXmlSerializer.class,
		RdfSerializer.Xml.class,
		RdfSerializer.XmlAbbrev.class,
		RdfSerializer.N3.class,
		RdfSerializer.NTriple.class,
		RdfSerializer.Turtle.class,
		JavaSerializedObjectSerializer.class
	},
	parsers={
		JsonParser.class,
		XmlParser.class,
		HtmlParser.class,
		UrlEncodingParser.class,
		JavaSerializedObjectParser.class,
		RdfParser.Xml.class,
		RdfParser.N3.class,
		RdfParser.NTriple.class,
		RdfParser.Turtle.class
	}
)
public class RestServletJenaDefault extends RestServlet {}