/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.urlencoding;

import static com.ibm.juno.core.urlencoding.UrlEncodingParserProperties.*;

import java.lang.reflect.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;

/**
 * Context object that lives for the duration of a single parsing of {@link UrlEncodingParser}.
 * <p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class UrlEncodingParserContext extends ParserContext {

	boolean decodeChars;

	/**
	 * Create a new parser context with the specified options.
	 *
	 * @param beanContext The bean context being used.
	 * @param pp The default parser properties.
	 * @param op The override properties.
	 * @param javaMethod Java method that invoked this serializer.
	 * 	When using the REST API, this is the Java method invoked by the REST call.
	 * 	Can be used to access annotations defined on the method or class.
	 * @param mediaType The media type being parsed.
	 * @param charset The charset being parsed.
	 */
	public UrlEncodingParserContext(BeanContext beanContext, ParserProperties pp, UrlEncodingParserProperties upp, ObjectMap op, Method javaMethod, String mediaType, String charset) {
		super(beanContext, pp, op, javaMethod, mediaType, charset);
		if (op == null || op.isEmpty()) {
			decodeChars = upp.decodeChars;
		} else {
			decodeChars = op.getBoolean(DECODE_CHARS, upp.decodeChars);
		}
	}

	/**
	 * Returns the {@link UrlEncodingParserProperties#DECODE_CHARS} setting value in this context.
	 * @return The {@link UrlEncodingParserProperties#DECODE_CHARS} setting value in this context.
	 */
	public final boolean isDecodeChars() {
		return decodeChars;
	}
}
