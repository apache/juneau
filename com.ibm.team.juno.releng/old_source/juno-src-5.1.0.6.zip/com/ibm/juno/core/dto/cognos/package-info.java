// XML namespaces used in this package
@XmlSchema(prefix="cognos", namespace="http://developer.cognos.com/schemas/xmldata/1/")
package com.ibm.juno.core.dto.cognos;
import com.ibm.juno.core.xml.annotation.*;

