package com.ibm.juno.core.html.dto;

import static com.ibm.juno.core.xml.annotation.XmlFormat.*;

import com.ibm.juno.core.xml.annotation.*;

/**
 * Represents an HTML IMG element.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
@SuppressWarnings("javadoc")
@Xml(name="img")
public class Img extends HtmlElement {

	@Xml(format=ATTR)
	public String src;

	public Img(String src) {
		this.src = src;
	}
}
