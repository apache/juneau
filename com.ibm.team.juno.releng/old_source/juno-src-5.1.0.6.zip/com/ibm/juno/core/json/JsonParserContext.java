/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.json;

import static com.ibm.juno.core.json.JsonParserProperties.*;

import java.lang.reflect.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.parser.*;

/**
 * Context object that lives for the duration of a single parsing of {@link JsonParser}.
 * <p>
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class JsonParserContext extends ParserContext {

	private final boolean strictMode;

	/**
	 * Create a new parser context with the specified options.
	 *
	 * @param beanContext The bean context being used.
	 * @param jpp The JSON parser properties.
	 * @param pp The default parser properties.
	 * @param op The override properties.
	 * @param javaMethod Java method that invoked this serializer.
	 * 	When using the REST API, this is the Java method invoked by the REST call.
	 * 	Can be used to access annotations defined on the method or class.
	 * @param mediaType The media type being parsed.
	 * @param charset The charset being parsed.
	 */
	public JsonParserContext(BeanContext beanContext, JsonParserProperties jpp, ParserProperties pp, ObjectMap op, Method javaMethod, String mediaType, String charset) {
		super(beanContext, pp, op, javaMethod, mediaType, charset);
		if (op == null || op.isEmpty()) {
			strictMode = jpp.isStrictMode();
		} else {
			strictMode = op.getBoolean(STRICT_MODE, jpp.isStrictMode());
		}
	}

	/**
	 * Returns the {@link JsonParserProperties#STRICT_MODE} setting in this context.
	 */
	public boolean isStrictMode() {
		return strictMode;
	}
}
