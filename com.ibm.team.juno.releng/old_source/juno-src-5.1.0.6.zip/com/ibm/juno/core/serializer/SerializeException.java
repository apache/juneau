/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.serializer;

import java.text.*;

/**
 * General exception thrown whenever an error occurs during serialization.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class SerializeException extends Exception {

	/**
	 * @param msg The error message.
	 * @param args Optional printf arguments to replace in the error message.
	 */
	public SerializeException(String msg, Object... args) {
		super(args.length == 0 ? msg : MessageFormat.format(msg, args));
	}

	/**
	 * @param cause The cause.
	 */
	public SerializeException(Throwable cause) {
		super(cause == null ? null : cause.getLocalizedMessage());
		initCause(cause);
	}

	/**
	 * Sets the inner cause for this exception.
	 * @param cause The inner cause.
	 * @return This object (for method chaining).
	 */
	@Override
	public synchronized SerializeException initCause(Throwable cause) {
		super.initCause(cause);
		return this;
	}
}
