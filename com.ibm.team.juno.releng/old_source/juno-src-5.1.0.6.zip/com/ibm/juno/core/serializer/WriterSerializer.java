/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.serializer;

import java.io.*;
import java.lang.reflect.*;

import com.ibm.juno.core.*;
import com.ibm.juno.core.annotation.*;

/**
 * Subclass of {@link Serializer} for character-based serializers.
 *
 *
 * <h6 class='topic'>Description</h6>
 * <p>
 * 	This class is typically the parent class of all character-based serializers.
 * 	It has 2 abstract methods to implement...
 * <ul>
 * 	<li>{@link #createContext(ObjectMap, Method, String, String)}
 * 	<li>{@link #serialize(Object, Writer, SerializerContext)}
 * </ul>
 *
 *
 * <h6 class='topic'>@Produces annotation</h6>
 * <p>
 * 	The media types that this serializer can produce is specified through the {@link Produces @Produces} annotation.
 * <p>
 * 	However, the media types can also be specified programmatically by overriding the {@link #getMediaTypes()}
 * 		and {@link #getResponseContentType()} methods.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public abstract class WriterSerializer extends Serializer<Writer> {


	//--------------------------------------------------------------------------------
	// Abstract methods
	//--------------------------------------------------------------------------------

	@Override
	public abstract void serialize(Object o, Writer out, SerializerContext ctx) throws IOException, SerializeException;


	//--------------------------------------------------------------------------------
	// Other methods
	//--------------------------------------------------------------------------------

	/**
	 * Same as {@link WriterSerializer#serialize(Object, Writer, SerializerContext)} except serializes to a <code>String</code>.
	 *
	 * @param o The object to serialize.
	 * @param ctx The serialize context.  Can be <jk>null</jk>.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o, SerializerContext ctx) throws SerializeException {
		try {
			StringWriter w = new StringWriter();
			serializeSafe(o, w, ctx);
			return w.toString();
		} catch (IOException e) { // Shouldn't happen.
			throw new RuntimeException(e);
		}
	}

	/**
	 * Same as {@link #serialize(Object, SerializerContext)} with <jk>null</jk> context.
	 *
	 * @param o The object to serialize.
	 * @return The output serialized to a string.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	public String serialize(Object o) throws SerializeException {
		return serialize(o, (SerializerContext)null);
	}

	/**
	 * Convenience method for serializing directly to a writer.
	 *
	 * @param o The object to serialize.
	 * @param w The writer to send the output to.
	 * @throws IOException If a problem occurred trying to send output to the writer.
	 * @throws SerializeException If a problem occurred trying to convert the output.
	 */
	@Override
	public void serialize(Object o, Writer w) throws SerializeException, IOException {
		serializeSafe(o, w, null);
	}


	//--------------------------------------------------------------------------------
	// Overridden methods
	//--------------------------------------------------------------------------------

	@Override // CoreApi
	public WriterSerializer addNotBeanClasses(Class<?>...classes) throws LockedException {
		super.addNotBeanClasses(classes);
		return this;
	}

	@Override // CoreApi
	public WriterSerializer addFilters(Class<?>...classes) throws LockedException {
		super.addFilters(classes);
		return this;
	}

	@Override // CoreApi
	public <T> WriterSerializer addImplClass(Class<T> interfaceClass, Class<? extends T> implClass) throws LockedException {
		super.addImplClass(interfaceClass, implClass);
		return this;
	}

	@Override // Lockable
	public WriterSerializer lock() {
		super.lock();
		return this;
	}

	@Override // CoreApi
	public WriterSerializer clone() throws CloneNotSupportedException {
		WriterSerializer c = (WriterSerializer)super.clone();
		return c;
	}
}
