/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 *  The source code for this program is not published or otherwise
 *  divested of its trade secrets, irrespective of what has been
 *  deposited with the U.S. Copyright Office.
 *******************************************************************************/
package com.ibm.juno.core.utils;

import java.io.*;

/**
 * Output stream that can send output to multiple output streams.
 *
 * @author James Bognar (jbognar@us.ibm.com)
 */
public class TeeOutputStream extends OutputStream {

	private OutputStream[] outputStreams;

	public TeeOutputStream(OutputStream...outputStreams) {
		this.outputStreams = outputStreams;
	}

	@Override
	public void write(int b) throws IOException {
		for (OutputStream os : outputStreams)
			os.write(b);
	}
}
